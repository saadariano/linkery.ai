
(function(){'use strict';
const t=key=>WebMarkLocale.text(key);
function localize(el){el.lang=WebMarkLocale.language();el.dir=el.lang==='ar'?'rtl':'ltr';el.querySelectorAll('[data-cloud-text]').forEach(n=>n.textContent=t(n.dataset.cloudText));el.setAttribute('aria-label',t('account'));}
function modal(){let el=document.getElementById('wm-cloud-dialog');if(el)return el;el=document.createElement('dialog');el.id='wm-cloud-dialog';el.setAttribute('aria-label','Google account and bookmark sync');el.style.cssText='width:min(440px,calc(100% - 28px));border:1px solid #d6e2da;border-radius:20px;padding:26px;color:#142b1e;background:#fff;font:14px/1.7 system-ui,sans-serif;max-height:90dvh;overflow:auto';el.innerHTML='<button type="button" data-cloud="close" aria-label="Close" style="float:right;background:transparent;border:0;font-size:26px;cursor:pointer">×</button><p style="color:#16834b;font-size:12px;font-weight:700" data-cloud-text="account">WEBMARK ACCOUNT</p><h2 style="font-size:23px;margin:8px 0" >Sync center</h2><p >Sync bookmarks, notes, and encrypted passwords with your Google account.</p><p style="font-size:12px;color:#63776b" data-cloud-text="privacy">Google sign-in uses your account identity only. WebMark does not read your Gmail messages.</p><div id="wm-cloud-account" style="margin:18px 0;padding:13px;background:#f0f7f2;border-radius:12px;overflow-wrap:anywhere"></div><p id="wm-cloud-state" role="status" style="font-size:12px;color:#63776b;min-height:36px"></p><button type="button" data-cloud="login" style="width:100%;padding:13px;border:1px solid #d6e2da;border-radius:11px;background:#fff;color:#182c21;font-size:14px;cursor:pointer">G &nbsp; Continue with Google</button><button type="button" data-cloud="sync" style="width:100%;margin-top:9px;padding:12px;border:0;border-radius:11px;background:#198a50;color:#fff;cursor:pointer" >Sync all now</button><button type="button" data-cloud="logout" style="width:100%;padding:12px;border:0;background:transparent;color:#65766b;cursor:pointer" data-cloud-text="logout">Sign out</button><p style="font-size:11px;color:#7c8c82;margin:12px 0 0" >Offline edits stay on this device and sync after you reconnect. Sync manually at any time. Daily sync runs while WebMark is active or catches up when you reopen it.</p>';
el.addEventListener('click',e=>{const a=e.target.closest('[data-cloud]')?.dataset.cloud;if(a==='close')el.close();if(a==='login')WebMarkCloud.signIn().catch(err=>{document.getElementById('wm-cloud-state').textContent=err.message});if(a==='sync'){if(window.WebMarkSyncCenter)window.WebMarkSyncCenter.run();else WebMarkCloud.sync();}if(a==='logout')WebMarkCloud.signOut()});document.body.append(el);WebMarkCloud.subscribe(update);return el}
function update(info){const el=document.getElementById('wm-cloud-dialog');if(!el)return;localize(el);document.getElementById('wm-cloud-account').textContent=info.user?info.user.email:t('local');document.getElementById('wm-cloud-state').textContent=WebMarkLocale.status(info.status);el.querySelector('[data-cloud="login"]').hidden=!!info.user;el.querySelector('[data-cloud="sync"]').hidden=!info.user;el.querySelector('[data-cloud="logout"]').hidden=!info.user;el.querySelector('[data-cloud="sync"]').disabled=info.busy||info.quotaUntil>Date.now();el.querySelector('[data-cloud="login"]').textContent=info.configured?t('login'):t('setup')}
function avatar(button,user,label){
 const initial=(user?.name||user?.email||'G').charAt(0).toUpperCase();
 button.title=user?.name||user?.email||label;
 button.setAttribute('aria-label',user?.email?t('account')+' · '+user.email:label);
 const current=button.querySelector('img');
 if(user?.photoURL&&current?.getAttribute('src')===user.photoURL)return;
 button.classList.remove('has-photo');
 button.textContent=initial;
 if(!user?.photoURL)return;
 const image=document.createElement('img');
 image.alt='';
 image.referrerPolicy='no-referrer';
 image.addEventListener('load',()=>{
  if(image.parentElement!==button)return;
  button.replaceChildren(image);
  button.classList.add('has-photo');
 },{once:true});
 image.addEventListener('error',()=>{
  if(image.parentElement!==button)return;
  button.classList.remove('has-photo');
  button.textContent=initial;
 },{once:true});
 button.append(image);
 image.src=user.photoURL;
}
function chooseImport(email){return new Promise(resolve=>{
 const d=document.createElement('dialog');d.style.cssText='width:min(420px,calc(100% - 28px));padding:24px;border:1px solid #cfe0d4;border-radius:18px;background:#fff;color:#172f21;font:14px/1.6 system-ui';
 const title=document.createElement('h2');title.textContent=t('connect');const text=document.createElement('p');text.textContent=t('choice').replace('{email}',email);d.append(title,text);
 let settled=false;function done(value){if(settled)return;settled=true;d.close();d.remove();resolve(value)}
 for(const [label,value] of [[t('merge'),true],[t('load'),false],[t('cancel'),null]]){const b=document.createElement('button');b.type='button';b.textContent=label;b.style.cssText='display:block;width:100%;padding:13px;margin-top:10px;border:1px solid #cfe0d4;border-radius:10px;background:#f2f8f4;color:#172f21;cursor:pointer';b.onclick=()=>done(value);d.append(b)}
 d.addEventListener('cancel',e=>{e.preventDefault();done(null)});d.lang=WebMarkLocale.language();d.dir=d.lang==='ar'?'rtl':'ltr';document.body.append(d);d.showModal();
})}
window.WebMarkCloudUI={avatar,chooseImport,open(){const el=modal();update(WebMarkCloud.info());window.WebMarkSyncCenter?.mount(el);if(!el.open)el.showModal()}};
new MutationObserver(()=>{const el=document.getElementById('wm-cloud-dialog');if(el)update(WebMarkCloud.info())}).observe(document.documentElement,{attributes:true,attributeFilter:['lang']});
})();

