/* Manage bookmark actions immediately; repaint the current view after app resume. */
(()=>{
    let scheduled=false;
    window.WebMarkRefreshBookmarks=async()=>{
        if(document.hidden||scheduled)return;
        scheduled=true;
        try{
            if(typeof wmStorage!=='undefined')await wmStorage.ready;
            requestAnimationFrame(()=>{
                scheduled=false;
                if(typeof S==='undefined'||!Array.isArray(S.links)||!Array.isArray(S.folders))return;
                const reserved=['all','fav','vip','archive','__recent__'];
                if(!reserved.includes(S.activeTab)){
                    const folder=S.folders.find(folder=>String(folder.id)===String(S.activeTab));
                    S.activeTab=folder?folder.id:'all';
                }
                renderTabs();renderLinks();
            });
        }catch{scheduled=false;}
    };
    document.addEventListener('visibilitychange',()=>{if(!document.hidden)WebMarkRefreshBookmarks();});
    window.addEventListener('pageshow',WebMarkRefreshBookmarks);
    window.addEventListener('focus',WebMarkRefreshBookmarks);
    window.toggleGlobalEdit=()=>{
        S._tabEditMode=false;S._bmEditMode=!S._bmEditMode;
        document.getElementById('linkListWrap')?.classList.toggle('link-list-edit-mode',S._bmEditMode);
        const banner=document.getElementById('editModeBanner');if(banner)banner.style.display=S._bmEditMode?'flex':'none';
        renderTabs();renderLinks();
    };
    window.toggleBookmarkEditMode=window.toggleGlobalEdit;
    function remove(id,close){
        requireDeletePassword(()=>{
            const link=S.links.find(item=>String(item.id)===String(id));if(!link)return;
            (S.trash??=[]).unshift({...link,deletedAt:Date.now()});
            S.links=S.links.filter(item=>item!==link);
            document.getElementById('lc-'+id)?.remove();
            save();renderTabs();renderLinks();
            if(close)closeModal('editDetailModal');
            showToast('Moved to trash — recover it in Settings','#ef4444');
        });
    }
    window.deleteLink=id=>remove(id,false);
    window.deleteCurrent=()=>remove(S.editingLink,true);
})();
