const api = globalThis.browser || globalThis.chrome;

async function send(message) {
 const result = await api.runtime.sendMessage(message);
 if (!result?.ok) throw new Error(result?.error || 'Could not open WebMark');
 window.close();
}

function showError(error) {
 document.getElementById('state').textContent = error.message;
}

document.getElementById('open').onclick = () => send({action: 'open-library'}).catch(showError);
document.getElementById('save').onclick = async () => {
 try {
  const [tab] = await api.tabs.query({active: true, currentWindow: true});
  if (!/^https?:\/\//i.test(tab?.url || '')) {
   throw new Error('Open a website first. Browser settings pages cannot be saved.');
  }
  await send({action: 'save-site', url: tab.url, title: tab.title});
 } catch (error) {
  showError(error);
 }
};
