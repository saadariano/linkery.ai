/* Consume captures from the toolbar and browser context menu in the website dashboard. */
(() => {
 const storage = (globalThis.browser || globalThis.chrome).storage;
 let queue = Promise.resolve();

 async function capture() {
  await wmStartup;
  const {webmarkInbox: inbox = []} = await storage.local.get('webmarkInbox');
  if (!inbox.length) return;
  const folders = new Map(S.folders.map(folder=>[folder.id,folder]));
  const existing = new Set(S.links.filter(bookmark=>!bookmarkBrowser(bookmark,folders)).map(bookmark => wmURL(bookmark.url)));
  let count = 0;
  for (const entry of inbox) {
   const url = wmURL(entry.url);
   if (!url || existing.has(url)) continue;
   const title = entry.title || new URL(url).hostname;
   S.links.push({id: wmId(), url, title, desc: '', tags: [], fId: null, imported: false,
    siteIcon: _buildSiteIconForLink(url, title)});
   existing.add(url);
   count++;
  }
  if (count) {
   save();
   await wmStorage.flush();
   init();
  }
  await storage.local.remove('webmarkInbox');
  if (count) showToast(T('bookmarkSaved') === 'bookmarkSaved' ? 'Bookmark saved' : T('bookmarkSaved'));
 }

 function drain() {
  queue = queue.then(() => navigator.locks.request('webmark-capture', capture))
   .catch(error => showToast(error.message, '#ef4444'));
 }

 document.addEventListener('DOMContentLoaded', drain);
 window.addEventListener('focus', drain);
 storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && changes.webmarkInbox?.newValue?.length && document.hasFocus()) drain();
 });
})();
