
/* Adapter for the WebMark web interface. Uses the same sync records as the extension. */
(function(){'use strict';
let remote=false;const localSave=window.save;window.save=function(){localSave();if(!remote)try{WebMarkCloud.changed()}catch(error){showToast(error.message)}};
async function attach(){
 await wmStartup;
 document.querySelectorAll('.header-right,.desktop-nav-right').forEach(el=>{const button=document.createElement('button');button.className='hbtn wm-google-account';button.type='button';button.title='Google account & sync';button.setAttribute('aria-label','Google account and bookmark sync');button.textContent='G';button.style.fontWeight='800';button.onclick=()=>WebMarkCloudUI.open();el.prepend(button)});
 // The existing account/sync action now opens the configured Google option.
 window.openSyncModal=()=>WebMarkCloudUI.open();
 const settingsTargets=[document.getElementById('settingsPageBody'),document.querySelector('#settingsModal .mc')];
 for(const target of settingsTargets){if(!target)continue;const section=document.createElement('section');section.style.cssText='padding:14px;border:1px solid var(--border);border-radius:14px;margin:12px 0';const button=document.createElement('button');button.type='button';button.className='erow wm-setting-action';button.textContent='Google account & sync';button.onclick=()=>WebMarkCloudUI.open();const state=document.createElement('p');state.className='wm-settings-cloud-state';state.style.cssText='font-size:12px;color:var(--text-dim);margin:8px';state.textContent='Bookmarks save on this device offline. Google sync runs only when you tap Sync now.';section.append(button,state);if(target.id==='settingsPageBody')target.prepend(section);else target.querySelector('.mhdr')?.after(section)}
 WebMarkCloud.subscribe(info=>{document.querySelectorAll('.wm-google-account').forEach(b=>WebMarkCloudUI.avatar(b,info.user,'Google account & sync'));document.querySelectorAll('.wm-settings-cloud-state').forEach(p=>p.textContent=(info.user?info.user.email+' · ':'')+info.status+' · Tap Sync now to upload pending changes.');});
 await WebMarkCloud.attach({snapshot:()=>({f:S.folders,l:S.links}),persistKeys:()=>localSave(),apply(data){remote=true;try{S.folders=data.f;S.links=data.l;if(S.activeTab!=='all'&&S.activeTab!=='fav'&&S.activeTab!=='vip'&&S.activeTab!=='archive'&&!S.folders.some(f=>f.id===S.activeTab))S.activeTab='all';localSave();init()}finally{remote=false}},confirmUpload:email=>WebMarkCloudUI.chooseImport(email)});
}
document.addEventListener('DOMContentLoaded',attach);
})();
