const WebMarkActions = {
 "0": function(event) { exitFocusMode()
 },
 "1": function(event) { navTo('all','nav-home')
 },
 "2": function(event) { deskNav('all','dnl-home')
 },
 "3": function(event) { deskNav('fav','dnl-fav')
 },
 "4": function(event) { deskNav('archive','dnl-arc')
 },
 "5": function(event) { deskNav('vip','dnl-vip')
 },
 "6": function(event) { openManageFolders()
 },
 "7": function(event) { toggleTheme()
 },
 "8": function(event) { document.getElementById('impFile').click()
 },
 "9": function(event) { openShareOptions()
 },
 "10": function(event) { openSettings()
 },
 "11": function(event) { openContact()
 },
 "12": function(event) { openAddModal()
 },
 "13": function(event) { importData(event)
 },
 "14": function(event) { handleSearchInput(this)
 },
 "15": function(event) { clearSearchInput()
 },
 "16": function(event) { toggleSourceDD()
 },
 "17": function(event) { toggleSortDD()
 },
 "18": function(event) { event.stopPropagation()
 },
 "19": function(event) { setSortMode('manual')
 },
 "20": function(event) { setSortMode('date')
 },
 "21": function(event) { setSortMode('visits')
 },
 "22": function(event) { setSortMode('last')
 },
 "23": function(event) { setSortMode('folder')
 },
 "24": function(event) { setSortMode('name')
 },
 "25": function(event) { toggleFolderFilterDD()
 },
 "26": function(event) { toggleTagDD()
 },
 "27": function(event) { setView('list')
 },
 "28": function(event) { setView('cards')
 },
 "29": function(event) { setView('headlines')
 },
 "30": function(event) { setView('imagetitle')
 },
 "31": function(event) { toggleViewDD()
 },
 "32": function(event) { setView('list'); toggleViewDD()
 },
 "33": function(event) { setView('cards'); toggleViewDD()
 },
 "34": function(event) { setView('headlines'); toggleViewDD()
 },
 "35": function(event) { setView('imagetitle'); toggleViewDD()
 },
 "36": function(event) { toggleGlobalEdit()
 },
 "37": function(event) { navTo('fav','nav-fav')
 },
 "38": function(event) { navTo('vip','nav-vip')
 },
 "39": function(event) { navTo('archive','nav-arc')
 },
 "40": function(event) { openPage('settings')
 },
 "41": function(event) { confirmCloseAddModal()
 },
 "42": function(event) { saveLink()
 },
 "43": function(event) { queueWebMeta(event)
 },
 "44": function(event) { fetchWebMeta()
 },
 "45": function(event) { cleanBookmarkUrl()
 },
 "46": function(event) { document.getElementById('fIn').click()
 },
 "47": function(event) { refetchIcon()
 },
 "48": function(event) { clearIcon()
 },
 "49": function(event) { handleLogoUpload(event)
 },
 "50": function(event) { openFolderSelect('add')
 },
 "51": function(event) { useAutoFolderIcon()
 },
 "52": function(event) { document.getElementById('autoFolderSuggest').style.display='none'
 },
 "53": function(event) { hideDupWarning()
 },
 "54": function(event) { saveLink(true)
 },
 "55": function(event) { closeModal('editDetailModal')
 },
 "56": function(event) { saveEditDetail()
 },
 "57": function(event) { markChanged()
 },
 "58": function(event) { document.getElementById('editLogoIn').click()
 },
 "59": function(event) { handleEditLogoUpload(event)
 },
 "60": function(event) { openFolderSelect('editDetail')
 },
 "61": function(event) { favCurrent()
 },
 "62": function(event) { shareCurrent()
 },
 "63": function(event) { closeModal('editDetailModal');openAddModal(S.editingLink)
 },
 "64": function(event) { pinCurrent()
 },
 "65": function(event) { openTagsEdit()
 },
 "66": function(event) { openReminderPicker()
 },
 "67": function(event) { waShare()
 },
 "68": function(event) { archiveCurrent()
 },
 "69": function(event) { deleteCurrent()
 },
 "70": function(event) { closeModal('folderSelectModal')
 },
 "71": function(event) { selectFolder(null)
 },
 "72": function(event) { openCreateFolder()
 },
 "73": function(event) { filterFolderSelectList(this.value)
 },
 "74": function(event) { this.style.borderColor='var(--primary)'
 },
 "75": function(event) { this.style.borderColor='var(--border)'
 },
 "76": function(event) { document.getElementById('folderSelectSearch').value='';filterFolderSelectList('');document.getElementById('folderSelectSearch').focus();
 },
 "77": function(event) { closeFolderModal()
 },
 "78": function(event) { openIconPicker()
 },
 "79": function(event) { saveFolder()
 },
 "80": function(event) { deleteCurFolder()
 },
 "81": function(event) { closeModal('iconPickerModal')
 },
 "82": function(event) { saveIconSel()
 },
 "83": function(event) { renderIconGrid()
 },
 "84": function(event) { closeModal('manageFoldersModal')
 },
 "85": function(event) { renderManageFolders()
 },
 "86": function(event) { document.getElementById('manageFolderSearch').value='';renderManageFolders();this.style.display='none';
 },
 "87": function(event) { saveTags()
 },
 "88": function(event) { closeModal('tagsModal')
 },
 "89": function(event) { closeModal('manageTagsModal')
 },
 "90": function(event) { window.open('https://wa.me/393899528528')
 },
 "91": function(event) { window.open('mailto:saadariano@gmail.com')
 },
 "92": function(event) { closeModal('contactModal')
 },
 "93": function(event) { openExportPicker();closeModal('shareModal')
 },
 "94": function(event) { shareFormat('copy')
 },
 "95": function(event) { shareFormat('pdf')
 },
 "96": function(event) { shareFormat('excel')
 },
 "97": function(event) { closeModal('shareModal')
 },
 "98": function(event) { setLang('en')
 },
 "99": function(event) { setLang('es')
 },
 "100": function(event) { setLang('fr')
 },
 "101": function(event) { setLang('it')
 },
 "102": function(event) { setLang('ar')
 },
 "103": function(event) { closeModal('importBMModal')
 },
 "104": function(event) { importBrowserBookmarks(event)
 },
 "105": function(event) { importBrowserJSON(event)
 },
 "106": function(event) { importPersonalJSON(event)
 },
 "107": function(event) { doImportSelected()
 },
 "108": function(event) { closeModal('settingsModal')
 },
 "109": function(event) { closeModal('settingsModal');openLangModal()
 },
 "110": function(event) { openManageFolders();closeModal('settingsModal')
 },
 "111": function(event) { openTagsMgr()
 },
 "112": function(event) { toggleSetting('showFolders')
 },
 "113": function(event) { toggleSetting('showTags')
 },
 "114": function(event) { toggleSetting('sortByDate')
 },
 "115": function(event) { toggleSetting('pinnedTop')
 },
 "116": function(event) { toggleSetting('compactCards')
 },
 "117": function(event) { toggleSetting('showThumbs')
 },
 "118": function(event) { toggleSetting('showViews')
 },
 "119": function(event) { setAppFont(this.value)
 },
 "120": function(event) { setFontSize(this.value)
 },
 "121": function(event) { toggleSetting('hideImported');renderLinks()
 },
 "122": function(event) { toggleSetting('showImportedBadge');renderLinks()
 },
 "123": function(event) { renderImportPicker();openModal('importBMModal');closeModal('settingsModal')
 },
 "124": function(event) { exportImportedLinks()
 },
 "125": function(event) { clearImportedLinks()
 },
 "126": function(event) { showRecentlyVisited();closeModal('settingsModal')
 },
 "127": function(event) { setOpenLinkMode(this.value)
 },
 "128": function(event) { findDuplicates()
 },
 "129": function(event) { archiveAllRead()
 },
 "130": function(event) { openTrashModal()
 },
 "131": function(event) { openManageDeletePassword()
 },
 "132": function(event) { deleteAllPersonalBookmarks()
 },
 "133": function(event) { clearAllData()
 },
 "134": function(event) { setAccent('#22c55e')
 },
 "135": function(event) { setAccent('#8b5cf6')
 },
 "136": function(event) { setAccent('#3b82f6')
 },
 "137": function(event) { setAccent('#ef4444')
 },
 "138": function(event) { setAccent('#ec4899')
 },
 "139": function(event) { setAccent('#f97316')
 },
 "140": function(event) { setAccent('#06b6d4')
 },
 "141": function(event) { setAccent('#eab308')
 },
 "142": function(event) { closeModal('settingsModal');openContact()
 },
 "143": function(event) { showHelp()
 },
 "144": function(event) { remCalPrev()
 },
 "145": function(event) { remCalNext()
 },
 "146": function(event) { remTimeAdj('h',1)
 },
 "147": function(event) { remTimeAdj('h',-1)
 },
 "148": function(event) { remTimeAdj('m',1)
 },
 "149": function(event) { remTimeAdj('m',-1)
 },
 "150": function(event) { closeModal('reminderModal')
 },
 "151": function(event) { saveReminder()
 },
 "152": function(event) { closePage()
 },
 "153": function(event) { openFromSettingsPage('langModal')
 },
 "154": function(event) { openPage('folders')
 },
 "155": function(event) { openFromSettingsPage('manageTagsModal')
 },
 "156": function(event) { toggleSettSection('mob-sort-body', this)
 },
 "157": function(event) { openFromSettingsPage('importBMModal')
 },
 "158": function(event) { showRecentlyVisited()
 },
 "159": function(event) { openFromSettingsPage('trashModal')
 },
 "160": function(event) { openFromSettingsPage('deletePassModal',openManageDeletePassword)
 },
 "161": function(event) { openFromSettingsPage('contactModal')
 },
 "162": function(event) { closeModal('syncModal')
 },
 "163": function(event) { syncUpload()
 },
 "164": function(event) { copySyncCode()
 },
 "165": function(event) { syncDownload()
 },
 "166": function(event) { document.getElementById('signup-username').style.borderColor='var(--border)'
 },
 "167": function(event) { if(event.key==='Enter')document.getElementById('signup-pass').focus()
 },
 "168": function(event) { if(event.key==='Enter')document.getElementById('signup-confirm').focus()
 },
 "169": function(event) { if(event.key==='Enter')doSignup()
 },
 "170": function(event) { doSignup()
 },
 "171": function(event) { skipSignup()
 },
 "172": function(event) { closeModal('deletePassModal')
 },
 "173": function(event) { closeModal('trashModal')
 },
 "174": function(event) { emptyTrash()
 },
 "175": function(event) { switchTab('all')
 },
 "176": function(event, a0) { event.stopPropagation();quickDeleteFolderFromTab(wmReadActionArgument(a0))
 },
 "177": function(event, a0) { switchTab(wmReadActionArgument(a0))
 },
 "178": function(event) { this.parentElement.innerHTML='<i class=fa-solid fa-globe></i>'
 },
 "179": function(event, a0) { openEditDetail(wmReadActionArgument(a0))
 },
 "180": function(event, a0) { event.stopPropagation();openLink(wmReadActionArgument(a0))
 },
 "181": function(event, a0) { event.stopPropagation();toggleVip(wmReadActionArgument(a0))
 },
 "182": function(event, a0) { event.stopPropagation();toggleArchiveById(wmReadActionArgument(a0))
 },
 "183": function(event, a0) { event.stopPropagation();openEditDetail(wmReadActionArgument(a0))
 },
 "184": function(event, a0) { event.stopPropagation();deleteLink(wmReadActionArgument(a0))
 },
 "185": function(event, a0) { event.stopPropagation();toggleFav(wmReadActionArgument(a0))
 },
 "186": function(event, a0) { event.stopPropagation();togglePin(wmReadActionArgument(a0))
 },
 "187": function(event, a0, a1) { event.stopPropagation();shareCard(wmReadActionArgument(a0),wmReadActionArgument(a1))
 },
 "188": function(event, a0) { event.stopPropagation();copyUrl(wmReadActionArgument(a0),this)
 },
 "189": function(event, a0) { selectFolder(wmReadActionArgument(a0))
 },
 "190": function(event, a0) { openEditFolder(wmReadActionArgument(a0))
 },
 "191": function(event, a0) { event.stopPropagation();quickDeleteFolder(wmReadActionArgument(a0))
 },
 "192": function(event, a0) { selIcon(wmReadActionArgument(a0))
 },
 "193": function(event, a0) { selColor(wmReadActionArgument(a0))
 },
 "194": function(event, a0) { setSortMode(wmReadActionArgument(a0))
 },
 "195": function(event) { this.style.display='none'
 },
 "196": function(event, a0) { restoreFromTrash(wmReadActionArgument(a0))
 },
 "197": function(event, a0) { permanentDelete(wmReadActionArgument(a0))
 },
 "198": function(event) { document.getElementById('helpModal').remove()
 },
 "199": function(event) { filterByTag(null)
 },
 "200": function(event, a0) { filterByTag(wmReadActionArgument(a0))
 },
 "201": function(event) { switchTabFromDD('all')
 },
 "202": function(event, a0) { switchTabFromDD(wmReadActionArgument(a0))
 },
 "203": function(event, a0) { event.stopPropagation();deleteTagGlobal(wmReadActionArgument(a0))
 },
 "204": function(event) { toggleAllExportPicks(true)
 },
 "205": function(event) { toggleAllExportPicks(false)
 },
 "206": function(event) { doExportSelected()
 },
 "207": function(event) { toggleAllBrowserPicks(true)
 },
 "208": function(event) { toggleAllBrowserPicks(false)
 },
 "209": function(event) { confirmClearSelectedBrowsers()
 },
 "210": function(event, a0) { remSelDay(wmReadActionArgument(a0))
 },
 "211": function(event) { this.parentElement.remove()
 },
 "212": function(event) { saveDeletePassword()
 },
 "213": function(event) { if(event.key==='Enter')verifyDeletePassword()
 },
 "214": function(event) { verifyDeletePassword()
 },
 "215": function(event) { openForgotPassword()
 },
 "216": function(event) { if(event.key==='Enter')verifyRecoveryUsername()
 },
 "217": function(event) { verifyRecoveryUsername()
 },
 "218": function(event) { resetDeletePassword()
 },
 "219": function(event) { openChangeUsername()
 },
 "220": function(event) { openChangePasswordWithUsername()
 },
 "221": function(event) { confirmRemoveDeletePassword()
 },
 "222": function(event) { doChangeUsername()
 },
 "223": function(event) { if(event.key==='Enter')doRemoveDeletePassword()
 },
 "224": function(event) { doRemoveDeletePassword()
 },
 "225": function(event) { exportData()
 },
 "226": function(event) { wmTransferImport()
 },
 "227": function(event, a0) { quickDeleteFolder(wmReadActionArgument(a0))
 }
};
/* Only build-time handlers run. Values from rendered markup are JSON arguments. */
function wmReadActionArgument(value) {
 return JSON.parse(value);
}

(() => {
 const events = ['click','change','input','error','keydown','mousedown','focus','blur','mouseover','mouseout'];
 const attributes = events.map(event => 'data-wm-' + event);
 const selector = attributes.map(attr => `[${attr}]`).join(',');
 const bound = new WeakMap();

 function bind(element) {
  if (bound.has(element)) return;
  bound.set(element, true);
  events.forEach((event, i) => {
   const attribute = attributes[i];
   if (!element.hasAttribute(attribute)) return;
   element.addEventListener(event, e => {
    const action = WebMarkActions[element.getAttribute(attribute)];
    if (typeof action !== 'function' || !Object.hasOwn(WebMarkActions, element.getAttribute(attribute))) return;
    const args = Array.from({length: action.length - 1}, (_, n) => element.getAttribute(attribute + '-' + n));
    if (action.call(element, e, ...args) === false) e.preventDefault();
   });
  });
 }

 function scan(element) {
  if (element.nodeType !== Node.ELEMENT_NODE) return;
  if (element.matches(selector)) bind(element);
  element.querySelectorAll(selector).forEach(bind);
 }

 document.querySelectorAll(selector).forEach(bind);
 new MutationObserver(records => {
  for (const record of records) record.addedNodes.forEach(scan);
 }).observe(document.documentElement, {childList: true, subtree: true});
})();
