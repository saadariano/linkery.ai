

(function() {
    function updateNavHeight() {
        var nav = document.querySelector('.desktop-nav');
        if (nav) {
            var h = nav.getBoundingClientRect().height;
            document.documentElement.style.setProperty('--nav-height', h + 'px');
        }
    }
    // Run on load
    document.addEventListener('DOMContentLoaded', updateNavHeight);
    // Run on resize (orientation change on mobile)
    window.addEventListener('resize', updateNavHeight);
    // Also run after a short delay in case fonts/layout shift
    window.addEventListener('load', function() {
        updateNavHeight();
        setTimeout(updateNavHeight, 300);
    });
})();

