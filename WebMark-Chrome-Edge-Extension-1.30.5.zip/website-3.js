

/* WebMark compatibility layer: local-only data, validated imports, portable actions. */
const wmStorage = (() => {
 const managed = new Set(['wm_bookmark_cloud_checkpoint_v1','wm_bookmark_relay_key_v1','wm_bookmark_relay_origin_v1','ly_state_v4','ly_f','ly_l','ly_trash','wm_before_google_login','wm_cloud_records_v1','wm_google_session_v1','wm_notes_v1','wm_password_vault_v1','ly_deluser','ly_delpass','wm_bookmark_protection_v1']);
 const values = new Map();
 const writes = new Map();
 const backupMessage = 'Changes were not saved. Export a JSON backup before closing.';
 let db = null;
 let usable = true;
 try{localStorage.getItem('ly_state_v4')}catch{usable=false}
 function legacy(key){try{return localStorage.getItem(key)}catch{return null}}
 function transaction(database, action) {
  return new Promise((resolve,reject)=>{
   const tx=database.transaction('values','readwrite');
   tx.oncomplete=()=>resolve();
   tx.onabort=()=>reject(tx.error||new Error(backupMessage));
   action(tx.objectStore('values'));
  });
 }
 const ready = (async()=>{
  let database;
  try {
   database = await new Promise((resolve,reject)=>{
    const request=indexedDB.open('webmark-extension',1);
    request.onupgradeneeded=()=>request.result.createObjectStore('values');
    request.onsuccess=()=>resolve(request.result);
    request.onerror=()=>reject(request.error);
    request.onblocked=()=>reject(new Error('Close other WebMark tabs and reload.'));
   });
   if (!legacy('ly_lang')) {
    try {
     const {webmarkLanguage} = await (globalThis.browser || globalThis.chrome).storage.local.get('webmarkLanguage');
     if (['en','it','fr','es','ar'].includes(webmarkLanguage)) localStorage.setItem('ly_lang',webmarkLanguage);
    } catch {}
   }
   const migrated = new Map();
   await transaction(database, store=>{
    for(const key of managed){
     const request=store.get(key);
     request.onsuccess=()=>{
      const old=legacy(key);
      if(request.result!==undefined){values.set(key,request.result);return}
      values.set(key,old);
      if(old!==null){store.put(old,key);migrated.set(key,old)}
     };
    }
   });
   db=database;
   for(const [key,old] of migrated){
    try{if(localStorage.getItem(key)===old)localStorage.removeItem(key)}catch{}
   }
  } catch(error){
   database?.close();
   console.error('WebMark storage initialization failed',error);
  }
 })();
 function write(key,value){
  values.set(key,value);
  const result=transaction(db,store=>store.put(value,key));
  writes.set(key,result);
  result.then(()=>{if(writes.get(key)===result)writes.delete(key)},()=>{
   if(writes.get(key)===result)window.showToast?.(backupMessage,'#ef4444');
  });
 }
 return {
  ready,
  get durable(){return !!db},
  get persistent(){return !!db||usable},
  flush(){return Promise.all(writes.values())},
  getItem(key){return db&&managed.has(key)?values.get(key)??null:legacy(key)??values.get(key)??null},
  setItem(key,value){
   value=String(value);
   if(db&&managed.has(key)){write(key,value);return}
   if(usable){try{localStorage.setItem(key,value);return}catch(error){alert(backupMessage);throw error}}
   values.set(key,value);
  },
  removeItem(key){
   if(db&&managed.has(key)){if(values.get(key)!=null)write(key,null);return}
   if(usable)localStorage.removeItem(key);
   values.delete(key);
  }
 };
})();
function wmJSON(key,fallback){try{let x=JSON.parse(wmStorage.getItem(key));if(x===null)return fallback;if(Array.isArray(fallback))return Array.isArray(x)?x:fallback;return typeof x==='object'&&!Array.isArray(x)?x:fallback}catch{return fallback}}
function wmEncode(s){try{return btoa(s)}catch{return 'u8:'+btoa(String.fromCharCode(...new TextEncoder().encode(s)))}}
function wmDecode(s){try{return s.startsWith('u8:')?new TextDecoder().decode(Uint8Array.from(atob(s.slice(3)),c=>c.charCodeAt(0))):atob(s)}catch{return ''}}
let wmLastId=Date.now();
function wmId(){return wmLastId=Math.max(Date.now(),wmLastId+1)}
function wmURL(raw){let s=String(raw||'').trim();if(!s)return null;if(!/^[a-z][a-z0-9+.-]*:/i.test(s))s='https://'+s;try{const u=new URL(s);return ['https:','http:'].includes(u.protocol)&&u.hostname?u.href:null}catch{return null}}
function wmImage(raw){let s=String(raw||'');return /^data:image\/(png|jpe?g|webp|gif|avif);base64,/i.test(s)||/^https?:\/\//i.test(s)?s:null}
function wmIcon(s){return typeof s==='string'&&/^fa-(solid|regular|brands)\s+fa-[a-z0-9-]+$/.test(s)?s:'fa-solid fa-globe'}
function wmColor(s){return /^#[0-9a-f]{3,8}$/i.test(s||'')?s:'#8b5cf6'}
function wmNormalize(data){
 const folders=Array.isArray(data.f)?data.f:Array.isArray(data.folders)?data.folders:[];
 const links=Array.isArray(data)?data:Array.isArray(data.l)?data.l:Array.isArray(data.links)?data.links:null;
 if(!links)throw Error('Invalid backup');
 const ids=new Set(),map=new Map();
 const outF=folders.filter(f=>f&&typeof f==='object').map(f=>{const id=Number.isSafeInteger(f.id)&&f.id>0&&!ids.has(f.id)?f.id:wmId();ids.add(id);map.set(f.id,id);return {...f,id,name:String(f.name||'Folder'),icon:wmIcon(f.icon),color:wmColor(f.color)}});
 const linkIds=new Set();
 function clean(l){if(!l||typeof l!=='object')return null;let url=wmURL(l.url);if(!url)return null;let id=Number.isSafeInteger(l.id)&&l.id>0&&!linkIds.has(l.id)?l.id:wmId();linkIds.add(id);return {...l,addedAt: l.addedAt===undefined ? (l.id??null) : l.addedAt,id,url,title:String(l.title||url),desc:String(l.desc||''),tags:Array.isArray(l.tags)?l.tags.filter(t=>typeof t==='string'):[],logo:wmImage(l.logo),fId:map.get(l.fId)??(ids.has(l.fId)?l.fId:null),views:Math.max(0,Number(l.views)||0),siteIcon:l.siteIcon?{icon:wmIcon(l.siteIcon.icon),color:wmColor(l.siteIcon.color)}:null}}
 return {f:outF,l:links.map(clean).filter(Boolean),trash:(Array.isArray(data.trash)?data.trash:[]).map(clean).filter(Boolean)};
}
function wmInitial(){let snap=wmJSON('ly_state_v4',{});let raw=Array.isArray(snap.l)&&Array.isArray(snap.f)?snap:{f:wmJSON('ly_f',[]),l:wmJSON('ly_l',[]),trash:wmJSON('ly_trash',[])};return wmNormalize(raw)}
const wmInitialData={f:[],l:[],trash:[]};
async function wmCopy(text){text=String(text);try{if(navigator.clipboard?.writeText){await navigator.clipboard.writeText(text);return}}catch{}const area=document.createElement('textarea');area.value=text;area.style.cssText='position:fixed;top:0;left:0;opacity:0';document.body.append(area);area.select();try{if(document.execCommand('copy'))return}finally{area.remove()}throw Error('clipboard unavailable')}
function wmDownload(name,data,type='application/json'){const url=URL.createObjectURL(new Blob([data],{type}));const a=document.createElement('a');a.href=url;a.download=name;document.body.append(a);a.click();setTimeout(()=>{a.remove();URL.revokeObjectURL(url)},10000)}
function jsArg(s){return esc(JSON.stringify(String(s??'')).replace(/</g,'\\u003c').replace(/'/g,'\\u0027'))}


