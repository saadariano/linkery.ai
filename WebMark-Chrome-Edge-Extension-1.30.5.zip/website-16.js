/* Public release checks are separate from Google sync. Android installs require approval. */
(()=>{
    'use strict';
    const native=globalThis.WebMarkAndroid;
    if(!native?.checkAppUpdate||!native?.appVersion)return;
    let current;try{current=JSON.parse(native.appVersion());}catch{return;}
    let pending=null,release=null,dialog=null,shownVersion=0;
    const setupKey='wm_update_notification_setup_v1';
    let lastCheck=0,setupChosen=false;
    try{setupChosen=localStorage.getItem(setupKey)==='1';}catch{}
    const words={
        en:['App updates','Check for updates','Checking…','Update available','Confirm','Later','You have the latest version.','Updates have not been published yet.','Could not check. Check your connection and try again.','Continue to the download page to get the update. Android will check the APK before installation.'],
        it:['Aggiornamenti app','Controlla aggiornamenti','Controllo…','Aggiornamento disponibile','Conferma','Più tardi','Hai la versione più recente.','Gli aggiornamenti non sono ancora stati pubblicati.','Controllo non riuscito. Verifica la connessione e riprova.','Android scaricherà il file APK. Aprilo e conferma l’aggiornamento. I dati salvati restano nell’app.'],
        fr:['Mises à jour','Vérifier les mises à jour','Vérification…','Mise à jour disponible','Confirmer','Plus tard','Vous avez la dernière version.','Les mises à jour ne sont pas encore publiées.','Échec de la vérification. Vérifiez votre connexion.','Android téléchargera le fichier APK. Ouvrez-le et confirmez la mise à jour. Vos données restent dans l’application.'],
        es:['Actualizaciones','Buscar actualizaciones','Comprobando…','Actualización disponible','Confirmar','Más tarde','Tienes la última versión.','Las actualizaciones aún no se han publicado.','No se pudo comprobar. Revisa tu conexión.','Android descargará el APK. Ábrelo y confirma la actualización. Tus datos se conservan.'],
        ar:['تحديثات التطبيق','التحقق من التحديثات','جارٍ التحقق…','يتوفر تحديث جديد','تأكيد','لاحقاً','لديك أحدث إصدار.','لم تُنشر ملفات التحديث بعد.','تعذر التحقق. تأكد من الاتصال وحاول مجدداً.','سيتم تنزيل ملف APK. افتحه ووافق على التحديث. تبقى بياناتك المحفوظة داخل التطبيق.']
    };
    const t=i=>(words[document.documentElement.lang]||words.en)[i];
    const node=(tag,text)=>{const el=document.createElement(tag);if(text!==undefined)el.textContent=text;return el;};
    function status(text){document.querySelectorAll('.wm-update-status').forEach(el=>el.textContent=text);}
    function show(){
        if(!release)return;
        if(!dialog){dialog=node('dialog');dialog.id='wm-app-update';dialog.setAttribute('aria-label',t(3));dialog.style.cssText='position:fixed;inset:0;margin:auto;box-sizing:border-box;width:min(320px,calc(100% - 32px));max-height:65dvh;overflow:auto;padding:18px;border:2px solid #dc2626;border-radius:22px;background:#fff1f2;color:#7f1d1d;font:inherit';document.body.append(dialog);}
        const title=node('h2',t(3)),version=node('p','WebMark '+release.versionName+' · '+current.versionName+' → '+release.versionName);
        const notes=node('p',release.notes||'');notes.hidden=!release.notes;notes.style.cssText='white-space:pre-wrap;max-height:100px;overflow:auto';
        const help=node('p','Confirm to download the update.');help.style.cssText='font-size:13px;line-height:1.6;opacity:.8';
        const update=node('button',t(4));update.type='button';update.style.cssText='padding:12px 18px;border:0;border-radius:12px;background:#b91c1c;color:white;font:inherit;font-weight:700';
        update.addEventListener('click',()=>{native.openAppUpdate();dialog.close();});
        const later=node('button',({it:'Annulla',fr:'Annuler',es:'Cancelar',ar:'إلغاء'})[document.documentElement.lang]||'Cancel');later.type='button';later.style.cssText='padding:12px 18px;margin:8px;border:1px solid var(--border);border-radius:12px;background:transparent;color:inherit;font:inherit';later.addEventListener('click',()=>dialog.close());
        dialog.replaceChildren(title,version,notes,help,update,later);if(!dialog.open)dialog.showModal();
    }
    function check(manual=false){
        if(pending)return;
        if(navigator.onLine===false){if(manual)status(t(8));return;}
        if(!manual&&lastCheck&&Date.now()-lastCheck<3600000)return;
        const request=crypto.randomUUID();pending={request,manual};status(t(2));
        pending.timeout=setTimeout(()=>{if(pending?.request===request){const explicit=pending.manual;pending=null;if(explicit)status(t(8));}},20000);
        native.checkAppUpdate(request);
    }
    function result(request,value,error){
        if(pending?.request!==request)return;const manual=pending.manual;clearTimeout(pending.timeout);pending=null;
        if(error||!value){status(t(error==='not_published'?7:8));return;}
        lastCheck=Date.now();
        if(!Number.isSafeInteger(value.versionCode)||value.versionCode<=current.versionCode){release=null;status(t(6));return;}
        release=value;status(t(3)+' · '+value.versionName);
        if(manual||shownVersion!==value.versionCode){shownVersion=value.versionCode;show();}
    }
    function refreshPermission(){
        if(!native.updateNotificationsEnabled)return;
        const enabled=native.updateNotificationsEnabled();
        document.querySelectorAll('.wm-update-permission').forEach(button=>{
            button.hidden=setupChosen||enabled;
            button.style.display=button.hidden?'none':'flex';
        });
    }
    function resume(){refreshPermission();check(false);}
    function foreground(){lastCheck=0;resume();}
    function init(){
        for(const target of [document.getElementById('settingsPageBody'),document.querySelector('#settingsModal .mc')]){
            if(!target||target.querySelector('.wm-app-updates'))continue;
            const box=node('section');box.className='wm-app-updates';box.style.cssText='padding:14px;margin:12px 0;border:1px solid var(--border);border-radius:14px';
            box.append(node('h3',t(0)),node('p','WebMark '+current.versionName));const button=node('button',t(1));button.type='button';button.className='erow wm-setting-action wm-update-action';button.addEventListener('click',()=>check(true));
            const state=node('p',t(1));state.className='wm-update-status';state.style.cssText='font-size:12px;opacity:.8';box.append(button,state);
            if(native.enableUpdateNotifications){
                const permission=node('button','Set up update notifications');
                permission.type='button';permission.className='wm-update-permission';
                const bell=node('i');bell.className='fa-solid fa-bell';bell.setAttribute('aria-hidden','true');
                permission.prepend(bell);
                permission.style.cssText='display:flex;align-items:center;justify-content:center;gap:10px;width:100%;padding:13px 16px;border:0;border-radius:14px;background:linear-gradient(110deg,#4338a8,#155fb6);color:white;font:inherit;font-weight:700;cursor:pointer';
                permission.addEventListener('click',()=>{
                    native.enableUpdateNotifications();
                    setupChosen=true;
                    try{localStorage.setItem(setupKey,'1');}catch{}
                    refreshPermission();
                });
                box.append(permission);
            }
            target.append(box);
        }
        resume();
        window.addEventListener?.('online',resume);
    }
    window.WebMarkUpdates={check,result,resume,foreground,back(){if(dialog?.open){dialog.close();return true;}return false;}};
    if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init,{once:true});else init();
})();
