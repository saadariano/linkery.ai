/* Read the active page only when the user chooses to save it. */
const api = globalThis.browser || globalThis.chrome;

async function openLibrary() {
 const url = api.runtime.getURL('dashboard.html');
 const [tab] = await api.tabs.query({url}).catch(() => []);
 if (tab) {
  await api.windows.update(tab.windowId, {focused: true});
  return api.tabs.update(tab.id, {active: true});
 }
 return api.tabs.create({url});
}

async function capture(raw, title) {
 const url = new URL(raw);
 if (url.protocol !== 'https:' && url.protocol !== 'http:') {
  throw new Error('Open a website first. Browser settings pages cannot be saved.');
 }
 await navigator.locks.request('webmark-capture', async () => {
  const {webmarkInbox: inbox = []} = await api.storage.local.get('webmarkInbox');
  if (inbox.some(entry => entry.url === url.href)) return;
  inbox.push({url: url.href, title: title || url.hostname, queuedAt: Date.now()});
  await api.storage.local.set({webmarkInbox: inbox});
 });
 await openLibrary();
}

api.runtime.onMessage.addListener((message, sender, sendResponse) => {
 if (sender.id !== api.runtime.id || sender.url !== api.runtime.getURL('popup.html')) return;
 const operation = message?.action === 'open-library' ? openLibrary() :
  message?.action === 'save-site' ? capture(message.url, message.title) : null;
 if (!operation) return;
 operation.then(() => sendResponse({ok: true}), error => sendResponse({error: error.message}));
 return true;
});

api.runtime.onInstalled.addListener(async () => {
 await api.contextMenus.removeAll();
 api.contextMenus.create({id: 'webmark-save-page', title: 'Save website to WebMark', contexts: ['page']});
 api.contextMenus.create({id: 'webmark-save-link', title: 'Save link to WebMark', contexts: ['link']});
});
api.contextMenus.onClicked.addListener((info, tab) => {
 capture(info.linkUrl || tab?.url, info.linkText || tab?.title).catch(console.error);
});
