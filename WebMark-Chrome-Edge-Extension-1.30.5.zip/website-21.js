
(() => {
    const workspaces = [
        {id:'wm-notes-app', selector:'dialog#wm-notes-app,dialog[id^="wm-note-"],dialog#wm-studio-lists', header:'.wm-notes-header', button:'wm-notes-button', label:'Notes'},
        {id:'wm-passwords', selector:'dialog#wm-passwords,dialog[id^="wm-pw-"]', header:'.wm-pw-header', button:'wm-pw-button', label:'Passwords'}
    ];
    for (const workspace of workspaces) {
        const header = document.getElementById(workspace.id)?.querySelector(workspace.header);
        if (!header) continue;
        const key = 'webmark-theme-' + workspace.id;
        const toggle = document.createElement('button');
        toggle.type = 'button';
        toggle.className = workspace.button + ' wm-workspace-theme';
        let mode = '';
        try {mode = localStorage.getItem(key) || '';} catch {}
        function apply() {
            for (const surface of document.querySelectorAll(workspace.selector)) surface.dataset.workspaceTheme = mode;
            const dark = mode ? mode === 'dark' : !document.body.classList.contains('light-mode');
            const locale = globalThis.WebMarkInterfaceLocale;
            const key = dark ? 'Use light mode in {workspace}' : 'Use dark mode in {workspace}';
            const label = locale ? locale.text(key,{workspace:locale.text(workspace.label)}) :
                (dark ? 'Use light mode in ' : 'Use dark mode in ') + workspace.label;
            toggle.title = label;
            toggle.setAttribute('aria-label',label);
            toggle.innerHTML = dark ? '<i class="fa-solid fa-sun" aria-hidden="true"></i>' : '<i class="fa-solid fa-moon" aria-hidden="true"></i>';
        }
        toggle.onclick = () => {
            mode = toggle.querySelector('.fa-sun') ? 'light' : 'dark';
            try {localStorage.setItem(key,mode);} catch {}
            apply();
        };
        globalThis.WebMarkInterfaceLocale?.onChange(apply);
        header.append(toggle);
        apply();
        new MutationObserver(()=>{if(!mode)apply();}).observe(document.body,{attributes:true,attributeFilter:['class']});
    }
})();
