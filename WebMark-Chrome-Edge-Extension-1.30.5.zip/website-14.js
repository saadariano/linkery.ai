
const WebMarkPasswordsCore = (() => {
    const encode = bytes => {
        let text='';
        const data=new Uint8Array(bytes);
        for(let i=0;i<data.length;i+=8192)text+=String.fromCharCode(...data.subarray(i,i+8192));
        return btoa(text);
    };
    const decode = text => Uint8Array.from(atob(text),char=>char.charCodeAt(0));
    const bytes = text => new TextEncoder().encode(text);
    const random = size => crypto.getRandomValues(new Uint8Array(size));
    const key = raw => crypto.subtle.importKey('raw',raw,'AES-GCM',false,['encrypt','decrypt']);
    async function passwordKey(password,salt) {
        const material=await crypto.subtle.importKey('raw',bytes(password),'PBKDF2',false,['deriveKey']);
        return crypto.subtle.deriveKey({name:'PBKDF2',hash:'SHA-256',iterations:600000,salt},
            material,{name:'AES-GCM',length:256},false,['encrypt','decrypt']);
    }
    async function seal(cryptoKey,value,context) {
        const iv=random(12);
        const data=await crypto.subtle.encrypt({name:'AES-GCM',iv,additionalData:bytes(context)},
            cryptoKey,value);
        return {iv:encode(iv),data:encode(data)};
    }
    async function open(cryptoKey,packet,context) {
        return crypto.subtle.decrypt({name:'AES-GCM',iv:decode(packet.iv),additionalData:bytes(context)},
            cryptoKey,decode(packet.data));
    }
    async function wrap(id,raw,password) {
        const salt=random(16);
        return {salt:encode(salt),...await seal(await passwordKey(password,salt),raw,id)};
    }
    function validate(packet) {
        if(!packet||packet.format!=='webmark-password-vault-v1'||!/^password-vault-[\w-]{10,100}$/.test(packet.id)||
            !Number.isSafeInteger(packet.revision)||packet.revision<1 ||
            !packet.wrapped?.salt || !packet.wrapped?.iv || !packet.wrapped?.data ||
            !packet.payload?.iv || !packet.payload?.data)throw Error('Invalid encrypted vault file.');
        if(decode(packet.wrapped.salt).length!==16 || decode(packet.wrapped.iv).length!==12 ||
            decode(packet.payload.iv).length!==12)throw Error('Invalid encrypted vault file.');
        return packet;
    }
    async function create(password) {
        const raw=random(32);
        const id='password-vault-'+crypto.randomUUID();
        return {raw,packet:{format:'webmark-password-vault-v1',id,revision:1,keyUpdatedAt:Date.now(),
            wrapped:await wrap(id,raw,password)}};
    }
    async function unlock(packet,password) {
        validate(packet);
        const box=packet.wrapped;
        const raw=await open(await passwordKey(password,decode(box.salt)),box,packet.id);
        return {raw:new Uint8Array(raw),data:await read(packet,raw)};
    }
    async function read(packet,raw) {
        validate(packet);
        const value=JSON.parse(new TextDecoder().decode(await open(await key(raw),packet.payload,packet.id)));
        if(!value || !Array.isArray(value.items)||!Array.isArray(value.groups))throw Error('Invalid vault contents.');
        const ids=new Set();
        for(const item of value.items){
            if(!item||typeof item.id!=='string'||ids.has(item.id)||typeof item.title!=='string'||
                typeof item.username!=='string'||typeof item.password!=='string'||
                !['password','wifi','code','pin'].includes(item.type)||!Array.isArray(item.websites)||
                item.websites.some(site=>typeof site!=='string')||typeof item.notes!=='string'||
                !Number.isSafeInteger(item.createdAt)||!Number.isSafeInteger(item.updatedAt))
                throw Error('Invalid password record.');
            ids.add(item.id);
        }
        for(const group of value.groups)if(!group||typeof group.id!=='string'||typeof group.name!=='string')
            throw Error('Invalid password group.');
        return migrateFolders(value);
    }
    function migrateFolders(value) {
        const migrated=value.folderSchemaVersion!==1;
        if(value.folders!==undefined&&!Array.isArray(value.folders))throw Error('Invalid password folders.');
        const folders=value.folders||[];
        for(const group of value.groups||[])if(!folders.some(folder=>folder.id===group.id))
            folders.push({id:group.id,name:group.name,icon:'fa-solid fa-folder',color:'#7957dc'});
        const ids=new Set();
        for(const folder of folders){
            if(!folder||typeof folder.id!=='string'||typeof folder.name!=='string'||ids.has(folder.id))throw Error('Invalid password folder.');
            ids.add(folder.id);
            folder.icon=typeof folder.icon==='string'&&/^fa-(solid|regular|brands) fa-[a-z0-9-]+$/.test(folder.icon)?folder.icon:'fa-solid fa-folder';
            folder.color=typeof folder.color==='string'&&/^#[a-f0-9]{6}$/i.test(folder.color)?folder.color:'#7957dc';
        }
        for(const item of value.items){
            item.folderId=typeof item.folderId==='string'?item.folderId:typeof item.groupId==='string'?item.groupId:'';
            if(!ids.has(item.folderId))item.folderId='';
            delete item.groupId;delete item.sharedReadOnly;
        }
        value.folders=folders;value.groups=[];value.folderSchemaVersion=1;
        delete value.sharingIdentities;
        Object.defineProperty(value,'_folderMigration',{value:migrated,enumerable:false,configurable:true});
        return value;
    }
    async function save(packet,raw,data) {
        return {...packet,revision:packet.revision+1,
            payload:await seal(await key(raw),bytes(JSON.stringify(data)),packet.id)};
    }
    async function changePassword(packet,raw,password) {
        return {...packet,wrapped:await wrap(packet.id,raw,password),keyUpdatedAt:Math.max(Date.now(),(packet.keyUpdatedAt||0)+1),revision:packet.revision+1};
    }
    function csv(text) {
        text=text.replace(/^\uFEFF/,'');
        const rows=[];let row=[],field='',quoted=false,closed=false;
        for(let i=0;i<text.length;i++){
            const char=text[i];
            if(quoted){
                if(char==='"'&&text[i+1]==='"'){field+='"';i++;}
                else if(char==='"'){quoted=false;closed=true;}
                else field+=char;
            } else if(char===',' || char==='\n' || char==='\r'){
                row.push(field);field='';closed=false;
                if(char!==','){rows.push(row);row=[];if(char==='\r'&&text[i+1]==='\n')i++;}
            } else if(char==='"'&&!field&&!closed)quoted=true;
            else {
                if(closed)throw Error('Malformed CSV file.');
                field+=char;
            }
        }
        if(quoted)throw Error('Incomplete quoted CSV field.');
        if(field||row.length){row.push(field);rows.push(row);}
        return rows.filter(row=>row.some(value=>value.length));
    }
    const safeURL = value => {
        try{
            let text=value.trim();
            if(!/^[a-z][a-z0-9+.-]*:/i.test(text))text='https://'+text;
            const url=new URL(text);
            return /^(https?:)$/.test(url.protocol)&&!url.username&&!url.password?url.href:null;
        }catch{return null;}
    };
    function importCSV(text,source) {
        const rows=csv(text);
        const headers=(rows.shift()||[]).map(value=>value.trim().toLowerCase().replace(/[ _-]/g,''));
        const col=names=>names.map(name=>headers.indexOf(name)).find(index=>index>=0);
        const pwd=col(['password']);
        const user=col(['username','login','email','user']);
        const url=col(['url','website','origin','loginuri']);
        const title=col(['title','name','sitename']);
        const notes=col(['notes','note','comment']);
        const date=col(['timecreated','created','createdat']);
        if(pwd===undefined || (url===undefined && title===undefined))throw Error('CSV needs Password and URL, Website, Name, or Title columns.');
        const entries=[];
        for(const row of rows){
            if(!row[pwd])continue;
            const websites=String(row[url]||'').split(/[;\n]/).map(safeURL).filter(Boolean);
            const parsed=Number(row[date]);
            const createdAt=Number.isSafeInteger(parsed)&&parsed>=Date.UTC(1990,0,1)&&parsed<=Date.now()?parsed:Date.now();
            entries.push({id:crypto.randomUUID(),type:'password',
                title:String(row[title]|| (websites[0]?new URL(websites[0]).hostname:'Account')).slice(0,250),
                username:String(row[user]||''),password:row[pwd],websites,
                notes:String(row[notes]||''),source,createdAt,updatedAt:createdAt});
        }
        return entries;
    }
    function security(items) {
        const passwords=items.filter(item=>!item.deletedAt&&item.type!=='code'&&item.password);
        const counts=new Map();
        for(const item of passwords) counts.set(item.password,(counts.get(item.password)||0)+1);
        return new Map(passwords.map(item=>[item.id,{
            short:item.password.length<12,reused:counts.get(item.password)>1
        }]));
    }
    function generate(length=24) {
        const alphabet='ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!#$%&*+-=?@_';
        const result=[];
        const limit=256-(256%alphabet.length);
        while(result.length<length)for(const byte of random(length)){
            if(byte<limit&&result.length<length)result.push(alphabet[byte%alphabet.length]);
        }
        return result.join('');
    }
    async function totp(secret,time=Date.now()) {
        const normalized=secret.replace(/[\s=-]/g,'').toUpperCase();
        if(!/^[A-Z2-7]{16,256}$/.test(normalized))throw Error('Enter a valid Base32 verification-code secret.');
        let held=0,bits=0;const output=[];
        for(const char of normalized){
            held=(held<<5)|'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567'.indexOf(char);bits+=5;
            if(bits>=8){bits-=8;output.push((held>>>bits)&255);}
        }
        const counter=new ArrayBuffer(8);
        new DataView(counter).setBigUint64(0,BigInt(Math.floor(time/30000)));
        const hmac=await crypto.subtle.importKey('raw',new Uint8Array(output),{name:'HMAC',hash:'SHA-1'},false,['sign']);
        const signature=new Uint8Array(await crypto.subtle.sign('HMAC',hmac,counter));
        const offset=signature.at(-1)&15;
        const binary=((signature[offset]&127)<<24)|(signature[offset+1]<<16)|(signature[offset+2]<<8)|signature[offset+3];
        return String(binary%1000000).padStart(6,'0');
    }
    return {create,unlock,read,save,changePassword,validate,importCSV,csv,safeURL,security,generate,totp,encode,decode,migrateFolders};
})();

// A passkey PRF wraps the local vault key. Neither the PRF output nor the raw
// vault key is stored. Android uses its existing native Keystore bridge.
const WebMarkPasswordDevice = globalThis.WebMarkPasswordDevice = (() => {
    'use strict';
    const C=WebMarkPasswordsCore,key='wm_password_device_v1';
    const random=n=>crypto.getRandomValues(new Uint8Array(n));
    const supported=()=>globalThis.isSecureContext===true &&
        globalThis.location?.protocol==='https:' && !!globalThis.PublicKeyCredential &&
        !!navigator.credentials?.create && !!navigator.credentials?.get;
    function record(vaultId) {
        try {
            const value=JSON.parse(wmStorage.getItem(key)||'null');
            return value?.vaultId===vaultId && value.version===1 ? value:null;
        }catch{return null;}
    }
    const available=vaultId=>supported()&&!!record(vaultId);
    const equal=(a,b)=>a.length===b.length&&a.every((byte,i)=>byte===b[i]);
    function validateClient(credential,challenge,type) {
        if(!credential?.response?.clientDataJSON)throw Error('Device verification was not completed.');
        const data=JSON.parse(new TextDecoder().decode(credential.response.clientDataJSON));
        const actual=data.challenge.replace(/-/g,'+').replace(/_/g,'/');
        if(data.type!==type || data.origin!==location.origin || data.crossOrigin===true ||
            !equal(C.decode(actual),challenge))throw Error('Device verification did not match this website.');
    }
    async function assertion(id,salt) {
        const challenge=random(32);
        const credential=await navigator.credentials.get({publicKey:{challenge,rpId:location.hostname,
            allowCredentials:[{type:'public-key',id:C.decode(id)}],userVerification:'required',
            extensions:{prf:{eval:{first:C.decode(salt)}}},timeout:60000}});
        validateClient(credential,challenge,'webauthn.get');
        const auth=new Uint8Array(credential.response.authenticatorData||[]);
        if(auth.length<37 || !(auth[32]&4) || !equal(new Uint8Array(credential.rawId),C.decode(id)))
            throw Error('Face, fingerprint, or device PIN verification is required.');
        const rpHash=new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(location.hostname)));
        if(!equal(auth.slice(0,32),rpHash))throw Error('Device verification belongs to another website.');
        const output=credential.getClientExtensionResults()?.prf?.results?.first;
        if(!output || output.byteLength!==32)throw Error('This passkey provider cannot unlock encrypted vaults. Use your vault password.');
        return crypto.subtle.importKey('raw',output,'AES-GCM',false,['encrypt','decrypt']);
    }
    async function enable(vaultId,raw) {
        if(!supported())throw Error('Open the HTTPS website in a compatible passkey browser, or use the Android app.');
        const challenge=random(32),salt=C.encode(random(32));
        const credential=await navigator.credentials.create({publicKey:{challenge,
            rp:{id:location.hostname,name:'WebMark Passwords'},
            user:{id:random(32),name:'WebMark vault',displayName:'WebMark vault'},
            pubKeyCredParams:[{type:'public-key',alg:-7},{type:'public-key',alg:-257}],
            authenticatorSelection:{authenticatorAttachment:'platform',residentKey:'preferred',userVerification:'required'},
            attestation:'none',extensions:{prf:{}},timeout:60000}});
        validateClient(credential,challenge,'webauthn.create');
        if(!credential.getClientExtensionResults()?.prf?.enabled)
            throw Error('This device does not support encrypted passkey unlock. Your vault password still works.');
        const id=C.encode(new Uint8Array(credential.rawId));
        const wrapping=await assertion(id,salt),iv=random(12);
        const encrypted=await crypto.subtle.encrypt({name:'AES-GCM',iv,additionalData:new TextEncoder().encode(vaultId)},wrapping,raw);
        wmStorage.setItem(key,JSON.stringify({version:1,vaultId,id,salt,iv:C.encode(iv),data:C.encode(new Uint8Array(encrypted))}));
        await wmStorage.flush?.();
    }
    async function unlock(vaultId) {
        const value=record(vaultId);
        if(!supported()||!value)throw Error('Enable device unlock on this device first.');
        const wrapping=await assertion(value.id,value.salt);
        return new Uint8Array(await crypto.subtle.decrypt({name:'AES-GCM',iv:C.decode(value.iv),
            additionalData:new TextEncoder().encode(vaultId)},wrapping,C.decode(value.data)));
    }
    async function disable(){wmStorage.removeItem(key);await wmStorage.flush?.();}
    return {supported,available,enable,unlock,disable};
})();



/* Bookmark deletion credentials travel only inside the encrypted password vault. */
(()=>{
    'use strict';
    if(typeof wmStorage==='undefined')return;
    const key='wm_bookmark_protection_v1',fields=['ly_deluser','ly_delpass'];
    const get=wmStorage.getItem.bind(wmStorage),set=wmStorage.setItem.bind(wmStorage),remove=wmStorage.removeItem.bind(wmStorage);
    function previous(){try{return JSON.parse(get(key)||'null')}catch{return null}}
    function pair(){return {username:get(fields[0])||null,password:get(fields[1])||null};}
    function capture(){
        const current=pair(),saved=previous();
        if(saved&&saved.username===current.username&&saved.password===current.password)return saved;
        if(!saved&&!current.username&&!current.password)return null;
        const result={...current,updatedAt:saved?Math.max(Date.now(),saved.updatedAt+1):0};
        set(key,JSON.stringify(result));return result;
    }
    function changed(){const current=pair(),saved=previous();set(key,JSON.stringify({...current,updatedAt:Math.max(Date.now(),(saved?.updatedAt||0)+1)}));}
    wmStorage.setItem=function(name,value){set(name,value);if(fields.includes(name))changed();};
    wmStorage.removeItem=function(name){remove(name);if(fields.includes(name))changed();};
    function apply(record){
        if(!record||!Number.isSafeInteger(record.updatedAt)||record.updatedAt<0)return;
        for(const name of ['username','password'])if(record[name]!==null&&(typeof record[name]!=='string'||record[name].length>4096))return;
        if(record.username===null)remove(fields[0]);else set(fields[0],record.username);
        if(record.password===null)remove(fields[1]);else set(fields[1],record.password);
        set(key,JSON.stringify(record));
        if(typeof updateDelPassLabel==='function')updateDelPassLabel();
        if(typeof initUserChip==='function')initUserChip();
    }
    function restore(remote){
        const local=capture();
        if(!remote)return;
        const chosen=typeof WebMarkPasswordSyncCore!=='undefined'?WebMarkPasswordSyncCore.protection(local,remote):
            local&&local.updatedAt>remote.updatedAt?local:remote;
        apply(chosen);
    }
    globalThis.WebMarkBookmarkProtection={capture,apply,restore};
})();

const WebMarkPasswordSyncCore=(()=>{
    'use strict';
    const stable=value=>JSON.stringify(order(value));
    function order(value){
        if(Array.isArray(value))return value.map(order);
        if(value&&typeof value==='object')return Object.fromEntries(Object.keys(value).sort().map(key=>[key,order(value[key])]));
        return value;
    }
    function tombstones(a={},b={}){
        const result=Object.create(null);
        for(const source of [a,b])for(const [id,time]of Object.entries(source||{}))
            if(Number.isSafeInteger(time)&&time>0)result[id]=Math.max(time,result[id]||0);
        return result;
    }
    function records(a=[],b=[],removed={}){
        const map=new Map();
        for(const item of [...a,...b]){
            if(removed[item.id])continue;
            const prior=map.get(item.id);
            const winner=!prior||item.updatedAt>prior.updatedAt||
                (item.updatedAt===prior.updatedAt&&stable(item)>stable(prior))?item:prior;
            const dates=[prior?.createdAt,item.createdAt].filter(n=>Number.isSafeInteger(n)&&n>0);
            map.set(item.id,{...winner,...(dates.length?{createdAt:Math.min(...dates)}:{})});
        }
        return [...map.values()].sort((x,y)=>x.id.localeCompare(y.id));
    }
    function protection(a,b){
        const valid=value=>value&&Number.isSafeInteger(value.updatedAt)&&value.updatedAt>=0&&
            ['username','password'].every(key=>value[key]===null||(typeof value[key]==='string'&&value[key].length<=4096));
        const values=[a,b].filter(valid).sort((x,y)=>y.updatedAt-x.updatedAt||(stable(y)>stable(x)?1:stable(y)<stable(x)?-1:0));
        return values.length?{...values[0]}:null;
    }
    function merge(a,b){
        const deletedItems=tombstones(a.deletedItems,b.deletedItems),deletedFolders=tombstones(a.deletedFolders,b.deletedFolders);
        const folders=records(a.folders,b.folders,deletedFolders);
        const ids=new Set(folders.map(folder=>folder.id));
        const items=records(a.items,b.items,deletedItems).map(item=>({...item,folderId:ids.has(item.folderId)?item.folderId:''}));
        const credential=protection(a.bookmarkProtection,b.bookmarkProtection);
        return {groups:[],folders,items,deletedItems,deletedFolders,folderSchemaVersion:1,autoLock:120,...(credential?{bookmarkProtection:credential}:{})};
    }
    const portable=data=>merge(data,{items:[],folders:[]});
    function wrapping(local,remote){
        if(local.id!==remote.id)return remote;
        const a=local.keyUpdatedAt||0,b=remote.keyUpdatedAt||0;
        return a>b||(a===b&&stable(local.wrapped)>stable(remote.wrapped))?local:remote;
    }
    return {stable,merge,portable,wrapping,protection};
})();

(() => {
    'use strict';
    const C=WebMarkPasswordsCore,storageKey='wm_password_vault_v1';
    const tr=(text,values)=>globalThis.WebMarkInterfaceLocale?.text(text,values)??text;
    const $=id=>document.getElementById(id);
    const app=$('wm-passwords'),detail=$('wm-pw-detail'),editor=$('wm-pw-editor'),settings=$('wm-pw-settings');
    const preview=$('wm-pw-import-preview'),promptDialog=$('wm-pw-prompt');
    const folderEditor=$('wm-pw-folder-editor'),folderManager=$('wm-pw-folder-manager');
    let folderEditingId=null,folderDraftIcon='fa-solid fa-folder',page='home';
    let packet=null,raw=null,vault=null,currentId=null,list='all',selected=new Set(),selecting=false;
    let pendingImport=null,promptTask=null,nativeTask=null,epoch=0,busy=false,deviceBusy=false;
    let queue=Promise.resolve(),idleTimer,revealTimer,codeTimer,filePicker=false,pendingMethod='device';
    const categories=[
        ['all','All','key','#2d6fe8'],['passkeys','Passkeys','user-lock','#57b844'],
        ['code','Codes','clock','#d7a928'],['wifi','Wi-Fi','wifi','#52a3ce'],
        ['security','Security','exclamation','#e44739'],['deleted','Deleted','trash','#e58b2c']
    ];
    const element=(tag,text)=>{
        const node=document.createElement(tag);
        if(text!==undefined)node.textContent=text;
        return node;
    };
    function faceAvailable(){return !!globalThis.WebMarkAndroid?.passwordFaceAvailable?.();}
    function deviceAvailable(){return !!packet&&(globalThis.WebMarkAndroid?.passwordDeviceAvailable?.(packet.id)||globalThis.WebMarkPasswordDevice?.available(packet.id));}
    async function enableDevice(method='device') {
        if(!vault||!raw)return;
        if(globalThis.WebMarkAndroid?.passwordDeviceRequest)await native('enable-'+method,C.encode(raw));
        else if(globalThis.WebMarkPasswordDevice?.supported())await browserDevice('enable');
        else throw Error('Device unlock needs the Android app or a compatible HTTPS browser.');
        message('Device unlock linked. You can use the icons next time.',settings.open?'wm-pw-settings-status':'wm-pw-status');
    }
    async function offerDeviceUnlock(){
        if(deviceAvailable())return;
        const supported=globalThis.WebMarkAndroid?.passwordDeviceRequest||globalThis.WebMarkPasswordDevice?.supported();
        if(!supported)return;
        const key='wm_password_device_offered_'+packet.id;
        if(wmStorage.getItem(key)&&pendingMethod==='device')return;
        wmStorage.setItem(key,'1');
        try{await enableDevice(pendingMethod);}catch(error){message(error.name==='NotAllowedError'?'Device setup cancelled. Tap Device unlock to try again.':error.message);}
        pendingMethod='device';
    }
    function updateEditorType(){
        const type=$('wm-pw-type').value;
        $('wm-pw-sites-row').hidden=type==='pin';
        $('wm-pw-editor-secret-label').textContent=type==='pin'?tr('Code / PIN'):type==='code'?tr('Authenticator Base32 secret'):tr('Password');
        $('wm-pw-secret').inputMode=type==='pin'?'numeric':'text';
        $('wm-pw-secret').placeholder=type==='pin'?tr('Device, app, card or phone code'):'';
    }
    function icon(name) {
        const node=element('i');node.className='fa-solid fa-'+name;node.setAttribute('aria-hidden','true');return node;
    }
    function button(text,action,id) {
        const node=element('button',text);
        node.type='button';node.className='wm-pw-button';node.dataset.pwAction=action;
        if(id)node.dataset.pwId=id;
        return node;
    }
    const messagesByTarget=new Map();
    function message(text,target='wm-pw-status') {
        messagesByTarget.set(target,text);
        $(target).textContent=tr(text);
    }
    const date=value=>new Intl.DateTimeFormat(document.documentElement.lang||undefined,
        {dateStyle:'medium',timeStyle:'short'}).format(value);
    const current=()=>vault?.items.find(item=>item.id===currentId);
    function touch() {
        clearTimeout(idleTimer);
        if(vault)idleTimer=setTimeout(lock,(vault.autoLock||120)*1000);
    }
    function resetForm() {
        for(const id of ['wm-pw-name','wm-pw-user','wm-pw-secret','wm-pw-sites','wm-pw-notes'])$(id).value='';
        $('wm-pw-secret').type='password';
    }
    function clearDetail() {
        for(const id of ['wm-pw-detail-title','wm-pw-detail-user','wm-pw-detail-password',
            'wm-pw-detail-folder','wm-pw-detail-date','wm-pw-detail-notes','wm-pw-detail-security','wm-pw-detail-status'])$(id).textContent='';
        $('wm-pw-detail-sites').replaceChildren();
        $('wm-pw-copy-menu').hidden=true;
        clearTimeout(revealTimer);clearInterval(codeTimer);
    }
    function lock() {
        requestedSyncAccount=null;
        epoch++;page='home';list='all';
        raw?.fill(0);raw=null;vault=null;pendingImport=null;currentId=null;selected.clear();
        clearTimeout(idleTimer);
        for(const dialog of [detail,editor,settings,preview,promptDialog,folderEditor,folderManager,$('wm-pw-share-options')])if(dialog.open)dialog.close();
        clearDetail();resetForm();
        $('wm-pw-home-search').value='';$('wm-pw-search').value='';$('wm-pw-master').value='';$('wm-pw-master-confirm').value='';
        $('wm-pw-list').replaceChildren();$('wm-pw-folders').replaceChildren();
        $('wm-pw-manage-folders').replaceChildren();$('wm-pw-categories').replaceChildren();
        $('wm-pw-prompt-value').value='';
        $('wm-pw-main').hidden=true;$('wm-pw-locked').hidden=false;
        $('wm-pw-settings-status').textContent='';
        promptTask?.resolve(null);promptTask=null;
        message('');
        showLocked();
    }
    async function browserDevice(operation) {
        if(deviceBusy)throw Error('Device verification is already open.');
        const version=epoch,key=raw?.slice(),id=packet?.id;
        deviceBusy=true;
        try {
            const result=operation==='enable'?await WebMarkPasswordDevice.enable(id,key):
                operation==='disable'?await WebMarkPasswordDevice.disable():await WebMarkPasswordDevice.unlock(id);
            if(version!==epoch){result?.fill?.(0);throw Error('Vault locked. Try again.');}
            return result;
        }finally{key?.fill(0);deviceBusy=false;if(vault)touch();}
    }
    const syncCore=WebMarkPasswordSyncCore,syncOwnerKey='wm_password_sync_owner_v1';
    let syncBusy=false,syncTimer,lastCloudUser=null,requestedSyncAccount=null;
    let syncStatus='Unlock the vault to sync encrypted passwords.';
    const owner=()=>{try{return JSON.parse(wmStorage.getItem(syncOwnerKey)||'null')}catch{return null}};
    const autoSync=()=>false;
    function updateSyncStatus(){
        const user=globalThis.WebMarkCloud?.info().user;
        $('wm-pw-auto-sync').checked=autoSync();
        const last=wmStorage.getItem('wm_password_last_sync_v1');
        $('wm-pw-sync-status').textContent=(user?user.email+' · ':tr('Sign in to Google in WebMark Settings.')+' ')+tr(syncStatus)+
            (last?' · '+tr('Last sync:')+' '+new Date(Number(last)).toLocaleString(document.documentElement.lang):'');
    }
    function scheduleVaultSync(){clearTimeout(syncTimer);syncStatus='Manual sync · changes wait until you tap Sync now.';updateSyncStatus();}
    async function syncVault(manual=false,automatic=false){
        if(!manual||syncBusy)return;
        if(!manual&&(!autoSync()||editor.open||folderEditor.open||promptDialog.open||nativeTask||deviceBusy))return;
        const cloud=globalThis.WebMarkCloud,user=cloud?.info().user;
        if(!user){syncStatus='Sign in to Google to sync.';updateSyncStatus();return;}
        const binding=owner();
        if(binding&&binding.uid!==user.uid){syncStatus='This vault belongs to '+(binding.email||'another Google account')+'. Sign in with that account.';updateSyncStatus();return;}
        if(!navigator.onLine){syncStatus='Offline · encrypted changes saved on this device.';updateSyncStatus();return;}
        const revision=globalThis.WebMarkSyncCenter?.revision('passwords');
        syncBusy=true;syncStatus='Syncing encrypted vault…';updateSyncStatus();
        const version=epoch;let key=null,adoptedKey=null;
        const guard=()=>{if(epoch!==version||cloud.info().user?.uid!==user.uid)throw Error('Sync paused because the vault or account changed.');};
        try{
            await queue;guard();
            if(!vault)packet=readPacket();
            const local=packet?JSON.parse(JSON.stringify(packet)):null;
            const serialized=wmStorage.getItem(storageKey);
            const snapshot=vault?JSON.parse(JSON.stringify(vault)):null;
            const snapshotText=syncCore.stable(vault),protection=globalThis.WebMarkBookmarkProtection?.capture(),protectionVersion=syncCore.stable(protection);
            if(snapshot){const mergedProtection=syncCore.protection(snapshot.bookmarkProtection,protection);if(mergedProtection)snapshot.bookmarkProtection=mergedProtection;}
            key=raw?.slice();
            let remoteData=null;
            const unchanged=()=>{guard();if(wmStorage.getItem(storageKey)!==serialized||syncCore.stable(vault)!==snapshotText||syncCore.stable(globalThis.WebMarkBookmarkProtection?.capture())!==protectionVersion)throw Error('Local changes are waiting to sync.');};
            const next=await cloud.syncPasswordVault(user.uid,async(remote)=>{
                unchanged();
                if(remote)C.validate(remote);
                if(!snapshot){return null;}
                if(!remote){return C.save(local,key,syncCore.portable(snapshot));}
                let source=remote,cloudKey=key;
                if(remote.id!==local.id){
                    if(automatic)throw Error('Another vault is linked to Google. Use Sync now to merge with its vault password.');
                    const password=await ask(tr('Link Google vault'),tr('Enter the vault password used on your other device'),true);
                    if(!password)throw Error('Vault linking cancelled.');
                    const opened=await C.unlock(remote,password);adoptedKey?.fill(0);adoptedKey=opened.raw;cloudKey=adoptedKey;remoteData=opened.data;
                }else{remoteData=await C.read(remote,key);source=syncCore.wrapping(local,remote);}
                unchanged();
                const merged=syncCore.merge(snapshot,remoteData);
                if(syncCore.stable(merged)===syncCore.stable(syncCore.portable(remoteData))&&source===remote)return remote;
                const result=await C.save(source,cloudKey,merged);unchanged();return result;
            },manual,automatic);
            unchanged();
            if(!snapshot){
                if(!local&&next){await writePacket(next,false);packet=next;wmStorage.setItem(syncOwnerKey,JSON.stringify({uid:user.uid,email:user.email}));showLocked();syncStatus='Cloud vault ready. Unlock with your existing vault password.';}
                else syncStatus=local?'Unlock your vault to sync.':'No cloud vault yet. Create a vault to begin.';
            }else{
                const result=await C.read(next,adoptedKey||key);unchanged();
                const changed=next.id!==local.id||syncCore.stable(syncCore.portable(result))!==syncCore.stable(syncCore.portable(vault))||syncCore.stable(next.wrapped)!==syncCore.stable(local.wrapped);
                if(changed){
                    result.autoLock=snapshot.autoLock||120;
                    const localNext=await C.save(next,adoptedKey||key,result);unchanged();
                    await writePacket(localNext,false);guard();packet=localNext;vault=result;
                    if(adoptedKey){raw?.fill(0);raw=adoptedKey.slice();}
                    render();
                }
                globalThis.WebMarkBookmarkProtection?.apply(result.bookmarkProtection);
                wmStorage.setItem(syncOwnerKey,JSON.stringify({uid:user.uid,email:user.email}));
                wmStorage.setItem('wm_password_last_sync_v1',String(Date.now()));
                await wmStorage.flush?.();syncStatus='Encrypted passwords, folders and bookmark protection synced.';
                globalThis.WebMarkSyncCenter?.complete('passwords',user.uid,revision);
                if(adoptedKey)await offerDeviceUnlock();
                return true;
            }
        }catch(error){syncStatus=error.quota?error.message:tr('Saved on this device ·')+' '+error.message;}
        finally{key?.fill(0);adoptedKey?.fill(0);syncBusy=false;updateSyncStatus();}
    }

    if(globalThis.WebMarkCloud)WebMarkCloud.subscribe(info=>{
        if(lastCloudUser&&lastCloudUser!==info.user?.uid){
            requestedSyncAccount=null;
            if(vault)lock();
        }
        const changed=lastCloudUser!==info.user?.uid;lastCloudUser=info.user?.uid||null;
        if(changed&&vault)scheduleVaultSync();updateSyncStatus();
    });


    function readPacket() {
        const text=wmStorage.getItem(storageKey);
        return text?C.validate(JSON.parse(text)):null;
    }
    function showLocked() {
        $('wm-pw-lock-title').textContent=packet?tr('Passwords is locked'):tr('Create your password vault');
        $('wm-pw-unlock').textContent=packet?tr('Unlock'):tr('Create vault');
        $('wm-pw-confirm-row').hidden=!!packet;
        $('wm-pw-master-confirm').required=!packet;
        $('wm-pw-master').autocomplete=packet?'current-password':'new-password';
        $('wm-pw-master').minLength=packet?1:4;
        $('wm-pw-device').hidden=false;
        $('wm-pw-select').hidden=true;$('wm-pw-count').hidden=true;
        $('wm-pw-settings-button').hidden=false;$('wm-pw-lock-button').hidden=false;
        $('wm-pw-face-button').hidden=false;
        $('wm-pw-face-button').setAttribute('aria-disabled',String(!faceAvailable()));
        $('wm-pw-face-button').title=faceAvailable()?tr('Secure face unlock'):tr('Face unlock availability — tap for details');
        $('wm-pw-device-label').textContent=tr('Device unlock');
        $('wm-pw-unlock-form').hidden=!!packet;
    }
    async function openApp() {
        await wmStorage.ready;
        const menu=$('wm-app-menu');if(menu.open)menu.close();
        const notes=$('wm-notes-app');if(notes.open)notes.close();
        if(!app.open)app.showModal();
        globalThis.WebMarkAndroid?.passwordScreen?.(true);
        page='home';list='all';selecting=false;selected.clear();
        try{packet=readPacket();showLocked();if(!packet&&globalThis.WebMarkCloud?.info().user)message('Existing Google vault? Open Password settings and tap Sync now to load it.');}catch{message('The vault could not be read. Open an encrypted backup to recover it.');}
        if(vault)render();else showLocked();
    }
    async function openForSync(account) {
        if(!app.open)await openApp();
        if(!account||account!==globalThis.WebMarkCloud?.info().user?.uid||!app.open)return;
        requestedSyncAccount=account;
        if(vault)await resumeRequestedSync();
        else if(packet){
            if(settings.open)settings.close();
            message('Unlock your vault to continue Google sync.');
        }else{
            await syncVault(true);
            if(app.open)message(syncStatus);
        }
    }
    async function resumeRequestedSync() {
        const account=requestedSyncAccount;
        requestedSyncAccount=null;
        if(!account||account!==globalThis.WebMarkCloud?.info().user?.uid||!app.open)return false;
        message('Syncing encrypted passwords…');
        await syncVault(true);
        if(app.open)message(syncStatus);
        return true;
    }
    async function writePacket(next,localChange=true) {
        const previous=wmStorage.getItem(storageKey);
        try {
            wmStorage.setItem(storageKey,JSON.stringify(next));
            if(!wmStorage.persistent)throw Error('Storage unavailable');
            await wmStorage.flush?.();
            if(localChange)globalThis.WebMarkSyncCenter?.pending('passwords');
        } catch(error) {
            try{if(previous)wmStorage.setItem(storageKey,previous);else wmStorage.removeItem(storageKey);}catch{}
            throw error;
        }
    }
    async function unlock(event) {
        event.preventDefault();
        if(busy)return;
        busy=true;const version=epoch;
        const password=$('wm-pw-master').value;
        $('wm-pw-master').value='';
        message('Unlocking…');
        try{
            let opened,next;
            if(!packet){
                if(wmStorage.getItem(storageKey))throw Error('Existing vault could not be read. Open an encrypted backup.');
                if(password.length<4||password!==$('wm-pw-master-confirm').value)throw Error('Use at least 4 characters and enter the same password twice.');
                const created=await C.create(password);
                opened={raw:created.raw,data:{items:[],groups:[],folders:[],folderSchemaVersion:1,autoLock:120}};
                next=await C.save(created.packet,opened.raw,opened.data);
                if(version!==epoch){opened.raw.fill(0);return;}
                await writePacket(next);
            } else {
                opened=await C.unlock(packet,password);next=packet;
            }
            if(version!==epoch){opened.raw.fill(0);return;}
            packet=next;raw=opened.raw;vault=opened.data;globalThis.WebMarkBookmarkProtection?.restore(vault.bookmarkProtection);page='home';list='all';
            if(vault._folderMigration)await persist();
            $('wm-pw-master-confirm').value='';
            message('');render();touch();scheduleVaultSync();
            if(!await resumeRequestedSync())await offerDeviceUnlock();
        } catch(error){
            if(version===epoch)message(error.message.startsWith('Use at least')?error.message:tr('Could not unlock. Check your vault password or backup.'));
        } finally{busy=false;}
    }
    async function persist() {
        if(!vault||!raw)throw Error('Unlock the vault first.');
        const version=epoch,snapshot=JSON.parse(JSON.stringify(vault)),key=raw.slice();
        const task=queue.catch(()=>{}).then(async()=>{
            try{
                if(version!==epoch)throw Error('Vault locked. Try again.');
                const latest=readPacket();
                if(packet && latest && (latest.id!==packet.id||latest.revision!==packet.revision||
                    latest.payload.data!==packet.payload.data))throw Error('Vault changed in another tab. Lock and unlock to reload.');
                const next=await C.save(packet,key,snapshot);
                if(version!==epoch)throw Error('Vault locked. Try again.');
                await writePacket(next);
                if(version===epoch)packet=next;
            }finally{key.fill(0);}
        });
        queue=task;
        try{await task;scheduleVaultSync();}catch(error){lock();message('Could not save. '+error.message);throw error;}
    }
    function matches(item,mode,flags) {
        if(mode==='deleted')return !!item.deletedAt;
        if(item.deletedAt)return false;
        if(mode==='all')return true;
        if(mode==='security'){const issue=flags.get(item.id);return !!(issue?.short||issue?.reused);}
        if(mode==='code')return WebMarkCategories.credentialCategory(item)==='codes';
        if(mode==='wifi')return WebMarkCategories.credentialCategory(item)==='wifi';
        if(mode==='passkeys')return WebMarkCategories.credentialCategory(item)==='passkeys';
        return item.folderId===mode;
    }
    function itemsForView() {
        const q=$('wm-pw-search').value.trim().toLowerCase(),flags=C.security(vault.items);
        return vault.items.filter(item=>matches(item,list,flags)&&
            (!q||[item.title,item.username,...(item.websites||[])].join(' ').toLowerCase().includes(q)))
            .sort((a,b)=>$('wm-pw-sort').value==='recent'?b.updatedAt-a.updatedAt:a.title.localeCompare(b.title));
    }
    const folderPalette=['#7957dc','#168d87','#d85388','#dd861a','#3979d7','#bd6544'];
    function folderColor(folder) {
        let hash=0;for(const char of folder?.id||'personal')hash=(hash*31+char.charCodeAt(0))>>>0;
        return /^#[a-f0-9]{6}$/i.test(folder?.color||'')?folder.color:folderPalette[hash%folderPalette.length];
    }
    const folderIcons=typeof FA_ICONS!=='undefined'?[...new Set(FA_ICONS)]:['folder','users','globe','briefcase','house','heart','lock','wallet','credit-card','mobile-screen','gamepad','plane','book','star'].map(name=>'fa-solid fa-'+name);
    function folderGlyph(value){const node=element('i');node.className=/^fa-(solid|regular|brands) fa-[a-z0-9-]+$/.test(value||'')?value:'fa-solid fa-folder';node.setAttribute('aria-hidden','true');return node;}
    function folderOptions(value){$('wm-pw-folder').replaceChildren(new Option(tr('No folder'),''),...vault.folders.map(folder=>new Option(folder.name,folder.id)));$('wm-pw-folder').value=vault.folders.some(folder=>folder.id===value)?value:'';}
    function renderFolders(){
        $('wm-pw-manage-folders').replaceChildren(...vault.folders.map(folder=>{
            const row=element('div');row.className='wm-pw-toolbar wm-pw-folder-row';row.style.setProperty('--folder-color',folderColor(folder));
            row.append(folderGlyph(folder.icon),element('strong',folder.name),button(tr('Edit'),'edit-folder',folder.id),button(tr('Delete'),'delete-folder',folder.id));return row;
        }));
    }
    function renderFolderIcons(){
        const query=$('wm-pw-folder-icon-search').value.trim().toLowerCase().replaceAll(' ','-');
        $('wm-pw-folder-icons').replaceChildren(...folderIcons.filter(value=>value.includes(query)).map(value=>{
            const node=button('','folder-icon',value);node.append(folderGlyph(value));node.setAttribute('aria-label',value.split(' fa-').at(-1));node.setAttribute('aria-pressed',String(value===folderDraftIcon));node.style.color=$('wm-pw-folder-color').value;return node;
        }));
    }
    function openFolder(folder){
        folderEditingId=folder?.id||null;folderDraftIcon=folder?.icon||'fa-solid fa-folder';
        $('wm-pw-folder-heading').textContent=folder?tr('Edit folder'):tr('New folder');$('wm-pw-folder-name').value=folder?.name||'';
        $('wm-pw-folder-color').value=folder?.color||'#7957dc';$('wm-pw-folder-icon-search').value='';$('wm-pw-folder-status').textContent='';
        $('wm-pw-folder-colors').replaceChildren(...folderPalette.map(color=>{const node=button('','folder-color',color);node.style.background=color;node.setAttribute('aria-label',color);return node;}));
        renderFolderIcons();folderEditor.showModal();
    }
    async function saveFolder(event){
        event.preventDefault();if(!vault)return;
        try {
            const name=$('wm-pw-folder-name').value.trim();if(!name)throw Error('Enter a folder name.');
            const color=$('wm-pw-folder-color').value;if(!/^#[a-f0-9]{6}$/i.test(color))throw Error('Choose a valid color.');
            let folder=vault.folders.find(folder=>folder.id===folderEditingId);
            if(!folder){folder={id:crypto.randomUUID(),createdAt:Date.now()};vault.folders.push(folder);}
            folderEditingId=folder.id;
            Object.assign(folder,{name:name.slice(0,100),icon:folderDraftIcon,color,updatedAt:Math.max(Date.now(),(folder.updatedAt||0)+1)});
            await persist();folderEditor.close();folderOptions(editor.open?folder.id:$('wm-pw-folder').value);render();renderFolders();
        }catch(error){message(error.message,'wm-pw-folder-status');}
    }
    function siteIcon(item) {
        const node=element('span');node.className='wm-pw-site-icon';
        node.textContent=(item.title||'?').slice(0,1).toUpperCase();
        if(item.type==='password' && typeof detectSiteIcon==='function') {
            const site=detectSiteIcon((item.websites||[])[0]||'');
            if(site?.icon) {
                const glyph=element('i');glyph.className=site.icon;glyph.setAttribute('aria-hidden','true');
                node.textContent='';node.append(glyph);
                if(/^#[a-f0-9]{3,8}$/i.test(site.color||''))node.style.color=site.color;
            }
        }
        if(item.type==='password') {
            const safe=C.safeURL((item.websites||[])[0]||'');
            const host=safe?new URL(safe).hostname:'';
            if(/^[a-z0-9.-]+\.[a-z]{2,}$/i.test(host)&&!/(^|\.)(localhost|local|test|invalid|lan|internal)$/i.test(host)) {
                const logo=element('img');logo.alt='';logo.loading='lazy';logo.referrerPolicy='no-referrer';
                logo.src='https://www.google.com/s2/favicons?domain='+encodeURIComponent(host)+'&sz=128';
                const fallback=[...node.children];const letter=node.textContent;
                logo.addEventListener('error',()=>{node.replaceChildren(...fallback);if(!fallback.length)node.textContent=letter;});
                node.textContent='';node.append(logo);node.className+=' wm-pw-original-logo';
            }
        }
        if(item.type==='wifi'){node.textContent='';node.append(icon('wifi'));}
        if(item.type==='code'||item.type==='pin'){node.textContent='';node.append(icon(item.type==='pin'?'hashtag':'clock'));node.style.background='#d7a928';}
        return node;
    }
    function render() {
        if(!vault)return;
        $('wm-pw-main').hidden=false;$('wm-pw-locked').hidden=true;
        const flags=C.security(vault.items);
        $('wm-pw-categories').replaceChildren(...categories.map(([key,label,glyph,color])=>{
            const node=button('', 'view',key);node.className='wm-pw-tile';
            node.style.setProperty('--pw-tint',color);
            node.setAttribute('aria-pressed',String(key===list));
            node.append(icon(glyph),element('b',String(vault.items.filter(item=>matches(item,key,flags)).length)),
                element('span',tr(label)));return node;
        }));
        $('wm-pw-folders').replaceChildren(...vault.folders.map(folder=>{
            const node=button(folder.name,'view',folder.id);
            node.className='wm-pw-tile';node.style.setProperty('--pw-tint',folderColor(folder));
            node.textContent='';node.append(folderGlyph(folder.icon),element('b',String(vault.items.filter(item=>!item.deletedAt&&item.folderId===folder.id).length)),element('span',folder.name));return node;
        }));
        $('wm-pw-home').hidden=page!=='home';$('wm-pw-list-page').hidden=page!=='list';
        $('wm-pw-select').hidden=page!=='list';$('wm-pw-count').hidden=page!=='list';
        $('wm-pw-settings-button').hidden=page==='list';$('wm-pw-lock-button').hidden=page==='list';
        $('wm-pw-selection-bar').hidden=!selecting;
        const category=categories.find(row=>row[0]===list)?.[1];
        $('wm-pw-title').textContent=page==='home'?tr('Passwords'):(category&&tr(category))||vault.folders.find(folder=>folder.id===list)?.name||tr('Passwords');
        $('wm-pw-back').setAttribute('aria-label',page==='list'?tr('Back to password categories'):tr('Return to WebMark'));
        const rows=page==='list'?itemsForView():[],visible=new Set(rows.map(item=>item.id));
        for(const id of selected)if(!visible.has(id))selected.delete(id);
        $('wm-pw-list-title').textContent=(category&&tr(category))||
            vault.folders.find(folder=>folder.id===list)?.name||'All';
        $('wm-pw-count').textContent=tr('{count} items',{count:new Intl.NumberFormat(document.documentElement.lang).format(rows.length)});
        $('wm-pw-select').textContent=selecting?tr('Cancel'):tr('Select');
        $('wm-pw-select-all').hidden=!selecting;
        $('wm-pw-delete-selected').hidden=!selecting;
        $('wm-pw-delete-selected').disabled=!selected.size;
        $('wm-pw-recover-selected').hidden=!selecting||list!=='deleted';$('wm-pw-recover-selected').disabled=!selected.size;
        $('wm-pw-list').replaceChildren(...rows.map(item=>{
            const node=button('',selecting?'pick':'detail',item.id);node.className='wm-pw-row';if(selecting)node.setAttribute('aria-pressed',String(selected.has(item.id)));
            const text=element('span');text.className='wm-pw-row-text';
            text.append(element('strong',item.title),element('small',item.username||item.source||item.type));
            node.append(siteIcon(item),text);
            const issue=flags.get(item.id);
            if(issue?.short||issue?.reused){const warning=icon('circle-exclamation');warning.className+=' wm-pw-warning';warning.title=tr('Short or reused password');node.append(warning);}
            node.append(icon(selecting?(selected.has(item.id)?'square-check':'square'):'chevron-right'));
            return node;
        }));
        if(page==='list'&&!rows.length)$('wm-pw-list').append(element('p',list==='passkeys'
            ?'No saved passkey references. Your phone or browser manages actual passkeys.':'No passwords here.'));
    }
    function showDetail(item) {
        currentId=item.id;clearDetail();
        $('wm-pw-detail-title').textContent=item.title;
        $('wm-pw-detail-icon').replaceChildren(siteIcon(item));
        const folder=vault.folders.find(folder=>folder.id===item.folderId);
        $('wm-pw-detail-folder').textContent=folder?.name||tr('Personal');
        $('wm-pw-detail-folder').style.setProperty('--folder-color',folderColor(folder));
        $('wm-pw-detail-user').textContent=item.username||'—';
        $('wm-pw-secret-label').textContent=item.type==='code'?tr('Authenticator code'):item.type==='pin'?tr('Code / PIN'):tr('Password');
        $('wm-pw-detail-password').textContent='••••••••';
        $('wm-pw-detail-date').textContent=date(item.updatedAt);
        $('wm-pw-detail-notes').textContent=item.notes||'';
        $('wm-pw-detail-sites').replaceChildren(...(item.websites||[]).map(value=>{
            const url=C.safeURL(value);
            if(!url)return element('span',value);
            const link=element('a',new URL(url).hostname);link.href=url;link.target='_blank';link.rel='noopener noreferrer';return link;
        }));
        const issue=C.security(vault.items).get(item.id);
        $('wm-pw-detail-security').textContent=[issue?.short?tr('Short password'):null,issue?.reused?tr('Password reused in this vault'):null].filter(Boolean).join(' · ');
        $('wm-pw-detail-actions').replaceChildren(...(item.deletedAt
            ?[button(tr('Recover'),'restore-item'),button(tr('Delete permanently'),'purge')]
            :[button(tr('Move to Deleted'),'delete')]));
        if(!detail.open)detail.showModal();
    }
    async function reveal() {
        const item=current();if(!item)return;
        const version=epoch;
        const show=async()=>{
            const value=item.type==='code'?await C.totp(item.password):item.password;
            if(epoch!==version||!detail.open)return;
            $('wm-pw-detail-password').textContent=value;
        };
        await show();
        $('wm-pw-copy-menu').hidden=false;
        clearTimeout(revealTimer);clearInterval(codeTimer);
        revealTimer=setTimeout(hideSecret,20000);
        if(item.type==='code')codeTimer=setInterval(()=>show().catch(()=>{}),1000);
    }
    function hideSecret() {
        $('wm-pw-detail-password').textContent='••••••••';$('wm-pw-copy-menu').hidden=true;
        clearTimeout(revealTimer);clearInterval(codeTimer);
    }
    function updateFolderSuggestion(){
        if(!vault)return;
        const suggested=WebMarkCategories.category({title:$('wm-pw-name').value,websites:$('wm-pw-sites').value.split('\n'),type:$('wm-pw-type').value});
        $('wm-pw-folder-suggestion').textContent='Suggested folder: '+suggested.name;
    }
    async function useSuggestedFolder(){
        const folder=WebMarkCategories.folder(vault,{title:$('wm-pw-name').value,websites:$('wm-pw-sites').value.split('\n'),type:$('wm-pw-type').value});
        await persist();folderOptions(folder.id);updateFolderSuggestion();
    }
    async function organizeUnfiled(){
        let count=0;
        for(const item of vault.items)if(!item.deletedAt&&!vault.folders.some(folder=>folder.id===item.folderId)){
            item.folderId=WebMarkCategories.folder(vault,item).id;item.updatedAt=Math.max(Date.now(),item.updatedAt+1);count++;
        }
        if(count)await persist();
        render();renderFolders();message(count+' unfiled entries organized.','wm-pw-settings-status');
    }

    function edit(item) {
        currentId=item?.id||null;resetForm();
        $('wm-pw-editor-title').textContent=item?tr('Edit password'):tr('New password');
        $('wm-pw-name').value=item?.title||'';
        $('wm-pw-user').value=item?.username||'';
        $('wm-pw-secret').value=item?.password||'';
        $('wm-pw-type').value=item?.type||(list==='code'?'pin':list==='wifi'?'wifi':'password');
        $('wm-pw-sites').value=(item?.websites||[]).join('\n');
        $('wm-pw-notes').value=item?.notes||'';
        $('wm-pw-folder').replaceChildren(new Option(tr('No folder'),''),...vault.folders.map(folder=>new Option(folder.name,folder.id)));
        $('wm-pw-folder').value=item?.folderId||(vault.folders.some(folder=>folder.id===list)?list:'');
        updateEditorType();updateFolderSuggestion();
        $('wm-pw-editor-status').textContent='';
        editor.showModal();
    }
    async function saveItem(event) {
        event.preventDefault();
        if(busy||!vault)return;
        busy=true;
        const version=epoch;
        try{
            const name=$('wm-pw-name').value.trim(),password=$('wm-pw-secret').value;
            if(!name||!password)throw Error('Name and password are required.');
            const type=$('wm-pw-type').value;
            if($('wm-pw-folder').value&&!vault.folders.some(folder=>folder.id===$('wm-pw-folder').value))throw Error('Choose an existing folder or create one.');
            const websites=[];
            for(const line of (type==='pin'?[]:$('wm-pw-sites').value.split('\n').filter(line=>line.trim()))){
                const url=C.safeURL(line);if(!url)throw Error('Use valid HTTP or HTTPS website links.');websites.push(url);
            }
            if(type==='code')await C.totp(password);
            if(version!==epoch)return;
            let item=current();
            if(!item){item={id:crypto.randomUUID(),createdAt:Date.now(),source:'Personal'};vault.items.push(item);}
            Object.assign(item,{title:name,username:$('wm-pw-user').value,password,type,websites,
                notes:$('wm-pw-notes').value,folderId:$('wm-pw-folder').value,updatedAt:Math.max(Date.now(),item.updatedAt+1||0)});
            await persist();
            if(version!==epoch)return;
            editor.close();showDetail(item);render();
        }catch(error){if(version===epoch)message(error.message,'wm-pw-editor-status');}finally{busy=false;}
    }
    function ask(title,label,secret=false) {
        if(promptTask)return Promise.resolve(null);
        $('wm-pw-prompt-title').textContent=title;$('wm-pw-prompt-label').textContent=label;
        $('wm-pw-prompt-value').value='';$('wm-pw-prompt-value').type=secret?'password':'text';
        $('wm-pw-prompt-value').minLength=secret?4:1;$('wm-pw-prompt-status').textContent='';
        return new Promise(resolve=>{promptTask={resolve,version:epoch};promptDialog.showModal();});
    }
    async function shareOne(item){
        const password=item.type==='code'?await C.totp(item.password):item.password;
        const text=[item.title,item.username?'Username / email: '+item.username:'',
            'Password / code: '+password,...item.websites].filter(Boolean).join('\n');
        if(globalThis.WebMarkAndroid?.shareText){WebMarkAndroid.shareText(text);return;}
        if(navigator.share){await navigator.share({title:item.title,text});return;}
        const menu=$('wm-pw-share-options');menu.replaceChildren(element('h2','Share '+item.title),element('p','The selected app receives this password.'));
        const email=element('a','Gmail / email');email.className='wm-pw-button';email.href='mailto:?subject='+encodeURIComponent(item.title)+'&body='+encodeURIComponent(text);
        email.addEventListener('click',()=>menu.close(),{once:true});
        const copy=button(tr('Copy login'),'');copy.addEventListener('click',async()=>{await wmCopy(text);menu.close();},{once:true});
        const close=button(tr('Cancel'),'');close.addEventListener('click',()=>menu.close(),{once:true});menu.append(email,copy,close);menu.showModal();
        menu.addEventListener('close',()=>menu.replaceChildren(),{once:true});
    }
    async function shareEncrypted(items) {
        if(!items.length){message('There are no entries to export.','wm-pw-settings-status');return;}
        const version=epoch;
        const password=await ask('Share encrypted passwords','Create a sharing password of at least 4 characters',true);
        if(!password||version!==epoch)return;
        const created=await C.create(password);
        try{
            const data={items:items.map(item=>({...item,folderId:''})),groups:[],folders:[],folderSchemaVersion:1,autoLock:120};
            const shared=await C.save(created.packet,created.raw,data);
            if(version!==epoch)return;
            const text=JSON.stringify(shared);
            const file=new File([text],'WebMark-Shared-Passwords.webmark',{type:'application/json'});
            if(navigator.canShare?.({files:[file]})&&navigator.share){
                try {await navigator.share({files:[file],title:'Encrypted passwords'});}
                catch(error){
                    if(error.name==='AbortError')return;
                    wmDownload(file.name,text,'application/json');
                }
            } else wmDownload(file.name,text,'application/json');
            message('Encrypted file ready. Send the sharing password separately.','wm-pw-settings-status');
        }finally{created.raw.fill(0);}
    }
    async function loadCSV(event) {
        filePicker=false;
        const file=event.target.files?.[0];event.target.value='';
        if(!file||!vault)return;
        const version=epoch;
        try{
            if(file.size>5*1024*1024)throw Error('Choose a CSV smaller than 5 MB.');
            const text=await file.text();
            if(version!==epoch)return;
            pendingImport=C.importCSV(text,$('wm-pw-import-source').value);
            $('wm-pw-import-count').textContent=pendingImport.length+' passwords found. Their values stay hidden in this preview.';
            preview.showModal();
        }catch(error){message(error.message,'wm-pw-settings-status');}
    }
    async function confirmImport() {
        if(!pendingImport||!vault||busy)return;
        busy=true;
        try{
            const identity=item=>JSON.stringify([item.title,item.username,item.password,item.websites]);
            const existing=new Set(vault.items.filter(item=>!item.deletedAt).map(identity));
            let count=0;
            for(const item of pendingImport){const key=identity(item);if(!existing.has(key)){existing.add(key);item.folderId=$('wm-pw-import-auto-folders').checked?WebMarkCategories.folder(vault,item).id:(vault.folders.some(folder=>folder.id===list)?list:'');vault.items.push(item);count++;}}
            pendingImport=null;await persist();preview.close();render();
            message(count+' passwords imported.','wm-pw-settings-status');
        }finally{busy=false;}
    }
    async function restoreFile(event) {
        filePicker=false;
        const file=event.target.files?.[0];event.target.value='';
        if(!file)return;
        const version=epoch;
        try{
            if(file.size>20*1024*1024)throw Error('Choose a backup smaller than 20 MB.');
            const restored=C.validate(JSON.parse(await file.text()));
            if(version!==epoch)return;
            const password=await ask('Open encrypted file','Password for this file',true);
            if(!password||version!==epoch)return;
            const opened=await C.unlock(restored,password);
            try{
                if(version!==epoch)return;
                if(vault){
                    if(!confirm('Merge '+opened.data.items.length+' entries from this encrypted file into your vault?'))return;
                    const folderMap=new Map();
                    for(const folder of opened.data.folders){
                        let local=vault.folders.find(candidate=>candidate.name===folder.name&&candidate.color===folder.color&&candidate.icon===folder.icon);
                        if(!local){local={...folder,id:crypto.randomUUID()};vault.folders.push(local);}
                        folderMap.set(folder.id,local.id);
                    }
                    const known=new Set(vault.items.map(item=>JSON.stringify([item.title,item.username,item.password,item.websites])));
                    for(const entry of opened.data.items){
                        const fingerprint=JSON.stringify([entry.title,entry.username,entry.password,entry.websites]);
                        if(!known.has(fingerprint)){known.add(fingerprint);vault.items.push({...entry,id:crypto.randomUUID(),folderId:folderMap.get(entry.folderId)||'',source:'Encrypted import'});}
                    }
                    await persist();render();message('Encrypted entries imported.','wm-pw-settings-status');
                } else {
                    if(packet&&!confirm('Replace the locked vault on this device with this backup? Export a backup of the current vault first if you need it.'))return;
                    await writePacket(restored);
                    if(version!==epoch)return;
                    packet=restored;raw=opened.raw.slice();vault=opened.data;globalThis.WebMarkBookmarkProtection?.restore(vault.bookmarkProtection);page='home';list='all';
                    if(vault._folderMigration)await persist();render();touch();await offerDeviceUnlock();
                }
            }finally{opened.raw.fill(0);}
        }catch(error){message('Could not open the encrypted file. '+error.message);}
    }
    async function native(operation,value) {
        if(!globalThis.WebMarkAndroid?.passwordDeviceRequest)throw Error('Device unlock is available in the Android app.');
        if(nativeTask)throw Error('Device authentication is already open.');
        const request=crypto.randomUUID();
        return new Promise((resolve,reject)=>{
            const timer=setTimeout(()=>{if(nativeTask?.request===request){nativeTask=null;reject(Error('Device authentication expired.'));}},90000);
            nativeTask={request,resolve,reject,timer,version:epoch};
            WebMarkAndroid.passwordDeviceRequest(request,operation,packet.id,value||'');
        });
    }
    function navigateBack(){
        if(!app.open)return false;
        if(editor.open){const item=vault?.items.find(row=>row.id===currentId);const dirty=[['wm-pw-name','title'],['wm-pw-user','username'],['wm-pw-secret','password'],['wm-pw-notes','notes']].some(([id,key])=>$(id).value!==(item?.[key]||''))||$('wm-pw-sites').value!==(item?.websites||[]).join('\n');if(dirty&&!confirm('Discard unsaved password changes?'))return true;}
        for(const dialog of [$('wm-pw-share-options'),folderEditor,promptDialog,preview,editor,folderManager,settings,detail])if(dialog.open){dialog.close();if(dialog===preview)pendingImport=null;return true;}
        if(vault&&page==='list'){page='home';list='all';selecting=false;selected.clear();$('wm-pw-search').value='';render();return true;}
        lock();app.close();globalThis.WebMarkAndroid?.passwordScreen?.(false);return true;
    }
    async function handle(event) {
        const control=event.target.closest('[data-pw-action]');
        if(!control)return;
        let action=control.dataset.pwAction,id=control.dataset.pwId;
        try{
            if(action==='open'){await openApp();return;}
            if(action==='back'){navigateBack();return;}
            if(action==='lock'){lock();return;}
            if(action==='sync-vault'){
                const account=globalThis.WebMarkCloud?.info().user?.uid;
                if(account&&!vault)await openForSync(account);
                else await syncVault(true);
                return;
            }
            if(action==='restore'){filePicker=true;$('wm-pw-restore-file').click();return;}
            if(action==='cancel-prompt'){promptDialog.close();return;}
            if(action==='unlock-password'){$('wm-pw-unlock-form').hidden=false;$('wm-pw-master').focus();return;}
            if(action==='unlock-face'&&!faceAvailable()){message(globalThis.WebMarkAndroid?'Android does not offer separate secure face unlock on this device. Fingerprint / device PIN and your vault password remain available.':'Your browser controls biometric verification and cannot select face separately. Use Device unlock or your vault password.');globalThis.WebMarkAndroid?.explainFaceUnlock?.(document.documentElement.lang||'en');return;}
            if(action==='unlock-face'||action==='unlock-fingerprint'){
                pendingMethod=action==='unlock-face'?'face':'device';
                if(vault){await enableDevice(pendingMethod);return;}
                if(!packet){message('Create your vault first. Device unlock will be offered automatically.');$('wm-pw-master').focus();return;}
                if(!deviceAvailable()){
                    message('Unlock with your vault password once to link this device.');$('wm-pw-unlock-form').hidden=false;$('wm-pw-master').focus();return;
                }
                action='device-unlock';
            }
            if(action==='device-unlock'){
                const version=epoch;
                const candidate=globalThis.WebMarkAndroid?.passwordDeviceRequest
                    ? C.decode(await native('unlock-'+pendingMethod)) : await browserDevice('unlock');
                try {
                    const data=await C.read(packet,candidate);
                    if(epoch!==version)return;
                    raw=candidate.slice();vault=data;
                    globalThis.WebMarkBookmarkProtection?.restore(vault.bookmarkProtection);
                    page='home';list='all';
                    if(vault._folderMigration)await persist();
                    render();touch();scheduleVaultSync();
                    await resumeRequestedSync();
                } finally{candidate.fill(0);}
                return;
            }
            if(action==='backup'){
                await queue.catch(()=>{});
                const serialized=wmStorage.getItem(storageKey);
                if(serialized)wmDownload('WebMark-Passwords-Encrypted.webmark',serialized,'application/json');
                return;
            }
            if(action==='settings'){
                $('wm-pw-auto-lock').value=String(vault?.autoLock||120);
                $('wm-pw-enable-device').hidden=!(globalThis.WebMarkAndroid?.passwordDeviceRequest || globalThis.WebMarkPasswordDevice?.supported());
                if(vault)renderFolders();
                settings.querySelectorAll('[data-pw-action]').forEach(node=>{node.disabled=!vault&&!['close-settings','restore','backup','sync-vault'].includes(node.dataset.pwAction);});
                $('wm-pw-auto-lock').disabled=!vault;updateSyncStatus();
                settings.showModal();return;
            }
            if(action==='close-settings'){settings.close();return;}
            if(!vault)return;
            touch();
            if(action==='suggest-folder'){await useSuggestedFolder();return;}
            if(action==='organize-passwords'){await organizeUnfiled();return;}
            if(action==='new'){edit();return;}
            if(action==='edit'){const item=current();if(item&&!item.deletedAt){detail.close();edit(item);}return;}
            if(action==='cancel-edit'){editor.close();return;}
            if(action==='close-detail'){detail.close();return;}
            if(action==='view'){if(!categories.some(c=>c[0]===id)&&!vault.folders.some(folder=>folder.id===id))return;list=id;page='list';selecting=false;selected.clear();$('wm-pw-search').value='';render();return;}
            if(action==='detail'){const item=vault.items.find(item=>item.id===id);if(item)showDetail(item);return;}
            if(action==='password'){await reveal();return;}
            if(action==='username'){$('wm-pw-copy-menu').hidden=false;return;}
            if(action==='hide-password'){hideSecret();return;}
            if(action==='copy-user'||action==='copy-password'){
                const item=current();if(!item)return;
                const version=epoch;
                const text=action==='copy-user'?item.username:item.type==='code'?await C.totp(item.password):item.password;
                if(version!==epoch)return;
                if(globalThis.WebMarkAndroid?.copyPasswordField)WebMarkAndroid.copyPasswordField(text);
                else await wmCopy(text);
                message(tr('Copied.'),'wm-pw-detail-status');return;
            }
            if(action==='edit-reveal'){$('wm-pw-secret').type=$('wm-pw-secret').type==='password'?'text':'password';return;}
            if(action==='generate'){
                if($('wm-pw-type').value==='pin'){let pin='';while(pin.length<6){const n=crypto.getRandomValues(new Uint8Array(1))[0];if(n<250)pin+=n%10;}$('wm-pw-secret').value=pin;return;}
                if($('wm-pw-type').value==='code'){message('Paste the Base32 secret supplied by the website.','wm-pw-editor-status');return;}
                $('wm-pw-secret').value=C.generate();return;
            }
            if(action==='import'){filePicker=true;$('wm-pw-import-file').click();return;}
            if(action==='cancel-import'){preview.close();pendingImport=null;return;}
            if(action==='confirm-import'){await confirmImport();return;}
            if(action==='change-password'){
                const version=epoch;
                const old=await ask(tr('Confirm vault password'),'Current vault password',true);
                if(!old||version!==epoch)return;
                const verified=await C.unlock(packet,old);verified.raw.fill(0);
                const nextPassword=await ask('New vault password','At least 4 characters',true);
                if(!nextPassword||version!==epoch)return;
                const confirmation=await ask('Confirm new vault password','Enter it again',true);
                if(!confirmation||version!==epoch)return;
                if(nextPassword!==confirmation)throw Error('Passwords do not match.');
                await queue;
                const updated=await C.changePassword(packet,raw,nextPassword);
                if(version!==epoch)return;
                await writePacket(updated);
                packet=updated;scheduleVaultSync();
                message('Vault password changed. Save a new encrypted backup.','wm-pw-settings-status');
                return;
            }
            if(action==='enable-device'){await enableDevice('device');return;}
            if(action==='select'){selecting=!selecting;selected.clear();render();return;}
            if(action==='pick'){if(!selecting)return;if(selected.has(id))selected.delete(id);else if(itemsForView().some(item=>item.id===id))selected.add(id);render();return;}
            if(action==='select-all'){for(const item of itemsForView())selected.add(item.id);render();return;}
            if(['delete','purge','delete-selected'].includes(action)){
                const items=action==='delete-selected'?vault.items.filter(item=>selected.has(item.id)):[current()].filter(Boolean);
                if(!items.length||!confirm((action==='purge'||list==='deleted'?'Permanently delete ':'Move to Deleted ')+items.length+' entry(s)?'))return;
                for(const item of items){
                    if(item.deletedAt){(vault.deletedItems??={})[item.id]=Date.now();vault.items=vault.items.filter(row=>row!==item);}
                    else {item.deletedAt=Date.now();item.updatedAt=Date.now();}
                }
                await persist();if(detail.open)detail.close();selected.clear();render();return;
            }
            if(action==='recover-selected'){for(const item of vault.items)if(item.deletedAt&&selected.has(item.id)){delete item.deletedAt;item.updatedAt=Math.max(Date.now(),item.updatedAt+1);}await persist();selected.clear();render();return;}
            if(action==='restore-item'){const item=current();if(item){delete item.deletedAt;item.updatedAt=Math.max(Date.now(),item.updatedAt+1);await persist();detail.close();render();}return;}
            if(action==='manage-folders'){renderFolders();folderManager.showModal();return;}
            if(action==='close-folder-manager'){folderManager.close();return;}
            if(action==='new-folder'){openFolder();return;}
            if(action==='edit-folder'){openFolder(vault.folders.find(folder=>folder.id===id));return;}
            if(action==='cancel-folder'){folderEditor.close();return;}
            if(action==='folder-icon'){if(folderIcons.includes(id)){folderDraftIcon=id;renderFolderIcons();}return;}
            if(action==='folder-color'){if(/^#[a-f0-9]{6}$/i.test(id)){$('wm-pw-folder-color').value=id;renderFolderIcons();}return;}
            if(action==='delete-folder'){
                if(!confirm('Delete this folder? Its entries will stay in All.'))return;
                (vault.deletedFolders??={})[id]=Date.now();vault.folders=vault.folders.filter(folder=>folder.id!==id);
                for(const item of vault.items)if(item.folderId===id)item.folderId='';
                if(list===id){page='home';list='all';}
                await persist();render();renderFolders();folderOptions($('wm-pw-folder').value);return;
            }
            if(action==='share-one'){const item=current();if(item&&!item.deletedAt)await shareOne(item);return;}
            if(action==='share-all'){await shareEncrypted(vault.items.filter(item=>!item.deletedAt));return;}
        }catch(error){if(error.name!=='AbortError')message(error.message,settings.open?'wm-pw-settings-status':editor.open?'wm-pw-editor-status':'wm-pw-status');}
    }
    globalThis.WebMarkInterfaceLocale?.onChange(()=>{
        updateSyncStatus();
        if(!app.open)return;
        if(vault)render();else showLocked();
        const status=$('wm-pw-status');
        const messageKey=messagesByTarget.get('wm-pw-status');
        if(messageKey&&status.textContent)status.textContent=tr(messageKey);
        if(editor.open)updateEditorType();
        if(folderManager.open&&vault)renderFolders();
    });
    document.addEventListener('click',event=>handle(event));
    $('wm-pw-unlock-form').addEventListener('submit',unlock);
    $('wm-pw-form').addEventListener('submit',saveItem);
    $('wm-pw-search').addEventListener('input',render);
    $('wm-pw-home-search').addEventListener('input',()=>{if(!vault)return;list='all';page='list';$('wm-pw-search').value=$('wm-pw-home-search').value;$('wm-pw-home-search').value='';render();$('wm-pw-search').focus();});
    $('wm-pw-folder-form').addEventListener('submit',saveFolder);
    $('wm-pw-folder-icon-search').addEventListener('input',renderFolderIcons);
    $('wm-pw-folder-color').addEventListener('input',renderFolderIcons);
    $('wm-pw-type').addEventListener('change',()=>{updateEditorType();updateFolderSuggestion();});
    for(const id of ['wm-pw-name','wm-pw-sites'])$(id).addEventListener('input',updateFolderSuggestion);
    $('wm-pw-sort').addEventListener('change',render);
    $('wm-pw-import-file').addEventListener('change',loadCSV);
    $('wm-pw-restore-file').addEventListener('change',restoreFile);
    $('wm-pw-auto-lock').addEventListener('change',async()=>{
        if(!vault)return;vault.autoLock=Number($('wm-pw-auto-lock').value);await persist();touch();
    });
    $('wm-pw-prompt-form').addEventListener('submit',event=>{
        event.preventDefault();const pending=promptTask;if(!pending)return;
        const value=$('wm-pw-prompt-value').value;
        if(!value||($('wm-pw-prompt-value').type==='password'&&value.length<4))return;
        promptTask=null;promptDialog.close();$('wm-pw-prompt-value').value='';
        pending.resolve(pending.version===epoch?value:null);
    });
    promptDialog.addEventListener('close',()=>{
        if(promptDialog.open)return;
        const pending=promptTask;promptTask=null;$('wm-pw-prompt-value').value='';pending?.resolve(null);
    });
    detail.addEventListener('close',clearDetail);
    editor.addEventListener('close',resetForm);
    app.addEventListener('close',()=>{lock();globalThis.WebMarkAndroid?.passwordScreen?.(false);});
    for(const id of ['wm-pw-import-file','wm-pw-restore-file'])$(id).addEventListener('cancel',()=>{filePicker=false;});
    document.addEventListener('visibilitychange',()=>{
        if(document.hidden && !nativeTask && !deviceBusy && !filePicker)lock();
    });
    document.addEventListener('pointerdown',()=>{if(vault)touch();},{passive:true});
    document.addEventListener('keydown',()=>{if(vault)touch();},{passive:true});
    globalThis.addEventListener?.('pagehide',lock);
    globalThis.addEventListener?.('storage',event=>{
        if(event.key===storageKey&&vault){lock();message('Vault changed in another tab. Unlock to reload.');}
    });
    window.WebMarkPasswords={
        lock,back:navigateBack,sync:syncVault,syncStatus:()=>tr(syncStatus),unlocked:()=>!!vault,open:openApp,openForSync,
        nativeResult(request,value,error){
            const pending=nativeTask;
            if(!pending||pending.request!==request)return;
            nativeTask=null;clearTimeout(pending.timer);
            if(pending.version!==epoch)pending.reject(Error('Vault locked.'));
            else if(error)pending.reject(Error(error));
            else pending.resolve(value);
        }
    };
})();

