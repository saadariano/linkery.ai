
/* WebMark's shared merge protocol. No network calls or credentials in this module. */
(function(root){
'use strict';
function uid(){return crypto.randomUUID?crypto.randomUUID():Array.from(crypto.getRandomValues(new Uint8Array(16)),b=>b.toString(16).padStart(2,'0')).join('')}
function compare(a,b){if(!a)return -1;if(!b)return 1;return (a.ts-b.ts)||String(a.device).localeCompare(String(b.device))||Number(a.deleted)-Number(b.deleted)}
// The saved date belongs to the bookmark, while its ID and edit clock serve other purposes.
function savedTimestamp(value){
 return Number.isSafeInteger(value)&&value>=Date.UTC(1990,0,1)&&value<=8640000000000000?value:null;
}
function bookmarkDate(bookmark){
 return bookmark?.addedAt===null?null:savedTimestamp(bookmark?.addedAt)??savedTimestamp(bookmark?.id);
}
function earlierDate(a,b){
 return a===null?b:b===null?a:Math.min(a,b);
}
function merge(a,b){
 const out={...a};
 for(const [key,record] of Object.entries(b||{})){
  if(!valid(record,key))continue;
  const previous=out[key];
  const winner=!previous||compare(record,previous)>0?record:previous;
  const date=earlierDate(savedTimestamp(record.data.addedAt),savedTimestamp(previous?.data.addedAt));
  out[key]=winner.kind==='link'&&date!==null&&winner.data.addedAt!==date
   ?{...winner,data:{...winner.data,addedAt:date}}:winner;
 }
 return out;
}
function needsUpload(record,remote){
 return !remote||compare(record,remote)>0||
  (record.kind==='link'&&savedTimestamp(record.data.addedAt)!==savedTimestamp(remote.data.addedAt));
}
function recoverBookmarkDates(records,snapshot){
 let result=records;
 for(const bookmark of snapshot.l||[]){
  const record=Object.hasOwn(records,bookmark._syncKey)?records[bookmark._syncKey]:null;
  if(record?.kind!=='link'||record.deleted)continue;
  const known=savedTimestamp(record.data.addedAt);
  const recovered=earlierDate(known,bookmarkDate(bookmark));
  if(recovered===known)continue;
  if(result===records)result={...records};
  result[record.key]={...record,data:{...record.data,addedAt:recovered}};
 }
 return result;
}
function valid(r,key){return r&&['link','folder'].includes(r.kind)&&typeof r.key==='string'&&r.key===key&&/^[a-zA-Z0-9-]{8,80}$/.test(key)&&Number.isSafeInteger(r.ts)&&r.ts>0&&typeof r.device==='string'&&typeof r.deleted==='boolean'&&r.data&&typeof r.data==='object'&&!Array.isArray(r.data)}
function safeURL(raw){try{let s=String(raw||'').trim();if(!/^[a-z][a-z0-9+.-]*:/i.test(s))s='https://'+s;const u=new URL(s);return ['https:','http:'].includes(u.protocol)?u.href:null}catch{return null}}
function pack(snapshot,previous,device){
 const records={...previous};let clock=Math.max(Date.now(),...Object.values(previous||{}).map(r=>r.ts));const seen=new Set(),folderKeys=new Map();
 for(const f of snapshot.f||[]){if(!/^[a-zA-Z0-9-]{8,80}$/.test(f._syncKey||''))f._syncKey=uid();folderKeys.set(f.id,f._syncKey)}
 for(const kind of ['folder','link']){const rows=kind==='folder'?snapshot.f:snapshot.l;for(const [order,item]of (rows||[]).entries()){
  if(!/^[a-zA-Z0-9-]{8,80}$/.test(item._syncKey||''))item._syncKey=uid();const key=item._syncKey;seen.add(key);const data={...item,order};delete data.id;delete data._syncKey;
  const old=records[key];
  if(kind==='link'){
   data.folderKey=folderKeys.get(item.fId)||null;
   delete data.fId;
   if(!safeURL(data.url))continue;
   data.url=safeURL(data.url);
   const addedAt=earlierDate(bookmarkDate(item),savedTimestamp(old?.data.addedAt));
   delete data.addedAt;
   if(addedAt!==null)data.addedAt=addedAt;
  }
  if(!old||old.deleted||JSON.stringify(old.data)!==JSON.stringify(data))records[key]={key,kind,data,ts:++clock,device,deleted:false};
 }}
 for(const [key,old]of Object.entries(previous||{})){if(!seen.has(key)&&!old.deleted)records[key]={...old,ts:++clock,device,deleted:true}}
 return records;
}
function unpack(records,existing={f:[],l:[]}){
 const ids=new Map();
 const known=new Map([...(existing.f||[]),...(existing.l||[])]
  .filter(row=>row._syncKey&&Number.isSafeInteger(row.id)).map(row=>[row._syncKey,row]));
 let id=Date.now();
 for(const row of known.values())id=Math.max(id,row.id);
 const ordered=(kind)=>Object.values(records).filter(row=>row.kind===kind&&!row.deleted)
  .sort((a,b)=>(a.data.order-b.data.order)||a.key.localeCompare(b.key));
 const f=ordered('folder').map(row=>{
  const localId=known.get(row.key)?.id??++id;
  ids.set(row.key,localId);
  const {order,...data}=row.data;
  return {...data,id:localId,_syncKey:row.key};
 });
 const l=ordered('link').filter(row=>safeURL(row.data.url)).map(row=>{
  const previous=known.get(row.key);
  const {folderKey,order,...data}=row.data;
  return {...data,id:previous?.id??++id,_syncKey:row.key,fId:ids.get(folderKey)??null,
   addedAt:earlierDate(savedTimestamp(data.addedAt),bookmarkDate(previous))};
 });
 return {f,l};
}
const api={uid,compare,merge,valid,pack,unpack,safeURL,bookmarkDate,needsUpload,recoverBookmarkDates};root.WebMarkSyncCore=api;if(typeof module!=='undefined')module.exports=api;
})(typeof globalThis!=='undefined'?globalThis:this);

