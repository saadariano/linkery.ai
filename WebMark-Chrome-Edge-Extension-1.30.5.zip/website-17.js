/* Android Back follows dialogs and in-app pages before offering to close WebMark. */
(()=>{
    const history=[],modals=[];let replay=false,ready=false,depth=0;
    Promise.resolve(typeof wmStartup!=='undefined'?wmStartup:undefined).then(()=>ready=true);
    function state(){return {tab:S.activeTab,source:S._sourceMode||'personal'};}
    function remember(before){if(!ready||replay)return;const after=state();if(JSON.stringify(before)!==JSON.stringify(after)){history.push(before);if(history.length>40)history.shift();}}
    for(const name of ['switchTab','setSourceMode']){const original=window[name];if(typeof original==='function')window[name]=function(...args){const before=state(),outer=depth===0;depth++;try{return original.apply(this,args);}finally{depth--;if(outer)remember(before);}};}
    const open=window.openModal;if(typeof open==='function')window.openModal=function(id,...args){const result=open.call(this,id,...args);modals.push(id);return result;};
    function back(){
        if(window.WebMarkUpdates?.back?.())return true;
        if(window.WebMarkPasswords?.back?.())return true;
        if(window.WebMarkNotes?.back?.())return true;
        const dialog=[...document.querySelectorAll('dialog[open]')].at(-1);
        if(dialog){if(dialog.dispatchEvent(new Event('cancel',{cancelable:true})))dialog.close();return true;}
        for(const id of ['sourceDD','sortDD','folderFilterDD','tagDD','viewDD']){const element=document.getElementById(id);if(element?.classList.contains('open')){element.classList.remove('open');return true;}}
        let modal;while(modals.length&&!modal){const candidate=document.getElementById(modals.pop());if(candidate?.classList.contains('active'))modal=candidate;}
        modal||=[...document.querySelectorAll('.modal.active')].at(-1);
        if(modal){if(modal.id==='addModal')confirmCloseAddModal();else closeModal(modal.id);return true;}
        if(document.querySelector('.inline-page.active')){closePage();return true;}
        if(history.length){const previous=history.pop();replay=true;try{S._sourceMode=previous.source;wmStorage.setItem('ly_sourceMode',previous.source);switchTab(previous.tab);if(typeof updateSourceChecks==='function')updateSourceChecks();}finally{replay=false;}return true;}
        return false;
    }
    window.WebMarkNavigation={back};
})();
