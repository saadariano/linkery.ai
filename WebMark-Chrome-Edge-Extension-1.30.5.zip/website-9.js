
/* Optional Firebase Auth + Firestore REST sync. Local use never requires an account. */
(function(){'use strict';
const C=WebMarkSyncCore,AUTH_KEY='wm_google_session_v1',META_KEY='wm_cloud_records_v1';let adapter=null,config=null,session=null,records={},device='',busy=false,again=false,timer=null,applying=false,pending=null,status='Local only',listeners=new Set(),remoteCache=null,quotaUntil=0,quotaFailures=0,quotaTimer=null;
const enc=b=>btoa(String.fromCharCode(...new Uint8Array(b))).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');const dec=s=>Uint8Array.from(atob(s.replace(/-/g,'+').replace(/_/g,'/')),c=>c.charCodeAt(0));
const storage=()=>typeof wmStorage!=='undefined'?wmStorage:localStorage;
const read=(k,f)=>{try{return JSON.parse(storage().getItem(k))??f}catch{return f}};
function emit(text){status=text;for(const fn of listeners)fn(info())}
function info(){return {quotaUntil,status:session&&quotaFailures&&!bookmarkOrigin()?quotaDescription():status,configured:!!config?.enabled,user:session?{uid:session.uid,email:session.email,name:session.name||'',photoURL:session.photoURL||''}:null,busy,ready:!!adapter,bookmarkRelay:!!bookmarkOrigin()}}
const pacificClock=new Intl.DateTimeFormat('en-US',{timeZone:'America/Los_Angeles',year:'numeric',month:'numeric',day:'numeric',hour:'numeric',minute:'numeric',second:'numeric',hourCycle:'h23'});
function pacificWallTime(time){
 const parts=Object.fromEntries(pacificClock.formatToParts(time).map(({type,value})=>[type,Number(value)]));
 return Date.UTC(parts.year,parts.month-1,parts.day,parts.hour,parts.minute,parts.second);
}
function nextPacificMidnight(now){
 const day=86400000,wall=pacificWallTime(now),midnight=(Math.floor(wall/day)+1)*day;
 const guess=midnight+8*3600000;
 return midnight+guess-pacificWallTime(guess);
}
function remaining(ms){
 const seconds=Math.max(0,Math.ceil(ms/1000));
 const hours=Math.floor(seconds/3600),minutes=Math.floor(seconds%3600/60);
 return hours?hours+'h '+minutes+'m':minutes?minutes+'m '+seconds%60+'s':seconds+'s';
}
function quotaDescription(){
 const now=Date.now();
 const retry=quotaUntil>now?'Retry in '+remaining(quotaUntil-now)+'.':'You can retry now.';
 return 'Google quota reached. '+retry+' If the daily free quota was exhausted, its next estimated reset is in '+remaining(nextPacificMidnight(now)-now)+' (midnight Pacific). Changes are saved locally.';
}
function notifyQuota(){
 clearTimeout(quotaTimer);
 emit(quotaDescription());
 if(quotaFailures)quotaTimer=setTimeout(notifyQuota,1000);
}
function clearQuota(){
 clearTimeout(quotaTimer);quotaFailures=0;quotaUntil=0;
 try{storage().removeItem('wm_cloud_quota_pause_v1')}catch{}
}
function quotaError(){const e=Error(quotaDescription());e.quota=true;return e}
async function request(url,options={}){
 const firestore=url.startsWith('https://firestore.googleapis.com/');
 if(firestore&&Date.now()<quotaUntil)throw quotaError();
 const controller=new AbortController(),timeout=setTimeout(()=>controller.abort(),15000);
 try{const r=await fetch(url,{...options,signal:controller.signal});const d=await r.json().catch(()=>({}));
  if(!r.ok){if(firestore&&(r.status===429||d.error?.status==='RESOURCE_EXHAUSTED'||/quota exceeded|quota.*exhausted/i.test(d.error?.message||''))){
   quotaFailures++;
   const hint=r.headers?.get('Retry-After'),now=Date.now();
   const retryAfter=hint&&/^\d+$/.test(hint)?Number(hint)*1000:Date.parse(hint)-now;
   const retryInfo=Array.isArray(d.error?.details)?d.error.details.find(detail=>detail['@type']==='type.googleapis.com/google.rpc.RetryInfo'):null;
   const seconds=/^\d+(?:\.\d+)?s$/.test(retryInfo?.retryDelay||'')?parseFloat(retryInfo.retryDelay):0;
   quotaUntil=now+Math.max(1000,Number.isFinite(retryAfter)&&retryAfter>0?retryAfter:seconds>0?seconds*1000:Math.min(3600000,300000*2**Math.min(quotaFailures-1,4)));
   notifyQuota();try{storage().setItem('wm_cloud_quota_pause_v1',JSON.stringify({until:quotaUntil,failures:quotaFailures}))}catch{}throw quotaError();
  }const e=Error(d.error?.message||(typeof d.error==='string'?d.error:'Cloud request failed'));e.status=r.status;throw e}if(firestore&&quotaFailures){clearQuota();emit('Syncing…');}return d;
 }finally{clearTimeout(timeout)}
}
async function token(){if(!session)throw Error('Sign in first');if(session.expiresAt>Date.now()+90000)return session.idToken;const d=await request('https://securetoken.googleapis.com/v1/token?key='+encodeURIComponent(config.apiKey),{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams({grant_type:'refresh_token',refresh_token:session.refreshToken})});session={...session,idToken:d.id_token,refreshToken:d.refresh_token,uid:d.user_id,expiresAt:Date.now()+Number(d.expires_in)*1000};storage().setItem(AUTH_KEY,JSON.stringify(session));return session.idToken}
function base(){return 'https://firestore.googleapis.com/v1/projects/'+encodeURIComponent(config.projectId)+'/databases/(default)/documents'}
async function headers(){return {'Authorization':'Bearer '+await token(),'Content-Type':'application/json'}}
function persist(){storage().setItem(META_KEY,JSON.stringify({owner:session?.uid||null,device,records}))}
function changed(){if(!adapter||applying)return;const before=records;records=C.pack(adapter.snapshot(),records,device);if(JSON.stringify(before)!==JSON.stringify(records))globalThis.WebMarkSyncCenter?.pending('bookmarks');adapter.persistKeys();persist();if(session){emit(bookmarkOrigin()?'Bookmark changes waiting to sync':'Pending changes · tap Sync now to upload');scheduleBookmarkSync();}}
// The optional bookmark service uses the same account and merge rules.
let bookmarkKey, keyRequest, bookmarkTimer, bookmarkRetryAt=0;
const bookmarkKeyName='wm_bookmark_relay_key_v1';
const bookmarkOrigin=()=>{
 try{
  const endpoint=new URL(config?.bookmarkSyncUrl);
  return endpoint.protocol==='https:'&&endpoint.href===endpoint.origin+'/' ? endpoint.origin : '';
 }catch{return '';}
};
const bookmarkBase=()=>bookmarkOrigin()?bookmarkOrigin()+'/v1':base();
const keyScope=()=>JSON.stringify([bookmarkOrigin(),config?.projectId,session?.uid]);
function savedBookmarkKey(){
 const saved=read(bookmarkKeyName,null);
 return saved?.scope===keyScope()?saved.key:null;
}
function askBookmarkPhrase(){
 if(keyRequest)return keyRequest;
 const dialog=document.createElement('dialog');
 dialog.innerHTML='<form method="dialog"><h2>Connect bookmark sync</h2><p>Choose a sync passphrase of at least 16 characters. Enter the same passphrase on each device. Keep a copy somewhere safe.</p><label>Sync passphrase <input type="password" minlength="16" maxlength="256" required autocomplete="off"></label><p><button type="button">Cancel</button> <button value="ok">Connect</button></p></form>';
 document.body.append(dialog);
 keyRequest=new Promise(resolve=>{
  dialog.querySelector('button[type=button]').onclick=()=>dialog.close();
  dialog.addEventListener('close',()=>{
   const input=dialog.querySelector('input');
   const phrase=dialog.returnValue==='ok'?input.value:null;
   input.value='';dialog.remove();keyRequest=null;resolve(phrase);
  },{once:true});
 });
 dialog.showModal();return keyRequest;
}
async function unlockBookmarkSync(manual,account){
 if(bookmarkKey?.scope===keyScope())return bookmarkKey;
 const scope=keyScope();
 let encoded=savedBookmarkKey();
 if(!encoded){
  if(!manual)return null;
  const passphrase=await askBookmarkPhrase();
  if(!passphrase||session?.uid!==account)return null;
  const text=new TextEncoder();
  const secret=await crypto.subtle.importKey('raw',text.encode(passphrase),'PBKDF2',false,['deriveBits']);
  const bits=await crypto.subtle.deriveBits({name:'PBKDF2',hash:'SHA-256',iterations:600000,
   salt:text.encode('WebMark Bookmarks 1 '+config.projectId+' '+account)},secret,256);
  encoded=enc(bits);
 }
 if(session?.uid!==account)return null;
 const key=await crypto.subtle.importKey('raw',dec(encoded),'AES-GCM',false,['encrypt','decrypt']);
 return bookmarkKey={scope,encoded,key};
}
async function sealBookmark(doc,key){
 const iv=crypto.getRandomValues(new Uint8Array(12));
 const text=new TextEncoder();
 const bytes=await crypto.subtle.encrypt({name:'AES-GCM',iv,additionalData:text.encode(doc.name)},
  key,text.encode(doc.fields.value.stringValue));
 const buffer=new Uint8Array(bytes);
 // Avoid spreading a large bookmark attachment into a single function call.
 let binary='';
 for(let i=0;i<buffer.length;i+=8192)binary+=String.fromCharCode(...buffer.subarray(i,i+8192));
 doc.fields.value.stringValue='wm1.'+enc(iv)+'.'+btoa(binary).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');
}
async function openBookmark(doc,key){
 try{
  const [format,iv,value]=doc.fields.value.stringValue.split('.');
  if(format!=='wm1')throw Error();
  const bytes=await crypto.subtle.decrypt({name:'AES-GCM',iv:dec(iv),additionalData:new TextEncoder().encode(doc.name)},key,dec(value));
  doc.fields.value.stringValue=new TextDecoder().decode(bytes);
 }catch{
  const failure=Error('Could not unlock bookmark sync. Tap Sync and enter the same passphrase used on your other devices.');
  failure.bookmarkPassphrase=true;
  throw failure;
 }
}
async function bookmarkRequest(url,options,key){
 if(!key)return request(url,options);
 if(options?.body&&url.endsWith(':commit')){
  const {writes}=JSON.parse(options.body);
  for(const write of writes)await sealBookmark(write.update,key);
  options={...options,body:JSON.stringify({writes})};
 }
 const result=await request(url,{...options,redirect:'error'});
 const docs=Array.isArray(result)?result.filter(row=>row.found).map(row=>row.found):
  result.documents||(result.fields?[result]:[]);
 for(const doc of docs)await openBookmark(doc,key);
 return result;
}
function scheduleBookmarkSync(delay=1200){
 if(!bookmarkOrigin()||!session||(!savedBookmarkKey()&&!bookmarkKey))return;
 clearTimeout(bookmarkTimer);
 bookmarkTimer=setTimeout(()=>{if(!document.hidden&&Date.now()>=bookmarkRetryAt)sync(false)},delay);
}
function bookmarkSummary(previous,merged,local){
 const counts={added:0,edited:0,deleted:0};
 for(const [id,record] of Object.entries(merged)){
  const incoming=previous[id];
  if(record.kind!=='link'||!incoming||record.ts!==incoming.ts||record.device!==incoming.device)continue;
  const before=local[id];
  if(record.deleted){if(before&&!before.deleted)counts.deleted++;}
  else if(!before||before.deleted)counts.added++;
  else if(JSON.stringify(before.data)!==JSON.stringify(record.data))counts.edited++;
 }
 const parts=Object.entries(counts).filter(([,count])=>count).map(([label,count])=>count+' '+label);
 if(parts.length)window.showToast?.('Bookmark changes synced · '+parts.join(', '),'var(--primary)',3600);
}

// Keep a bounded list of changed bookmark IDs inside the existing Firestore
// marker. The marker and its bookmarks are committed atomically.
const CHECKPOINT_KEY='wm_bookmark_cloud_checkpoint_v1';
const MAX_CHANGE_BATCHES=128;
function journal(value){
 try{
  const entries=JSON.parse(value);
  if(Array.isArray(entries)&&entries.length>0&&entries.length<=MAX_CHANGE_BATCHES&&
    entries.every(entry=>typeof entry.id==='string'&&Array.isArray(entry.keys)&&entry.keys.length<=25&&
      entry.keys.every(key=>typeof key==='string'&&/^[a-zA-Z0-9-]{8,80}$/.test(key))))return entries;
 }catch{}
 return [];
}
async function bookmarkMarker(path,key){
 try{
  const doc=await bookmarkRequest(bookmarkBase()+path+'/webmark-bookmark-index-v1',{headers:await headers()},key);
  return {value:doc.fields?.value?.stringValue||'',version:doc.updateTime};
 }catch(error){
  if(error.status!==404)throw error;
  return {value:'',version:null};
 }
}
function addRemoteRecord(doc,map,versions){
 try{
  const key=doc.name.split('/').at(-1);
  const record=JSON.parse(doc.fields.value.stringValue);
  if(C.valid(record,key)){map[key]=record;versions[key]=doc.updateTime;}
 }catch{}
}
async function remote(account,key){
 const path='/users/'+encodeURIComponent(account)+'/records';
 const marker=await bookmarkMarker(path,key);
 const saved=remoteCache||read(CHECKPOINT_KEY,null);
 const previous=saved?.account===account&&saved.project===config.projectId&&saved.origin===(bookmarkOrigin()||undefined)?saved:null;
 if(previous&&marker.version&&previous.marker.version===marker.version)return remoteCache=previous;
 const entries=journal(marker.value),last=journal(previous?.marker?.value).at(-1);
 const index=last?entries.findIndex(entry=>entry.id===last.id):-1;
 const map=index>=0?{...previous.map}:Object.create(null);
 const versions=index>=0?{...previous.versions}:Object.create(null);
 if(index>=0){
  const keys=[...new Set(entries.slice(index+1).flatMap(entry=>entry.keys))];
  const prefix='projects/'+config.projectId+'/databases/(default)/documents'+path+'/';
  for(let start=0;start<keys.length;start+=50){
   if(session?.uid!==account)throw Error('The Google account changed during sync.');
   const rows=await bookmarkRequest(bookmarkBase()+':batchGet',{method:'POST',headers:await headers(),
       body:JSON.stringify({documents:keys.slice(start,start+50).map(id=>prefix+id)})},key);
   if(!Array.isArray(rows)||rows.length!==Math.min(50,keys.length-start)||rows.some(row=>!row.found)){
    throw Error('Could not verify the changed bookmarks. Try syncing again.');
   }
   for(const {found} of rows)addRemoteRecord(found,map,versions);
  }
 }else{
  let page='';
  do{
   if(session?.uid!==account)throw Error('The Google account changed during sync.');
   const result=await bookmarkRequest(bookmarkBase()+path+'?pageSize=200'+(page?'&pageToken='+encodeURIComponent(page):''),{headers:await headers()},key);
   for(const doc of result.documents||[])addRemoteRecord(doc,map,versions);
   page=result.nextPageToken||'';
  }while(page);
  if((await bookmarkMarker(path,key)).version!==marker.version)return null;
 }
 return remoteCache={account,project:config.projectId,origin:bookmarkOrigin()||undefined,marker,map,versions};
}
async function writeBookmarkBatch(account,cloud,batch,merged,key){
 const keys=batch.map(write=>write.update.name.split('/').at(-1));
 const entries=journal(cloud.marker.value);
 entries.push({id:C.uid(),keys});
 const value=JSON.stringify(entries.slice(-MAX_CHANGE_BATCHES));
 const marker={update:{
  name:'projects/'+config.projectId+'/databases/(default)/documents/users/'+account+'/records/webmark-bookmark-index-v1',
  fields:{value:{stringValue:value}}
 },currentDocument:cloud.marker.version?{updateTime:cloud.marker.version}:{exists:false}};
 const result=await bookmarkRequest(bookmarkBase()+':commit',{method:'POST',headers:await headers(),
     body:JSON.stringify({writes:[...batch,marker]})},key);
 cloud.marker={value,version:result.writeResults?.at(-1)?.updateTime||result.commitTime};
 keys.forEach((key,index)=>{
  cloud.map[key]=merged[key];
  cloud.versions[key]=result.writeResults?.[index]?.updateTime;
 });
}

async function sync(manual=true){

 if(!session||!config?.enabled)return;if(busy)return;if(!navigator.onLine){emit('Offline · changes saved on this device');return}busy=true;emit('Syncing…');const account=session.uid;const revision=globalThis.WebMarkSyncCenter?.revision('bookmarks');
 if(globalThis.browser?.runtime?.getManifest?.().browser_specific_settings?.gecko?.data_collection_permissions){try{const p=await browser.permissions.getAll();if(!['authenticationInfo','bookmarksInfo','personallyIdentifyingInfo'].every(x=>p.data_collection?.includes(x))){busy=false;emit('Sync paused · optional data sharing permission is off');return}}catch{busy=false;emit('Sync paused · unable to check data sharing permission');return}}
 let key;
 try{
  if(bookmarkOrigin()){
   key=(await unlockBookmarkSync(manual,account))?.key;
   if(!key){emit('Tap Sync to connect encrypted bookmark sync.');return false;}
  }
  for(let retry=0;retry<4;retry++){
   const cloud=await remote(account,key);if(session?.uid!==account)return;
   if(!cloud){if(retry===3)throw Error('Bookmarks changed during sync. Try again.');continue;}
   const local=records;
   const previous=key?{...cloud.map}:null;
   const merged=C.recoverBookmarkDates(C.merge(cloud.map,records),adapter.snapshot());
   const writes=Object.values(merged).filter(r=>C.needsUpload(r,cloud.map[r.key])).map(r=>{
    const value=JSON.stringify(r);if(new TextEncoder().encode(value).length>700000)throw Error('A bookmark is too large to sync. Use a smaller uploaded image.');
    return {update:{name:'projects/'+config.projectId+'/databases/(default)/documents/users/'+account+'/records/'+r.key,fields:{value:{stringValue:value}}},currentDocument:cloud.versions[r.key]?{updateTime:cloud.versions[r.key]}:{exists:false}};
   });let conflict=false;
   const writeCount=writes.length||(!journal(cloud.marker.value).length?1:0);
   for(let i=0;i<writeCount;i+=25){
    if(session?.uid!==account)return;
    try{await writeBookmarkBatch(account,cloud,writes.slice(i,i+25),merged,key);}
    catch(e){
     if([409,412,400].includes(e.status)&&/ABORTED|FAILED_PRECONDITION|ALREADY_EXISTS|precondition|exists/i.test(e.message)){conflict=true;break}
     throw e;
    }
   }
   if(conflict){remoteCache=null;if(retry===3)throw Error('Sync conflict. Your changes are safe; try Sync now again.');continue}
   if(session?.uid!==account)return;
   const current=adapter.snapshot();
   records=C.merge(merged,records);
   const materialized=C.unpack(records,current);
   const changedView=JSON.stringify({f:current.f||[],l:current.l||[]})!==JSON.stringify(materialized);
   applying=true;try{if(changedView)adapter.apply(materialized);adapter.persistKeys();persist()}finally{applying=false}
   if(key&&bookmarkKey?.key===key){
    if(!savedBookmarkKey())storage().setItem(bookmarkKeyName,JSON.stringify({scope:bookmarkKey.scope,key:bookmarkKey.encoded}));
    bookmarkRetryAt=0;
   }else clearQuota();
   if(cloud.marker.version&&storage().durable)storage().setItem(CHECKPOINT_KEY,JSON.stringify(cloud));
   await storage().flush?.();
   globalThis.WebMarkSyncCenter?.complete('bookmarks',account,revision);
   if(key&&changedView)bookmarkSummary(previous,records,local);
   emit('Synced · '+new Date().toLocaleString());return true;
  }
 }catch(e){remoteCache=null;
 if(key){
  bookmarkRetryAt=Date.now()+30000;
  if(e.bookmarkPassphrase&&bookmarkKey?.key===key){bookmarkKey=null;storage().removeItem(bookmarkKeyName);}
 }
 if(e.quota)emit(e.message);else if(e.status===401||e.status===403)emit('Sync needs attention: sign in again or check project permissions');else emit('Saved locally · '+(e.name==='AbortError'?'connection timed out':e.message))}finally{busy=false;for(const fn of listeners)fn(info())}
}
async function loadConfig(){if(globalThis.location?.protocol==='file:'){config={enabled:false};return}try{config=await request('./cloud-config.json')}catch{config={enabled:false}}if(!config.enabled)return;for(const key of ['apiKey','projectId','authDomain','authPageUrl'])if(!config[key]){config.enabled=false;return}const url=new URL(config.authPageUrl);if(url.protocol!=='https:'||url.hostname!==config.authDomain){config.enabled=false;return}
 if(!config.enabled||!config.bookmarkSyncConfigUrl||!globalThis.WebMarkAndroid)return;
 const key='wm_bookmark_relay_origin_v1';
 try{
  const published=await request(config.bookmarkSyncConfigUrl,{redirect:'error',cache:'no-store'});
  if(published.projectId===config.projectId){
   config.bookmarkSyncUrl=published.bookmarkSyncUrl;
   if(bookmarkOrigin())storage().setItem(key,bookmarkOrigin());
  }
 }catch{}
 if(!bookmarkOrigin())config.bookmarkSyncUrl=storage().getItem(key);
}
function language(){try{return ['en','ar','it','fr','es'].includes(storage().getItem('ly_lang'))?storage().getItem('ly_lang'):['en','ar','it','fr','es'].includes(document.documentElement.lang)?document.documentElement.lang:'en'}catch{return 'en'}}
function popup(url){if(window.WebMarkAndroid?.openSignIn){window.WebMarkAndroid.openSignIn(url);return}if(window.WebMarkAndroid){const a=document.createElement('a');a.href=url;a.target='_blank';a.rel='noopener noreferrer';a.click();return}const api=globalThis.browser||globalThis.chrome;if(api?.tabs){api.tabs.create({url});return}window.open(url,'_blank','noopener,noreferrer')}
async function signIn(){
 if(globalThis.location?.protocol==='file:'){emit('Install WebMark using Load unpacked in chrome://extensions or edge://extensions, then open it from the toolbar.');return}
 if(!config?.enabled){emit('Google sign-in is not activated yet. Connect and configure Firebase first.');return}
 if(session){emit('Manual sync · tap Sync now');return}if(pending)return;
 if(window.WebMarkAndroid?.hasNativeGoogle?.()){
  const id=enc(crypto.getRandomValues(new Uint8Array(24))),nonce=enc(crypto.getRandomValues(new Uint8Array(32)));
  pending={id,nonce,native:true,deadline:Date.now()+180000};emit('Choose your Google account');
  window.WebMarkAndroid.signInGoogle(id,nonce,language());
  setTimeout(()=>{if(pending?.id===id){pending=null;emit('Sign-in expired. Try again.')}},180000);return;
 }
 if(globalThis.browser?.runtime?.getManifest?.().browser_specific_settings?.gecko?.data_collection_permissions){const granted=await browser.permissions.request({data_collection:['authenticationInfo','bookmarksInfo','personallyIdentifyingInfo']});if(!granted){emit('Google sync was not enabled: data sharing permission declined');return}}
 // The login page receives only a public key. Tokens are encrypted and never included in a URL.
 const pair=await crypto.subtle.generateKey({name:'RSA-OAEP',modulusLength:2048,publicExponent:new Uint8Array([1,0,1]),hash:'SHA-256'},true,['encrypt','decrypt']);const pub=await crypto.subtle.exportKey('spki',pair.publicKey),random=crypto.getRandomValues(new Uint8Array(32));const id=Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',random)),b=>b.toString(16).padStart(2,'0')).join('');
 pending={id,key:pair.privateKey,deadline:Date.now()+300000};const payload={session:id,key:enc(pub),platform:window.WebMarkAndroid?'android':'extension',language:language()};
 popup(config.authPageUrl+'#'+enc(new TextEncoder().encode(JSON.stringify(payload))));emit('Complete Google sign-in in the browser, then return here');pollLogin();
}
async function pollLogin(){const current=pending;if(!current||current.native||current.inFlight)return;current.inFlight=true;if(Date.now()>current.deadline){pending=null;emit('Sign-in expired. Try again.');return}try{
 const doc=await request(base()+'/authHandoffs/'+current.id);if(pending!==current)return;
 const packet=JSON.parse(doc.fields.encrypted.stringValue);const aesBytes=await crypto.subtle.decrypt({name:'RSA-OAEP'},current.key,dec(packet.key));const aes=await crypto.subtle.importKey('raw',aesBytes,'AES-GCM',false,['decrypt']);const clear=await crypto.subtle.decrypt({name:'AES-GCM',iv:dec(packet.iv)},aes,dec(packet.data));const result=JSON.parse(new TextDecoder().decode(clear));if(!result.refreshToken)throw Error('Invalid sign-in result');
 const auth=await request('https://securetoken.googleapis.com/v1/token?key='+encodeURIComponent(config.apiKey),{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams({grant_type:'refresh_token',refresh_token:result.refreshToken})});if(pending!==current)return;
 const lookup=await request('https://identitytoolkit.googleapis.com/v1/accounts:lookup?key='+encodeURIComponent(config.apiKey),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({idToken:auth.id_token})});const user=lookup.users?.[0];if(!user||user.localId!==auth.user_id||!user.providerUserInfo?.some(p=>p.providerId==='google.com'))throw Error('Google account could not be verified');
 await acceptAccount(auth,user,current);if(session?.uid!==auth.user_id)return;
 persist();pending=null;try{await request(base()+'/authHandoffs/'+current.id,{method:'DELETE',headers:await headers()})}catch{}emit('Connected · tap Sync now');return;
 }catch(e){if(e.status!==404&&e.status!==403&&e.name!=='AbortError'&&e.message!=='Missing or insufficient permissions.'){pending=null;emit('Sign-in could not finish: '+e.message);return}}
 current.inFlight=false;if(pending===current)setTimeout(pollLogin,1500);
}
async function acceptAccount(auth,user,current){
 const importLocal=await adapter.confirmUpload(user.email||'this Google account');if(pending!==current)return false;if(importLocal===null){pending=null;emit('Sign-in cancelled · your bookmarks are unchanged');return false;}
 // Keep a recoverable backup before changing the active account's local view.
 storage().setItem('wm_before_google_login',JSON.stringify(adapter.snapshot()));
 session={uid:auth.user_id,email:user.email||'',name:user.displayName||'',photoURL:profilePhoto(user.photoUrl),idToken:auth.id_token,refreshToken:auth.refresh_token,expiresAt:Date.now()+Number(auth.expires_in)*1000};storage().setItem(AUTH_KEY,JSON.stringify(session));
 const oldMeta=read(META_KEY,{});records=oldMeta.owner===session.uid?oldMeta.records||{}:{};
 if(importLocal)records=C.pack(adapter.snapshot(),records,device);else{applying=true;try{adapter.apply({f:[],l:[]})}finally{applying=false}}
  persist();pending=null;return true;
}
async function nativeResult(id,idToken,error){
 const current=pending;if(!current?.native||current.id!==id||current.inFlight)return;
 if(error||!idToken){pending=null;emit(error==='cancelled'?'Sign-in cancelled · your bookmarks are unchanged':error==='no_credentials'?'No Google account is available. Add an account in Android settings and try again.':'Google sign-in is unavailable. Update Google Play services and try again.');return;}
 current.inFlight=true;emit('Verifying your Google account…');
 try{
  const claims=JSON.parse(new TextDecoder().decode(dec(idToken.split('.')[1]||'')));
  if(claims.nonce!==current.nonce)throw Error('Google account could not be verified');
  // Firebase verifies signature, issuer, audience, expiry and Google provider. Never trust JWT claims as a session.
  const result=await request('https://identitytoolkit.googleapis.com/v1/accounts:signInWithIdp?key='+encodeURIComponent((config.nativeApiKey||config.apiKey)),{method:'POST',headers:{'Content-Type':'application/json','X-Android-Package':'com.saadmounir.webmark','X-Android-Cert':'AFCB2174AB18E2DB528C87A6500EA9D12107C894'},body:JSON.stringify({postBody:new URLSearchParams({id_token:idToken,providerId:'google.com'}).toString(),requestUri:'https://'+config.authDomain,returnSecureToken:true,returnIdpCredential:true})});
  if(pending!==current)return;
  const lookup=await request('https://identitytoolkit.googleapis.com/v1/accounts:lookup?key='+encodeURIComponent(config.apiKey),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({idToken:result.idToken})});
  const user=lookup.users?.[0];if(!user||user.localId!==result.localId||!user.providerUserInfo?.some(p=>p.providerId==='google.com'))throw Error('Google account could not be verified');
  if(await acceptAccount({user_id:result.localId,id_token:result.idToken,refresh_token:result.refreshToken,expires_in:result.expiresIn},user,current))emit('Connected · tap Sync now');
 }catch(e){if(pending===current){pending=null;emit('Sign-in could not finish: '+e.message)}}
}
function signOut(){bookmarkKey=null;clearTimeout(bookmarkTimer);storage().removeItem(bookmarkKeyName);remoteCache=null;storage().removeItem(CHECKPOINT_KEY);window.WebMarkAndroid?.clearGoogle?.();pending=null;session=null;storage().removeItem(AUTH_KEY);emit('Signed out · bookmarks remain on this device')}
function profilePhoto(value){try{const url=new URL(value);return url.protocol==='https:'&&(/(^|\.)googleusercontent\.com$/i.test(url.hostname))?url.href:''}catch{return ''}}
async function refreshProfile(){const account=session?.uid;if(!account)return;try{const result=await request('https://identitytoolkit.googleapis.com/v1/accounts:lookup?key='+encodeURIComponent(config.apiKey),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({idToken:await token()})});const user=result.users?.[0];if(session?.uid!==account||user?.localId!==account)return;session={...session,name:user.displayName||'',photoURL:profilePhoto(user.photoUrl)};storage().setItem(AUTH_KEY,JSON.stringify(session));emit(status)}catch{}}
async function attach(a){if(typeof wmStorage!=='undefined')await wmStorage.ready;adapter=a;const pause=read('wm_cloud_quota_pause_v1',{});quotaUntil=Number(pause.until)||0;quotaFailures=Number(pause.failures)||0;const meta=read(META_KEY,{});device=meta.device||C.uid();records=meta.records||{};session=read(AUTH_KEY,null);if(session&&meta.owner!==session.uid){session=null;storage().removeItem(AUTH_KEY);records={}}await loadConfig();if(session&&config?.enabled){if(quotaFailures)notifyQuota();else emit('Manual sync · tap Sync now');refreshProfile()}else emit('Local only · Google sign-in '+(config?.enabled?'available':'not activated'));document.addEventListener('visibilitychange',()=>{if(!document.hidden&&pending)pollLogin()});if(bookmarkOrigin()){addEventListener('online',()=>scheduleBookmarkSync(0));addEventListener('focus',()=>scheduleBookmarkSync(0));document.addEventListener('visibilitychange',()=>scheduleBookmarkSync(0));setInterval(()=>scheduleBookmarkSync(0),20000);scheduleBookmarkSync(0);}}
async function syncNotes(account,merge,manual,automatic=false) {
    if(!manual)return;
    const requireAccount=()=>{
        if(!config?.enabled || session?.uid!==account) throw Error('Sign in again to sync notes.');
    };
    requireAccount();
    if(globalThis.browser?.runtime?.getManifest?.().browser_specific_settings?.gecko?.data_collection_permissions){
        const data_collection=['authenticationInfo','bookmarksInfo','personallyIdentifyingInfo'];
        const allowed=manual
            ? await browser.permissions.request({data_collection})
            : false;
        if(!allowed){
            const granted=(await browser.permissions.getAll()).data_collection||[];
            if(!data_collection.every(type=>granted.includes(type))) throw Error('Allow optional data sharing to sync notes.');
        }
    }
    const path='/users/'+encodeURIComponent(account)+'/records/webmark-notes-v2';
    const documentName='projects/'+config.projectId+'/databases/(default)/documents'+path;
    const authorizedHeaders=async()=>{
        requireAccount();
        const result=await headers();
        requireAccount();
        return result;
    };
    for(let attempt=0;attempt<4;attempt++){
        let remote;
        try {
            remote=await request(base()+path,{headers:await authorizedHeaders()});
        } catch(error) {
            if(error.status!==404) throw error;
        }
        requireAccount();
        const stored=remote?JSON.parse(remote.fields.value.stringValue):{};
        const merged=merge(stored);
        const value=JSON.stringify(merged);
        if(value===JSON.stringify(stored)) return merged;
        if(new TextEncoder().encode(value).length>700000) throw Error('Your notes are too large to sync as one collection.');
        try {
            const write={update:{name:documentName,fields:{value:{stringValue:value}}},
                currentDocument:remote?{updateTime:remote.updateTime}:{exists:false}};
            await request(base()+':commit',{method:'POST',headers:await authorizedHeaders(),
                body:JSON.stringify({writes:[write]})});
            requireAccount();
            return merged;
        } catch(error) {
            if(![400,409,412].includes(error.status) ||
                !/ABORTED|precondition|already exists|changed/i.test(error.message)) throw error;
        }
    }
    throw Error('Notes changed on another device. Try syncing again.');
}

async function syncPasswordVault(account,merge,manual=false,automatic=false){
    if(!manual)return;
    const requireAccount=()=>{if(!config?.enabled||session?.uid!==account)throw Error('Sign in with the same Google account to sync passwords.');};
    requireAccount();
    if(globalThis.browser?.runtime?.getManifest?.().browser_specific_settings?.gecko?.data_collection_permissions){
        const data_collection=['authenticationInfo','bookmarksInfo','personallyIdentifyingInfo'];
        const allowed=manual?await browser.permissions.request({data_collection}):false;
        if(!allowed){const granted=(await browser.permissions.getAll()).data_collection||[];
            if(!data_collection.every(type=>granted.includes(type)))throw Error('Allow optional Google sync permissions to sync passwords.');}
    }
    const path='/users/'+encodeURIComponent(account)+'/records/webmark-passwords-v1';
    const name='projects/'+config.projectId+'/databases/(default)/documents'+path;
    const authorized=async()=>{requireAccount();const value=await headers();requireAccount();return value;};
    for(let retry=0;retry<4;retry++){
        let document;
        try{document=await request(base()+path,{headers:await authorized()});}
        catch(error){if(error.status!==404)throw error;}
        requireAccount();
        const remote=document?JSON.parse(document.fields.value.stringValue):null;
        const next=await merge(remote);requireAccount();
        if(next===null)return remote;
        const value=JSON.stringify(next);
        if(document&&value===document.fields.value.stringValue)return next;
        if(new TextEncoder().encode(value).length>700000)throw Error('The encrypted vault is too large for this sync record. Your local vault is unchanged.');
        try{
            await request(base()+':commit',{method:'POST',headers:await authorized(),body:JSON.stringify({writes:[{
                update:{name,fields:{value:{stringValue:value}}},currentDocument:document?{updateTime:document.updateTime}:{exists:false}
            }]})});
            requireAccount();return next;
        }catch(error){if(![400,409,412].includes(error.status)||!/ABORTED|precondition|already exists|changed/i.test(error.message))throw error;}
    }
    throw Error('The cloud vault changed repeatedly. Your local changes are safe; sync again.');
}

window.WebMarkCloud={syncPasswordVault,syncNotes,attach,changed,signIn,signOut,sync,info,nativeResult,subscribe(fn){listeners.add(fn);fn(info());return()=>listeners.delete(fn)}};
})();
