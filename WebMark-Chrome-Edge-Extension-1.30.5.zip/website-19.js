
(() => {
    const names = {bookmarks:'Bookmarks', notes:'Notes', passwords:'Passwords'};
    const tr=(text,values)=>globalThis.WebMarkInterfaceLocale?.text(text,values)??text;
    const key = 'wm_sync_center_v1';
    const dayKey = date => [date.getFullYear(), date.getMonth()+1, date.getDate()].join('-');
    let working = false;
    let timer;
    let dialog;
    const errors = {};
    function read(){
        try{return JSON.parse(localStorage.getItem(key)) || {};}catch{return {};}
    }
    function change(fn){
        const data=read();
        fn(data);
        try{localStorage.setItem(key,JSON.stringify(data));}catch{}
        paint();
    }
    function uid(){return globalThis.WebMarkCloud?.info().user?.uid;}
    function pending(section){
        change(data=>{data.revision ||= {};data.revision[section]=(data.revision[section]||0)+1;});
    }
    function revision(section){return read().revision?.[section]||0;}
    function complete(section, account, syncedRevision){
        if(!account||account!==uid())return;
        delete errors[section];
        change(data=>{
            data.accounts ||= {};
            const rows=data.accounts[account] ||= {};
            rows[section]={time:Date.now(),revision:syncedRevision};
        });
    }
    function waiting(section,data=read()){
        const current=data.revision?.[section]||0;
        return current>(data.accounts?.[uid()]?.[section]?.revision||0);
    }
    function paint(){
        const data=read();
        const cloud=globalThis.WebMarkCloud?.info();
        const list=Object.keys(names).filter(section=>waiting(section,data));
        for(const toolbar of document.querySelectorAll('.wm-settings-cloud-state')){
            const next=list.length?tr('Changes to sync:')+' '+list.map(section=>tr(names[section])).join(', '):'';
            if(toolbar.dataset.syncPending!==next)toolbar.dataset.syncPending=next;
        }
        document.querySelectorAll('.wm-google-account').forEach(button=>{
            const pending=list.length>0||cloud?.quotaUntil>0;
            button.classList.toggle('wm-sync-pending',!!cloud?.user&&pending);
            button.classList.toggle('wm-sync-ready',!!cloud?.user&&!pending);
            if(list.length)button.title=tr('Changes to sync:')+' '+list.map(section=>tr(names[section])).join(', ');
        });
        if(!dialog)return;
        const main=dialog.querySelector('[data-cloud="sync"]');
        if(main)main.textContent=tr('Sync all now');
        for(const section of Object.keys(names)){
            dialog.querySelector('[data-sync-title="'+section+'"]').textContent=tr(names[section]);
            const last=data.accounts?.[uid()]?.[section]?.time;
            dialog.querySelector('[data-sync-state="'+section+'"]').textContent=
                tr(waiting(section,data)?'Changes waiting to sync':'No new local changes')+
                (errors[section]?' · '+tr(errors[section]):'');
            dialog.querySelector('[data-sync-run="'+section+'"]').textContent=
                section==='passwords'&&globalThis.WebMarkPasswords?.unlocked()===false?tr('Unlock to sync'):tr('Sync');
            dialog.querySelector('[data-sync-time="'+section+'"]').textContent=
                last?tr('Last synced')+' '+new Date(last).toLocaleString(document.documentElement?.lang):tr('No successful sync recorded');
        }
        dialog.querySelectorAll('[data-sync-run]').forEach(button=>button.disabled=working||!uid()||
            (cloud?.quotaUntil>Date.now()&&!(cloud.bookmarkRelay&&button.dataset.syncRun==='bookmarks')));
    }
    async function run(section='all',automatic=false){
        if(working||!uid()||!navigator.onLine)return false;
        working=true;paint();
        const account=uid();
        try{
            for(const target of section==='all'?Object.keys(names):[section]){
                if(uid()!==account)break;
                const cloud=WebMarkCloud.info();
                if(cloud.quotaUntil>Date.now()&&!(cloud.bookmarkRelay&&target==='bookmarks'))continue;
                if(target==='passwords'&&globalThis.WebMarkPasswords?.unlocked()===false){
                    errors[target]='Unlock to sync';
                    if(!automatic){
                        delete errors[target];
                        dialog?.close();
                        await globalThis.WebMarkPasswords.openForSync(account);
                    }
                    continue;
                }
                let ok=false;
                try{
                    if(target==='bookmarks')ok=await WebMarkCloud.sync(!automatic);
                    if(target==='notes')ok=await globalThis.WebMarkNotesSync?.(automatic);
                    if(target==='passwords')ok=await globalThis.WebMarkPasswords?.sync(true,automatic);
                }catch{}
                errors[target]=ok?'':(target==='passwords'&&globalThis.WebMarkPasswords?.syncStatus?.())||
                    tr('Sync incomplete. Review {section} settings.',{section:tr(names[target])});
                paint();
            }
            return true;
        }finally{working=false;paint();}
    }
    async function tick(){
        clearTimeout(timer);
        const now=new Date(), next=new Date(now);
        next.setHours(24,0,0,0);
        timer=setTimeout(tick,Math.max(1000,next-now));
        const data=read(), account=uid(), today=dayKey(now);
        if(!account||!navigator.onLine||working||data.midnight===false)return;
        if(data.lastRun?.[account]===today)return;
        if(!data.lastRun?.[account]&&now.getHours()!==0){
            change(value=>{(value.lastRun ||= {})[account]=today;});
            return;
        }
        change(value=>{(value.lastRun ||= {})[account]=today;});
        await run('all',true);
    }
    function mount(el){
        const main=el.querySelector('[data-cloud="sync"]');
        if(!main)return;
        dialog=el;
        if(el.querySelector('.wm-sync-sections')){paint();return;}
        const panel=document.createElement('section');
        panel.setAttribute('aria-live','polite');
        panel.className='wm-sync-sections';
        for(const section of Object.keys(names)){
            const row=document.createElement('article');
            row.innerHTML='<div><strong data-sync-title="'+section+'"></strong><span data-sync-state="'+section+'"></span><small data-sync-time="'+section+'"></small></div><button type="button" data-sync-run="'+section+'">Sync</button>';
            row.lastElementChild.onclick=()=>run(section);
            panel.append(row);
        }
        const label=document.createElement('label');
        label.className='wm-sync-midnight';
        label.innerHTML='<input type="checkbox"> Daily sync at midnight';
        label.firstElementChild.checked=read().midnight!==false;
        label.firstElementChild.onchange=()=>{change(data=>{data.midnight=label.firstElementChild.checked;});tick();};
        main.before(panel,label);
        globalThis.WebMarkInterfaceLocale?.capture(label);
        paint();
    }
    globalThis.WebMarkSyncCenter={pending,revision,complete,run,mount};
    const start=()=>{
        globalThis.WebMarkCloud?.subscribe(paint);
        globalThis.WebMarkInterfaceLocale?.onChange(paint);
        setTimeout(tick,6000);
        addEventListener('online',tick);
        addEventListener('focus',tick);
        document.addEventListener('visibilitychange',()=>{if(!document.hidden)tick();});
    };
    if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start,{once:true});
    else start();
})();

