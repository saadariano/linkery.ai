
/* Notes workspace tools. Plain text stays portable; formatted text and ink are optional. */
(()=>{'use strict';
 const tr=(text,values)=>globalThis.WebMarkInterfaceLocale?.text(text,values)??text;
 const $=id=>document.getElementById(id),native=()=>window.WebMarkAndroid;
 let rich,canvas,ink=[],stroke=null,tool='pen',color='#4f6fff',paper='plain',undo=[],ready=false,active=null;
 const allowed=new Set(['B','STRONG','I','EM','U','S','P','DIV','BR','UL','OL','LI','H2','H3','BLOCKQUOTE','MARK','SPAN','FONT']);
 function sanitize(html){
  const root=document.createElement('div'),parsed=new DOMParser().parseFromString(String(html||'').slice(0,200000),'text/html');
  const copy=(from,to)=>{for(const node of from.childNodes){if(node.nodeType===3){to.append(document.createTextNode(node.textContent));continue;}if(node.nodeType!==1||['SCRIPT','STYLE','IFRAME','OBJECT','SVG','IMG','AUDIO','VIDEO'].includes(node.tagName))continue;
   const target=allowed.has(node.tagName)?document.createElement(node.tagName):document.createElement('span');
   for(const property of ['color','background-color','font-weight','font-style','text-decoration','text-align']){const value=node.style.getPropertyValue(property);if(value&&/^[#a-zA-Z0-9(),.% -]{1,60}$/.test(value))target.style.setProperty(property,value);}
   if(node.tagName==='FONT'&&/^#[a-f0-9]{6}$/i.test(node.getAttribute('color')||''))target.style.color=node.getAttribute('color');
   copy(node,target);to.append(target);
  }};copy(parsed.body,root);return root.innerHTML;
 }
 function cleanInk(rows){return (Array.isArray(rows)?rows:[]).slice(0,120).map(row=>({tool:['pen','pencil','highlighter','calligraphy','rectangle','ellipse','tape'].includes(row.tool)?row.tool:'pen',color:/^#[a-f0-9]{6}$/i.test(row.color)?row.color:'#4f6fff',points:(Array.isArray(row.points)?row.points:[]).slice(0,400).filter(p=>Array.isArray(p)&&p.length===2&&p.every(Number.isFinite)).map(p=>p.map(n=>Math.round(Math.max(0,Math.min(1,n))*1000)/1000))})).filter(row=>row.points.length);
 }
 function paint(target=canvas,rows=ink){if(!target)return;const c=target.getContext('2d'),w=target.width,h=target.height;c.clearRect(0,0,w,h);
  for(const row of rows){if(!row.points.length)continue;c.save();c.strokeStyle=row.color;c.fillStyle=row.color;c.lineCap='round';c.lineJoin='round';c.lineWidth=row.tool==='highlighter'?18:row.tool==='calligraphy'?5:row.tool==='pencil'?1.5:3;c.globalAlpha=row.tool==='highlighter'?.3:1;
   const [x,y]=row.points[0],last=row.points.at(-1);c.beginPath();
   if(row.tool==='rectangle'||row.tool==='tape'){c.rect(x*w,y*h,(last[0]-x)*w,(last[1]-y)*h);if(row.tool==='tape'){c.fillStyle='#c6b5ff';c.fill();}else c.stroke();}
   else if(row.tool==='ellipse'){c.ellipse((x+last[0])*w/2,(y+last[1])*h/2,Math.abs(last[0]-x)*w/2,Math.abs(last[1]-y)*h/2,0,0,Math.PI*2);c.stroke();}
   else{c.moveTo(x*w,y*h);for(const p of row.points)c.lineTo(p[0]*w,p[1]*h);if(row.points.length===1)c.lineTo(x*w+.5,y*h+.5);c.stroke();}c.restore();
  }
 }
 function changed(){if(!ready)return;$('wm-note-body').value=rich.innerText.slice(0,100000);$('wm-note-body').dispatchEvent(new Event('input',{bubbles:true}));}
 function noteExtras(){return {rich:rich?sanitize(rich.innerHTML):'',ink:cleanInk(ink),paper,reminderAt:Date.parse($('wm-studio-date')?.value||'')||null};}
 function open(note){ready=false;active=note;ink=cleanInk(note?.ink);undo=[];paper=['plain','lined','grid'].includes(note?.paper)?note.paper:'plain';rich.innerHTML=note?.rich?sanitize(note.rich):'';if(!note?.rich)rich.textContent=note?.body||'';
  $('wm-studio-paper').value=paper;rich.dataset.paper=paper;$('wm-studio-date').value=note?.reminderAt?localDate(note.reminderAt):'';canvas.hidden=!ink.length;paint();ready=true;updateReminderLabel();updateAlarmButton();const calendarButton=$('wm-studio-calendar');calendarButton.textContent=tr('Add to calendar');calendarButton.classList.remove('wm-note-confirmed');}
 function localDate(at){const d=new Date(at);return new Date(at-d.getTimezoneOffset()*60000).toISOString().slice(0,16);}
 function updateReminderLabel(){const el=$('wm-studio-reminder-status');if(el)el.textContent=$('wm-studio-date').value?tr('Reminder set for')+' '+new Date($('wm-studio-date').value).toLocaleString(document.documentElement.lang): tr('Choose a date and time. Android reminders ring until Stop or Snooze.');}
 function updateAlarmButton(){
  const button=$('wm-studio-permission');if(!button)return;
  const enabled=!!native()?.remindersEnabled?.();
  button.textContent=enabled?tr('Alarms enabled'):native()?.reminderPermissions?tr('Enable alarms'):tr('Alarms on Android');
  button.classList.toggle('wm-note-confirmed',enabled);
  button.disabled=enabled||!native()?.reminderPermissions;
  $('wm-studio-ring').disabled=!native()?.chooseReminderRingtone;
 }
 function reschedule(){updateAlarmButton();const library=window.WebMarkNotesData?.();if(!library)return 'not-loaded';const rows=library.notes||[];if(native()?.noteReminders){const status=native().noteReminders(JSON.stringify(rows.filter(n=>!n.deletedAt&&!n.archived&&Number.isFinite(n.reminderAt)&&n.reminderAt>0).map(n=>({id:n.id,at:n.reminderAt}))));
  const el=$('wm-studio-alarm-status');if(el)el.textContent=status==='permission'?tr('Allow Alarms & reminders, then return here.'):status==='notifications'?tr('Allow notifications so you can Stop or Snooze.'):status==='ok'?tr('Reminder schedule saved on this Android device.'):tr('Could not schedule reminders. Check permissions and try again.');
  return status;}
  return 'browser';
 }
 function reader(note,content){const holder=$('wm-note-reader-text');if(content.rich)holder.innerHTML=sanitize(content.rich);if(content.ink?.length){const image=document.createElement('canvas');image.width=900;image.height=600;image.style.cssText='width:100%;height:auto';paint(image,cleanInk(content.ink));holder.append(image);}}
 function calendar(){const at=Date.parse($('wm-studio-date').value)||Date.now()+3600000,title=$('wm-note-title').value||'WebMark Note',body=$('wm-note-body').value;
  if(native()?.noteCalendar){native().noteCalendar(title,body,at);return;}
  const stamp=n=>new Date(n).toISOString().replace(/[-:]/g,'').replace(/\.\d{3}/,'');const q=new URLSearchParams({action:'TEMPLATE',text:title,details:body.slice(0,10000),dates:stamp(at)+'/'+stamp(at+3600000)});window.open('https://calendar.google.com/calendar/render?'+q,'_blank','noopener');
 }
 let listsDialog, listsButton;
 function closeLists(restoreFocus=true){
  if(!listsDialog?.open)return false;
  listsDialog.close();
  if(restoreFocus)listsButton.focus();
  return true;
 }
 function setupLists(){
  const app=$('wm-notes-app'), sidebar=app.querySelector('.wm-notes-sidebar');
  const compact=matchMedia('(max-width:620px)');
  const marker=document.createComment('Notes list location');
  sidebar.before(marker);
  listsButton=document.createElement('button');
  listsButton.type='button';
  listsButton.className='wm-notes-button wm-notes-icon wm-studio-lists';
  listsButton.setAttribute('aria-label','Note lists and folders');
  listsButton.setAttribute('aria-haspopup','dialog');
  listsButton.innerHTML='<i class="fa-solid fa-list" aria-hidden="true"></i>';
  $('wm-notes-title').after(listsButton);
  listsDialog=document.createElement('dialog');
  listsDialog.id='wm-studio-lists';
  listsDialog.setAttribute('aria-label','Note lists and folders');
  const heading=document.createElement('header');
  heading.className='wm-notes-header';
  heading.innerHTML='<strong>Lists & folders</strong><button type="button" class="wm-notes-button wm-red-close" aria-label="Close lists">×</button>';
  heading.querySelector('button').onclick=()=>closeLists();
  listsDialog.append(heading);
  app.append(listsDialog);
  listsButton.onclick=()=>listsDialog.showModal();
  listsDialog.addEventListener('click',event=>{
   if(event.target===listsDialog||event.target.closest('[data-note-action="view"],[data-note-action="add-folder"]'))closeLists();
  });
  const resize=()=>{
   if(compact.matches)listsDialog.append(sidebar);
   else {closeLists(false);marker.after(sidebar);}
  };
  compact.addEventListener('change',resize);
  resize();
 }
 function setup(){
  if(!$('wm-note-editor'))return;
  setupLists();
  const header=$('wm-note-editor').querySelector('header');
  const done=header.querySelector('[data-note-action="done"]');
  done.insertAdjacentHTML('beforebegin','<button type="button" class="wm-notes-button" id="wm-studio-share">Share</button><button type="button" class="wm-notes-button" id="wm-studio-pdf">Share PDF</button><button type="button" class="wm-notes-button" id="wm-studio-print">Print</button>');
  header.insertAdjacentHTML('beforeend','<button type="button" class="wm-notes-button" id="wm-studio-more" aria-label="Note options"><i class="fa-solid fa-ellipsis-vertical" aria-hidden="true"></i></button>');
  $('wm-note-body').hidden=true;$('wm-note-body').insertAdjacentHTML('afterend','<div id="wm-studio-rich" contenteditable="true" role="textbox" aria-multiline="true" aria-label="Note text" dir="auto" data-placeholder="Start writing…"></div><canvas id="wm-studio-ink" width="900" height="600" aria-label="Drawing page" hidden></canvas><div id="wm-studio-tools" role="toolbar" aria-label="Note tools"><button type="button" data-format="undo" title="Undo">↶</button><button type="button" data-format="bold" title="Bold"><b>B</b></button><button type="button" data-format="italic" title="Italic"><i>I</i></button><button type="button" data-format="underline" title="Underline"><u>U</u></button><button type="button" data-format="insertUnorderedList" title="Bullet list">☷</button><button type="button" id="wm-studio-checklist" title="Insert checklist item">☐</button><button type="button" data-format="hiliteColor" title="Highlight">▰</button><button type="button" id="wm-studio-type" title="Type"><i class="fa-solid fa-keyboard"></i></button><select id="wm-studio-tool" aria-label="Drawing tool"><option value="pen">Pen</option><option value="pencil">Pencil</option><option value="calligraphy">Calligraphy</option><option value="highlighter">Highlighter</option><option value="eraser">Eraser</option><option value="rectangle">Rectangle</option><option value="ellipse">Ellipse</option><option value="tape">Tape</option></select><input id="wm-studio-ink-color" type="color" value="#4f6fff" aria-label="Ink color"><button type="button" id="wm-studio-undo-ink" title="Undo drawing">↶ Ink</button></div>');
  const options=document.createElement('details');options.id='wm-studio-options';options.innerHTML='<summary>Note options · Folder, color & reminder</summary><div class="wm-studio-options-inner"><label>Paper <select id="wm-studio-paper"><option value="plain">Plain</option><option value="lined">Lined</option><option value="grid">Grid</option></select></label><label>Reminder <input id="wm-studio-date" type="datetime-local"></label><p id="wm-studio-reminder-status"></p><div class="wm-note-toolbar"><button type="button" class="wm-notes-button" id="wm-studio-clear-reminder">Remove reminder</button><button type="button" class="wm-notes-button" id="wm-studio-ring">Choose ringtone</button><button type="button" class="wm-notes-button" id="wm-studio-permission">Enable alarms</button><button type="button" class="wm-notes-button" id="wm-studio-calendar">Add to calendar</button></div><p id="wm-studio-alarm-status" role="status"></p><p>Reminders ring on Android. Calendar opens your calendar app to review and save an event. Browser pages cannot ring reliably after closing.</p></div>';
  $('wm-note-editor').querySelector('.wm-notes-fields').append(options);const inner=options.querySelector('.wm-studio-options-inner');
  for(const id of ['wm-note-folder','wm-note-colors-label','wm-note-colors']){const el=$(id);if(id==='wm-note-folder'){const label=document.querySelector('label[for="wm-note-folder"]');inner.append(label,el.parentElement);}else inner.append(el);}
  rich=$('wm-studio-rich');canvas=$('wm-studio-ink');rich.addEventListener('input',changed);
  rich.addEventListener('paste',event=>{event.preventDefault();document.execCommand('insertText',false,(event.clipboardData?.getData('text/plain')||'').slice(0,100000));changed();});
  rich.addEventListener('drop',event=>event.preventDefault());
  $('wm-studio-tools').addEventListener('pointerdown',e=>{if(e.target.closest('[data-format]'))e.preventDefault();});
  $('wm-studio-tools').addEventListener('click',e=>{const format=e.target.closest('[data-format]')?.dataset.format;if(format){rich.focus();document.execCommand(format,false,format==='hiliteColor'?'#fff49a':null);changed();}});
  $('wm-studio-checklist').onpointerdown=event=>event.preventDefault();
  $('wm-studio-checklist').onclick=()=>{rich.focus();document.execCommand('insertText',false,'☐ ');changed();};
  $('wm-studio-more').onclick=()=>{options.open=!options.open;if(options.open)options.scrollIntoView({behavior:'smooth',block:'nearest'});};
  $('wm-studio-tool').onchange=e=>{tool=e.target.value;canvas.hidden=false;canvas.style.touchAction='none';canvas.scrollIntoView({block:'nearest'});};
  $('wm-studio-ink-color').oninput=e=>color=e.target.value;
  $('wm-studio-type').onclick=()=>{canvas.style.touchAction='auto';rich.focus();};
  $('wm-studio-undo-ink').onclick=()=>{if(undo.length)ink=undo.pop();paint();changed();};
  const point=e=>{const r=canvas.getBoundingClientRect();return [Math.max(0,Math.min(1,(e.clientX-r.left)/r.width)),Math.max(0,Math.min(1,(e.clientY-r.top)/r.height))];};
  canvas.onpointerdown=e=>{if(canvas.style.touchAction!=='none')return;e.preventDefault();undo.push(JSON.parse(JSON.stringify(ink)));if(undo.length>20)undo.shift();canvas.setPointerCapture(e.pointerId);const p=point(e);if(tool==='eraser'){ink=ink.filter(s=>!s.points.some(q=>Math.hypot(q[0]-p[0],q[1]-p[1])<.045));paint();changed();return;}if(ink.length>=120){alert('Drawing page is full. Erase or undo a stroke first.');return;}stroke={tool,color,points:[p]};ink.push(stroke);paint();};
  canvas.onpointermove=e=>{if(!stroke)return;if(stroke.points.length<400&&ink.reduce((total,row)=>total+row.points.length,0)<4000)stroke.points.push(point(e));paint();};
  canvas.onpointerup=canvas.onpointercancel=()=>{if(stroke){stroke=null;changed();}};
  $('wm-studio-paper').onchange=e=>{paper=e.target.value;rich.dataset.paper=paper;changed();};
  $('wm-studio-date').onchange=async()=>{const at=Date.parse($('wm-studio-date').value);if(at&&at<=Date.now()){alert('Choose a future date and time.');$('wm-studio-date').value='';}updateReminderLabel();changed();reschedule();};
  $('wm-studio-clear-reminder').onclick=()=>{$('wm-studio-date').value='';updateReminderLabel();changed();reschedule();};
  $('wm-studio-ring').onclick=()=>{if(native()?.chooseReminderRingtone)native().chooseReminderRingtone();else alert('Ringtone selection is available in the Android APK.');};
  $('wm-studio-permission').onclick=()=>{if(native()?.reminderPermissions)native().reminderPermissions();else alert('Install the Android APK for background ringing reminders.');};
  $('wm-studio-calendar').onclick=()=>{
   calendar();
   const button=$('wm-studio-calendar');button.textContent=tr('Save event in calendar');button.classList.add('wm-note-confirmed');
  };
  $('wm-studio-share').onclick=async()=>{const text=$('wm-note-title').value+'\n\n'+$('wm-note-body').value;if(native()?.shareText)native().shareText(text);else if(navigator.share)await navigator.share({title:$('wm-note-title').value,text});else await wmCopy(text);};
  function editorNote(){
   let drawing;
   if(ink.length){drawing=document.createElement('canvas');drawing.width=900;drawing.height=600;paint(drawing);}
   return {title:$('wm-note-title').value||'WebMark Note',body:$('wm-note-body').value,
    rich:sanitize(rich.innerHTML),drawing,date:''};
  }
  $('wm-studio-print').onclick=()=>WebMarkNotesExport.print([editorNote()]);
  $('wm-studio-pdf').onclick=async()=>{
   const button=$('wm-studio-pdf');button.disabled=true;
   try{await WebMarkNotesExport.sharePdf(editorNote());}
   catch(error){if(error.name!=='AbortError')alert(error.message||'Could not share the PDF.');}
   finally{button.disabled=false;}
  };

  const hero=document.createElement('div');hero.className='wm-studio-hero';const emblem=document.createElement('i');emblem.className='fa-solid fa-pen-nib';const heading=document.createElement('h2');heading.textContent=new Date().toLocaleDateString(document.documentElement.lang,{weekday:'long',day:'numeric',month:'long'});hero.append(emblem,heading);const homeActions=document.createElement('div');homeActions.className='wm-studio-home-actions';homeActions.innerHTML='<button type="button" class="wm-notes-button" id="wm-studio-import"><i class="fa-solid fa-file-import"></i> Import text</button><input type="file" accept=".txt,.md,text/plain,text/markdown" id="wm-studio-import-file" hidden>';const pdf=document.createElement('button');pdf.type='button';pdf.className='wm-notes-button';
  pdf.innerHTML='<i class="fa-solid fa-file-pdf" aria-hidden="true"></i> '+(native()?.openPdfMarkup?'Mark up PDF':'Import PDF');
  if(native()?.openPdfMarkup)pdf.onclick=()=>native().openPdfMarkup();
  else{
   const picker=document.createElement('input');picker.type='file';picker.accept='.pdf,application/pdf';picker.hidden=true;
   const status=document.createElement('p');status.setAttribute('role','status');
   pdf.onclick=()=>picker.click();
   picker.onchange=async()=>{
    const file=picker.files?.[0];picker.value='';if(!file)return;
    pdf.disabled=true;status.textContent=tr('Reading PDF…');
    let loading;
    try{
     if(file.size>25*1024*1024)throw Error('Choose a PDF smaller than 25 MB.');
     const pdfjs=await import('./pdf-import.min.mjs');
     pdfjs.GlobalWorkerOptions.workerSrc=new URL('./pdf-import.worker.min.mjs',location.href).href;
     loading=pdfjs.getDocument({data:await file.arrayBuffer(),isEvalSupported:false,enableXfa:false});
     const doc=await loading.promise;
     if(doc.numPages>200)throw Error('Choose a PDF with 200 pages or fewer.');
     let text='';
     for(let number=1;number<=doc.numPages;number++){
      const page=await doc.getPage(number);
      const content=await page.getTextContent();
      text+=content.items.map(item=>item.str===undefined?'':item.str+(item.hasEOL?'\n':' ')).join('')+'\n\n';
      if(text.length>100000)throw Error('This PDF contains more text than fits in one note.');
     }
     if(!text.trim())throw Error('No selectable text found. Scanned PDFs need OCR first.');
     await window.WebMarkNotesImportText(file.name.replace(/\.pdf$/i,''),text.trim());
     status.textContent=tr('PDF text imported into a note.');
    }catch(error){status.textContent=error.name==='PasswordException'?tr('Unlock the PDF before importing.'):error.message||tr('Could not import PDF.');}
    finally{await loading?.destroy().catch(()=>{});pdf.disabled=false;}
   };
   hero.append(picker);homeActions.append(status);
  }
  homeActions.prepend(pdf);
  hero.append(homeActions);$('wm-note-view').before(hero);$('wm-studio-import').onclick=()=>$('wm-studio-import-file').click();$('wm-studio-import-file').onchange=async e=>{const file=e.target.files?.[0];e.target.value='';if(!file)return;if(file.size>100000){alert('Choose a text file smaller than 100 KB.');return;}await window.WebMarkNotesImportText?.(file.name.replace(/\.[^.]+$/,''),await file.text());};
  const settings=$('wm-note-settings').querySelector('.wm-notes-fields')||$('wm-note-settings').querySelector('div');if(settings){const row=document.createElement('section');row.className='wm-note-settings-group';row.innerHTML='<h3>Reminders & calendar</h3><p>Set the reminder in each note’s options. Choose a phone ringtone; it repeats until Stop or Snooze. Alarms use the phone’s alarm volume and system settings.</p><button type="button" class="wm-notes-button" id="wm-studio-stop">Stop ringing</button>';settings.append(row);$('wm-studio-stop').onclick=()=>native()?.stopNoteAlarm?.();}
  const locale=globalThis.WebMarkInterfaceLocale;
  for(const id of ['wm-studio-lists','wm-notes-app','wm-note-editor','wm-note-settings'])locale?.capture($(id));
  updateAlarmButton();
  locale?.onChange(()=>{
   heading.textContent=new Date().toLocaleDateString(document.documentElement.lang,{weekday:'long',day:'numeric',month:'long'});
   updateReminderLabel();updateAlarmButton();
  });
  window.addEventListener('focus',reschedule);document.addEventListener('visibilitychange',()=>{if(!document.hidden)reschedule();});
 }
 window.WebMarkNoteStudio={open,extras:noteExtras,reschedule,reader,sanitize,cleanInk,closeLists};setup();
})();

