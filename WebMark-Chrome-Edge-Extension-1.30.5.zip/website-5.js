

// ── INLINE PAGE FUNCTIONS (mobile only) ──

// Open a modal from inside the settings inline page —
// hides settings page, opens modal, returns to settings on close
let _returnToSettings = false;
let _returnToFolders = false;
function openFromSettingsPage(modalId, customFn) {
    document.getElementById('page-settings').classList.remove('active');
    _returnToSettings = true;
    if (customFn) { customFn(); }
    else {
        if (modalId === 'manageTagsModal') renderAllTags();
        if (modalId === 'trashModal') {
            // Always render trash list before opening
            renderTrashModal();
        }
        if (modalId === 'importBMModal') {
            setTimeout(renderImportPicker, 50);
        }
        openModal(modalId);
    }
}

function openPage(name) {
    closeAllPanels();
    if (window.innerWidth >= 768) {
        if (name === 'folders') openManageFolders();
        else if (name === 'settings') openSettings();
        return;
    }
    document.querySelectorAll('.inline-page').forEach(p => p.classList.remove('active'));
    document.querySelectorAll('.nitem').forEach(n => n.classList.remove('active'));
    if (name === 'folders') {
        renderInlineFolders();
        document.getElementById('page-folders').classList.add('active');
        // Always scroll to top when opening folders page
        requestAnimationFrame(()=>{
            const fp = document.querySelector('#page-folders .inline-page-body');
            if (fp) fp.scrollTop = 0;
            const fp2 = document.getElementById('page-folders');
            if (fp2) fp2.scrollTop = 0;
        });
    } else if (name === 'settings') {
        syncSettingsPage();
        document.getElementById('nav-settings').classList.add('active');
        document.getElementById('page-settings').classList.add('active');
        document.getElementById('settingsPageBody').scrollTop = 0;
        requestAnimationFrame(()=>{ document.getElementById('settingsPageBody').scrollTop = 0; });
        // Update theme toggle knob in settings page
        _syncSpThemeToggle();
        // Always update language label with correct current flag
        const lb = document.getElementById('sp-langLabel');
        if (lb) lb.innerHTML = getFlagImg(S.lang) + ' ' + (LANG_LABELS[S.lang]||'English');
        // Update font size label
        const fsLbl = document.getElementById('sp-fontSizeLabel');
        if(fsLbl) fsLbl.textContent = (wmStorage.getItem('ly_fontSize')||'14')+'px';
        // Update font pill active state
        const savedFont = wmStorage.getItem('ly_font')||'Inter';
        document.querySelectorAll('.font-pill').forEach(p=>p.classList.toggle('active', p.dataset.font===savedFont));
    }
}

function closePage() {
    document.querySelectorAll('.inline-page').forEach(p => p.classList.remove('active'));
    resetCollapsibleSections();
    document.querySelectorAll('.nitem').forEach(n => n.classList.remove('active'));
    const map = { all:'nav-home', fav:'nav-fav', vip:'nav-vip', archive:'nav-arc' };
    const el = document.getElementById(map[S.activeTab] || 'nav-home');
    if (el) el.classList.add('active');
}

function renderInlineFolders() {
    const el = document.getElementById('inlineFoldersList');
    if (!el) return;
    el.innerHTML = S.folders.map(f => {
        const cnt = S.links.filter(l => l.fId === f.id && !l.archived).length;
        const col = f.color || '#8b5cf6';
        return `<div class="ifl-row" data-id="${f.id}" style="display:flex;align-items:center;gap:12px;padding:14px 0;border-bottom:1px solid var(--border);">
            <i class="fa-solid fa-grip-lines ifl-handle" data-id="${f.id}" style="color:${col};font-size:20px;flex-shrink:0;cursor:grab;touch-action:none;padding:4px 8px;"></i>
            <i class="${f.icon}" style="color:${col};font-size:18px;flex-shrink:0;width:22px;text-align:center;"></i>
            <span style="flex:1;font-size:15px;font-weight:600;">${esc(f.name)}</span>
            <span style="background:#3f3f46;color:#fff;border-radius:6px;padding:2px 8px;font-size:12px;font-weight:700;">${cnt}</span>
            <button data-wm-click="190" data-wm-click-0="${f.id}" style="background:rgba(245,158,11,.15);color:#f59e0b;border:1px solid rgba(245,158,11,.3);border-radius:8px;width:36px;height:36px;cursor:pointer;display:flex;align-items:center;justify-content:center;flex-shrink:0;"><i class="fa-solid fa-pencil"></i></button>
            <button data-wm-click="227" data-wm-click-0="${f.id}" style="background:rgba(239,68,68,.15);color:#ef4444;border:1px solid rgba(239,68,68,.3);border-radius:8px;width:36px;height:36px;cursor:pointer;display:flex;align-items:center;justify-content:center;flex-shrink:0;"><i class="fa-solid fa-trash"></i></button>
        </div>`;
    }).join('') || '<div style="text-align:center;padding:40px 0;color:var(--text-dim);"><i class="fa-solid fa-folder-open" style="font-size:36px;opacity:.3;display:block;margin-bottom:10px;"></i>No folders yet</div>';
    // Attach touch drag handlers to grip handles
    el.querySelectorAll('.ifl-handle').forEach(handle => {
        handle.addEventListener('touchstart', iflTouchStart, {passive:false});
    });
}
// Inline folders touch drag state
let _iflDragId=null, _iflClone=null, _iflOffY=0, _iflScrollRaf=null;
function iflTouchStart(e){
    e.preventDefault();
    const id = parseInt(this.dataset.id);
    _iflDragId = id;
    const row = this.closest('.ifl-row');
    const rect = row.getBoundingClientRect();
    _iflOffY = e.touches[0].clientY - rect.top;
    _iflClone = row.cloneNode(true);
    _iflClone.style.cssText = `position:fixed;left:${rect.left}px;top:${rect.top}px;width:${rect.width}px;z-index:9999;opacity:.85;background:var(--card);border-radius:12px;box-shadow:0 8px 32px rgba(0,0,0,.4);pointer-events:none;`;
    document.body.appendChild(_iflClone);
    row.style.opacity = '.3';
    document.addEventListener('touchmove', iflTouchMove, {passive:false});
    document.addEventListener('touchend', iflTouchEnd);
}
function iflTouchMove(e){
    e.preventDefault();
    if(!_iflClone) return;
    const ty = e.touches[0].clientY;
    const tx = e.touches[0].clientX;
    _iflClone.style.top = (ty - _iflOffY) + 'px';
    // Highlight target row
    document.querySelectorAll('.ifl-row').forEach(r => r.style.borderTop = '');
    const el = document.elementFromPoint(tx, ty);
    const target = el && el.closest('.ifl-row');
    if(target && parseInt(target.dataset.id) !== _iflDragId) target.style.borderTop = '2px solid var(--primary)';
    // Auto-scroll the inline-page-body container
    if(_iflScrollRaf){ cancelAnimationFrame(_iflScrollRaf); _iflScrollRaf=null; }
    const scroller = document.getElementById('inlineFoldersList') || document.querySelector('#page-folders .inline-page-body');
    if(scroller){
        const sr = scroller.getBoundingClientRect();
        const ZONE=90, SPEED=10;
        let dir=0;
        if(ty < sr.top + ZONE)      dir = -SPEED;
        else if(ty > sr.bottom - ZONE) dir =  SPEED;
        if(dir !== 0){
            const scroll = () => { scroller.scrollTop += dir; if(_iflClone) _iflScrollRaf=requestAnimationFrame(scroll); };
            _iflScrollRaf = requestAnimationFrame(scroll);
        }
    }
}
function iflTouchEnd(e){
    if(_iflScrollRaf){ cancelAnimationFrame(_iflScrollRaf); _iflScrollRaf=null; }
    document.removeEventListener('touchmove', iflTouchMove);
    document.removeEventListener('touchend', iflTouchEnd);
    if(_iflClone){ document.body.removeChild(_iflClone); _iflClone=null; }
    document.querySelectorAll('.ifl-row').forEach(r => { r.style.opacity=''; r.style.borderTop=''; });
    const el = document.elementFromPoint(e.changedTouches[0].clientX, e.changedTouches[0].clientY);
    const target = el && el.closest('.ifl-row');
    if(target){
        const toId = parseInt(target.dataset.id);
        if(toId && toId !== _iflDragId){
            const si = S.folders.findIndex(f=>f.id===_iflDragId);
            const ti = S.folders.findIndex(f=>f.id===toId);
            if(si>=0&&ti>=0){ const [mv]=S.folders.splice(si,1); S.folders.splice(ti,0,mv); save(); renderInlineFolders(); renderTabs(); }
        }
    }
    _iflDragId=null;
}

function syncSettingsPage() {
    const keys = ['showFolders','showTags','sortByDate','compactCards','showViews','openNewTab','showThumbs','hideImported','pinnedTop','showImportedBadge'];
    const defaultOn = ['showFolders','openNewTab','showThumbs','pinnedTop','showTags'];
    keys.forEach(k => {
        const val = S.settings[k] !== undefined ? S.settings[k] : defaultOn.includes(k);
        const tog = document.getElementById('sp-tog-' + k);
        const knob = document.getElementById('sp-togInner-' + k);
        if (tog) { tog.style.background = val ? 'var(--primary)' : '#27272a'; }
        if (knob) { knob.style.left = val ? 'auto' : '2px'; knob.style.right = val ? '2px' : 'auto'; }
    });
    const g = id => document.getElementById(id);
    const total = S.links.filter(l => !l.archived).length;
    if (g('sp-statTotalLinks')) g('sp-statTotalLinks').textContent = total;
    if (g('sp-statTotalFolders')) g('sp-statTotalFolders').textContent = S.folders.length;
    if (g('sp-statFavs')) g('sp-statFavs').textContent = S.links.filter(l => l.fav && !l.archived).length;
    if (g('sp-statArchived')) g('sp-statArchived').textContent = S.links.filter(l => l.archived).length;
    _syncSpThemeToggle();
    // Update language label
    const lb = document.getElementById('sp-langLabel');
    if (lb) lb.innerHTML = getFlagImg(S.lang) + ' ' + (LANG_LABELS[S.lang]||'English');
    // Populate browser source toggles in mobile settings
    setTimeout(renderPerBrowserToggles, 10);
    setTimeout(updateBrowserPills, 10);
}

function _syncSpThemeToggle() {
    const isDark = !document.body.classList.contains('light-mode');
    const tog = document.getElementById('sp-themeToggleRow');
    const knob = document.getElementById('sp-themeToggleKnob');
    if (tog) tog.style.background = isDark ? '#27272a' : 'var(--primary)';
    if (knob) {
        knob.style.left = isDark ? '2px' : 'auto';
        knob.style.right = isDark ? 'auto' : '2px';
        knob.innerHTML = isDark ? '<i class="fa-solid fa-moon" style="color:#a78bfa;font-size:10px;"></i>' : '<i class="fa-solid fa-sun" style="color:#f59e0b;font-size:10px;"></i>';
    }
}

// Patch openManageFolders & openSettings to route to inline page on mobile
const _origOpenManageFolders = openManageFolders;
openManageFolders = function() {
    if (window.innerWidth <= 767) { openPage('folders'); return; }
    _origOpenManageFolders();
};
const _origOpenSettings = openSettings;
openSettings = function() {
    if (window.innerWidth <= 767) { openPage('settings'); return; }
    _origOpenSettings();
};
// Also refresh inline folders after saves
const _origRenderManageFolders = renderManageFolders;
renderManageFolders = function() {
    _origRenderManageFolders();
    if (document.getElementById('page-folders').classList.contains('active')) renderInlineFolders();
};
// Sync inline toggles when toggleSetting is called
const _origToggleSetting = toggleSetting;
toggleSetting = function(k) {
    _origToggleSetting(k);
    const val = S.settings[k];
    const tog = document.getElementById('sp-tog-' + k);
    const knob = document.getElementById('sp-togInner-' + k);
    if (tog) { tog.style.background = val ? 'var(--primary)' : '#27272a'; }
    if (knob) { knob.style.left = val ? 'auto' : '2px'; knob.style.right = val ? '2px' : 'auto'; }
};

