
(() => {
    const encoder = new TextEncoder();
    const crcTable = Uint32Array.from({length:256}, (_, byte) => {
        for(let bit=0;bit<8;bit++) byte=(byte>>>1)^((byte&1)?0xedb88320:0);
        return byte;
    });

    function zip(entries,type='application/zip') {
        const files=[], directory=[];
        let offset=0, directorySize=0;
        for(const [path,value] of entries) {
            const name=encoder.encode(path), data=typeof value==='string'?encoder.encode(value):value;
            let crc=0xffffffff;
            for(const byte of data) crc=(crc>>>8)^crcTable[(crc^byte)&255];
            crc=(crc^0xffffffff)>>>0;
            const local=new Uint8Array(30), central=new Uint8Array(46);
            const l=new DataView(local.buffer), c=new DataView(central.buffer);
            l.setUint32(0,0x04034b50,true);
            l.setUint16(4,20,true);
            l.setUint16(12,33,true);
            l.setUint32(14,crc,true);
            l.setUint32(18,data.length,true);
            l.setUint32(22,data.length,true);
            l.setUint16(26,name.length,true);
            c.setUint32(0,0x02014b50,true);
            c.setUint16(4,20,true);
            central.set(local.subarray(4,30),6);
            c.setUint32(42,offset,true);
            files.push(local,name,data);
            directory.push(central,name);
            offset+=local.length+name.length+data.length;
            directorySize+=central.length+name.length;
        }
        const end=new Uint8Array(22), record=new DataView(end.buffer);
        record.setUint32(0,0x06054b50,true);
        record.setUint16(8,entries.length,true);
        record.setUint16(10,entries.length,true);
        record.setUint32(12,directorySize,true);
        record.setUint32(16,offset,true);
        return new Blob([...files,...directory,end],{type});
    }

    async function backup() {
        await wmStorage.ready;
        const notes=wmJSON('wm_notes_v1',{notes:[],folders:[]});
        const vault=wmStorage.getItem('wm_password_vault_v1');
        const entries=[
            ['bookmarks.json',JSON.stringify({format:'webmark-v4',f:S.folders,l:S.links,trash:S.trash||[]})],
            ['notes.json',JSON.stringify({format:'webmark-notes-v2',...mergeNotes(notes,{})})]
        ];
        if(vault) entries.push(['passwords-encrypted.webmark',vault]);
        const file=zip(entries);
        wmDownload('WebMark-Backup-'+new Date().toISOString().slice(0,10)+'.zip',file,file.type);
    }

    if(typeof document!=='undefined')document.addEventListener('DOMContentLoaded',()=>{
        for(const container of document.querySelectorAll('#settingsPageBody,#settingsModal .mc')){
            const button=document.createElement('button');
            button.type='button';button.className='erow wm-setting-action wm-backup-action';
            button.textContent='Export everything';
            button.onclick=async()=>{
                if(!confirm('Export bookmarks, notes, and the encrypted password vault in one ZIP? Keep the ZIP private.'))return;
                try{await backup();}catch(error){alert('Backup failed. '+error.message);}
            };
            container.append(button);
        }
    });
})();
