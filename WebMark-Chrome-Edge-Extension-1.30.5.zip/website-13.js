
const WebMarkNoteVault = (() => {
    const bytes = value => new TextEncoder().encode(value);
    const random = size => crypto.getRandomValues(new Uint8Array(size));
    const encode = value => {
        const array = new Uint8Array(value);
        let binary = '';
        for (let index=0;index<array.length;index+=8192) {
            binary += String.fromCharCode(...array.subarray(index,index+8192));
        }
        return btoa(binary);
    };
    const decode = value => Uint8Array.from(atob(value), character=>character.charCodeAt(0));
    const aesKey = raw => crypto.subtle.importKey('raw',raw,'AES-GCM',false,['encrypt','decrypt']);

    async function derivedKey(secret,salt) {
        const material = await crypto.subtle.importKey('raw',bytes(secret),'PBKDF2',false,['deriveKey']);
        return crypto.subtle.deriveKey(
            {name:'PBKDF2',salt,iterations:600000,hash:'SHA-256'},material,
            {name:'AES-GCM',length:256},false,['encrypt','decrypt']
        );
    }

    async function seal(key,value,context) {
        const iv = random(12);
        const data = await crypto.subtle.encrypt({name:'AES-GCM',iv,additionalData:bytes(context)},key,value);
        return {iv:encode(iv),data:encode(data)};
    }

    function unseal(key,box,context) {
        return crypto.subtle.decrypt(
            {name:'AES-GCM',iv:decode(box.iv),additionalData:bytes(context)},key,decode(box.data)
        );
    }

    async function wrap(id,raw,secret) {
        const salt = random(16);
        return {salt:encode(salt),...await seal(await derivedKey(secret,salt),raw,id)};
    }

    async function unwrap(vault,method,secret) {
        const box = vault[method];
        return unseal(await derivedKey(secret,decode(box.salt)),box,vault.id);
    }

    return {
        async create(password) {
            const id = 'vault-'+encode(random(18)).replaceAll('+','-').replaceAll('/','_');
            const recoveryCode = encode(random(24)).replaceAll('+','-').replaceAll('/','_');
            const key = random(32);
            const [passwordBox,recovery] = await Promise.all([
                wrap(id,key,password),wrap(id,key,recoveryCode),
            ]);
            return {vault:{id,password:passwordBox,recovery,updatedAt:Date.now()},recoveryCode};
        },
        async verify(vault,password) {
            await unwrap(vault,'password',password);
        },
        async reset(vault,recoveryCode,newPassword) {
            const key = await unwrap(vault,'recovery',recoveryCode);
            return {...vault,password:await wrap(vault.id,key,newPassword),updatedAt:Date.now()};
        },
        async lock(vault,password,note) {
            const key = await aesKey(await unwrap(vault,'password',password));
            return seal(key,bytes(JSON.stringify({title:note.title,body:note.body,rich:note.rich||'',ink:note.ink||[],paper:note.paper||'plain'})),note.id);
        },
        async unlock(vault,password,note) {
            const key = await aesKey(await unwrap(vault,'password',password));
            const data = await unseal(key,note.locked,note.id);
            return JSON.parse(new TextDecoder().decode(data));
        },
    };
})();

function mergeNotes(local,remote={}) {
    const result={};
    for(const key of ['notes','folders','vaults','removedNotes','removedFolders']) {
        const rows=new Map();
        for(const row of [...(remote[key]||[]),...(local[key]||[])]) {
            const current=rows.get(row.id);
            const date=row.updatedAt||0;
            const previousDate=current?.updatedAt||0;
            if (!current || date>previousDate ||
                (date===previousDate && JSON.stringify(row)>JSON.stringify(current))) rows.set(row.id,row);
        }
        result[key]=[...rows.values()].sort((a,b)=>a.id.localeCompare(b.id));
    }
    const removedNotes=new Set(result.removedNotes.map(row=>row.id));
    const removedFolders=new Set(result.removedFolders.map(row=>row.id));
    result.notes=result.notes.filter(note=>!removedNotes.has(note.id)).map(note=>
        removedFolders.has(note.folderId)?{...note,folderId:''}:note);
    result.folders=result.folders.filter(folder=>!removedFolders.has(folder.id));
    result.activeVault=[local.activeVault,remote.activeVault,...result.vaults.map(vault=>vault.id)]
        .find(id=>result.vaults.some(vault=>vault.id===id))||null;
    // Concurrent edits can mark more than ten notes as Top 10 on different devices.
    const promoted=result.notes.filter(note=>note.top&&!note.archived&&!note.deletedAt)
        .sort((a,b)=>b.updatedAt-a.updatedAt||a.id.localeCompare(b.id));
    const overflow=new Set(promoted.slice(10).map(note=>note.id));
    result.notes=result.notes.map(note=>overflow.has(note.id)?{...note,top:false,updatedAt:(note.updatedAt||0)+1}:note);
    return result;
}

const WebMarkNotesExport = (() => {
    function print(rows) {
        const escape = value => String(value).replace(/[&<>]/g,char=>({'&':'&amp;','<':'&lt;','>':'&gt;'}[char]));
        const articles=rows.map(row=>'<article><h2 dir="auto">'+escape(row.title)+'</h2><time>'+
            escape(row.date)+'</time>'+
            (row.rich||'<p dir="auto">'+escape(row.body)+'</p>')+
            (row.drawing?'<img style="width:100%;break-inside:avoid" src="'+row.drawing.toDataURL()+'">':'')+'</article>').join('');
        if(globalThis.WebMarkAndroid?.printNoteDocument){
            WebMarkAndroid.printNoteDocument('<!doctype html><meta charset="utf-8"><title>WebMark Notes</title>'+
                '<style>body{font:12pt sans-serif;color:#111;margin:12mm}article{margin-bottom:18pt}h2{font-size:14pt;break-after:avoid;margin-bottom:3pt}time{font-size:10pt;color:#555}p{white-space:pre-wrap;overflow-wrap:anywhere}</style>'+
                '<h1>WebMark Notes</h1>'+articles);
            return;
        }
        const area=document.getElementById('wm-note-print');
        area.innerHTML='<h1>WebMark Notes</h1>'+articles;
        document.body.classList.add('wm-printing-notes');
        const clean=()=>{document.body.classList.remove('wm-printing-notes');area.replaceChildren();};
        window.addEventListener('afterprint',clean,{once:true});
        try {window.print();} catch(error){clean();throw error;}
    }

    function pdfBytes(rows) {
        if(!globalThis.jspdf?.jsPDF) throw Error('PDF export is unavailable.');
        const file=new jspdf.jsPDF({unit:'mm',format:'a4',compress:true});
        const page=document.createElement('canvas');
        page.width=1190;page.height=1684;
        const context=page.getContext('2d');
        const padding=82,width=page.width-2*padding;
        let y;
        function clear() {
            context.fillStyle='#fff';
            context.fillRect(0,0,page.width,page.height);
            context.textBaseline='top';
            y=padding;
        }
        function flush() {
            file.addImage(page.toDataURL('image/jpeg',0.96),'JPEG',0,0,210,297);
        }
        function text(value,size,bold=false,color='#18181b') {
            const font=(bold?'bold ':'')+size+'px Arial, sans-serif';
            context.font=font;
            const lineHeight=Math.ceil(size*1.45);
            for(const paragraph of String(value).split(/\r?\n/)){
                const rtl=/^[^\p{L}]*[\p{Script=Arabic}\p{Script=Hebrew}]/u.test(paragraph);
                function line(word) {
                    if(y+lineHeight>page.height-padding){flush();file.addPage();clear();}
                    context.font=font;
                    context.fillStyle=color;
                    context.direction=rtl?'rtl':'ltr';
                    context.textAlign=rtl?'right':'left';
                    context.fillText(word,rtl?page.width-padding:padding,y);
                    y+=lineHeight;
                }
                let held='';
                for(const word of paragraph.split(/(\s+)/)){
                    if(context.measureText(held+word).width<=width){held+=word;continue;}
                    if(held.trim()) line(held.trimEnd());
                    held='';
                    if(!word.trim()) continue;
                    if(context.measureText(word).width<=width){held=word;continue;}
                    for(const character of word){
                        if(held&&context.measureText(held+character).width>width){line(held);held='';}
                        held+=character;
                    }
                }
                line(held.trimEnd());
            }
        }
        clear();
        text('WebMark Notes',48,true,'#5b35ab');
        y+=30;
        for(const row of rows){
            if(y+140>page.height-padding){flush();file.addPage();clear();}
            text(row.title,34,true);
            text(row.date,24,false,'#555');
            y+=10;
            text(row.body,30);
            if(row.drawing){
                const height=width*row.drawing.height/row.drawing.width;
                if(y+height>page.height-padding){flush();file.addPage();clear();}
                context.drawImage(row.drawing,padding,y,width,height);
                y+=height;
            }
            y+=30;
        }
        flush();
        return file.output('arraybuffer');
    }
    function pdf(rows){wmDownload('WebMark-Notes.pdf',pdfBytes(rows),'application/pdf');}

    async function sharePdf(row){
        const name=(row.title.replace(/[^\p{L}\p{N} ._-]/gu,'_').trim().slice(0,60)||'WebMark Note')+'.pdf';
        const bytes=pdfBytes([row]);
        if(globalThis.wmShareNoteFile)return wmShareNoteFile(new Blob([bytes],{type:'application/pdf'}),name);
        const file=new File([bytes],name,{type:'application/pdf'});
        if(navigator.canShare?.({files:[file]}))return navigator.share({files:[file]});
        wmDownload(name,bytes,'application/pdf');
    }
    return {print,pdf,sharePdf};
})();

(() => {
    const key = 'wm_notes_v1';
    const tr=(text,values)=>globalThis.WebMarkInterfaceLocale?.text(text,values)??text;
    const $= id => document.getElementById(id);
    const menu = $('wm-app-menu');
    const app = $('wm-notes-app');
    const editor = $('wm-note-editor');
    const folderEditor = $('wm-note-folder-editor');
    const labels = {all:'All notes',favorites:'Favorites',top:'Top 10',archive:'Archive',reminders:'Reminders',trash:'Trash'};
    const icons = {all:'note-sticky',favorites:'heart',top:'star',archive:'box-archive',reminders:'bell',trash:'trash'};
    const settings = $('wm-note-settings');
    const reader = $('wm-note-reader');
    const manager = $('wm-note-folder-manager');
    const iconGroups = {All:null,Folders:/folder|box|archive|bookmark/,Work:/briefcase|laptop|calendar|chart|building|pen/,Life:/house|heart|car|plane|music|cat|book|gamepad/,Brands:/^fa-brands /};
    let iconGroup='All';
    let reading;
    let syncPoll;
    let sort='newest';
    const passwordDialog = $('wm-note-password');
    const tint = {all:'#15803d',favorites:'#dc2626',top:'#a16207',archive:'#2563eb',reminders:'#7c3aed',trash:'#c2410c'};
    const folderIcons = typeof FA_ICONS !== 'undefined' ? [...new Set(FA_ICONS)] :
        ['folder','briefcase','house','book','lightbulb','heart','plane'].map(icon=>'fa-solid fa-'+icon);
    const colors = typeof COLORS !== 'undefined' ? [...new Set(COLORS)] : ['#22c55e','#3b82f6','#ef4444'];
    const selected = new Set();
    let selecting = false;
    let noteColor = '';
    let folderColor = '';
    let passwordPrompt;
    let syncTimer;
    let syncing = false;
    let recoveryCode = '';
    const validColor = color => /^#[0-9a-f]{6}$/i.test(color || '') ? color : '';
    const folderIcon = icon => {
        const value = icon?.includes(' ') ? icon : 'fa-solid fa-'+icon;
        return folderIcons.includes(value) ? value : 'fa-solid fa-folder';
    };
    const newId = prefix => prefix+'-'+(globalThis.crypto?.randomUUID?.() || wmId());
    const stamp = row => Math.max(Date.now(),(row?.updatedAt || 0)+1);
    let library;
    let view = 'all';
    const viewHistory=[];
    let editingId = null;
    let editingFolder = null;
    let draft;
    let originalNote;
    let saveQueue = Promise.resolve();

    function initNotes() {
        if (!library) library = wmJSON(key,{notes:[],folders:[]});
        if (!Array.isArray(library.notes) || !Array.isArray(library.folders)) library={notes:[],folders:[]};
        library.vaults ||= [];
        library.removedNotes ||= [];
        library.removedFolders ||= [];
        sort=library.sort||'newest';
        $('wm-note-sort').value=sort;
        updateSyncSettings();
    }

    const activeVault = () => library.vaults.find(item=>item.id===library.activeVault) || library.vaults[0];
    function setNoteStyle(node,name,value) {
        if (value) node.style.setProperty(name,value);
    }

    function scheduleSync(){clearTimeout(syncTimer);}

    async function syncNotes(manual,automatic=false) {
        if(!manual || syncing || editor.open || folderEditor.open || passwordDialog.open) return;
        const cloud=globalThis.WebMarkCloud;
        const user=cloud?.info().user;
        const status=$('wm-note-settings-status');
        if (!user || !cloud.syncNotes) {
            if(manual) status.textContent=tr('Sign in with Google from WebMark Settings first.');
            return;
        }
        if (library.owner && library.owner!==user.uid) {
            if(manual) status.textContent=tr('These notes are linked to a different Google account.');
            return;
        }
        if (!manual && (!library.owner || library.autoSync===false || navigator.onLine===false)) return;
        if (!library.owner && automatic) return false;
        if (!library.owner && !confirm('Sync these notes with '+user.email+'?')) return;
        const revision=globalThis.WebMarkSyncCenter?.revision('notes');
        syncing=true;
        status.textContent=tr('Syncing notes…');
        try {
            if(manual) clearTimeout(syncTimer);
            const merged=await cloud.syncNotes(user.uid,remote=>mergeNotes(library,remote),manual,automatic);
            await saveQueue;
            if (cloud.info().user?.uid!==user.uid) return;
            const latest=mergeNotes(library,merged);
            const changed=JSON.stringify(latest)!==JSON.stringify(merged);
            // Keep the local account binding out of the cloud document.
            Object.assign(library,latest,{owner:user.uid,lastSyncAt:Date.now()});
            const saved=await persistNotes(status,false);
            if(saved){status.textContent=tr('Notes synced');globalThis.WebMarkSyncCenter?.complete('notes',user.uid,revision);}
            renderCards();
            updateSyncSettings();
            if(manager.open) renderFolders();
            if(changed) scheduleSync();
            return saved;
        } catch(error) {
            status.textContent=tr('Notes sync failed.')+' '+error.message;
        } finally { syncing=false; }
    }

    function persistNotes(status,sync=true) {
        const snapshot = JSON.stringify(library);
        saveQueue = saveQueue.catch(()=>{}).then(async()=>{
            wmStorage.setItem(key,snapshot);
            if (!wmStorage.persistent) throw new Error('Storage is unavailable.');
            await wmStorage.flush?.();
        });
        return saveQueue.then(()=>{
            status.textContent=tr('Saved');
            globalThis.WebMarkNoteStudio?.reschedule();
            if(sync){scheduleSync();globalThis.WebMarkSyncCenter?.pending('notes');}
            return true;
        },()=>{
            status.textContent=tr('Could not save. Keep WebMark open and try again.');
            return false;
        });
    }

    function element(tag,text) {
        const node=document.createElement(tag);
        if (text!==undefined) node.textContent=text;
        return node;
    }
    function button(text,action,id,selected) {
        const node=element('button',text);
        node.type='button';
        node.className='wm-notes-button';
        node.dataset.noteAction=action;
        if(id!==undefined) node.dataset.noteId=id;
        if(selected!==undefined) node.setAttribute('aria-pressed',String(selected));
        return node;
    }
    function withIcon(node,name) {
        const icon=element('i');
        icon.className=(name.includes(' ') ? name : 'fa-solid fa-'+name)+' wm-note-tinted';
        icon.setAttribute('aria-hidden','true');
        node.prepend(icon,document.createTextNode(' '));
        return node;
    }
    function nameOf(note) {
        if(note.locked) return 'Locked note';
        return (note.title || '').trim() || (note.body || '').trim().split('\n')[0].slice(0,100) || 'Untitled note';
    }
    function matchesView(note,list) {
        if(list==='trash') return !!note.deletedAt;
        if(note.deletedAt) return false;
        if(list==='archive') return !!note.archived;
        if(note.archived) return false;
        if(list==='reminders') return Number(note.reminderAt)>Date.now();
        if(list==='favorites') return !!note.favorite;
        if(list==='top') return !!note.top;
        return list==='all' || list===note.folderId;
    }
    const locale=()=>document.documentElement.lang||undefined;
    function dateLabel(value,withTime=false) {
        return value ? new Intl.DateTimeFormat(locale(),{
            dateStyle:'medium',...(withTime?{timeStyle:'short'}:{})
        }).format(value) : 'Date unavailable';
    }
    function noteDate(note) {return note.createdAt || note.updatedAt;}
    function notesForView() {
        const query=$('wm-note-search').value.trim().toLowerCase();
        return library.notes.filter(note=>{
            if (query && !(note.locked?'locked note':(note.title||'')+' '+(note.body||'')).toLowerCase().includes(query)) return false;
            return matchesView(note,view);
        }).sort((a,b)=>Number(!!b.pinned)-Number(!!a.pinned)||
            (sort==='title'?nameOf(a).localeCompare(nameOf(b),locale()):
                sort==='oldest'?noteDate(a)-noteDate(b):noteDate(b)-noteDate(a)));
    }
    function iconButton(text,action,id,icon,color,pressed) {
        const node=withIcon(button('',action,id,pressed),icon);
        node.className+=' wm-note-action-icon';
        node.title=text;
        node.setAttribute('aria-label',text);
        setNoteStyle(node,'--note-icon',color);
        return node;
    }
    function noteCard(note) {
        const card=element('article');
        card.className='wm-note-card';
        setNoteStyle(card,'--note-color',validColor(note.color));
        const folder=library.folders.find(item=>item.id===note.folderId);
        if (folder) {
            const label=withIcon(element('small',folder.name),folderIcon(folder.icon));
            setNoteStyle(label,'--note-icon',validColor(folder.color));
            card.append(label);
        }
        const open=button('',selecting?'select-note':'read',note.id,selecting?selected.has(note.id):undefined);
        open.className='wm-note-open';
        const title=element('span',nameOf(note));
        title.className='wm-note-card-heading';
        open.append(title);
        if (note.body && !note.locked) {
            const preview=element('span',note.body.replace(/\s+/g,' '));
            preview.className='wm-note-card-preview';
            open.append(preview);
        }
        const time=element('time',dateLabel(noteDate(note)));
        if(noteDate(note)) time.dateTime=new Date(noteDate(note)).toISOString();
        open.append(time);
        card.append(open);
        if(note.reminderAt&&!note.deletedAt){
            const reminder=withIcon(element('small',dateLabel(note.reminderAt,true)),'fa-solid fa-clock');
            reminder.className='wm-note-reminder-badge';
            reminder.setAttribute('aria-label',tr('Reminder')+' '+dateLabel(note.reminderAt,true));
            card.append(reminder);
        }
        const actions=element('div');
        actions.className='wm-note-actions';
        const add=(label,action,icon,color,pressed)=>actions.append(iconButton(label,action,note.id,icon,color,pressed));
        if (selecting) {
            const picked=selected.has(note.id);
            add(picked?tr('Deselect note'):tr('Select note'),'select-note',picked?'square-check':'square','#15803d',picked);
        } else if (note.deletedAt) {
            add(tr('Restore'),'restore','rotate-left','#15803d');
            add(tr('Delete permanently'),'purge','trash','#dc2626');
        } else {
            if (note.locked) add(tr('Unlock note'),'lock','lock','#7c3aed');
            else {
                add(tr('Edit'),'edit','pen','#2563eb');
                add(tr('Copy'),'copy','copy','#475569');
                add(tr('Share'),'share','share-nodes','#2563eb');
                if(activeVault()) add(tr('Lock note'),'lock','lock-open','#7c3aed');
            }
            add(tr('Favorite'),'favorite','heart',tint.favorites,!!note.favorite);
            add(tr('Pin'),'pinned','thumbtack','#2563eb',!!note.pinned);
            add(tr('Top 10'),'top','star',tint.top,!!note.top);
            add(note.archived?tr('Unarchive'):tr('Archive'),'archived','box-archive',tint.archive,!!note.archived);
            add(tr('Delete'),'trash','trash',tint.trash);
        }
        card.append(actions);
        return card;
    }
    function renderNavigation() {
        const viewButton=(label,id,icon,color)=>{
            const node=withIcon(button(label,'view',id,view===id),icon);
            setNoteStyle(node,'--note-icon',color);
            const count=element('span',String(library.notes.filter(note=>matchesView(note,id)).length));
            count.className='wm-note-count';
            node.append(count);
            return node;
        };
        $('wm-note-views').replaceChildren(...Object.entries(labels).map(([id,label])=>
            viewButton(tr(label),id,icons[id],tint[id])));
        $('wm-note-folders').replaceChildren(...library.folders.map(folder=>
            viewButton(folder.name,folder.id,folderIcon(folder.icon),validColor(folder.color))));
        $('wm-note-view').textContent=labels[view] ? tr(labels[view]) : library.folders.find(folder=>folder.id===view)?.name || tr(labels.all);
    }
    function renderCards() {
        renderNavigation();
        const visible=notesForView();
        const visibleIds=new Set(visible.map(note=>note.id));
        for(const id of selected) if(!visibleIds.has(id)) selected.delete(id);
        const cards=visible.map(noteCard);
        $('wm-note-select').textContent=selecting?tr('Cancel selection'):tr('Select');
        $('wm-note-select-all').hidden=!selecting;
        $('wm-note-select-all').disabled=!visible.length;
        const remove=$('wm-note-delete-selected');
        remove.hidden=!selecting;
        remove.disabled=!selected.size;
        remove.textContent=tr('Delete selected')+(selected.size?' ('+selected.size+')':'');
        $('wm-note-list').replaceChildren(...(cards.length?cards:[element('p',tr('No notes here'))]));
    }
    function renderFolders() {
        $('wm-note-manage-folders').replaceChildren(...library.folders.map(folder=>{
            const row=element('div');
            row.className='wm-note-settings-row';
            const label=withIcon(element('span',folder.name),folderIcon(folder.icon));
            setNoteStyle(label,'--note-icon',validColor(folder.color));
            row.append(label,iconButton('Edit '+folder.name,'edit-folder',folder.id,'pen','#2563eb'));
            return row;
        }));
    }
    function updateSyncSettings() {
        $('wm-note-auto-sync').checked=false;$('wm-note-auto-sync').disabled=true;
        $('wm-note-last-sync').textContent=library.lastSyncAt
            ? tr('Last synced')+' '+dateLabel(library.lastSyncAt,true) : 'Never synced on this device';
    }
    function renderSettings() {
        updateSyncSettings();
        const vaults=library.vaults;
        $('wm-note-lock-settings').replaceChildren(...(vaults.length
            ? vaults.map((vault,index)=>button(vaults.length>1?'Reset password '+(index+1):tr('Forgot password'),'reset-password',vault.id))
            : [button(tr('Set admin password'),'set-password')]));
        if (recoveryCode) {
            $('wm-note-recovery').textContent=tr('Save this recovery code:')+' '+recoveryCode+' ';
            $('wm-note-recovery').append(button(tr('Copy recovery code'),'copy-recovery'));
            if(globalThis.WebMarkCloud?.info().user?.email) $('wm-note-recovery').append(button(tr('Open email draft'),'email-recovery'));
        } else $('wm-note-recovery').textContent='';
    }
    function palette(id,action,active) {
        const values=['',...colors];
        $(id).replaceChildren(...values.map(color=>{
            const name=color||'Default color';
            const node=button('',action,color,color===active);
            node.title=name;
            node.setAttribute('aria-label',name);
            node.className+=' wm-note-swatch';
            setNoteStyle(node,'--swatch',color);
            return node;
        }));
    }
    function renderFolderIcons() {
        const query=$('wm-note-icon-search').value.trim().toLowerCase().replaceAll(' ','-');
        const current=folderIcon($('wm-note-folder-icon').value);
        const group=iconGroups[iconGroup];
        $('wm-note-icon-categories').replaceChildren(...Object.keys(iconGroups).map(name=>
            button(tr(name),'folder-icon-group',name,name===iconGroup)));
        const matches=folderIcons.filter(icon=>(!group||group.test(icon))&&icon.split(' fa-').at(-1).includes(query));
        $('wm-note-icon-options').replaceChildren(...matches.map(icon=>
            iconButton(icon.split(' fa-').at(-1),'folder-icon',icon,icon,folderColor,current===icon)));
    }
    function animateMenu() {
        const mode=app.open?'open':'bookmarks';
        menu.querySelectorAll?.('.wm-app-choice').forEach(choice=>
            choice.setAttribute('aria-current',String(choice.dataset.noteAction===mode)));
        if(!menu.open) menu.showModal();
    }

    globalThis.WebMarkNotes={back(){
        if(!app.open&&!menu.open)return false;
        if(passwordDialog.open){passwordDialog.close();return true;}
        if(folderEditor.open){folderEditor.close();return true;}
        if(editor.open){editContent().then(ok=>{if(ok)editor.close();});return true;}
        for(const dialog of [manager,settings,reader])if(dialog.open){dialog.close();return true;}
        if(menu.open){menu.close();return true;}
        if(globalThis.WebMarkNoteStudio?.closeLists())return true;
        if(viewHistory.length){view=viewHistory.pop();selected.clear();selecting=false;renderCards();return true;}
        if(view!=='all'){view='all';renderCards();return true;}
        app.close();return true;
    }};

    globalThis.WebMarkNotesSync=async(automatic=false)=>{await wmStorage.ready;initNotes();return syncNotes(true,automatic);};
    async function openNotes() {
        await wmStorage.ready;
        initNotes();
        menu.close();
        if (!app.open) app.showModal();
        renderCards();
        if(library.owner) scheduleSync();
        clearInterval(syncPoll);

    }
    function openNote(note) {
        editingId=note?.id || null;
        originalNote=note?{...note}:null;
        draft={title:note?.title||'', body:note?.body||'', folderId:note?.folderId ||
            (library.folders.some(folder=>folder.id===view)?view:'')};
        noteColor=validColor(note?.color);
        draft.color=noteColor;
        palette('wm-note-colors','note-color',noteColor);
        $('wm-note-title').value=draft.title;
        $('wm-note-body').value=draft.body;
        folderOptions(draft.folderId);
        $('wm-note-editor-heading').textContent=note?tr('Edit note'):tr('New note');
        $('wm-note-editor-message').textContent='';
        editor.showModal();
        globalThis.WebMarkNoteStudio?.open(note);
        (document.getElementById('wm-studio-rich')||$('wm-note-body')).focus();
    }
    function folderOptions(value) {
        const select=$('wm-note-folder');
        select.replaceChildren(new Option(tr('No folder'),''),...library.folders.map(folder=>new Option(folder.name,folder.id)));
        select.value=value;
    }
    function editContent() {
        if (!draft) return Promise.resolve(true);
        const title=$('wm-note-title').value;
        const body=$('wm-note-body').value;
        const folderId=$('wm-note-folder').value;
        const extras=globalThis.WebMarkNoteStudio?.extras()||{};
        if (title===draft.title && body===draft.body && folderId===draft.folderId && noteColor===draft.color && JSON.stringify(extras)===JSON.stringify(draft.extras||{}) &&
            (editingId || (!title.trim() && !body.trim()))) return saveQueue.then(()=>true,()=>persistNotes($('wm-note-editor-message')));
        if (!editingId && !title.trim() && !body.trim()) return Promise.resolve(true);
        draft={title,body,folderId,color:noteColor,extras};
        let note=library.notes.find(item=>item.id===editingId);
        if (!note) {
            editingId=newId('note');
            note={id:editingId,createdAt:Date.now()};
            library.notes.push(note);
        }
        const {extras:details,...plain}=draft;
        Object.assign(note,plain,details,{updatedAt:stamp(note)});
        return persistNotes($('wm-note-editor-message'));
    }
    function openFolder(folder) {
        editingFolder=folder?.id || null;
        $('wm-note-folder-heading').textContent=folder?tr('Edit folder'):tr('New folder');
        $('wm-note-folder-name').value=folder?.name || '';
        $('wm-note-folder-icon').value=folderIcon(folder?.icon);
        $('wm-note-icon-search').value='';
        iconGroup='All';
        folderColor=validColor(folder?.color);
        palette('wm-note-folder-colors','folder-color',folderColor);
        renderFolderIcons();
        $('wm-note-folder-message').textContent='';
        $('wm-note-delete-folder').hidden=!folder;
        folderEditor.showModal();
    }
    async function saveFolder(event) {
        event.preventDefault();
        const status=$('wm-note-folder-message');
        const name=$('wm-note-folder-name').value.trim();
        const icon=folderIcon($('wm-note-folder-icon').value);
        if(!name) return;
        if(library.folders.some(folder=>folder.id!==editingFolder && folder.name.toLowerCase()===name.toLowerCase())){
            status.textContent=tr('A note folder already has this name.');
            return;
        }
        let folder=library.folders.find(item=>item.id===editingFolder);
        if(!folder) {
            editingFolder=newId('note-folder');
            folder={id:editingFolder};
            library.folders.push(folder);
        }
        Object.assign(folder,{name,icon,color:folderColor,updatedAt:stamp(folder)});
        if(await persistNotes(status)){
            folderEditor.close();
            if(editor.open){folderOptions(folder.id);await editContent();}
            renderCards();
            if(manager.open) renderFolders();
        }
    }
    function askPassword(heading,label,operation,creating=false) {
        if(passwordPrompt) return Promise.resolve(null);
        $('wm-note-password-heading').textContent=heading;
        $('wm-note-password-label').textContent=label;
        const input=$('wm-note-password-value');
        input.value='';
        input.autocomplete=creating?'new-password':'off';
        input.minLength=creating?4:1;
        const second=$('wm-note-password-confirm');
        second.value='';
        second.hidden=!creating;
        second.required=creating;
        $('wm-note-password-confirm-label').hidden=!creating;
        $('wm-note-password-status').textContent='';
        return new Promise(resolve=>{
            passwordPrompt={resolve,operation,creating,busy:false};
            passwordDialog.showModal();
        });
    }
    async function submitPassword(event) {
        event.preventDefault();
        const pending=passwordPrompt;
        if(!pending || pending.busy) return;
        const value=$('wm-note-password-value').value;
        const status=$('wm-note-password-status');
        if(pending.creating && (value.length<4 || value!==$('wm-note-password-confirm').value)){
            status.textContent=tr('Use at least 4 characters and enter the same password twice.');
            return;
        }
        pending.busy=true;
        status.textContent=tr('Checking…');
        try {
            const result=await pending.operation(value);
            if(passwordPrompt!==pending || !passwordDialog.open) return;
            passwordPrompt=null;
            passwordDialog.close();
            pending.resolve(result);
        } catch {
            if(passwordPrompt===pending) status.textContent=tr('Could not verify that password or recovery code.');
        } finally {pending.busy=false;}
    }
    async function managePassword(action,id) {
        const status=$('wm-note-settings-status');
        if(!globalThis.crypto?.subtle) {
            status.textContent=tr('Password protection needs an HTTPS page or the installed app.');
            return;
        }
        if(action==='set-password'){
            if(activeVault()) return;
            const created=await askPassword(tr('Set admin password'),tr('New password'),
                value=>WebMarkNoteVault.create(value),true);
            if(!created) return;
            library.vaults.push(created.vault);
            library.activeVault=created.vault.id;
            recoveryCode=created.recoveryCode;
        } else {
            const vault=library.vaults.find(item=>item.id===id);
            if(!vault) return;
            const code=await askPassword(tr('Recover admin password'),tr('Recovery code'),value=>value.trim()||null);
            if(!code) return;
            const reset=await askPassword('Choose a new password',tr('New password'),
                value=>WebMarkNoteVault.reset(vault,code,value),true);
            if(!reset) return;
            if(library.vaults.find(item=>item.id===id)!==vault) {
                status.textContent=tr('Password changed on another device. Try again.');
                return;
            }
            Object.assign(vault,reset,{updatedAt:stamp(vault)});
        }
        renderCards();
        renderSettings();
        await persistNotes(status);
    }
    async function toggleLock(note) {
        if(note.deletedAt) return;
        const id=note.id;
        const vault=note.locked?library.vaults.find(item=>item.id===note.vaultId):activeVault();
        if(!vault) return;
        const unlocking=!!note.locked;
        const result=await askPassword(unlocking?tr('Unlock note'):tr('Lock note'),tr('Admin password'),
            value=>unlocking?WebMarkNoteVault.unlock(vault,value,note):WebMarkNoteVault.lock(vault,value,note));
        if(!result || library.notes.find(item=>item.id===id)!==note) return;
        if(unlocking) {
            Object.assign(note,result);
            delete note.locked;
            delete note.vaultId;
        } else {
            note.locked=result;
            note.vaultId=vault.id;
            delete note.title;
            delete note.body;
            delete note.rich;delete note.ink;delete note.paper;
        }
        note.updatedAt=stamp(note);
        await persistNotes($('wm-note-message'));
        renderCards();
    }
    async function authorizeDeletion(notes) {
        const admin=activeVault();
        const vaultIds=new Set(notes.filter(note=>note.locked).map(note=>note.vaultId));
        if(admin) vaultIds.add(admin.id);
        for(const id of vaultIds) {
            const vault=library.vaults.find(item=>item.id===id);
            if(!vault) return false;
            const allowed=await askPassword('Confirm deletion',tr('Admin password'),async value=>{
                await WebMarkNoteVault.verify(vault,value);
                return true;
            });
            if(!allowed) return false;
        }
        return true;
    }
    async function deleteNotes(notes,permanent) {
        if(!notes.length || !confirm(permanent
            ? 'Permanently delete '+notes.length+' note(s)?'
            : 'Move '+notes.length+' note(s) to Trash?')) return;
        if(!await authorizeDeletion(notes)) return;
        const current=notes.filter(note=>library.notes.includes(note));
        if(permanent) {
            for(const note of current) library.removedNotes.push({id:note.id,updatedAt:stamp(note)});
            library.notes=library.notes.filter(note=>!current.includes(note));
        } else {
            for(const note of current){note.deletedAt=Date.now();note.updatedAt=stamp(note);}
        }
        selected.clear();
        selecting=false;
        await persistNotes($('wm-note-message'));
        renderCards();
    }

    function displayNote(note,content) {
        reading={note,content};
        $('wm-note-reader-title').textContent=nameOf(content);
        $('wm-note-reader-meta').textContent=dateLabel(noteDate(note),true);
        $('wm-note-reader-text').textContent=content.body||'';
        $('wm-note-reader-edit').hidden=!!note.locked || !!note.deletedAt;
        $('wm-note-reader-status').textContent='';
        globalThis.WebMarkNoteStudio?.reader(note,content);
        reader.showModal();
    }
    async function readNote(note) {
        if(!note.locked){displayNote(note,note);return;}
        const vault=library.vaults.find(item=>item.id===note.vaultId);
        if(!vault) return;
        const content=await askPassword('Read locked note',tr('Admin password'),
            value=>WebMarkNoteVault.unlock(vault,value,note));
        if(content && library.notes.includes(note)) displayNote(note,content);
    }
    const plainNote=note=>[note.title,note.body].filter(Boolean).join('\n\n');
    async function shareOrCopy(title,text,share,status) {
        try {
            if(share && globalThis.WebMarkAndroid?.shareText) WebMarkAndroid.shareText(text);
            else if(share && navigator.share) await navigator.share({title,text});
            else {
                await wmCopy(text);
                status.textContent=share?tr('Copied. Paste wherever you want to share.'):tr('Copied.');
            }
        } catch(error){
            if(error.name!=='AbortError') status.textContent=share?tr('Could not share. Try exporting a file.'):tr('Could not copy.');
        }
    }
    async function exportNotes(action) {
        const status=$('wm-note-settings-status');
        try {
            if(action==='export-notes'){
                const backup=mergeNotes(library,{});
                wmDownload('WebMark-Notes.json',JSON.stringify({format:'webmark-notes-v2',...backup},null,2),'application/json');
                return;
            }
            const notes=library.notes.filter(note=>!note.deletedAt&&!note.locked);
            const rows=notes.map(note=>({title:nameOf(note),date:dateLabel(noteDate(note),true),body:note.body||''}));
            if(!rows.length){status.textContent=tr('No readable notes to export.');return;}
            if(action==='pdf-notes'){WebMarkNotesExport.pdf(rows);return;}
            if(action==='print-notes'){WebMarkNotesExport.print(rows);return;}
            const text=rows.map(row=>[row.title,row.date,row.body].join('\n')).join('\n\n———\n\n');
            if(action==='export-text') wmDownload('WebMark-Notes.txt',text,'text/plain;charset=utf-8');
            else await shareOrCopy('WebMark Notes',text,action==='share-all',status);
        } catch(error){status.textContent=error.message||tr('Could not export notes.');}
    }
    async function clearNotes() {
        const notes=library.notes.slice(),folders=library.folders.slice();
        const status=$('wm-note-settings-status');
        if(!notes.length&&!folders.length){status.textContent=tr('Notes is already empty.');return;}
        if(!confirm('Permanently delete all '+notes.length+' notes and '+folders.length+
            ' folders, including Trash? This will sync to your other devices.')) return;
        if(!await authorizeDeletion(notes)) return;
        const current=notes.filter(note=>library.notes.includes(note));
        const currentFolders=folders.filter(folder=>library.folders.includes(folder));
        for(const note of current) library.removedNotes.push({id:note.id,updatedAt:stamp(note)});
        for(const folder of currentFolders) library.removedFolders.push({id:folder.id,updatedAt:stamp(folder)});
        library.notes=library.notes.filter(note=>!current.includes(note));
        library.folders=library.folders.filter(folder=>!currentFolders.includes(folder));
        selected.clear();selecting=false;view='all';
        if(await persistNotes(status)) status.textContent=tr('Notes and folders cleared.');
        renderCards();
    }

    async function handleNoteAction(event) {
        const control=event.target.closest('[data-note-action]');
        if (!control) return;
        const action=control.dataset.noteAction;
        const id=control.dataset.noteId;
        if(action==='menu'){animateMenu();return;}
        if(action==='close-menu'){menu.close();return;}
        if(action==='bookmarks'){menu.close();if(app.open)app.close();return;}
        if(action==='open'){await openNotes();return;}
        if(action==='close-folder'){folderEditor.close();return;}
        if(action==='cancel-note'){
            if(!draft)return;
            const note=library.notes.find(item=>item.id===editingId);
            if(note && (!originalNote||note.updatedAt!==originalNote.updatedAt)){
                if(!confirm(originalNote?tr('Discard changes to this note?'):tr('Discard this new note?')))return;
                const activeDraft=draft;
                draft=null;
                if(originalNote){
                    const restored={...originalNote,updatedAt:stamp(note)};
                    library.notes=library.notes.map(item=>item===note?restored:item);
                }else{
                    library.removedNotes.push({id:note.id,updatedAt:stamp(note)});
                    library.notes=library.notes.filter(item=>item!==note);
                }
                if(!await persistNotes($('wm-note-editor-message'))){draft=activeDraft;return;}
            }
            editor.close();
            return;
        }
        if(action==='done'){if(await editContent())editor.close();return;}
        if(!library) return;
        if(action==='new'){openNote();return;}
        if(action==='settings'){renderSettings();settings.showModal();return;}
        if(action==='manage-folders'){renderFolders();manager.showModal();return;}
        if(action==='close-manager'){manager.close();return;}
        if(action==='close-reader'){reader.close();return;}
        if(action==='reader-edit'){
            const note=reading?.note;
            if(note && library.notes.includes(note) && !note.locked && !note.deletedAt){reader.close();openNote(note);}
            return;
        }
        if(action==='reader-copy' || action==='reader-share'){
            if(reading) await shareOrCopy(nameOf(reading.content),plainNote(reading.content),
                action==='reader-share',$('wm-note-reader-status'));
            return;
        }
        if(action==='clear-notes'){await clearNotes();return;}
        if(['share-all','copy-all','export-notes','export-text','print-notes','pdf-notes'].includes(action)){await exportNotes(action);return;}
        if(action==='folder-icon-group'){iconGroup=id;renderFolderIcons();return;}
        if(action==='close-settings'){settings.close();return;}
        if(action==='cancel-password'){passwordDialog.close();return;}
        if(action==='set-password' || action==='reset-password'){await managePassword(action,id);return;}
        if(action==='copy-recovery'){await wmCopy(recoveryCode);return;}
        if(action==='email-recovery'){
            const email=globalThis.WebMarkCloud?.info().user?.email;
            if(email && recoveryCode) location.href='mailto:'+encodeURIComponent(email)+
                '?subject=WebMark%20Notes%20recovery%20code&body='+encodeURIComponent(recoveryCode);
            return;
        }
        if(action==='sync'){await syncNotes(true);return;}
        if(action==='select'){selecting=!selecting;selected.clear();renderCards();return;}
        if(action==='select-note'){
            if(selected.has(id)) selected.delete(id); else selected.add(id);
            renderCards();return;
        }
        if(action==='select-all'){for(const note of notesForView())selected.add(note.id);renderCards();return;}
        if(action==='delete-selected'){
            await deleteNotes(library.notes.filter(note=>selected.has(note.id)),view==='trash');
            return;
        }
        if(action==='note-color'){noteColor=validColor(id);palette('wm-note-colors',action,noteColor);await editContent();return;}
        if(action==='folder-color'){folderColor=validColor(id);palette('wm-note-folder-colors',action,folderColor);renderFolderIcons();return;}
        if(action==='folder-icon'){$('wm-note-folder-icon').value=id;renderFolderIcons();return;}
        if(action==='view'){if(view!==id)viewHistory.push(view);view=id;selecting=false;selected.clear();renderCards();return;}
        if(action==='add-folder' || action==='edit-folder'){openFolder(library.folders.find(folder=>folder.id===id));return;}
        if(action==='delete-folder'){
            if(!confirm(tr('Delete this note folder? Its notes will stay in All notes.'))) return;
            const folder=library.folders.find(item=>item.id===editingFolder);
            if(!folder) return;
            library.removedFolders.push({id:folder.id,updatedAt:stamp(folder)});
            library.folders=library.folders.filter(item=>item!==folder);
            for(const note of library.notes) if(note.folderId===editingFolder) {
                note.folderId='';note.updatedAt=stamp(note);
            }
            if(view===editingFolder)view='all';
            if(await persistNotes($('wm-note-folder-message')))folderEditor.close();
            renderCards();
            if(manager.open) renderFolders();
            return;
        }
        const note=library.notes.find(item=>item.id===id);
        if(!note) return;
        if(action==='lock'){await toggleLock(note);return;}
        if(action==='edit'){if(!note.locked)openNote(note);return;}
        if(action==='read'){await readNote(note);return;}
        if(action==='copy' || action==='share'){
            if(!note.locked) await shareOrCopy(nameOf(note),plainNote(note),action==='share',$('wm-note-message'));
            return;
        }
        if(action==='top' && !note.top && library.notes.filter(item=>item.top&&!item.deletedAt&&!item.archived).length>=10){
            $('wm-note-message').textContent=tr('Top 10 is full. Remove a note from Top 10 first.');
            return;
        }
        if(action==='archived' && note.archived && note.top && library.notes.filter(item=>item.top&&!item.deletedAt&&!item.archived).length>=10) note.top=false;
        if(action==='purge'||action==='trash'){await deleteNotes([note],action==='purge');return;}
        if(action==='restore'){
            note.deletedAt=null;
            if(note.top&&!note.archived&&library.notes.filter(item=>item.top&&!item.deletedAt&&!item.archived).length>10)note.top=false;
        } else if(['favorite','pinned','top','archived'].includes(action)){
            note[action]=!note[action];
        }
        note.updatedAt=stamp(note);
        await persistNotes($('wm-note-message'));
        renderCards();
    }

    globalThis.WebMarkNotesData=()=>library;
    globalThis.WebMarkNotesImportText=async(title,body)=>{await openNotes();openNote();$('wm-note-title').value=String(title).slice(0,180);$('wm-note-body').value=String(body).slice(0,100000);globalThis.WebMarkNoteStudio?.open({title,body});await editContent();};
    globalThis.WebMarkOpenNotes=openNotes;
    globalThis.WebMarkInterfaceLocale?.onChange(()=>{
        if(!library)return;
        if(app.open)renderCards();
        if(settings.open)renderSettings();
        if(editor.open){
            $('wm-note-editor-heading').textContent=tr(originalNote?tr('Edit note'):tr('New note'));
            folderOptions($('wm-note-folder').value);
        }
        if(folderEditor.open)renderFolderIcons();
    });
    document.addEventListener('click',handleNoteAction);
    for(const id of ['wm-note-title','wm-note-body','wm-note-folder']){
        $(id).addEventListener(id==='wm-note-folder'?'change':'input',editContent);
    }
    reader.addEventListener('close',()=>{
        reading=null;$('wm-note-reader-title').textContent='';$('wm-note-reader-text').textContent='';
    });
    app.addEventListener('close',()=>{clearInterval(syncPoll);globalThis.WebMarkNoteStudio?.closeLists(false);globalThis.WebMarkAndroid?.stopNoteAlarm?.();});
    $('wm-note-sort').addEventListener('change',()=>{
        library.sort=sort=$('wm-note-sort').value;
        persistNotes($('wm-note-message'),false);
        renderCards();
    });
    $('wm-note-auto-sync').addEventListener('change',()=>{
        library.autoSync=false;
        clearTimeout(syncTimer);
        persistNotes($('wm-note-settings-status'));
    });
    $('wm-note-search').addEventListener('input',renderCards);
    $('wm-note-folder-form').addEventListener('submit',saveFolder);
    $('wm-note-icon-search').addEventListener('input',renderFolderIcons);
    $('wm-note-password-form').addEventListener('submit',submitPassword);
    passwordDialog.addEventListener('close',()=>{
        if(passwordDialog.open)return;
        const pending=passwordPrompt;
        passwordPrompt=null;
        $('wm-note-password-value').value='';
        $('wm-note-password-confirm').value='';
        pending?.resolve(null);
    });
    folderEditor.addEventListener('close',()=>{if(library)scheduleSync();});
    settings.addEventListener('close',()=>{recoveryCode='';$('wm-note-recovery').textContent='';});
    globalThis.addEventListener?.('online',()=>{if(library?.owner)scheduleSync();});
    editor.addEventListener('cancel',event=>{
        event.preventDefault();
        editContent().then(ok=>{if(ok)editor.close();});
    });
    editor.addEventListener('close',()=>{
        draft=null;
        if(app.open){renderCards();scheduleSync();}
    });
})();

