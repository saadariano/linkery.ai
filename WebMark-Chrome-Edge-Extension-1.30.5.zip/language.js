(() => {
 const storage = (globalThis.browser || globalThis.chrome)?.storage?.local;
 const key = 'webmarkLanguage';
 const languages = ['en', 'it', 'fr', 'es', 'ar'];
 const strings = {
  'Settings': ['Impostazioni', 'Paramètres', 'Ajustes', 'الإعدادات'],
  'Language': ['Lingua', 'Langue', 'Idioma', 'اللغة'],
  'Close': ['Chiudi', 'Fermer', 'Cerrar', 'إغلاق'],
  'Your library': ['La tua raccolta', 'Votre bibliothèque', 'Tu biblioteca', 'مكتبتك'],
  'All bookmarks': ['Tutti i segnalibri', 'Tous les favoris', 'Todos los marcadores', 'كل الإشارات المرجعية'],
  'Favorites': ['Preferiti', 'Favoris', 'Favoritos', 'المفضلة'],
  'Archive': ['Archivio', 'Archives', 'Archivo', 'الأرشيف'],
  'Trash': ['Cestino', 'Corbeille', 'Papelera', 'سلة المهملات'],
  'Folders': ['Cartelle', 'Dossiers', 'Carpetas', 'المجلدات'],
  'New folder': ['Nuova cartella', 'Nouveau dossier', 'Nueva carpeta', 'مجلد جديد'],
  'Edit folder': ['Modifica cartella', 'Modifier le dossier', 'Editar carpeta', 'تعديل المجلد'],
  'Folder name': ['Nome cartella', 'Nom du dossier', 'Nombre de la carpeta', 'اسم المجلد'],
  'Color': ['Colore', 'Couleur', 'Color', 'اللون'],
  'Delete folder': ['Elimina cartella', 'Supprimer le dossier', 'Eliminar carpeta', 'حذف المجلد'],
  'Save folder': ['Salva cartella', 'Enregistrer le dossier', 'Guardar carpeta', 'حفظ المجلد'],
  'Google account & sync': ['Account Google e sincronizzazione', 'Compte Google et synchronisation', 'Cuenta de Google y sincronización', 'حساب Google والمزامنة'],
  'Export backup': ['Esporta backup', 'Exporter la sauvegarde', 'Exportar copia de seguridad', 'تصدير نسخة احتياطية'],
  'Import bookmarks': ['Importa segnalibri', 'Importer des favoris', 'Importar marcadores', 'استيراد الإشارات المرجعية'],
  'Add bookmark': ['Aggiungi segnalibro', 'Ajouter un favori', 'Añadir marcador', 'إضافة إشارة مرجعية'],
  'Add your first bookmark': ['Aggiungi il primo segnalibro', 'Ajoutez votre premier favori', 'Añade tu primer marcador', 'أضف أول إشارة مرجعية'],
  'New bookmark': ['Nuovo segnalibro', 'Nouveau favori', 'Nuevo marcador', 'إشارة مرجعية جديدة'],
  'Edit bookmark': ['Modifica segnalibro', 'Modifier le favori', 'Editar marcador', 'تعديل الإشارة المرجعية'],
  'Save bookmark': ['Salva segnalibro', 'Enregistrer le favori', 'Guardar marcador', 'حفظ الإشارة المرجعية'],
  'Website URL': ['URL del sito', 'Adresse du site', 'URL del sitio', 'رابط الموقع'],
  'Title': ['Titolo', 'Titre', 'Título', 'العنوان'],
  'Notes': ['Note', 'Notes', 'Notas', 'الملاحظات'],
  'Folder': ['Cartella', 'Dossier', 'Carpeta', 'المجلد'],
  'Tags': ['Tag', 'Étiquettes', 'Etiquetas', 'الوسوم'],
  'Delete': ['Elimina', 'Supprimer', 'Eliminar', 'حذف'],
  'Cancel': ['Annulla', 'Annuler', 'Cancelar', 'إلغاء'],
  'Edit': ['Modifica', 'Modifier', 'Editar', 'تعديل'],
  'Restore': ['Ripristina', 'Restaurer', 'Restaurar', 'استعادة'],
  'Unsorted': ['Senza cartella', 'Sans dossier', 'Sin carpeta', 'بلا مجلد'],
  'Favorite': ['Preferito', 'Favori', 'Favorito', 'المفضلة'],
  'Pin': ['Fissa', 'Épingler', 'Fijar', 'تثبيت'],
  'Open website': ['Apri sito', 'Ouvrir le site', 'Abrir sitio', 'فتح الموقع'],
  'Restore from archive': ['Ripristina dall’archivio', 'Restaurer depuis les archives', 'Restaurar del archivo', 'استعادة من الأرشيف'],
  'Restore bookmark': ['Ripristina segnalibro', 'Restaurer le favori', 'Restaurar marcador', 'استعادة الإشارة المرجعية'],
  'Search websites, notes or tags…': ['Cerca siti, note o tag…', 'Rechercher sites, notes ou étiquettes…', 'Buscar sitios, notas o etiquetas…', 'ابحث في المواقع أو الملاحظات أو الوسوم…'],
  'Newest first': ['Più recenti', 'Plus récents', 'Más recientes', 'الأحدث أولًا'],
  'Oldest first': ['Meno recenti', 'Plus anciens', 'Más antiguos', 'الأقدم أولًا'],
  'Name A–Z': ['Nome A–Z', 'Nom A–Z', 'Nombre A–Z', 'حسب الاسم'],
  'Sort bookmarks': ['Ordina segnalibri', 'Trier les favoris', 'Ordenar marcadores', 'ترتيب الإشارات المرجعية'],
  'bookmarks': ['segnalibri', 'favoris', 'marcadores', 'إشارات مرجعية'],
  'Save this website': ['Salva questo sito', 'Enregistrer ce site', 'Guardar este sitio', 'حفظ هذا الموقع'],
  'Open my library': ['Apri la raccolta', 'Ouvrir ma bibliothèque', 'Abrir mi biblioteca', 'فتح مكتبتي'],
  'Bookmarks stay available offline.': ['I segnalibri sono disponibili offline.', 'Les favoris restent accessibles hors ligne.', 'Los marcadores están disponibles sin conexión.', 'تبقى الإشارات المرجعية متاحة دون اتصال.'],
  'No bookmarks yet': ['Nessun segnalibro', 'Aucun favori', 'Aún no hay marcadores', 'لا توجد إشارات مرجعية بعد'],
  'Add a website or import your WebMark backup.': ['Aggiungi un sito o importa il tuo backup WebMark.', 'Ajoutez un site ou importez votre sauvegarde WebMark.', 'Añade un sitio o importa tu copia de seguridad de WebMark.', 'أضف موقعًا أو استورد نسخة WebMark الاحتياطية.']
 };
 let language = 'en';
 const translate = text => strings[text]?.[languages.indexOf(language) - 1] ?? text;

 function apply(value) {
  language = languages.includes(value) ? value : 'en';
  document.documentElement.lang = language;
  document.documentElement.dir = language === 'ar' ? 'rtl' : 'ltr';
  document.querySelectorAll('[data-i18n]').forEach(el => { el.textContent = translate(el.dataset.i18n); });
  for (const [selector, attribute] of [['placeholder', 'placeholder'], ['label', 'aria-label'], ['title', 'title']]) {
   document.querySelectorAll('[data-i18n-' + selector + ']').forEach(el => {
    el.setAttribute(attribute, translate(el.getAttribute('data-i18n-' + selector)));
   });
  }
  const select = document.getElementById('language');
  if (select) select.value = language;
  document.dispatchEvent(new Event('webmarklanguagechange'));
 }

 const ready = storage ? storage.get(key).then(data => apply(data[key])).catch(() => apply('en')) : Promise.resolve();
 (globalThis.browser || globalThis.chrome)?.storage?.onChanged?.addListener((changes, area) => {
  if (area === 'local' && changes[key]) apply(changes[key].newValue);
 });
 window.WebMarkLanguage = {
  ready,
  translate,
  async set(value) {
   await storage.set({[key]: value});
   apply(value);
  }
 };
})();
