

const WebMarkCategories=(()=>{
    const groups=[
        ['social','Social','fa-solid fa-users','#d85388',/(facebook|instagram|tiktok|twitter|snapchat|linkedin|pinterest|reddit|discord|telegram|whatsapp|social media|mastodon|threads\.net|(^|\W)x\.com)/i],
        ['sports','Sports','fa-solid fa-futbol','#19a87b',/(sport|football|soccer|basketball|fifa|uefa|espn|strava|nike|adidas|fitness|gym|nba|formula ?1)/i],
        ['gaming','Gaming','fa-solid fa-gamepad','#8055d9',/(gaming|games?|roms?|emulat|playstation|xbox|nintendo|steam|epicgames|twitch|roblox|minecraft)/i],
        ['shopping','Shopping','fa-solid fa-bag-shopping','#df9a26',/(amazon|ebay|aliexpress|temu|etsy|shopping|shopify|zalando|vinted|shein)/i],
        ['finance','Finance','fa-solid fa-wallet','#2789bd',/(paypal|revolut|wise\.com|bank|banca|finance|binance|coinbase|crypto|credit|n26)/i],
        ['work','Work','fa-solid fa-briefcase','#5567ce',/(office|microsoft|slack|teams|zoom|notion|trello|asana|work|business|salesforce|workspace)/i],
        ['education','Education','fa-solid fa-graduation-cap','#b77d31',/(school|education|learn|course|university|coursera|udemy|duolingo|quizlet|classroom)/i],
        ['travel','Travel','fa-solid fa-plane','#249fbb',/(travel|booking|airbnb|tripadvisor|expedia|ryanair|easyjet|wizzair|flight|hotel|airline)/i],
        ['entertainment','Entertainment','fa-solid fa-film','#c76187',/(netflix|youtube|disney|spotify|primevideo|hulu|cinema|movie|music|deezer|apple tv)/i],
        ['health','Health','fa-solid fa-heart-pulse','#ce5c65',/(health|medical|pharma|doctor|hospital|patient|myfitnesspal|nutriti)/i],
        ['technology','Technology','fa-solid fa-laptop-code','#4f8cb8',/(github|gitlab|stackoverflow|openai|chatgpt|claude|developer|coding|technology|software|cloudflare)/i],
        ['email','Email','fa-solid fa-envelope','#d9653e',/(gmail|outlook|hotmail|proton|yahoo|mail\.com|email)/i],
    ];
    function credentialCategory(item){
        const label=[item.title,item.username,item.notes].filter(Boolean).join(' ');
        if(item.type==='wifi')return 'wifi';
        if(item.type==='pin'||item.type==='code')return 'codes';
        if(item.type==='passkey')return 'passkeys';
        if(!item.type || item.type==='password'){
            if(/\bpass[ -]?keys?\b/i.test(label))return 'passkeys';
            if(/\b(?:wi[ -]?fi|wlan|ssid)\b/i.test(label))return 'wifi';
            if(/\b(?:pin(?:\s+code)?|totp|2fa|mfa|otp|authenticator|recovery codes?|backup codes?|(?:door|device|access|unlock|security|verification|entry) code)\b/i.test(label))return 'codes';
        }
        return '';
    }
    function category(item){
        const credential=credentialCategory(item);
        if(credential==='passkeys')return {key:'passkeys',name:'Passkeys',icon:'fa-solid fa-user-lock',color:'#57b844'};
        if(credential==='wifi')return {key:'wifi',name:'Wi-Fi',icon:'fa-solid fa-wifi',color:'#52a3ce'};
        if(credential==='codes')return {key:'codes',name:'Codes & devices',icon:'fa-solid fa-mobile-screen',color:'#d7a928'};
        const content=[item.title,...(item.websites||[]),item.desc||''].join(' ');
        const row=groups.find(row=>row[4].test(content));return row?{key:row[0],name:row[1],icon:row[2],color:row[3]}:{key:'other',name:'Other',icon:'fa-solid fa-folder',color:'#7957dc'};
    }
    function folder(vault,item){
        const suggested=category(item);let target=vault.folders.find(f=>f.autoCategory===suggested.key||f.name.toLowerCase()===suggested.name.toLowerCase());
        if(!target){const now=Date.now();target={id:crypto.randomUUID(),name:suggested.name,icon:suggested.icon,color:suggested.color,autoCategory:suggested.key,createdAt:now,updatedAt:now};vault.folders.push(target);}
        return target;
    }
    function tags(url,title='',description='',keywords=''){
        const result=[],add=value=>{value=String(value).replace(/<[^>]*>/g,' ').replace(/\s+/g,' ').trim().slice(0,35);if(value.length>1&&!result.some(x=>x.toLowerCase()===value.toLowerCase()))result.push(value);};
        const suggested=category({title,desc:description,websites:[url]});if(suggested.key!=='other')add(suggested.name);
        String(keywords).split(/[,;|]/).slice(0,8).forEach(add);
        const stop=new Set('the and for with from this that your best free home official website online welcome download downloads www com org net http https'.split(' '));
        for(const word of (title+' '+description).match(/[\p{L}\p{N}][\p{L}\p{N}-]{3,24}/gu)||[]){if(!stop.has(word.toLowerCase()))add(word);if(result.length>=2)break;}
        return result.slice(0,2);
    }
    return {category,folder,tags,credentialCategory};
})();

/* Fetch only the public page URL; no account tokens, cookies or saved passwords. */
(()=>{
    const pending=new Map();
    const favicon=url=>'https://www.google.com/s2/favicons?domain='+encodeURIComponent(new URL(url).hostname)+'&sz=128';
    function normalize(data,url){return {title:typeof data.title==='string'?data.title.trim().slice(0,500):'',desc:typeof (data.desc||data.description)==='string'?(data.desc||data.description).replace(/\s+/g,' ').trim().slice(0,160):'',logo:typeof data.logo==='string'&&/^https:\/\//i.test(data.logo)?data.logo:favicon(url),keywords:typeof data.keywords==='string'?data.keywords:''};}
    function nativeResult(request,value,error){const task=pending.get(request);if(!task)return;pending.delete(request);clearTimeout(task.timer);if(error||!value)task.reject(Error('Page metadata unavailable'));else task.resolve(value);}
    async function direct(url){
        if(globalThis.WebMarkAndroid?.fetchBookmarkMetadata)return new Promise((resolve,reject)=>{const request=crypto.randomUUID(),timer=setTimeout(()=>{pending.delete(request);reject(Error('Page timed out'));},16000);pending.set(request,{resolve,reject,timer});WebMarkAndroid.fetchBookmarkMetadata(request,url);});
        const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),7000);
        try{const response=await fetch(url,{signal:controller.signal,credentials:'omit',referrerPolicy:'no-referrer'});if(!response.ok)throw Error('Page unavailable');const document=new DOMParser().parseFromString((await response.text()).slice(0,1048576),'text/html');const meta=key=>document.querySelector('meta[property="'+key+'"],meta[name="'+key+'"]')?.content||'';const icon=document.querySelector('link[rel~="apple-touch-icon"],link[rel~="icon"]')?.getAttribute('href');return {title:meta('og:title')||document.title,desc:meta('og:description')||meta('description'),keywords:meta('keywords'),logo:icon?new URL(icon,url).href:favicon(url)};}finally{clearTimeout(timer)}
    }
    async function fetchMetadata(url,signal){
        let found={logo:favicon(url)};
        try{const primary=normalize(await direct(url),url);if(primary.title||primary.desc)return primary;found=primary;}catch{}
        if(signal?.aborted)throw new DOMException('Aborted','AbortError');
        const controller=new AbortController(),timeout=setTimeout(()=>controller.abort(),9000);const abort=()=>controller.abort();signal?.addEventListener('abort',abort,{once:true});
        try{const response=await fetch('https://api.microlink.io?url='+encodeURIComponent(url)+'&meta=true',{signal:controller.signal,credentials:'omit',referrerPolicy:'no-referrer'});if(!response.ok)throw Error('Metadata service unavailable');const result=await response.json();if(result.status!=='success')throw Error('No metadata');const d=result.data||{};return normalize({title:d.title,desc:d.description,logo:d.logo?.url||d.image?.url,keywords:d.keywords},url);}catch{return found;}finally{clearTimeout(timeout);signal?.removeEventListener('abort',abort);}
    }
    window.WebMarkMetadata={fetch:fetchMetadata,nativeResult,favicon,normalize};
})();

// ============================================================
//  FULL FONT AWESOME ICON LIST
// ============================================================
const FA_ICONS = [
    'fa-solid fa-0','fa-solid fa-1','fa-solid fa-2','fa-solid fa-3','fa-solid fa-4','fa-solid fa-5','fa-solid fa-6','fa-solid fa-7','fa-solid fa-8','fa-solid fa-9',
    'fa-brands fa-42-group','fa-brands fa-500px',
    'fa-solid fa-a','fa-brands fa-accessible-icon','fa-brands fa-accusoft','fa-brands fa-adn','fa-brands fa-adversal','fa-brands fa-affiliatetheme','fa-brands fa-airbnb','fa-brands fa-algolia','fa-brands fa-alipay','fa-brands fa-amazon','fa-brands fa-amazon-pay','fa-brands fa-amilia','fa-brands fa-android','fa-brands fa-angellist','fa-brands fa-angrycreative','fa-brands fa-angular','fa-brands fa-apper','fa-brands fa-apple','fa-brands fa-apple-pay','fa-brands fa-app-store','fa-brands fa-app-store-ios','fa-brands fa-apsalar',
    'fa-solid fa-address-book','fa-solid fa-address-card','fa-solid fa-anchor','fa-solid fa-anchor-circle-check','fa-solid fa-anchor-circle-exclamation','fa-solid fa-anchor-circle-xmark','fa-solid fa-anchor-lock','fa-solid fa-angle-down','fa-solid fa-angle-left','fa-solid fa-angle-right','fa-solid fa-angle-up','fa-solid fa-angles-down','fa-solid fa-angles-left','fa-solid fa-angles-right','fa-solid fa-angles-up','fa-solid fa-ankh','fa-solid fa-apple-whole','fa-solid fa-archway','fa-solid fa-arrow-down','fa-solid fa-arrow-down-1-9','fa-solid fa-arrow-down-9-1','fa-solid fa-arrow-down-a-z','fa-solid fa-arrow-down-long','fa-solid fa-arrow-down-short-wide','fa-solid fa-arrow-down-wide-short','fa-solid fa-arrow-down-z-a','fa-solid fa-arrow-left','fa-solid fa-arrow-left-long','fa-solid fa-arrow-pointer','fa-solid fa-arrow-right','fa-solid fa-arrow-right-arrow-left','fa-solid fa-arrow-right-from-bracket','fa-solid fa-arrow-right-long','fa-solid fa-arrow-right-to-bracket','fa-solid fa-arrow-right-to-city','fa-solid fa-arrow-rotate-left','fa-solid fa-arrow-rotate-right','fa-solid fa-arrows-down-to-line','fa-solid fa-arrows-down-to-people','fa-solid fa-arrows-left-right','fa-solid fa-arrows-left-right-to-line','fa-solid fa-arrows-rotate','fa-solid fa-arrows-spin','fa-solid fa-arrows-split-up-and-left','fa-solid fa-arrows-to-circle','fa-solid fa-arrows-to-dot','fa-solid fa-arrows-to-eye','fa-solid fa-arrows-turn-right','fa-solid fa-arrows-turn-to-dots','fa-solid fa-arrows-up-down','fa-solid fa-arrows-up-down-left-right','fa-solid fa-arrows-up-to-line','fa-solid fa-arrow-trend-down','fa-solid fa-arrow-trend-up','fa-solid fa-arrow-turn-down','fa-solid fa-arrow-turn-up','fa-solid fa-arrow-up','fa-solid fa-arrow-up-1-9','fa-solid fa-arrow-up-9-1','fa-solid fa-arrow-up-a-z','fa-solid fa-arrow-up-from-bracket','fa-solid fa-arrow-up-from-ground-water','fa-solid fa-arrow-up-from-water-pump','fa-solid fa-arrow-up-long','fa-solid fa-arrow-up-right-dots','fa-solid fa-arrow-up-right-from-square','fa-solid fa-arrow-up-short-wide','fa-solid fa-arrow-up-wide-short','fa-solid fa-arrow-up-z-a','fa-solid fa-asterisk','fa-solid fa-at','fa-solid fa-atom','fa-solid fa-audio-description','fa-solid fa-austral-sign','fa-solid fa-award',
    'fa-solid fa-b','fa-solid fa-baby','fa-solid fa-baby-carriage','fa-solid fa-backward','fa-solid fa-backward-fast','fa-solid fa-backward-step','fa-solid fa-bacon','fa-solid fa-bacteria','fa-solid fa-bacterium','fa-solid fa-bag-shopping','fa-solid fa-bahai','fa-solid fa-baht-sign','fa-solid fa-ban','fa-solid fa-ban-smoking','fa-solid fa-bandage','fa-solid fa-barcode','fa-solid fa-bars','fa-solid fa-bars-progress','fa-solid fa-bars-staggered','fa-solid fa-baseball','fa-solid fa-baseball-bat-ball','fa-solid fa-basket-shopping','fa-solid fa-basketball','fa-solid fa-bath','fa-solid fa-battery-empty','fa-solid fa-battery-full','fa-solid fa-battery-half','fa-solid fa-battery-quarter','fa-solid fa-battery-three-quarters','fa-solid fa-bed','fa-solid fa-bed-pulse','fa-solid fa-beer-mug-empty','fa-solid fa-bell','fa-solid fa-bell-concierge','fa-solid fa-bell-slash','fa-solid fa-bezier-curve','fa-solid fa-bicycle','fa-solid fa-binoculars','fa-solid fa-biohazard','fa-solid fa-bitcoin-sign','fa-solid fa-blender','fa-solid fa-blender-phone','fa-solid fa-blog','fa-solid fa-bold','fa-solid fa-bolt','fa-solid fa-bolt-lightning','fa-solid fa-bomb','fa-solid fa-bone','fa-solid fa-book','fa-solid fa-book-atlas','fa-solid fa-book-bible','fa-solid fa-bookmark','fa-solid fa-book-medical','fa-solid fa-book-open','fa-solid fa-book-open-reader','fa-solid fa-book-quran','fa-solid fa-book-skull','fa-solid fa-book-tanakh','fa-solid fa-border-all','fa-solid fa-border-none','fa-solid fa-border-top-left','fa-solid fa-bore-hole','fa-solid fa-bottle-droplet','fa-solid fa-bottle-water','fa-solid fa-box','fa-solid fa-boxes-packing','fa-solid fa-boxes-stacked','fa-solid fa-box-archive','fa-solid fa-box-open','fa-solid fa-box-tissue','fa-solid fa-braille','fa-solid fa-brain','fa-solid fa-brazilian-real-sign','fa-solid fa-bread-slice','fa-solid fa-bridge','fa-solid fa-bridge-circle-check','fa-solid fa-bridge-circle-exclamation','fa-solid fa-bridge-circle-xmark','fa-solid fa-bridge-lock','fa-solid fa-bridge-water','fa-solid fa-briefcase','fa-solid fa-briefcase-medical','fa-solid fa-broom','fa-solid fa-broom-ball','fa-solid fa-brush','fa-solid fa-bug','fa-solid fa-bugs','fa-solid fa-bug-slash','fa-solid fa-building','fa-solid fa-building-circle-arrow-right','fa-solid fa-building-circle-check','fa-solid fa-building-circle-exclamation','fa-solid fa-building-circle-xmark','fa-solid fa-building-columns','fa-solid fa-building-flag','fa-solid fa-building-lock','fa-solid fa-building-ngo','fa-solid fa-building-shield','fa-solid fa-building-un','fa-solid fa-building-user','fa-solid fa-building-wheat','fa-solid fa-bullhorn','fa-solid fa-bullseye','fa-solid fa-burger','fa-solid fa-bus','fa-solid fa-bus-simple','fa-solid fa-business-time',
    'fa-brands fa-behance','fa-brands fa-bilibili','fa-brands fa-bing','fa-brands fa-bitcoin','fa-brands fa-blogger','fa-brands fa-bluetooth','fa-brands fa-bootstrap','fa-brands fa-bots',
    'fa-solid fa-c','fa-solid fa-cake-candles','fa-solid fa-calculator','fa-solid fa-calendar','fa-solid fa-calendar-check','fa-solid fa-calendar-day','fa-solid fa-calendar-days','fa-solid fa-calendar-minus','fa-solid fa-calendar-plus','fa-solid fa-calendar-week','fa-solid fa-calendar-xmark','fa-solid fa-camera','fa-solid fa-camera-retro','fa-solid fa-camera-rotate','fa-solid fa-campground','fa-solid fa-candy-cane','fa-solid fa-cannabis','fa-solid fa-capsules','fa-solid fa-car','fa-solid fa-caravan','fa-solid fa-car-battery','fa-solid fa-car-burst','fa-solid fa-car-on','fa-solid fa-car-rear','fa-solid fa-car-side','fa-solid fa-cart-arrow-down','fa-solid fa-cart-plus','fa-solid fa-cart-shopping','fa-solid fa-cash-register','fa-solid fa-cat','fa-solid fa-cedi-sign','fa-solid fa-cent-sign','fa-solid fa-certificate','fa-solid fa-chair','fa-solid fa-chalkboard','fa-solid fa-chalkboard-user','fa-solid fa-champagne-glasses','fa-solid fa-charging-station','fa-solid fa-chart-area','fa-solid fa-chart-bar','fa-solid fa-chart-column','fa-solid fa-chart-gantt','fa-solid fa-chart-line','fa-solid fa-chart-pie','fa-solid fa-chart-simple','fa-solid fa-check','fa-solid fa-check-double','fa-solid fa-cheese','fa-solid fa-chess','fa-solid fa-chess-bishop','fa-solid fa-chess-board','fa-solid fa-chess-king','fa-solid fa-chess-knight','fa-solid fa-chess-pawn','fa-solid fa-chess-queen','fa-solid fa-chess-rook','fa-solid fa-child','fa-solid fa-child-combatant','fa-solid fa-child-dress','fa-solid fa-child-reaching','fa-solid fa-children','fa-solid fa-church','fa-solid fa-circle','fa-solid fa-circle-arrow-down','fa-solid fa-circle-arrow-left','fa-solid fa-circle-arrow-right','fa-solid fa-circle-arrow-up','fa-solid fa-circle-check','fa-solid fa-circle-chevron-down','fa-solid fa-circle-chevron-left','fa-solid fa-circle-chevron-right','fa-solid fa-circle-chevron-up','fa-solid fa-circle-dollar-to-slot','fa-solid fa-circle-dot','fa-solid fa-circle-down','fa-solid fa-circle-exclamation','fa-solid fa-circle-h','fa-solid fa-circle-half-stroke','fa-solid fa-circle-info','fa-solid fa-circle-left','fa-solid fa-circle-minus','fa-solid fa-circle-nodes','fa-solid fa-circle-notch','fa-solid fa-circle-pause','fa-solid fa-circle-play','fa-solid fa-circle-plus','fa-solid fa-circle-question','fa-solid fa-circle-radiation','fa-solid fa-circle-right','fa-solid fa-circle-stop','fa-solid fa-circle-up','fa-solid fa-circle-user','fa-solid fa-circle-xmark','fa-solid fa-city','fa-solid fa-clapperboard','fa-solid fa-clipboard','fa-solid fa-clipboard-check','fa-solid fa-clipboard-list','fa-solid fa-clipboard-question','fa-solid fa-clipboard-user','fa-solid fa-clock','fa-solid fa-clock-rotate-left','fa-solid fa-clone','fa-solid fa-closed-captioning','fa-solid fa-cloud','fa-solid fa-cloud-arrow-down','fa-solid fa-cloud-arrow-up','fa-solid fa-cloud-bolt','fa-solid fa-cloud-meatball','fa-solid fa-cloud-moon','fa-solid fa-cloud-moon-rain','fa-solid fa-cloud-rain','fa-solid fa-cloud-showers-heavy','fa-solid fa-cloud-showers-water','fa-solid fa-cloud-sun','fa-solid fa-cloud-sun-rain','fa-solid fa-clover','fa-solid fa-code','fa-solid fa-code-branch','fa-solid fa-code-commit','fa-solid fa-code-compare','fa-solid fa-code-fork','fa-solid fa-code-merge','fa-solid fa-code-pull-request','fa-solid fa-coins','fa-solid fa-colon-sign','fa-solid fa-comment','fa-solid fa-comments','fa-solid fa-comment-dollar','fa-solid fa-comment-dots','fa-solid fa-comment-medical','fa-solid fa-comment-slash','fa-solid fa-comment-sms','fa-solid fa-comments-dollar','fa-solid fa-compact-disc','fa-solid fa-compass','fa-solid fa-compass-drafting','fa-solid fa-compress','fa-solid fa-computer','fa-solid fa-computer-mouse','fa-solid fa-cookie','fa-solid fa-cookie-bite','fa-solid fa-copy','fa-solid fa-copyright','fa-solid fa-couch','fa-solid fa-cow','fa-solid fa-credit-card','fa-solid fa-crop','fa-solid fa-crop-simple','fa-solid fa-cross','fa-solid fa-crosshairs','fa-solid fa-crow','fa-solid fa-crown','fa-solid fa-crutch','fa-solid fa-cruzeiro-sign','fa-solid fa-cube','fa-solid fa-cubes','fa-solid fa-cubes-stacked',
    'fa-brands fa-cc-amazon-pay','fa-brands fa-cc-amex','fa-brands fa-cc-apple-pay','fa-brands fa-cc-diners-club','fa-brands fa-cc-discover','fa-brands fa-cc-jcb','fa-brands fa-cc-mastercard','fa-brands fa-cc-paypal','fa-brands fa-cc-stripe','fa-brands fa-cc-visa','fa-brands fa-centercode','fa-brands fa-centos','fa-brands fa-chrome','fa-brands fa-chromecast','fa-brands fa-cloudflare','fa-brands fa-codepen','fa-brands fa-codiepie','fa-brands fa-confluence','fa-brands fa-connectdevelop','fa-brands fa-contao','fa-brands fa-cotton-bureau','fa-brands fa-cpanel','fa-brands fa-creative-commons','fa-brands fa-css3','fa-brands fa-css3-alt',
    'fa-solid fa-d','fa-solid fa-database','fa-solid fa-delete-left','fa-solid fa-democrat','fa-solid fa-desktop','fa-solid fa-dharmachakra','fa-solid fa-diagram-next','fa-solid fa-diagram-predecessor','fa-solid fa-diagram-project','fa-solid fa-diagram-successor','fa-solid fa-diamond','fa-solid fa-diamond-turn-right','fa-solid fa-dice','fa-solid fa-dice-d20','fa-solid fa-dice-d6','fa-solid fa-dice-five','fa-solid fa-dice-four','fa-solid fa-dice-one','fa-solid fa-dice-six','fa-solid fa-dice-three','fa-solid fa-dice-two','fa-solid fa-disease','fa-solid fa-display','fa-solid fa-divide','fa-solid fa-dna','fa-solid fa-dog','fa-solid fa-dollar-sign','fa-solid fa-dolly','fa-solid fa-dong-sign','fa-solid fa-door-closed','fa-solid fa-door-open','fa-solid fa-dove','fa-solid fa-down-left-and-up-right-to-center','fa-solid fa-download','fa-solid fa-down-long','fa-solid fa-droplet','fa-solid fa-droplet-slash','fa-solid fa-drum','fa-solid fa-drum-steelpan','fa-solid fa-drumstick-bite','fa-solid fa-dumbbell','fa-solid fa-dumpster','fa-solid fa-dumpster-fire','fa-solid fa-dungeon',
    'fa-brands fa-dailymotion','fa-brands fa-dashcube','fa-brands fa-deezer','fa-brands fa-delicious','fa-brands fa-deploydog','fa-brands fa-deskpro','fa-brands fa-dev','fa-brands fa-deviantart','fa-brands fa-dhl','fa-brands fa-diaspora','fa-brands fa-digg','fa-brands fa-discord','fa-brands fa-discourse','fa-brands fa-docker','fa-brands fa-dribbble','fa-brands fa-dropbox','fa-brands fa-drupal','fa-brands fa-dyalog',
    'fa-solid fa-e','fa-solid fa-earth-africa','fa-solid fa-earth-americas','fa-solid fa-earth-asia','fa-solid fa-earth-europe','fa-solid fa-earth-oceania','fa-solid fa-egg','fa-solid fa-eject','fa-solid fa-elevator','fa-solid fa-ellipsis','fa-solid fa-ellipsis-vertical','fa-solid fa-envelope','fa-solid fa-envelope-circle-check','fa-solid fa-envelope-open','fa-solid fa-envelope-open-text','fa-solid fa-envelopes-bulk','fa-solid fa-equals','fa-solid fa-eraser','fa-solid fa-ethereum','fa-solid fa-euro-sign','fa-solid fa-exclamation','fa-solid fa-expand','fa-solid fa-explosion','fa-solid fa-eye','fa-solid fa-eye-dropper','fa-solid fa-eye-low-vision','fa-solid fa-eye-slash',
    'fa-brands fa-earlybirds','fa-brands fa-ebay','fa-brands fa-edge','fa-brands fa-elementor','fa-brands fa-ello','fa-brands fa-ember','fa-brands fa-ethereum','fa-brands fa-etsy','fa-brands fa-evernote','fa-brands fa-expeditedssl',
    'fa-solid fa-f','fa-solid fa-face-angry','fa-solid fa-face-dizzy','fa-solid fa-face-flushed','fa-solid fa-face-frown','fa-solid fa-face-frown-open','fa-solid fa-face-grimace','fa-solid fa-face-grin','fa-solid fa-face-grin-beam','fa-solid fa-face-grin-beam-sweat','fa-solid fa-face-grin-hearts','fa-solid fa-face-grin-squint','fa-solid fa-face-grin-squint-tears','fa-solid fa-face-grin-stars','fa-solid fa-face-grin-tears','fa-solid fa-face-grin-tongue','fa-solid fa-face-grin-tongue-squint','fa-solid fa-face-grin-tongue-wink','fa-solid fa-face-grin-wide','fa-solid fa-face-grin-wink','fa-solid fa-face-kiss','fa-solid fa-face-kiss-beam','fa-solid fa-face-kiss-wink-heart','fa-solid fa-face-laugh','fa-solid fa-face-laugh-beam','fa-solid fa-face-laugh-squint','fa-solid fa-face-laugh-wink','fa-solid fa-face-meh','fa-solid fa-face-meh-blank','fa-solid fa-face-rolling-eyes','fa-solid fa-face-sad-cry','fa-solid fa-face-sad-tear','fa-solid fa-face-smile','fa-solid fa-face-smile-beam','fa-solid fa-face-smile-wink','fa-solid fa-face-surprise','fa-solid fa-face-tired','fa-solid fa-fan','fa-solid fa-faucet','fa-solid fa-faucet-drip','fa-solid fa-fax','fa-solid fa-feather','fa-solid fa-feather-pointed','fa-solid fa-ferry','fa-solid fa-file','fa-solid fa-file-arrow-down','fa-solid fa-file-arrow-up','fa-solid fa-file-audio','fa-solid fa-file-circle-check','fa-solid fa-file-circle-exclamation','fa-solid fa-file-circle-minus','fa-solid fa-file-circle-plus','fa-solid fa-file-circle-question','fa-solid fa-file-circle-xmark','fa-solid fa-file-code','fa-solid fa-file-contract','fa-solid fa-file-csv','fa-solid fa-file-excel','fa-solid fa-file-export','fa-solid fa-file-image','fa-solid fa-file-import','fa-solid fa-file-invoice','fa-solid fa-file-invoice-dollar','fa-solid fa-file-lines','fa-solid fa-file-medical','fa-solid fa-file-pdf','fa-solid fa-file-pen','fa-solid fa-file-powerpoint','fa-solid fa-file-prescription','fa-solid fa-file-shield','fa-solid fa-file-signature','fa-solid fa-file-video','fa-solid fa-file-waveform','fa-solid fa-file-word','fa-solid fa-file-zipper','fa-solid fa-fill','fa-solid fa-fill-drip','fa-solid fa-film','fa-solid fa-filter','fa-solid fa-filter-circle-dollar','fa-solid fa-filter-circle-xmark','fa-solid fa-fingerprint','fa-solid fa-fire','fa-solid fa-fire-burner','fa-solid fa-fire-extinguisher','fa-solid fa-fire-flame-curved','fa-solid fa-fire-flame-simple','fa-solid fa-fish','fa-solid fa-fish-fins','fa-solid fa-flag','fa-solid fa-flag-checkered','fa-solid fa-flag-usa','fa-solid fa-flask','fa-solid fa-flask-vial','fa-solid fa-floppy-disk','fa-solid fa-florin-sign','fa-solid fa-folder','fa-solid fa-folder-closed','fa-solid fa-folder-minus','fa-solid fa-folder-open','fa-solid fa-folder-plus','fa-solid fa-folder-tree','fa-solid fa-font','fa-solid fa-football','fa-solid fa-forward','fa-solid fa-forward-fast','fa-solid fa-forward-step','fa-solid fa-franc-sign','fa-solid fa-frog',
    'fa-brands fa-facebook','fa-brands fa-facebook-messenger','fa-brands fa-figma','fa-brands fa-firefox','fa-brands fa-first-order','fa-brands fa-flickr','fa-brands fa-flutter',
    'fa-solid fa-g','fa-solid fa-gamepad','fa-solid fa-gas-pump','fa-solid fa-gauge','fa-solid fa-gauge-high','fa-solid fa-gauge-simple','fa-solid fa-gauge-simple-high','fa-solid fa-gavel','fa-solid fa-gem','fa-solid fa-genderless','fa-solid fa-ghost','fa-solid fa-gift','fa-solid fa-gifts','fa-solid fa-globe','fa-solid fa-golf-ball-tee','fa-solid fa-graduation-cap','fa-solid fa-greater-than','fa-solid fa-greater-than-equal','fa-solid fa-grip','fa-solid fa-grip-lines','fa-solid fa-grip-lines-vertical','fa-solid fa-grip-vertical','fa-solid fa-guarani-sign','fa-solid fa-guitar','fa-solid fa-gun',
    'fa-brands fa-git','fa-brands fa-github','fa-brands fa-gitlab','fa-brands fa-google','fa-brands fa-google-drive','fa-brands fa-google-pay','fa-brands fa-google-play','fa-brands fa-google-plus','fa-brands fa-google-wallet',
    'fa-solid fa-h','fa-solid fa-hammer','fa-solid fa-hamsa','fa-solid fa-hand','fa-solid fa-hand-back-fist','fa-solid fa-hand-dots','fa-solid fa-hand-fist','fa-solid fa-hand-holding','fa-solid fa-hand-holding-dollar','fa-solid fa-hand-holding-droplet','fa-solid fa-hand-holding-hand','fa-solid fa-hand-holding-heart','fa-solid fa-hand-holding-medical','fa-solid fa-hand-lizard','fa-solid fa-hand-middle-finger','fa-solid fa-hand-peace','fa-solid fa-hand-point-down','fa-solid fa-hand-pointer','fa-solid fa-hand-point-left','fa-solid fa-hand-point-right','fa-solid fa-hand-point-up','fa-solid fa-hands','fa-solid fa-handshake','fa-solid fa-handshake-angle','fa-solid fa-handshake-simple','fa-solid fa-handshake-simple-slash','fa-solid fa-handshake-slash','fa-solid fa-hands-bound','fa-solid fa-hands-bubbles','fa-solid fa-hands-clapping','fa-solid fa-hands-holding','fa-solid fa-hands-holding-child','fa-solid fa-hands-holding-circle','fa-solid fa-hand-sparkles','fa-solid fa-hands-praying','fa-solid fa-hand-spock','fa-solid fa-hard-drive','fa-solid fa-hashtag','fa-solid fa-hat-cowboy','fa-solid fa-hat-cowboy-side','fa-solid fa-hat-wizard','fa-solid fa-headphones','fa-solid fa-headphones-simple','fa-solid fa-headset','fa-solid fa-heart','fa-solid fa-heart-circle-bolt','fa-solid fa-heart-circle-check','fa-solid fa-heart-circle-exclamation','fa-solid fa-heart-circle-minus','fa-solid fa-heart-circle-plus','fa-solid fa-heart-circle-xmark','fa-solid fa-heart-crack','fa-solid fa-heart-pulse','fa-solid fa-helicopter','fa-solid fa-helicopter-symbol','fa-solid fa-helmet-safety','fa-solid fa-helmet-un','fa-solid fa-highlighter','fa-solid fa-hill-avalanche','fa-solid fa-hill-rockslide','fa-solid fa-hippo','fa-solid fa-hockey-puck','fa-solid fa-holly-berry','fa-solid fa-horse','fa-solid fa-horse-head','fa-solid fa-hospital','fa-solid fa-hospital-user','fa-solid fa-hotel','fa-solid fa-hourglass','fa-solid fa-hourglass-end','fa-solid fa-hourglass-half','fa-solid fa-hourglass-start','fa-solid fa-house','fa-solid fa-house-chimney','fa-solid fa-house-chimney-crack','fa-solid fa-house-chimney-medical','fa-solid fa-house-chimney-user','fa-solid fa-house-chimney-window','fa-solid fa-house-circle-check','fa-solid fa-house-circle-exclamation','fa-solid fa-house-circle-xmark','fa-solid fa-house-crack','fa-solid fa-house-fire','fa-solid fa-house-flag','fa-solid fa-house-flood-water','fa-solid fa-house-flood-water-circle-arrow-right','fa-solid fa-house-lock','fa-solid fa-house-medical','fa-solid fa-house-medical-circle-check','fa-solid fa-house-medical-circle-exclamation','fa-solid fa-house-medical-circle-xmark','fa-solid fa-house-medical-flag','fa-solid fa-house-signal','fa-solid fa-house-tsunami','fa-solid fa-house-user',
    'fa-brands fa-hacker-news','fa-brands fa-hackerrank','fa-brands fa-hashnode','fa-brands fa-houzz',
    'fa-solid fa-i','fa-solid fa-i-cursor','fa-solid fa-image','fa-solid fa-images','fa-solid fa-inbox','fa-solid fa-indent','fa-solid fa-industry','fa-solid fa-infinity','fa-solid fa-info','fa-solid fa-italic',
    'fa-brands fa-instagram','fa-brands fa-ioxhost',
    'fa-solid fa-j','fa-solid fa-jar','fa-solid fa-jar-wheat','fa-solid fa-jedi','fa-solid fa-jet-fighter','fa-solid fa-jet-fighter-up',
    'fa-brands fa-java','fa-brands fa-jenkins','fa-brands fa-jira','fa-brands fa-joget','fa-brands fa-js',
    'fa-solid fa-k','fa-solid fa-key','fa-solid fa-keyboard','fa-solid fa-khanda','fa-solid fa-kip-sign','fa-solid fa-kit-medical','fa-solid fa-kiwi-bird',
    'fa-brands fa-kaggle','fa-brands fa-keybase','fa-brands fa-keycdn','fa-brands fa-kickstarter',
    'fa-solid fa-l','fa-solid fa-landmark','fa-solid fa-landmark-dome','fa-solid fa-landmark-flag','fa-solid fa-language','fa-solid fa-laptop','fa-solid fa-laptop-code','fa-solid fa-laptop-file','fa-solid fa-laptop-medical','fa-solid fa-lari-sign','fa-solid fa-layer-group','fa-solid fa-leaf','fa-solid fa-left-long','fa-solid fa-left-right','fa-solid fa-lemon','fa-solid fa-less-than','fa-solid fa-less-than-equal','fa-solid fa-life-ring','fa-solid fa-lightbulb','fa-solid fa-lines-leaning','fa-solid fa-link','fa-solid fa-link-slash','fa-solid fa-lira-sign','fa-solid fa-list','fa-solid fa-list-check','fa-solid fa-list-ol','fa-solid fa-list-ul','fa-solid fa-litecoin-sign','fa-solid fa-location-arrow','fa-solid fa-location-crosshairs','fa-solid fa-location-dot','fa-solid fa-location-pin','fa-solid fa-location-pin-lock','fa-solid fa-lock','fa-solid fa-lock-open','fa-solid fa-locust','fa-solid fa-lungs','fa-solid fa-lungs-virus',
    'fa-brands fa-laravel','fa-brands fa-lastfm','fa-brands fa-leanpub','fa-brands fa-less','fa-brands fa-line','fa-brands fa-linkedin','fa-brands fa-linux',
    'fa-solid fa-m','fa-solid fa-magnet','fa-solid fa-magnifying-glass','fa-solid fa-magnifying-glass-arrow-right','fa-solid fa-magnifying-glass-chart','fa-solid fa-magnifying-glass-dollar','fa-solid fa-magnifying-glass-location','fa-solid fa-magnifying-glass-minus','fa-solid fa-magnifying-glass-plus','fa-solid fa-manat-sign','fa-solid fa-map','fa-solid fa-map-location','fa-solid fa-map-location-dot','fa-solid fa-map-pin','fa-solid fa-marker','fa-solid fa-mars','fa-solid fa-mars-and-venus','fa-solid fa-mars-and-venus-burst','fa-solid fa-mars-double','fa-solid fa-mars-stroke','fa-solid fa-mars-stroke-right','fa-solid fa-mars-stroke-up','fa-solid fa-martini-glass','fa-solid fa-martini-glass-citrus','fa-solid fa-martini-glass-empty','fa-solid fa-mask','fa-solid fa-mask-face','fa-solid fa-mask-ventilator','fa-solid fa-maximize','fa-solid fa-medal','fa-solid fa-memory','fa-solid fa-menorah','fa-solid fa-mercury','fa-solid fa-message','fa-solid fa-meteor','fa-solid fa-microchip','fa-solid fa-microphone','fa-solid fa-microphone-lines','fa-solid fa-microphone-lines-slash','fa-solid fa-microphone-slash','fa-solid fa-microscope','fa-solid fa-mill-sign','fa-solid fa-minimize','fa-solid fa-minus','fa-solid fa-mitten','fa-solid fa-mobile','fa-solid fa-mobile-button','fa-solid fa-mobile-retro','fa-solid fa-mobile-screen','fa-solid fa-mobile-screen-button','fa-solid fa-money-bill','fa-solid fa-money-bill-1','fa-solid fa-money-bill-1-wave','fa-solid fa-money-bill-transfer','fa-solid fa-money-bill-trend-up','fa-solid fa-money-bill-wave','fa-solid fa-money-bill-wheat','fa-solid fa-money-check','fa-solid fa-money-check-dollar','fa-solid fa-monument','fa-solid fa-moon','fa-solid fa-mortar-pestle','fa-solid fa-mosque','fa-solid fa-mosquito','fa-solid fa-mosquito-net','fa-solid fa-motorcycle','fa-solid fa-mound','fa-solid fa-mountain','fa-solid fa-mountain-city','fa-solid fa-mountain-sun','fa-solid fa-mug-hot','fa-solid fa-mug-saucer','fa-solid fa-music',
    'fa-brands fa-markdown','fa-brands fa-mastodon','fa-brands fa-maxcdn','fa-brands fa-meta','fa-brands fa-microsoft',
    'fa-solid fa-n','fa-solid fa-naira-sign','fa-solid fa-network-wired','fa-solid fa-neuter','fa-solid fa-newspaper','fa-solid fa-not-equal','fa-solid fa-notes-medical',
    'fa-brands fa-napster','fa-brands fa-node','fa-brands fa-node-js','fa-brands fa-npm','fa-brands fa-ns8','fa-brands fa-nutritionix',
    'fa-solid fa-o','fa-solid fa-object-group','fa-solid fa-object-ungroup','fa-solid fa-oil-can','fa-solid fa-oil-well','fa-solid fa-om','fa-solid fa-otter',
    'fa-brands fa-odysee','fa-brands fa-old-republic','fa-brands fa-opencart',
    'fa-solid fa-p','fa-solid fa-pager','fa-solid fa-paintbrush','fa-solid fa-palette','fa-solid fa-pallet','fa-solid fa-paper-plane','fa-solid fa-paperclip','fa-solid fa-parachute-box','fa-solid fa-paragraph','fa-solid fa-passport','fa-solid fa-paste','fa-solid fa-pause','fa-solid fa-paw','fa-solid fa-peace','fa-solid fa-pen','fa-solid fa-pencil','fa-solid fa-pen-clip','fa-solid fa-pen-fancy','fa-solid fa-pen-nib','fa-solid fa-pen-ruler','fa-solid fa-pen-to-square','fa-solid fa-people-arrows','fa-solid fa-people-carry-box','fa-solid fa-people-group','fa-solid fa-people-line','fa-solid fa-people-pulling','fa-solid fa-people-robbery','fa-solid fa-people-roof','fa-solid fa-pepper-hot','fa-solid fa-percent','fa-solid fa-person','fa-solid fa-phone','fa-solid fa-photo-film','fa-solid fa-pie-chart','fa-solid fa-piggy-bank','fa-solid fa-pills','fa-solid fa-pizza-slice','fa-solid fa-plane','fa-solid fa-play','fa-solid fa-plug','fa-solid fa-plus','fa-solid fa-podcast','fa-solid fa-poo','fa-solid fa-poop','fa-solid fa-power-off','fa-solid fa-prescription','fa-solid fa-print','fa-solid fa-pump-medical','fa-solid fa-puzzle-piece',
    'fa-brands fa-paypal','fa-brands fa-phabricator','fa-brands fa-php','fa-brands fa-pinterest','fa-brands fa-python',
    'fa-solid fa-q','fa-solid fa-qrcode','fa-solid fa-question',
    'fa-solid fa-r','fa-solid fa-radiation','fa-solid fa-radio','fa-solid fa-rainbow','fa-solid fa-receipt','fa-solid fa-recycle','fa-solid fa-registered','fa-solid fa-repeat','fa-solid fa-republican','fa-solid fa-restroom','fa-solid fa-retweet','fa-solid fa-ribbon','fa-solid fa-right-from-bracket','fa-solid fa-right-left','fa-solid fa-right-long','fa-solid fa-right-to-bracket','fa-solid fa-ring','fa-solid fa-road','fa-solid fa-robot','fa-solid fa-rocket','fa-solid fa-rotate','fa-solid fa-route','fa-solid fa-rss','fa-solid fa-ruble-sign','fa-solid fa-rugby-ball','fa-solid fa-ruler','fa-solid fa-rupee-sign','fa-solid fa-rupiah-sign',
    'fa-brands fa-react','fa-brands fa-readme','fa-brands fa-reddit','fa-brands fa-redhat','fa-brands fa-rust',
    'fa-solid fa-s','fa-solid fa-sailboat','fa-solid fa-satellite','fa-solid fa-satellite-dish','fa-solid fa-scale-balanced','fa-solid fa-scale-unbalanced','fa-solid fa-scale-unbalanced-flip','fa-solid fa-school','fa-solid fa-scissors','fa-solid fa-screwdriver','fa-solid fa-screwdriver-wrench','fa-solid fa-scroll','fa-solid fa-seedling','fa-solid fa-server','fa-solid fa-shapes','fa-solid fa-share','fa-solid fa-share-from-square','fa-solid fa-share-nodes','fa-solid fa-shield','fa-solid fa-shield-cat','fa-solid fa-shield-dog','fa-solid fa-shield-halved','fa-solid fa-shield-heart','fa-solid fa-shield-virus','fa-solid fa-ship','fa-solid fa-shop','fa-solid fa-shower','fa-solid fa-shrimp','fa-solid fa-shuffle','fa-solid fa-signal','fa-solid fa-sitemap','fa-solid fa-skull','fa-solid fa-skull-crossbones','fa-solid fa-sliders','fa-solid fa-smog','fa-solid fa-snowflake','fa-solid fa-snowman','fa-solid fa-snowplow','fa-solid fa-soap','fa-solid fa-socks','fa-solid fa-solar-panel','fa-solid fa-sort','fa-solid fa-sort-down','fa-solid fa-sort-up','fa-solid fa-spa','fa-solid fa-spider','fa-solid fa-spinner','fa-solid fa-splotch','fa-solid fa-spoon','fa-solid fa-spray-can','fa-solid fa-spray-can-sparkles','fa-solid fa-square','fa-solid fa-square-arrow-up-right','fa-solid fa-square-check','fa-solid fa-square-envelope','fa-solid fa-square-full','fa-solid fa-square-h','fa-solid fa-square-minus','fa-solid fa-square-nfi','fa-solid fa-square-parking','fa-solid fa-square-pen','fa-solid fa-square-person-confined','fa-solid fa-square-phone','fa-solid fa-square-phone-flip','fa-solid fa-square-plus','fa-solid fa-square-poll-horizontal','fa-solid fa-square-poll-vertical','fa-solid fa-square-root-variable','fa-solid fa-square-rss','fa-solid fa-square-share-nodes','fa-solid fa-square-up-right','fa-solid fa-square-virus','fa-solid fa-square-xmark','fa-solid fa-staff-snake','fa-solid fa-stairs','fa-solid fa-star','fa-solid fa-star-and-crescent','fa-solid fa-star-half','fa-solid fa-star-half-stroke','fa-solid fa-star-of-david','fa-solid fa-star-of-life','fa-solid fa-sterling-sign','fa-solid fa-stethoscope','fa-solid fa-stop','fa-solid fa-stopwatch','fa-solid fa-stopwatch-20','fa-solid fa-store','fa-solid fa-street-view','fa-solid fa-strikethrough','fa-solid fa-subscript','fa-solid fa-suitcase','fa-solid fa-suitcase-medical','fa-solid fa-sun','fa-solid fa-sun-plant-wilt','fa-solid fa-superscript','fa-solid fa-swatchbook','fa-solid fa-synagogue',
    'fa-brands fa-safari','fa-brands fa-salesforce','fa-brands fa-sass','fa-brands fa-scribd','fa-brands fa-searchengin','fa-brands fa-shopify','fa-brands fa-signal-messenger','fa-brands fa-sketch','fa-brands fa-slack','fa-brands fa-snapchat','fa-brands fa-soundcloud','fa-brands fa-spotify','fa-brands fa-square-font-awesome','fa-brands fa-squarespace','fa-brands fa-stack-exchange','fa-brands fa-stack-overflow','fa-brands fa-strava','fa-brands fa-stripe','fa-brands fa-stripe-s','fa-brands fa-studiovinari','fa-brands fa-stumbleupon','fa-brands fa-swift','fa-brands fa-symfony',
    'fa-solid fa-t','fa-solid fa-table','fa-solid fa-table-cells','fa-solid fa-table-cells-large','fa-solid fa-table-columns','fa-solid fa-table-list','fa-solid fa-tablet','fa-solid fa-tablet-button','fa-solid fa-tablet-screen-button','fa-solid fa-tag','fa-solid fa-tags','fa-solid fa-tape','fa-solid fa-tarp','fa-solid fa-tarp-droplet','fa-solid fa-taxi','fa-solid fa-teeth','fa-solid fa-teeth-open','fa-solid fa-temperature-arrow-down','fa-solid fa-temperature-arrow-up','fa-solid fa-temperature-empty','fa-solid fa-temperature-full','fa-solid fa-temperature-half','fa-solid fa-temperature-high','fa-solid fa-temperature-low','fa-solid fa-temperature-quarter','fa-solid fa-temperature-three-quarters','fa-solid fa-tenge-sign','fa-solid fa-tent','fa-solid fa-tents','fa-solid fa-tent-arrow-down-to-line','fa-solid fa-tent-arrow-left-right','fa-solid fa-tent-arrow-turn-left','fa-solid fa-tent-arrows-down','fa-solid fa-terminal','fa-solid fa-text-height','fa-solid fa-text-slash','fa-solid fa-text-width','fa-solid fa-thermometer','fa-solid fa-thumbs-down','fa-solid fa-thumbs-up','fa-solid fa-thumbtack','fa-solid fa-ticket','fa-solid fa-ticket-simple','fa-solid fa-timeline','fa-solid fa-toggle-off','fa-solid fa-toggle-on','fa-solid fa-toilet','fa-solid fa-toilet-paper','fa-solid fa-toilet-paper-slash','fa-solid fa-toilet-portable','fa-solid fa-toilets-portable','fa-solid fa-toolbox','fa-solid fa-tooth','fa-solid fa-tornado','fa-solid fa-tower-broadcast','fa-solid fa-tower-cell','fa-solid fa-tower-observation','fa-solid fa-tractor','fa-solid fa-trademark','fa-solid fa-traffic-light','fa-solid fa-trailer','fa-solid fa-train','fa-solid fa-train-subway','fa-solid fa-train-tram','fa-solid fa-transgender','fa-solid fa-trash','fa-solid fa-trash-arrow-up','fa-solid fa-trash-can','fa-solid fa-trash-can-arrow-up','fa-solid fa-tree','fa-solid fa-tree-city','fa-solid fa-triangle-exclamation','fa-solid fa-trophy','fa-solid fa-trowel','fa-solid fa-trowel-bricks','fa-solid fa-truck','fa-solid fa-truck-arrow-right','fa-solid fa-truck-droplet','fa-solid fa-truck-fast','fa-solid fa-truck-field','fa-solid fa-truck-field-un','fa-solid fa-truck-front','fa-solid fa-truck-medical','fa-solid fa-truck-monster','fa-solid fa-truck-moving','fa-solid fa-truck-pickup','fa-solid fa-truck-plane','fa-solid fa-truck-ramp-box','fa-solid fa-tty','fa-solid fa-turkish-lira-sign','fa-solid fa-tv',
    'fa-brands fa-telegram','fa-brands fa-tiktok','fa-brands fa-trello','fa-brands fa-tumblr','fa-brands fa-twitch','fa-brands fa-twitter',
    'fa-solid fa-u','fa-solid fa-umbrella','fa-solid fa-umbrella-beach','fa-solid fa-underline','fa-solid fa-unlock','fa-solid fa-unlock-keyhole','fa-solid fa-up-down','fa-solid fa-up-down-left-right','fa-solid fa-up-long','fa-solid fa-up-right-and-down-left-from-center','fa-solid fa-up-right-from-square','fa-solid fa-upload','fa-solid fa-user','fa-solid fa-user-astronaut','fa-solid fa-user-check','fa-solid fa-user-clock','fa-solid fa-user-doctor','fa-solid fa-user-gear','fa-solid fa-user-graduate','fa-solid fa-user-group','fa-solid fa-user-injured','fa-solid fa-user-large','fa-solid fa-user-large-slash','fa-solid fa-user-lock','fa-solid fa-user-minus','fa-solid fa-user-ninja','fa-solid fa-user-nurse','fa-solid fa-user-pen','fa-solid fa-user-plus','fa-solid fa-users','fa-solid fa-user-secret','fa-solid fa-user-shield','fa-solid fa-user-slash','fa-solid fa-users-between-lines','fa-solid fa-user-tag','fa-solid fa-users-gear','fa-solid fa-users-line','fa-solid fa-users-rays','fa-solid fa-users-rectangle','fa-solid fa-users-slash','fa-solid fa-users-viewfinder','fa-solid fa-user-tie','fa-solid fa-user-xmark',
    'fa-brands fa-uber','fa-brands fa-ubuntu','fa-brands fa-uniregistry','fa-brands fa-unity','fa-brands fa-unsplash',
    'fa-solid fa-v','fa-solid fa-vault','fa-solid fa-vector-square','fa-solid fa-venus','fa-solid fa-venus-double','fa-solid fa-venus-mars','fa-solid fa-vest','fa-solid fa-vest-patches','fa-solid fa-vial','fa-solid fa-vial-circle-check','fa-solid fa-vial-virus','fa-solid fa-vials','fa-solid fa-video','fa-solid fa-video-slash','fa-solid fa-virus','fa-solid fa-viruses','fa-solid fa-virus-covid','fa-solid fa-virus-covid-slash','fa-solid fa-virus-slash','fa-solid fa-voicemail','fa-solid fa-volcano','fa-solid fa-volleyball',
    'fa-brands fa-vaadin','fa-brands fa-vimeo','fa-brands fa-vine','fa-brands fa-vuejs',
    'fa-solid fa-w','fa-solid fa-wallet','fa-solid fa-wand-magic-sparkles','fa-solid fa-warehouse','fa-solid fa-water','fa-solid fa-water-ladder','fa-solid fa-wave-square','fa-solid fa-weight-hanging','fa-solid fa-weight-scale','fa-solid fa-wheat-awn','fa-solid fa-wheat-awn-circle-exclamation','fa-solid fa-wheelchair','fa-solid fa-wheelchair-move','fa-solid fa-wifi','fa-solid fa-wind','fa-solid fa-window-maximize','fa-solid fa-window-minimize','fa-solid fa-window-restore','fa-solid fa-wine-bottle','fa-solid fa-wine-glass','fa-solid fa-wine-glass-empty','fa-solid fa-won-sign','fa-solid fa-worm','fa-solid fa-wrench',
    'fa-brands fa-whatsapp','fa-brands fa-wikipedia-w','fa-brands fa-windows','fa-brands fa-wordpress',
    'fa-solid fa-x','fa-solid fa-xmark','fa-solid fa-x-ray',
    'fa-brands fa-xbox','fa-brands fa-xing','fa-brands fa-x-twitter',
    'fa-solid fa-y','fa-solid fa-yen-sign',
    'fa-brands fa-yahoo','fa-brands fa-youtube',
    'fa-solid fa-z',

    // ── EXTRA ICON PACK 2: Nature, Food, Transport, Medical, Science ──
    'fa-solid fa-tree','fa-solid fa-leaf','fa-solid fa-seedling','fa-solid fa-spa','fa-solid fa-cannabis',
    'fa-solid fa-carrot','fa-solid fa-apple-whole','fa-solid fa-lemon','fa-solid fa-pepper-hot','fa-solid fa-egg',
    'fa-solid fa-bread-slice','fa-solid fa-cheese','fa-solid fa-fish','fa-solid fa-shrimp','fa-solid fa-bacon',
    'fa-solid fa-hotdog','fa-solid fa-hamburger','fa-solid fa-pizza-slice','fa-solid fa-ice-cream','fa-solid fa-cake-candles',
    'fa-solid fa-cookie','fa-solid fa-candy-cane','fa-solid fa-jar','fa-solid fa-bottle-water','fa-solid fa-wine-glass',
    'fa-solid fa-beer-mug-empty','fa-solid fa-mug-hot','fa-solid fa-blender','fa-solid fa-kitchen-set','fa-solid fa-utensils',
    'fa-solid fa-car','fa-solid fa-car-side','fa-solid fa-truck','fa-solid fa-motorcycle','fa-solid fa-bicycle',
    'fa-solid fa-ship','fa-solid fa-sailboat','fa-solid fa-ferry','fa-solid fa-helicopter','fa-solid fa-rocket',
    'fa-solid fa-space-shuttle','fa-solid fa-satellite','fa-solid fa-parachute-box','fa-solid fa-anchor',
    'fa-solid fa-stethoscope','fa-solid fa-syringe','fa-solid fa-pills','fa-solid fa-capsules','fa-solid fa-prescription-bottle',
    'fa-solid fa-hospital','fa-solid fa-kit-medical','fa-solid fa-heart-pulse','fa-solid fa-brain','fa-solid fa-lungs',
    'fa-solid fa-tooth','fa-solid fa-eye','fa-solid fa-ear-listen','fa-solid fa-hand','fa-solid fa-bone',
    'fa-solid fa-dna','fa-solid fa-microscope','fa-solid fa-flask','fa-solid fa-vial','fa-solid fa-atom',
    'fa-solid fa-magnet','fa-solid fa-compass','fa-solid fa-globe','fa-solid fa-globe-africa','fa-solid fa-globe-americas',
    'fa-solid fa-mountain','fa-solid fa-volcano','fa-solid fa-tornado','fa-solid fa-hurricane','fa-solid fa-rainbow',
    'fa-solid fa-snowflake','fa-solid fa-cloud-bolt','fa-solid fa-cloud-rain','fa-solid fa-cloud-sun','fa-solid fa-temperature-high',
    'fa-solid fa-house','fa-solid fa-building','fa-solid fa-castle','fa-solid fa-church','fa-solid fa-school',
    'fa-solid fa-hospital-user','fa-solid fa-store','fa-solid fa-warehouse','fa-solid fa-industry','fa-solid fa-city',
    'fa-solid fa-landmark','fa-solid fa-monument','fa-solid fa-archway','fa-solid fa-bridge','fa-solid fa-tower-observation',
    'fa-solid fa-chess','fa-solid fa-chess-king','fa-solid fa-chess-queen','fa-solid fa-chess-rook','fa-solid fa-dice',
    'fa-solid fa-puzzle-piece','fa-solid fa-gamepad','fa-solid fa-headset','fa-solid fa-vr-cardboard','fa-solid fa-ghost',
    'fa-solid fa-dragon','fa-solid fa-skull','fa-solid fa-robot','fa-solid fa-alien','fa-solid fa-wand-magic-sparkles',
    'fa-solid fa-hat-wizard','fa-solid fa-mask','fa-solid fa-theater-masks','fa-solid fa-film','fa-solid fa-clapperboard',
    'fa-solid fa-tv','fa-solid fa-radio','fa-solid fa-tower-broadcast','fa-solid fa-satellite-dish','fa-solid fa-signal',
    'fa-solid fa-wifi','fa-solid fa-bluetooth','fa-solid fa-battery-full','fa-solid fa-battery-half','fa-solid fa-battery-empty',
    'fa-solid fa-plug','fa-solid fa-bolt','fa-solid fa-solar-panel','fa-solid fa-wind','fa-solid fa-oil-well',
    'fa-solid fa-briefcase','fa-solid fa-suitcase','fa-solid fa-id-card','fa-solid fa-passport','fa-solid fa-address-book',
    'fa-solid fa-receipt','fa-solid fa-file-invoice','fa-solid fa-coins','fa-solid fa-piggy-bank','fa-solid fa-vault',
    'fa-solid fa-chart-pie','fa-solid fa-chart-bar','fa-solid fa-chart-area','fa-solid fa-arrow-trend-up','fa-solid fa-arrow-trend-down',
    'fa-solid fa-percent','fa-solid fa-tags','fa-solid fa-barcode','fa-solid fa-qrcode','fa-solid fa-box',
    'fa-solid fa-boxes-stacked','fa-solid fa-pallet','fa-solid fa-dolly','fa-solid fa-truck-fast','fa-solid fa-map-location-dot',
    'fa-solid fa-map','fa-solid fa-signs-post','fa-solid fa-route','fa-solid fa-person-walking','fa-solid fa-person-running',
    'fa-solid fa-dumbbell','fa-solid fa-bicycle','fa-solid fa-futbol','fa-solid fa-basketball','fa-solid fa-football',
    'fa-solid fa-baseball','fa-solid fa-volleyball','fa-solid fa-table-tennis-paddle-ball','fa-solid fa-golf-ball-tee','fa-solid fa-medal',
    ];

const COLORS = ['#22c55e','#16a34a','#4ade80','#8b5cf6','#7c3aed','#a78bfa','#3b82f6','#1d4ed8','#60a5fa','#06b6d4','#0891b2','#67e8f9','#ef4444','#dc2626','#fca5a5','#eab308','#ca8a04','#fde047','#ec4899','#db2777','#f9a8d4','#f97316','#ea580c','#fdba74','#14b8a6','#0f766e','#5eead4','#6366f1','#4338ca','#a5b4fc','#d946ef','#c026d3','#e879f9','#fb7185','#f43f5e','#fda4af','#84cc16','#65a30d','#bef264','#f59e0b','#d97706','#fcd34d','#10b981','#059669','#6ee7b7','#0ea5e9','#0284c7','#7dd3fc','#8b5cf6','#ffffff','#a1a1aa','#52525b'];


let S = {
    folders: wmInitialData.f,
    links:   wmInitialData.l,
    trash:   wmInitialData.trash,
    activeTab: 'all',
    selIcon:  'fa-solid fa-folder',
    selColor: '#8b5cf6',
    editingLink: null,
    editingFolder: null,
    tempLogo: null,
    selectedFolderId: null,
    folderSelectSrc: 'add',
    view: ['imagetitle','headlines','cards','list'].includes(wmStorage.getItem('ly_view'))?wmStorage.getItem('ly_view'):'imagetitle',
    lang: ['en','ar','it','fr','es'].includes(wmStorage.getItem('ly_lang'))?wmStorage.getItem('ly_lang'):'en',
    settings: Object.assign({showFolders:true,showTags:true,sortByDate:false,compactCards:false,showViews:false,showThumbs:true,openNewTab:true},wmJSON('ly_settings',{})),
    tsX: 0, tsEl: null,
};
// Translation (early def so renderTabs can use it)
const _LANGS_EARLY={en:{all:'All'},fr:{all:'Tout'},es:{all:'Todo'},it:{all:'Tutti'},ar:{all:'الكل'}};
const TRANSLATIONS = {
  en:{
    vipAdd:'Add to Top10', vipRemove:'Remove from Top10', vipAdded:'Added to Top10', vipRemoved:'Removed from Top10',
    bookmarkSaveError:"Could not save the links.",
    linkClean:"Remove tracking", linkMetaLoading:"Looking up page details…", linkOpenExisting:"Edit existing", linkNoTracking:"No tracking parameters found", linkTrackingRemoved:"Tracking parameters removed",
    all:'All', home:'Home', fav:'Favorite', archive:'Archive', folders:'Folders & Tags',
    search:'Search bookmarks...', newBM:'New Bookmark', save:'Save', cancel:'Cancel',
    settings:'Settings', addLink:'Add Link', createFolder:'Create Folder',
    editFolder:'Edit Folder', folderName:'Folder Name', icon:'Icon', color:'Color',
    saveFolder:'Save Folder', unsorted:'Unsorted', selectFolder:'Select Folder',
    manFolders:'Manage Folders', tags:'Tags', editTags:'Edit Tags',
    tagsComma:'Tags (comma separated)', saveTags:'Save Tags',
    summarize:'Summarize with AI', reminder:'Reminder', setReminder:'Set Reminder',
    link:'Link', whatsapp:'Whatsapp', share:'Share', archiveBtn:'Archive', delete:'Delete',
    exportShare:'Export / Share', exportJSON:'Export Bookmarks Backup', copyText:'Copy as Text',
    exportPDF:'Export as PDF', exportExcel:'Export as Excel', contact:'Contact',
    close:'Close', saveChanges:'Save changes', chooseIcon:'Choose Icon',
    filterByTag:'Filter by Tag', noTags:'No tags yet', noBookmarks:'No bookmarks found',
    rewriteAI:'Rewrite with AI', importBM:'Import Bookmarks',
    importJSON:'Import JSON Backup', exportJSON2:'Export JSON Backup',
    showFolders:'Show folders under links', showTags:'Show tags under links',
    sortDate:'Sort by date (newest first)', language:'Language',
    goodMorning:'Good Morning', goodAfternoon:'Good Afternoon', goodEvening:'Good Evening',
    urlLabel:'URL', titleLabel:'Title', descLabel:'Description', tagsLabel:'Tags',
    folderLabel:'Folder', chooseFolder:'Choose Folder...',
    hour:'Hour', minute:'Minute', importSuccess:'Import successful!', bookmarksLoaded:'bookmarks loaded.',
    edit:"Edit", done:"Done", sortBy:"Sort by", dateAdded:"Date Added", mostVisited:"Most Visited", lastVisited:"Last Visited", byFolder:"By Folder", nameAZ:"Name (A–Z)", filterFolder:"Filter by Folder", changeView:"Change View", appearance:"Appearance", sortDisplay:"Sort & Display", browserImport:"Browser Import", dataBackup:"Data & Backup", quickActions:"Quick Actions", statsTools:"Stats & Tools", dangerZone:"Danger Zone", about:"About", darkLight:"Dark / Light Mode", openNewTab:"Open links in new tab", accentColor:"Accent Color", manageFolders:"Manage Folders", manageTags:"Manage Tags", showFolderBadges:"Show folder badges on links", showTagBadges:"Show tag badges on links", sortNewest:"Sort by date (newest first)", pinnedTop:"Pinned bookmarks always on top", compactCards:"Compact cards", showThumbs:"Show thumbnails / favicons", showViews:"Show visit count badge", animEdit:"Animate edit mode (sparkle)", hideImported:"Hide ALL imported bookmarks", showImportedBadge:"Show \"Imported\" badge on links", importBMHtml:"Import Bookmarks (HTML)", importJSON2:"Import JSON Backup", exportJSON3:"Export JSON Backup", recentlyVisited:"Recently Visited (last 10)", findDuplicates:"Find & Remove Duplicates", archiveVisited:"Archive All Visited", clearData:"Clear All Data", deletePass:"Delete Password", deleted:"Deleted Bookmarks", saved:"Saved", favorites:"Favorites", noBookmarksFound:"No bookmarks found",
    fontFamily:"Font Family", fontSize:"Font Size", openLinkIn:"Open Link In", showFolderBadgesShort:"Show folder badges", showTagBadgesShort:"Show tag badges", sortByDateNewest:"Sort by date newest first", pinnedAlwaysTop:"Pinned always on top", showThumbnails:"Show thumbnails / favicons", showVisitCount:"Show visit count badge", animateEdit:"Animate edit mode", hideAllImported:"Hide ALL imported", showImportedBadgeShort:"Show \"Imported\" badge", browserNextImport:"Browser for next import", exportImportedOnly:"Export Imported Only", removeAllImported:"Remove All Imported", totalBookmarks:"Total Bookmarks", deletedBookmarks:"Deleted Bookmarks", deletePassword:"Delete Password", clearAllData:"Clear All Data", deletePersonal:"Delete Personal Bookmarks", contactBtn:"Contact", newTab:"New Tab", currentTab:"Current Tab", small:"Small", medium:"Medium", large:"Large", helpBtn:"Help",
    confirmLeave:"Are you sure you want to leave without saving?", confirmLeaveFolder:"Are you sure you want to leave without saving this folder?",
  },
  fr:{
    vipAdd:'Ajouter au Top10', vipRemove:'Retirer du Top10', vipAdded:'Ajouté au Top10', vipRemoved:'Retiré du Top10',
    bookmarkSaveError:"Impossible d’enregistrer les liens.",
    linkClean:"Supprimer le suivi", linkMetaLoading:"Recherche des détails…", linkOpenExisting:"Modifier le favori", linkNoTracking:"Aucun paramètre de suivi", linkTrackingRemoved:"Paramètres de suivi supprimés",
    all:'Tout', home:'Accueil', fav:'Favoris', archive:'Archive', folders:'Dossiers & Tags',
    search:'Chercher des favoris...', newBM:'Nouveau favori', save:'Sauver', cancel:'Annuler',
    settings:'Paramètres', addLink:'Ajouter', createFolder:'Créer dossier',
    editFolder:'Modifier dossier', folderName:'Nom du dossier', icon:'Icône', color:'Couleur',
    saveFolder:'Sauver dossier', unsorted:'Non trié', selectFolder:'Choisir dossier',
    manFolders:'Gérer les dossiers', tags:'Étiquettes', editTags:'Modifier étiquettes',
    tagsComma:'Étiquettes (séparées par virgule)', saveTags:'Sauver étiquettes',
    summarize:'Résumer avec IA', reminder:'Rappel', setReminder:'Définir rappel',
    link:'Lien', whatsapp:'Whatsapp', share:'Partager', archiveBtn:'Archiver', delete:'Supprimer',
    exportShare:'Exporter / Partager', exportJSON:'Export Bookmarks Backup', copyText:'Copier texte',
    exportPDF:'Exporter en PDF', exportExcel:'Exporter en Excel', contact:'Contact',
    close:'Fermer', saveChanges:'Sauvegarder', chooseIcon:'Choisir icône',
    filterByTag:'Filtrer par étiquette', noTags:'Aucune étiquette', noBookmarks:'Aucun favori',
    rewriteAI:'Réécrire avec IA', importBM:'Importer des favoris',
    importJSON:'Importer JSON', exportJSON2:'Exporter JSON',
    showFolders:'Afficher dossiers sous les liens', showTags:'Afficher étiquettes sous les liens',
    sortDate:'Trier par date (plus récent)', language:'Langue',
    goodMorning:'Bonjour', goodAfternoon:'Bon après-midi', goodEvening:'Bonsoir',
    urlLabel:'URL', titleLabel:'Titre', descLabel:'Description', tagsLabel:'Étiquettes',
    folderLabel:'Dossier', chooseFolder:'Choisir un dossier...',
    hour:'Heure', minute:'Minute', importSuccess:'Importation réussie!', bookmarksLoaded:'favoris chargés.',
    edit:"Modifier", done:"Terminé", sortBy:"Trier par", dateAdded:"Date ajoutée", mostVisited:"Plus visités", lastVisited:"Dernière visite", byFolder:"Par dossier", nameAZ:"Nom (A–Z)", filterFolder:"Filtrer par dossier", changeView:"Changer la vue", appearance:"Apparence", sortDisplay:"Tri & Affichage", browserImport:"Import navigateur", dataBackup:"Données & Sauvegarde", quickActions:"Actions rapides", statsTools:"Stats & Outils", dangerZone:"Zone dangereuse", about:"À propos", darkLight:"Mode sombre / clair", openNewTab:"Ouvrir dans un nouvel onglet", accentColor:"Couleur d'accentuation", manageFolders:"Gérer les dossiers", manageTags:"Gérer les étiquettes", showFolderBadges:"Afficher dossiers sur les liens", showTagBadges:"Afficher étiquettes sur les liens", sortNewest:"Trier par date (plus récent)", pinnedTop:"Épinglés toujours en haut", compactCards:"Cartes compactes", showThumbs:"Afficher vignettes", showViews:"Afficher le compteur de visites", animEdit:"Animer le mode édition", hideImported:"Masquer tous les imports", showImportedBadge:"Badge \"Importé\"", importBMHtml:"Importer favoris navigateur (HTML)", importJSON2:"Importer JSON", exportJSON3:"Exporter JSON", recentlyVisited:"Récemment visités (10 derniers)", findDuplicates:"Trouver les doublons", archiveVisited:"Archiver tout visité", clearData:"Effacer toutes les données", deletePass:"Mot de passe suppression", deleted:"Signets supprimés", saved:"Sauvegardés", favorites:"Favoris", noBookmarksFound:"Aucun favori trouvé",
    fontFamily:"Police", fontSize:"Taille de police", openLinkIn:"Ouvrir le lien dans", showFolderBadgesShort:"Afficher dossiers", showTagBadgesShort:"Afficher étiquettes", sortByDateNewest:"Trier par date récente", pinnedAlwaysTop:"Épinglés toujours en haut", showThumbnails:"Afficher vignettes", showVisitCount:"Compteur de visites", animateEdit:"Animer le mode édition", hideAllImported:"Masquer tous les imports", showImportedBadgeShort:"Badge \"Importé\"", browserNextImport:"Navigateur pour le prochain import", exportImportedOnly:"Exporter les importés uniquement", removeAllImported:"Supprimer tous les importés", totalBookmarks:"Total des favoris", deletedBookmarks:"Favoris supprimés", deletePassword:"Mot de passe suppression", clearAllData:"Effacer toutes les données", deletePersonal:"Supprimer mes signets", contactBtn:"Contact", newTab:"Nouvel onglet", currentTab:"Onglet actuel", small:"Petit", medium:"Moyen", large:"Grand", helpBtn:"Aide",
    confirmLeave:"Êtes-vous sûr de vouloir quitter sans sauvegarder?", confirmLeaveFolder:"Êtes-vous sûr de vouloir quitter sans sauvegarder ce dossier?",
  },
  es:{
    vipAdd:'Añadir al Top10', vipRemove:'Quitar del Top10', vipAdded:'Añadido al Top10', vipRemoved:'Quitado del Top10',
    bookmarkSaveError:"No se pudieron guardar los enlaces.",
    linkClean:"Quitar seguimiento", linkMetaLoading:"Buscando detalles…", linkOpenExisting:"Editar enlace guardado", linkNoTracking:"Sin parámetros de seguimiento", linkTrackingRemoved:"Parámetros de seguimiento eliminados",
    all:'Todo', home:'Inicio', fav:'Favoritos', archive:'Archivo', folders:'Carpetas & Tags',
    search:'Buscar marcadores...', newBM:'Nuevo marcador', save:'Guardar', cancel:'Cancelar',
    settings:'Ajustes', addLink:'Añadir', createFolder:'Crear carpeta',
    editFolder:'Editar carpeta', folderName:'Nombre de carpeta', icon:'Ícono', color:'Color',
    saveFolder:'Guardar carpeta', unsorted:'Sin clasificar', selectFolder:'Seleccionar carpeta',
    manFolders:'Gestionar carpetas', tags:'Etiquetas', editTags:'Editar etiquetas',
    tagsComma:'Etiquetas (separadas por coma)', saveTags:'Guardar etiquetas',
    summarize:'Resumir con IA', reminder:'Recordatorio', setReminder:'Establecer recordatorio',
    link:'Enlace', whatsapp:'Whatsapp', share:'Compartir', archiveBtn:'Archivar', delete:'Eliminar',
    exportShare:'Exportar / Compartir', exportJSON:'Export Bookmarks Backup', copyText:'Copiar texto',
    exportPDF:'Exportar como PDF', exportExcel:'Exportar como Excel', contact:'Contacto',
    close:'Cerrar', saveChanges:'Guardar cambios', chooseIcon:'Elegir ícono',
    filterByTag:'Filtrar por etiqueta', noTags:'Sin etiquetas', noBookmarks:'Sin marcadores',
    rewriteAI:'Reescribir con IA', importBM:'Importar marcadores',
    importJSON:'Importar JSON', exportJSON2:'Exportar JSON',
    showFolders:'Mostrar carpetas bajo enlaces', showTags:'Mostrar etiquetas bajo enlaces',
    sortDate:'Ordenar por fecha (más reciente)', language:'Idioma',
    goodMorning:'Buenos días', goodAfternoon:'Buenas tardes', goodEvening:'Buenas noches',
    urlLabel:'URL', titleLabel:'Título', descLabel:'Descripción', tagsLabel:'Etiquetas',
    folderLabel:'Carpeta', chooseFolder:'Elegir carpeta...',
    hour:'Hora', minute:'Minuto', importSuccess:'¡Importación exitosa!', bookmarksLoaded:'marcadores cargados.',
    edit:"Editar", done:"Hecho", sortBy:"Ordenar por", dateAdded:"Fecha añadida", mostVisited:"Más visitados", lastVisited:"Última visita", byFolder:"Por carpeta", nameAZ:"Nombre (A–Z)", filterFolder:"Filtrar por carpeta", changeView:"Cambiar vista", appearance:"Apariencia", sortDisplay:"Orden & Pantalla", browserImport:"Importar navegador", dataBackup:"Datos & Copia", quickActions:"Acciones rápidas", statsTools:"Stats & Herramientas", dangerZone:"Zona de peligro", about:"Acerca de", darkLight:"Modo oscuro / claro", openNewTab:"Abrir en nueva pestaña", accentColor:"Color de acento", manageFolders:"Gestionar carpetas", manageTags:"Gestionar etiquetas", showFolderBadges:"Mostrar carpetas en enlaces", showTagBadges:"Mostrar etiquetas en enlaces", sortNewest:"Ordenar por fecha (más reciente)", pinnedTop:"Fijados siempre arriba", compactCards:"Tarjetas compactas", showThumbs:"Mostrar miniaturas", showViews:"Mostrar contador de visitas", animEdit:"Animar modo edición", hideImported:"Ocultar todos los importados", showImportedBadge:"Badge \"Importado\"", importBMHtml:"Importar marcadores (HTML)", importJSON2:"Importar JSON", exportJSON3:"Exportar JSON", recentlyVisited:"Visitados recientemente (10 últimos)", findDuplicates:"Encontrar duplicados", archiveVisited:"Archivar todo visitado", clearData:"Borrar todos los datos", deletePass:"Contraseña de eliminación", deleted:"Marcadores eliminados", saved:"Guardados", favorites:"Favoritos", noBookmarksFound:"No se encontraron marcadores",
    fontFamily:"Tipografía", fontSize:"Tamaño de fuente", openLinkIn:"Abrir enlace en", showFolderBadgesShort:"Mostrar carpetas", showTagBadgesShort:"Mostrar etiquetas", sortByDateNewest:"Ordenar por fecha reciente", pinnedAlwaysTop:"Fijados siempre arriba", showThumbnails:"Mostrar miniaturas", showVisitCount:"Contador de visitas", animateEdit:"Animar modo edición", hideAllImported:"Ocultar todos importados", showImportedBadgeShort:"Badge \"Importado\"", browserNextImport:"Navegador para próxima importación", exportImportedOnly:"Exportar solo importados", removeAllImported:"Eliminar todos los importados", totalBookmarks:"Total marcadores", deletedBookmarks:"Marcadores eliminados", deletePassword:"Contraseña de eliminación", clearAllData:"Borrar todos los datos", deletePersonal:"Eliminar marcadores personales", contactBtn:"Contacto", newTab:"Nueva pestaña", currentTab:"Pestaña actual", small:"Pequeño", medium:"Mediano", large:"Grande", helpBtn:"Ayuda",
    confirmLeave:"¿Estás seguro de que quieres salir sin guardar?", confirmLeaveFolder:"¿Estás seguro de que quieres salir sin guardar esta carpeta?",
  },
  it:{
    vipAdd:'Aggiungi alla Top10', vipRemove:'Rimuovi dalla Top10', vipAdded:'Aggiunto alla Top10', vipRemoved:'Rimosso dalla Top10',
    bookmarkSaveError:"Impossibile salvare i link.",
    linkClean:"Rimuovi tracciamento", linkMetaLoading:"Ricerca dettagli…", linkOpenExisting:"Modifica salvato", linkNoTracking:"Nessun parametro di tracciamento", linkTrackingRemoved:"Parametri di tracciamento rimossi",
    all:'Tutti', home:'Home', fav:'Preferiti', archive:'Archivio', folders:'Cartelle & Tag',
    search:'Cerca segnalibri...', newBM:'Nuovo segnalibro', save:'Salva', cancel:'Annulla',
    settings:'Impostazioni', addLink:'Aggiungi', createFolder:'Crea cartella',
    editFolder:'Modifica cartella', folderName:'Nome cartella', icon:'Icona', color:'Colore',
    saveFolder:'Salva cartella', unsorted:'Non ordinato', selectFolder:'Seleziona cartella',
    manFolders:'Gestisci cartelle', tags:'Tag', editTags:'Modifica tag',
    tagsComma:'Tag (separati da virgola)', saveTags:'Salva tag',
    summarize:'Riassumi con IA', reminder:'Promemoria', setReminder:'Imposta promemoria',
    link:'Link', whatsapp:'Whatsapp', share:'Condividi', archiveBtn:'Archivia', delete:'Elimina',
    exportShare:'Esporta / Condividi', exportJSON:'Esporta Backup Segnalibri', copyText:'Copia testo',
    exportPDF:'Esporta PDF', exportExcel:'Esporta Excel', contact:'Contatto',
    close:'Chiudi', saveChanges:'Salva modifiche', chooseIcon:'Scegli icona',
    filterByTag:'Filtra per tag', noTags:'Nessun tag', noBookmarks:'Nessun segnalibro',
    rewriteAI:'Riscrivi con IA', importBM:'Importa segnalibri',
    importJSON:'Importa JSON', exportJSON2:'Esporta JSON',
    showFolders:'Mostra cartelle sotto i link', showTags:'Mostra tag sotto i link',
    sortDate:'Ordina per data (più recente)', language:'Lingua',
    goodMorning:'Buongiorno', goodAfternoon:'Buon pomeriggio', goodEvening:'Buonasera',
    urlLabel:'URL', titleLabel:'Titolo', descLabel:'Descrizione', tagsLabel:'Tag',
    folderLabel:'Cartella', chooseFolder:'Scegli cartella...',
    hour:'Ora', minute:'Minuto', importSuccess:'Importazione riuscita!', bookmarksLoaded:'segnalibri caricati.',
    edit:"Modifica", done:"Fatto", sortBy:"Ordina per", dateAdded:"Data aggiunta", mostVisited:"Più visitati", lastVisited:"Ultima visita", byFolder:"Per cartella", nameAZ:"Nome (A–Z)", filterFolder:"Filtra per cartella", changeView:"Cambia vista", appearance:"Aspetto", sortDisplay:"Ordine & Visualizzazione", browserImport:"Importa browser", dataBackup:"Dati & Backup", quickActions:"Azioni rapide", statsTools:"Stats & Strumenti", dangerZone:"Zona pericolosa", about:"Informazioni", darkLight:"Modalità scura / chiara", openNewTab:"Apri in nuova scheda", accentColor:"Colore accento", manageFolders:"Gestisci cartelle", manageTags:"Gestisci tag", showFolderBadges:"Mostra cartelle sui link", showTagBadges:"Mostra tag sui link", sortNewest:"Ordina per data (più recente)", pinnedTop:"Fissati sempre in cima", compactCards:"Schede compatte", showThumbs:"Mostra miniature", showViews:"Mostra contatore visite", animEdit:"Anima modalità modifica", hideImported:"Nascondi tutti gli importati", showImportedBadge:"Badge \"Importato\"", importBMHtml:"Importa segnalibri browser (HTML)", importJSON2:"Importa JSON", exportJSON3:"Esporta JSON", recentlyVisited:"Visitati di recente (ultimi 10)", findDuplicates:"Trova duplicati", archiveVisited:"Archivia tutti i visitati", clearData:"Cancella tutti i dati", deletePass:"Password eliminazione", deleted:"Segnalibri eliminati", saved:"Salvati", favorites:"Preferiti", noBookmarksFound:"Nessun segnalibro trovato",
    fontFamily:"Carattere", fontSize:"Dimensione carattere", openLinkIn:"Apri link in", showFolderBadgesShort:"Mostra cartelle", showTagBadgesShort:"Mostra tag", sortByDateNewest:"Ordina per data recente", pinnedAlwaysTop:"Fissati sempre in cima", showThumbnails:"Mostra miniature", showVisitCount:"Contatore visite", animateEdit:"Anima modalità modifica", hideAllImported:"Nascondi tutti importati", showImportedBadgeShort:"Badge \"Importato\"", browserNextImport:"Browser per prossima importazione", exportImportedOnly:"Esporta solo importati", removeAllImported:"Rimuovi tutti gli importati", totalBookmarks:"Totale segnalibri", deletedBookmarks:"Segnalibri eliminati", deletePassword:"Password eliminazione", clearAllData:"Cancella tutti i dati", deletePersonal:"Elimina segnalibri personali", contactBtn:"Contatto", newTab:"Nuova scheda", currentTab:"Scheda corrente", small:"Piccolo", medium:"Medio", large:"Grande", helpBtn:"Aiuto",
    confirmLeave:"Sei sicuro di voler uscire senza salvare?", confirmLeaveFolder:"Sei sicuro di voler uscire senza salvare questa cartella?",
  },
  ar:{
    vipAdd:'إضافة إلى Top10', vipRemove:'إزالة من Top10', vipAdded:'تمت الإضافة إلى Top10', vipRemoved:'تمت الإزالة من Top10',
    bookmarkSaveError:"تعذّر حفظ الروابط.",
    linkClean:"إزالة التتبع", linkMetaLoading:"جارٍ جلب تفاصيل الصفحة…", linkOpenExisting:"تعديل الرابط المحفوظ", linkNoTracking:"لا توجد معلمات تتبع", linkTrackingRemoved:"تمت إزالة معلمات التتبع",
    all:'الكل', home:'الرئيسية', fav:'المفضلة', archive:'الأرشيف', folders:'المجلدات & الوسوم',
    search:'ابحث في الإشارات...', newBM:'إشارة جديدة', save:'حفظ', cancel:'إلغاء',
    settings:'الإعدادات', addLink:'إضافة', createFolder:'إنشاء مجلد',
    editFolder:'تعديل المجلد', folderName:'اسم المجلد', icon:'أيقونة', color:'لون',
    saveFolder:'حفظ المجلد', unsorted:'غير مصنف', selectFolder:'اختر مجلداً',
    manFolders:'إدارة المجلدات', tags:'الوسوم', editTags:'تعديل الوسوم',
    tagsComma:'الوسوم (مفصولة بفاصلة)', saveTags:'حفظ الوسوم',
    summarize:'تلخيص بالذكاء الاصطناعي', reminder:'تذكير', setReminder:'تعيين تذكير',
    link:'الرابط', whatsapp:'واتساب', share:'مشاركة', archiveBtn:'أرشفة', delete:'حذف',
    exportShare:'تصدير / مشاركة', exportJSON:'تصدير النسخ الاحتياطية', copyText:'نسخ كنص',
    exportPDF:'تصدير PDF', exportExcel:'تصدير Excel', contact:'التواصل',
    close:'إغلاق', saveChanges:'حفظ التغييرات', chooseIcon:'اختر أيقونة',
    filterByTag:'تصفية بالوسم', noTags:'لا وسوم', noBookmarks:'لا إشارات مرجعية',
    rewriteAI:'إعادة كتابة بالذكاء الاصطناعي', importBM:'استيراد الإشارات المرجعية',
    importJSON:'استيراد JSON', exportJSON2:'تصدير JSON',
    showFolders:'عرض المجلدات تحت الروابط', showTags:'عرض الوسوم تحت الروابط',
    sortDate:'ترتيب بالتاريخ (الأحدث أولاً)', language:'اللغة',
    goodMorning:'صباح الخير', goodAfternoon:'مساء الخير', goodEvening:'مساء النور',
    urlLabel:'الرابط', titleLabel:'العنوان', descLabel:'الوصف', tagsLabel:'الوسوم',
    folderLabel:'المجلد', chooseFolder:'اختر مجلداً...',
    hour:'ساعة', minute:'دقيقة', importSuccess:'تم الاستيراد بنجاح!', bookmarksLoaded:'إشارة تم تحميلها.',
    edit:"تعديل", done:"تم", sortBy:"ترتيب حسب", dateAdded:"تاريخ الإضافة", mostVisited:"الأكثر زيارة", lastVisited:"آخر زيارة", byFolder:"حسب المجلد", nameAZ:"الاسم (أ-ي)", filterFolder:"تصفية حسب المجلد", changeView:"تغيير العرض", appearance:"المظهر", sortDisplay:"الترتيب والعرض", browserImport:"استيراد المتصفح", dataBackup:"البيانات والنسخ الاحتياطي", quickActions:"إجراءات سريعة", statsTools:"الإحصاءات والأدوات", dangerZone:"المنطقة الخطرة", about:"حول", darkLight:"الوضع الداكن / الفاتح", openNewTab:"فتح في تبويب جديد", accentColor:"لون التمييز", manageFolders:"إدارة المجلدات", manageTags:"إدارة الوسوم", showFolderBadges:"إظهار المجلدات على الروابط", showTagBadges:"إظهار الوسوم على الروابط", sortNewest:"الأحدث أولاً", pinnedTop:"المثبتة دائماً في الأعلى", compactCards:"بطاقات مدمجة", showThumbs:"إظهار الصور المصغرة", showViews:"إظهار عداد الزيارات", animEdit:"تحريك وضع التعديل", hideImported:"إخفاء جميع المستوردة", showImportedBadge:"شارة \"مستورد\"", importBMHtml:"استيراد الإشارات المرجعية (HTML)", importJSON2:"استيراد JSON", exportJSON3:"تصدير JSON", recentlyVisited:"زُيرت مؤخراً (آخر 10)", findDuplicates:"إيجاد المكررات", archiveVisited:"أرشفة جميع المزورة", clearData:"مسح جميع البيانات", deletePass:"كلمة مرور الحذف", deleted:"الإشارات المحذوفة", saved:"محفوظة", favorites:"المفضلة", noBookmarksFound:"لا توجد إشارات مرجعية",
    fontFamily:"الخط", fontSize:"حجم الخط", openLinkIn:"فتح الرابط في", showFolderBadgesShort:"إظهار المجلدات", showTagBadgesShort:"إظهار الوسوم", sortByDateNewest:"ترتيب بالتاريخ الأحدث", pinnedAlwaysTop:"المثبتة دائماً في الأعلى", showThumbnails:"إظهار الصور المصغرة", showVisitCount:"عداد الزيارات", animateEdit:"تحريك وضع التعديل", hideAllImported:"إخفاء جميع المستوردة", showImportedBadgeShort:"شارة \"مستورد\"", browserNextImport:"المتصفح للاستيراد التالي", exportImportedOnly:"تصدير المستوردة فقط", removeAllImported:"إزالة جميع المستوردة", totalBookmarks:"إجمالي الإشارات", deletedBookmarks:"الإشارات المحذوفة", deletePassword:"كلمة مرور الحذف", clearAllData:"مسح جميع البيانات", deletePersonal:"حذف الإشارات الشخصية", contactBtn:"تواصل", newTab:"تبويب جديد", currentTab:"التبويب الحالي", small:"صغير", medium:"متوسط", large:"كبير", helpBtn:"مساعدة",
    confirmLeave:"هل أنت متأكد أنك تريد المغادرة دون حفظ؟", confirmLeaveFolder:"هل أنت متأكد أنك تريد المغادرة دون حفظ هذا المجلد؟",
  }
};
function T(k){ return (TRANSLATIONS[S.lang]&&TRANSLATIONS[S.lang][k])||TRANSLATIONS.en[k]||k; }

function applyTranslations(){
    // Nav items
    document.querySelectorAll('[data-t]').forEach(el=>{ const k=el.getAttribute('data-t'); if(k) el.textContent=T(k); });
    // Search placeholder
    const srch=document.getElementById('search'); if(srch) srch.placeholder=T('search');
    // Add link btn
    const alb=document.querySelector('.add-link-btn span'); if(alb) { alb.textContent=T('addLink'); alb.parentElement.title=alb.textContent; }
    // Bottom nav
    const navHome=document.querySelector('#nav-home span'); if(navHome) navHome.textContent=T('home');
    const navFav=document.querySelector('#nav-fav span'); if(navFav) navFav.textContent=T('fav');
    const navArc=document.querySelector('#nav-arc span'); if(navArc) navArc.textContent=T('archive');
    // Desktop nav buttons
    const dnlHome=document.getElementById('dnl-home'); if(dnlHome) { const label=T('home'); dnlHome.querySelector('span').textContent=label; dnlHome.title=label; }
    const dnlFav=document.getElementById('dnl-fav'); if(dnlFav) { const label=T('fav'); dnlFav.querySelector('span').textContent=label; dnlFav.title=label; }
    const dnlArc=document.getElementById('dnl-arc'); if(dnlArc) { const label=T('archive'); dnlArc.querySelector('span').textContent=label; dnlArc.title=label; }
    const dnlFold=document.getElementById('dnl-fold'); if(dnlFold) { const label=T('folders'); dnlFold.querySelector('span').textContent=label; dnlFold.title=label; }
    // Direction
    document.body.setAttribute('dir', S.lang==='ar'?'rtl':'ltr');
    document.documentElement.setAttribute('lang', S.lang);
    // Share modal labels
    const _sm=document.getElementById('shareModalTitle'); if(_sm)_sm.textContent=T('exportShare');
    const _ej=document.getElementById('lbl-exportJson'); if(_ej)_ej.textContent=T('exportJSON');
    const _ct=document.getElementById('lbl-copyText'); if(_ct)_ct.textContent=T('copyText');
    const _ep=document.getElementById('lbl-exportPdf'); if(_ep)_ep.textContent=T('exportPDF');
    const _ee=document.getElementById('lbl-exportExcel'); if(_ee)_ee.textContent=T('exportExcel');
    const _cs=document.getElementById('lbl-cancelShare'); if(_cs)_cs.textContent=T('cancel');
    // Settings modal
    const _st=document.getElementById('settingsTitle'); if(_st)_st.textContent=T('settings');
    const _sf=document.getElementById('settFolders'); if(_sf)_sf.textContent=T('folders');
    const _sta=document.getElementById('settTags'); if(_sta)_sta.textContent=T('tags');
    const _ssf=document.getElementById('settShowFolders'); if(_ssf)_ssf.textContent=T('showFolders');
    const _sst=document.getElementById('settShowTags'); if(_sst)_sst.textContent=T('showTags');
    const _ssd=document.getElementById('settSortDate'); if(_ssd)_ssd.textContent=T('sortDate');
    const _si=document.getElementById('settImport'); if(_si)_si.textContent=T('importJSON');
    const _sie=document.getElementById('settImportBM'); if(_sie)_sie.textContent=T('importBM');
    const _se=document.getElementById('settExport'); if(_se)_se.textContent=T('exportJSON2');
    // Add modal
    const _amt=document.getElementById('addModalTitle'); if(_amt&&!S.editingLink)_amt.textContent=T('newBM');
    const _urlLbl=document.querySelector('#addModal label[for="lUrl"],#addModal .field:nth-child(1) label'); 
    // Settings section labels
    const _sfl=document.getElementById('settFolderTagsLabel'); if(_sfl)_sfl.textContent=T('folders').toUpperCase()+' & '+T('tags').toUpperCase();
    const _ssl=document.getElementById('settSortLabel'); if(_ssl)_ssl.textContent=(T('sortDate')||'SORT & DISPLAY').split(' ')[0].toUpperCase()+' & DISPLAY';
    const _sdl=document.getElementById('settDataLabel'); if(_sdl)_sdl.textContent='DATA';
    // Language in settings
    const _sla=document.getElementById('settLanguage'); if(_sla)_sla.textContent=T('language');
    // Import BM modal
    const _ibt=document.getElementById('importBMTitle'); if(_ibt)_ibt.textContent=T('importBM');
    const _ibb=document.getElementById('importBMBtn'); if(_ibb)_ibb.textContent=T('importBM');
    // Inline search placeholder
    const _spSearch=document.getElementById('search'); if(_spSearch) _spSearch.placeholder=T('search');
    // Translate bottom nav settings label
    const navSett=document.querySelector('#nav-settings span'); if(navSett) navSett.textContent=T('settings')||'Settings';
    // Translate inline settings section headers using data-tk attribute
    document.querySelectorAll('[data-tk]').forEach(el=>{
        const k=el.getAttribute('data-tk'); if(k) el.textContent=T(k);
    });

    // Translate "No bookmarks found" empty state
    document.querySelectorAll('[data-t="noBookmarks"]').forEach(el=>{ el.textContent=T('noBookmarks'); });
    // Translate sort dropdown options
    const _soptDate = document.getElementById('sopt-date'); if(_soptDate) { _soptDate.innerHTML=`<i class="fa-solid fa-calendar-days" style="color:#60a5fa;"></i> ${T('dateAdded')} <span class="vchk" id="schk-date" style="margin-left:auto;color:var(--primary);display:none;"><i class="fa-solid fa-check"></i></span>`; }
    const _soptVisits = document.getElementById('sopt-visits'); if(_soptVisits) { _soptVisits.innerHTML=`<i class="fa-solid fa-eye" style="color:#a78bfa;"></i> ${T('mostVisited')} <span class="vchk" id="schk-visits" style="margin-left:auto;color:var(--primary);display:none;"><i class="fa-solid fa-check"></i></span>`; }
    const _soptLast = document.getElementById('sopt-last'); if(_soptLast) { _soptLast.innerHTML=`<i class="fa-solid fa-clock-rotate-left" style="color:#22d3ee;"></i> ${T('lastVisited')} <span class="vchk" id="schk-last" style="margin-left:auto;color:var(--primary);display:none;"><i class="fa-solid fa-check"></i></span>`; }
    const _soptFolder = document.getElementById('sopt-folder'); if(_soptFolder) { _soptFolder.innerHTML=`<i class="fa-solid fa-folder" style="color:#fbbf24;"></i> ${T('byFolder')} <span class="vchk" id="schk-folder" style="margin-left:auto;color:var(--primary);display:none;"><i class="fa-solid fa-check"></i></span>`; }
    const _soptName = document.getElementById('sopt-name'); if(_soptName) { _soptName.innerHTML=`<i class="fa-solid fa-font" style="color:#4ade80;"></i> ${T('nameAZ')} <span class="vchk" id="schk-name" style="margin-left:auto;color:var(--primary);display:none;"><i class="fa-solid fa-check"></i></span>`; }
    // Re-apply sort checks after rebuild
    if(typeof updateSortChecks === 'function') setTimeout(updateSortChecks, 0);
    // Translate Add modal fields
    const addModal = document.getElementById('addModal');
    if(addModal){
        const labels = addModal.querySelectorAll('.field label');
        labels.forEach(l=>{
            const txt = l.textContent.trim().toLowerCase();
            if(txt==='url') l.textContent='URL';
            else if(txt==='title') l.textContent=T('titleLabel');
            else if(txt==='description') l.textContent=T('descLabel');
            else if(txt==='tags') l.textContent=T('tagsLabel');
            else if(txt==='folder') l.textContent=T('folderLabel');
            else if(txt==='logo / icon') l.textContent='Logo / Icon';
        });
        const selFolderName = document.getElementById('selFolderName');
        if(selFolderName && selFolderName.textContent===selFolderName.textContent) selFolderName.textContent=T('chooseFolder');
        const saveBtnAdd = addModal.querySelector('.btn-p');
        if(saveBtnAdd) saveBtnAdd.textContent=T('save')+' Bookmark';
        const cancelBtnAdd = addModal.querySelector('.btn-s');
        if(cancelBtnAdd) cancelBtnAdd.textContent=T('cancel');
    }
    // Translate Help button in About sections
    document.querySelectorAll('[data-tk="helpBtn"]').forEach(el=>el.textContent=T('helpBtn'));
    document.querySelectorAll('[data-tk="contactBtn"]').forEach(el=>el.textContent=T('contactBtn'));
    // Translate sort view dropdown labels
    const voptDD = document.getElementById('viewDD');
    if(voptDD){
        const el = voptDD.querySelector('[data-tk="changeView"]');
        // already handled by data-tk
    }
    // Translate font size options in selects
    document.querySelectorAll('#sp-fontSizeSelect option, #desk-fontSizeSelect option').forEach(opt=>{
        if(opt.value==='small') opt.textContent=T('small')||'Small';
        else if(opt.value==='medium') opt.textContent=T('medium')||'Medium';
        else if(opt.value==='large') opt.textContent=T('large')||'Large';
    });
    // Translate Open Link In select options
    document.querySelectorAll('#sp-openLinkSelect option, #desk-openLinkSelect option').forEach(opt=>{
        if(opt.value==='newtab') opt.textContent=T('newTab')||'New Tab';
        else if(opt.value==='current') opt.textContent=T('currentTab')||'Current Tab';
    });
}

function save() {
    wmStorage.setItem('ly_f', JSON.stringify(S.folders));
    wmStorage.setItem('ly_l', JSON.stringify(S.links));
    wmStorage.setItem('ly_view', S.view);
    wmStorage.setItem('ly_trash', JSON.stringify(S.trash||[]));
}

function init() { 
    const sourceFolders = new Map(S.folders.map(folder=>[folder.id,folder]));
    for (const bookmark of [...S.links, ...(S.trash || [])]) {
        if (bookmark.imported === false || bookmark.importedFrom) continue;
        const source = bookmarkBrowser(bookmark,sourceFolders);
        if (source) { bookmark.imported = true; bookmark.importedFrom = source; }
    }
    // ── REPAIR: Fix browser import folders whose names were corrupted by ID collision ──
    // Rebuild correct folder names from their metadata (_importBrowser + _importCategory)
    let dataRepaired = false;
    S.folders.forEach(f => {
        if(!f._browserImport) return;
        const expectedName = f._importCategory
            ? `${f._importCategory} (${f._importBrowser})`
            : `${f._importBrowser} Imports`;
        if(f.name !== expectedName){
            f.name = expectedName;
            dataRepaired = true;
        }
        // Ensure _folderKey is set for future collision prevention
        if(!f._folderKey){
            f._folderKey = f._importBrowser + '::' + (f._importCategory || '__fallback__');
            dataRepaired = true;
        }
    });
    // Also fix any link whose fId points to the wrong browser folder
    // (reassign to correct browser folder based on importedFrom)
    S.links.forEach(l => {
        if(!l.imported || !l.importedFrom) return;
        const currentFolder = S.folders.find(f=>f.id===l.fId);
        // If the folder belongs to a different browser, try to find the correct one
        if(currentFolder && currentFolder._browserImport && currentFolder._importBrowser !== l.importedFrom){
            // Look for a matching folder: same category, correct browser
            const correctFolder = S.folders.find(f =>
                f._browserImport &&
                f._importBrowser === l.importedFrom &&
                f._importCategory === currentFolder._importCategory
            );
            if(correctFolder){
                l.fId = correctFolder.id;
                dataRepaired = true;
            }
        }
    });
    if(dataRepaired){ wmStorage.setItem('ly_f', JSON.stringify(S.folders)); wmStorage.setItem('ly_l', JSON.stringify(S.links)); }
    setDate(); 
    renderTabs(); 
    renderLinks(); 
    applyView(); 
    updVCheck();
    applyTranslations();
    initUserChip();
    applyAccentColor();
    applyCompactCards();
    applyAnimEditMode();
    updateSortDateBtn();
    // Apply saved theme — default is LIGHT
    const savedTheme=wmStorage.getItem('ly_theme');
    const useLight = (savedTheme===null) ? true : (savedTheme==='light');
    if(useLight && !document.body.classList.contains('light-mode')){
        document.body.classList.add('light-mode');
        setTimeout(()=>{
            const inner=document.getElementById('themeInner');
            if(inner) inner.innerHTML='<i class="fa-regular fa-sun"></i>';
            const tog=document.getElementById('themeToggle');
            if(tog) tog.className='theme-toggle light-mode-btn';
        },50);
    } else if(!useLight && document.body.classList.contains('light-mode')){
        document.body.classList.remove('light-mode');
    }
    // Update search placeholder
    const srch=document.getElementById('search');
    if(srch) srch.placeholder=T('search');
    // Schedule any saved reminders
    initReminders();
    // One-time cleanup: strip tags from imported bookmarks
    _cleanImportedTags();
}

function _cleanImportedTags(){
    let changed = false;
    S.links.forEach(l => {
        if(l.imported && l.tags && l.tags.length > 0){
            l.tags = [];
            changed = true;
        }
    });
    if(changed) save();
}

function setDate() {
    const d = new Date();
    const days = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
    const months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
    const el = document.getElementById('todayDate');
    if(el) el.textContent = `${days[d.getDay()]} ${String(d.getDate()).padStart(2,'0')} ${months[d.getMonth()]} ${d.getFullYear()}`;
}

// TABS
function renderTabs() {
    updateSourceChecks();
    const fixed = document.getElementById('tabsFixed');
    const scroll = document.getElementById('tabContainer');
    const sourceFolders = new Map(S.folders.map(folder=>[folder.id,folder]));
    const visible = S.links.filter(bookmark=>!bookmark.archived &&
        sourceMatches(bookmark,S._sourceMode||'personal',sourceFolders));
    const allN = visible.length;
    const folderCounts = new Map();
    for (const bookmark of visible) folderCounts.set(bookmark.fId,(folderCounts.get(bookmark.fId)||0)+1);
    const favN = S.links.filter(l=>l.fav&&!l.archived).length;
    const arcN = S.links.filter(l=>l.archived).length;
    const editMode = S._tabEditMode || false;
    const source = sourceOptions().find(option=>option.key===S._sourceMode) || sourceOptions()[1];
    if(fixed) fixed.innerHTML = `
        <div class="chip" id="globalEditChip" data-wm-click="36" title="Edit bookmarks & folders" style="padding:7px 10px;background:${editMode?'rgba(34,197,94,.12)':'var(--card)'};border-color:${editMode?'var(--primary)':'var(--border)'};color:${editMode?'var(--primary)':'var(--text-dim)'};">
            <i class="fa-solid fa-pen" style="font-size:12px;"></i>
        </div>
        <div class="chip ${S.activeTab==='all'?'active':''}" data-wm-click="175"><span class="wm-source-all-label">${T('all')}</span><span class="wm-source-mobile-label">${esc(source.key==='all'?T('all'):source.label)}</span> <span class="chip-cnt">${allN}</span></div>`;
    let h = '';
    S.folders.forEach(f => {
        const cnt = folderCounts.get(f.id) || 0;
        if (!cnt && (f._browserImport || (S._sourceMode||'').startsWith('browser-') || S._sourceMode==='imported')) return;
        const icon = f.icon || 'fa-solid fa-folder';
        const color = f.color || '#8b5cf6';
        const isActive = S.activeTab===f.id;
        const borderStyle = 'border:2px solid '+(isActive?color:color+'66')+';';
        const bgStyle = isActive ? 'background:'+color+'22;color:'+color+';' : 'color:'+color+';';
        const cntStyle = 'background:'+color+'22;color:'+color+';font-weight:700;';
        if(editMode){
            h += '<div class="chip tced" id="tced-'+f.id+'"'
              +' draggable="true"'
              +' ondragstart="tcDragStart(event,'+f.id+')"'
              +' ondragend="tcDragEnd(event)"'
              +' ondragover="tcDragOver(event,'+f.id+')"'
              +' ondrop="tcDrop(event,'+f.id+')"'
              +' style="position:relative;overflow:visible;padding-left:6px;padding-right:22px;gap:4px;'+borderStyle+bgStyle+'">'
              +'<span ontouchstart="tcTouchStart(event,'+f.id+')" ontouchmove="tcTouchMove(event)" ontouchend="tcTouchEnd(event)"'
              +' style="display:inline-flex;align-items:center;cursor:grab;padding:2px 4px;touch-action:none;-webkit-user-select:none;">'
              +'<i class="fa-solid fa-grip-lines" style="color:#22c55e;font-size:12px;pointer-events:none;"></i></span>'
              +'<i class="'+icon+'" style="color:'+color+';font-size:12px;"></i>'
              +' '+esc(f.name)+' '
              +'<span class="chip-cnt" style="'+cntStyle+'">'+cnt+'</span>'
              +'<span data-wm-click="176" data-wm-click-0="'+f.id+'"'
              +' style="position:absolute;top:-6px;right:-6px;width:16px;height:16px;background:#ef4444;border-radius:50%;display:flex;align-items:center;justify-content:center;cursor:pointer;font-size:8px;color:#fff;font-weight:900;z-index:10;">✕</span>'
              +'</div>';
        } else {
            h += '<div class="chip '+(isActive?'active':'')+'" style="'+borderStyle+bgStyle+'" data-wm-click="177" data-wm-click-0="'+f.id+'">'
              +'<i class="'+icon+'" style="color:'+color+';font-size:12px;"></i> '+esc(f.name)
              +' <span class="chip-cnt" style="'+cntStyle+'">'+cnt+'</span></div>';
        }
    });
    if(scroll) scroll.innerHTML = h;
    updateNavCounters();
}

function updateNavCounters(){
    const favN = S.links.filter(l=>l.fav&&!l.archived).length;
    const arcN = S.links.filter(l=>l.archived).length;
    // Bottom nav badges
    const bc = (id, n) => {
        const el = document.getElementById(id);
        if(!el) return;
        if(n > 0){ el.textContent = n > 99 ? '99+' : n; el.style.display = 'block'; }
        else { el.style.display = 'none'; }
    };
    bc('nav-fav-cnt', favN);
    bc('nav-arc-cnt', arcN);
    const vipN = S.links.filter(l=>l.vip===true).length;
    bc('nav-vip-cnt', vipN);
    bc('dnl-vip-cnt', vipN);
    bc('dnl-fav-cnt', favN);
    bc('dnl-arc-cnt', arcN);
}

function switchTab(t) {
    S.activeTab=t;
    S._tabEditMode=false;
    if(t!=='__recent__'){
        S._recentIds=null;
        const hdr=document.getElementById('recentHeader');
        if(hdr) hdr.style.display='none';
    }
    // Update folder filter button active state
    const btn=document.getElementById('folderFilterBtn');
    if(btn) btn.style.borderColor=(t!=='all'&&t!=='fav'&&t!=='vip'&&t!=='archive'&&t!=='__recent__')?'var(--primary)':'var(--border)';
    const icon=document.getElementById('folderFilterIcon');
    if(icon) icon.style.color=(t!=='all'&&t!=='fav'&&t!=='vip'&&t!=='archive'&&t!=='__recent__')?'var(--primary)':'var(--text-dim)';
    renderTabs(); renderLinks();
}

function toggleGlobalEdit(){
    S._tabEditMode = !S._tabEditMode;
    S._bmEditMode = S._tabEditMode;
    const wrap = document.getElementById('linkListWrap');
    if(wrap) wrap.classList.toggle('link-list-edit-mode', S._bmEditMode);
    // Show/hide edit mode banner
    const banner = document.getElementById('editModeBanner');
    if(banner) banner.style.display = S._bmEditMode ? 'flex' : 'none';
    // Sort paused note no longer needed — edit mode respects current sort
    renderTabs();
    renderLinks(); // re-render to apply/remove sort bypass
}
function toggleTabEditMode(){
    S._tabEditMode = !S._tabEditMode;
    renderTabs();
}

// ── TAB CHIP DRAG REORDER (desktop) ──
let _tcDragSrc=null;
function tcDragStart(e,id){ _tcDragSrc=id; e.dataTransfer.effectAllowed='move'; setTimeout(()=>{ const el=document.getElementById('tced-'+id); if(el) el.style.opacity='.35'; },0); }
function tcDragEnd(){ document.querySelectorAll('.tced').forEach(c=>{c.style.opacity='';c.style.boxShadow='';}); _tcDragSrc=null; }
function tcDragOver(e,id){ e.preventDefault(); document.querySelectorAll('.tced').forEach(c=>c.style.boxShadow=''); const el=document.getElementById('tced-'+id); if(el&&id!==_tcDragSrc) el.style.boxShadow='0 0 0 2px #22c55e'; }
function tcDrop(e,tid){ e.preventDefault(); if(!_tcDragSrc||_tcDragSrc===tid) return; const si=S.folders.findIndex(f=>f.id===_tcDragSrc),ti=S.folders.findIndex(f=>f.id===tid); if(si<0||ti<0) return; const [mv]=S.folders.splice(si,1); S.folders.splice(ti,0,mv); save(); renderTabs(); _tcDragSrc=null; }

// ── TAB CHIP TOUCH REORDER (mobile) ──
let _tcTouchSrc=null, _tcClone=null, _tcOffX=0;
function tcTouchStart(e,id){
    e.stopPropagation(); _tcDragSrc=id; _tcTouchSrc=id;
    const chip=document.getElementById('tced-'+id); if(!chip) return;
    const rect=chip.getBoundingClientRect();
    _tcOffX=e.touches[0].clientX-rect.left;
    _tcClone=chip.cloneNode(true);
    _tcClone.style.cssText='position:fixed;top:'+rect.top+'px;left:'+rect.left+'px;width:'+rect.width+'px;opacity:.85;z-index:9999;pointer-events:none;border-radius:20px;box-shadow:0 4px 24px rgba(0,0,0,.5);';
    document.body.appendChild(_tcClone);
    chip.style.opacity='.3';
}
function tcTouchMove(e){
    if(!_tcClone) return; e.preventDefault();
    const tx=e.touches[0].clientX,ty=e.touches[0].clientY;
    _tcClone.style.left=(tx-_tcOffX)+'px';
    document.querySelectorAll('.tced').forEach(c=>c.style.boxShadow='');
    const el=document.elementFromPoint(tx,ty), tc=el&&el.closest('.tced');
    if(tc&&tc.id!=='tced-'+_tcTouchSrc) tc.style.boxShadow='0 0 0 2px #22c55e';
}
function tcTouchEnd(e){
    if(!_tcClone) return;
    document.body.removeChild(_tcClone); _tcClone=null;
    document.querySelectorAll('.tced').forEach(c=>{c.style.opacity='';c.style.boxShadow='';});
    const tx=e.changedTouches[0].clientX,ty=e.changedTouches[0].clientY;
    const el=document.elementFromPoint(tx,ty),tc=el&&el.closest('.tced');
    if(tc){ const tid=parseInt(tc.id.replace('tced-','')); if(tid&&tid!==_tcTouchSrc){ const si=S.folders.findIndex(f=>f.id===_tcTouchSrc),ti=S.folders.findIndex(f=>f.id===tid); if(si>=0&&ti>=0){const [mv]=S.folders.splice(si,1);S.folders.splice(ti,0,mv);save();renderTabs();}}}
    _tcDragSrc=null; _tcTouchSrc=null;
}

function quickDeleteFolderFromTab(id){
    if(!confirm('Delete folder? Bookmarks become unsorted.')) return;
    S.folders=S.folders.filter(f=>f.id!==id);
    S.links.forEach(l=>{if(l.fId===id)l.fId=null;});
    if(S.activeTab===id) S.activeTab='all';
    save(); init(); renderManageFolders && renderManageFolders();
}

function closeAllPanels(){
    // Close all dropdowns
    ['sortDD','folderFilterDD','tagDD','viewDD'].forEach(id=>{ const d=document.getElementById(id); if(d) d.classList.remove('open'); });
    // Exit edit mode
    if(S._bmEditMode){ S._bmEditMode=false; const wrap=document.getElementById('linkListWrap'); if(wrap) wrap.classList.remove('link-list-edit-mode'); const btn=document.getElementById('editModeToggle'); if(btn){btn.style.background='none';btn.style.borderColor='var(--border)';btn.style.color='var(--text-dim)';} const lbl=document.getElementById('editModeLabel'); if(lbl) lbl.textContent='Edit / Reorder'; const chk=document.getElementById('editModeCheck'); if(chk) chk.style.display='none'; const lblD=document.getElementById('editModeLabelDesktop'); if(lblD) lblD.textContent='Edit'; const btnD=document.getElementById('editModeToggleDesktop'); if(btnD){btnD.style.background='none';btnD.style.borderColor='var(--border)';btnD.style.color='var(--text-dim)';} }
}
function navTo(tab, navId) {
    closeAllPanels();
    // Close ALL inline pages
    document.querySelectorAll('.inline-page').forEach(p => p.classList.remove('active'));
    // Close ALL open modals
    document.querySelectorAll('.modal.active').forEach(m => m.classList.remove('active'));
    // Reset return flags
    if(typeof _returnToSettings !== 'undefined') _returnToSettings = false;
    if(typeof _returnToFolders !== 'undefined') _returnToFolders = false;
    document.querySelectorAll('.nitem').forEach(n=>n.classList.remove('active'));
    document.getElementById(navId).classList.add('active');
    switchTab(tab);
}

// LINKS

// ── SEARCH HANDLER ──
var _searchTimer = null;
function handleSearchInput(inp){
    var cb = document.getElementById('searchClearBtn');
    if(cb) cb.style.display = inp.value ? 'flex' : 'none';
    clearTimeout(_searchTimer);
    _searchTimer = setTimeout(function(){ renderLinks(); }, 150);
}
function clearSearchInput(){
    var inp = document.getElementById('search');
    if(inp){ inp.value = ''; inp.focus(); }
    var cb = document.getElementById('searchClearBtn');
    if(cb) cb.style.display = 'none';
    renderLinks();
}
// Legacy alias in case anything else calls _debouncedSearch
function _debouncedSearch(inp){ handleSearchInput(inp); }

function renderLinks() {
    const el = document.getElementById('linkList');
    const q  = document.getElementById('search').value.toLowerCase();
    let arr = [...S.links];
    if(S.activeTab==='fav')    arr = arr.filter(l=>l.fav&&!l.archived);
    else if(S.activeTab==='vip') arr = arr.filter(l=>l.vip===true);
    else if(S.activeTab==='archive') arr = arr.filter(l=>l.archived);
    else if(S.activeTab==='__recent__') { const ids=S._recentIds||[]; arr=ids.map(id=>S.links.find(l=>l.id===id)).filter(Boolean); }
    else if(S.folders.some(f=>String(f.id)===String(S.activeTab))) arr = arr.filter(l=>String(l.fId)===String(S.activeTab)&&!l.archived);
    else arr = arr.filter(l=>!l.archived);
    if(q) arr = arr.filter(l=>
        (l.title||'').toLowerCase().includes(q)||
        (l.desc||'').toLowerCase().includes(q)||
        (l.url||'').toLowerCase().includes(q)||
        (l.tags&&l.tags.some(t=>t.toLowerCase().includes(q)))
    );
    const sourceFolders = new Map(S.folders.map(folder=>[folder.id,folder]));
    arr = arr.filter(bookmark=>sourceMatches(bookmark,S._sourceMode||'personal',sourceFolders));
    // Sort logic:
    const _sm = S._sortMode || 'date';
    const isManual = (_sm === 'manual');
    if(!isManual) {
        if(_sm === 'date')        arr.sort((a,b)=>(WebMarkSyncCore.bookmarkDate(b)||0)-(WebMarkSyncCore.bookmarkDate(a)||0));
        else if(_sm === 'visits') arr.sort((a,b)=>(b.views||0)-(a.views||0));
        else if(_sm === 'last')   arr.sort((a,b)=>(b.lastVisited||0)-(a.lastVisited||0));
        else if(_sm === 'folder') arr.sort((a,b)=>{ const fa=S.folders.find(f=>f.id===a.fId); const fb=S.folders.find(f=>f.id===b.fId); return (fa?fa.name:'zzz').localeCompare(fb?fb.name:'zzz'); });
        else if(_sm === 'name')   arr.sort((a,b)=>(a.title||'').localeCompare(b.title||''));
        // Pinned always on top
        const pinnedTopOn = S.settings ? S.settings.pinnedTop !== false : true;
        if(pinnedTopOn) arr.sort((a,b)=>{ if(a.pinned&&!b.pinned) return -1; if(!a.pinned&&b.pinned) return 1; return 0; });
    }
    // Manual mode: use S.links order as-is (saved drag order)

    if(!arr.length) { el.innerHTML=`<div class="empty"><i class="fa-regular fa-bookmark"></i><p>${T('noBookmarks')||'No bookmarks found'}</p></div>`; return; }

    // Performance: batch DOM update
    el.innerHTML = arr.map(l => {
        // For imported bookmarks, always find the folder that matches the link's importedFrom browser
        // This prevents showing the wrong browser name if folder IDs collided
        let f = S.folders.find(x=>x.id===l.fId);
        if(l.imported && l.importedFrom && f && f._browserImport && f._importBrowser !== l.importedFrom){
            // The folder belongs to a different browser — find the correct one
            const correctF = S.folders.find(x=>
                x._browserImport &&
                x._importBrowser === l.importedFrom &&
                x._importCategory === f._importCategory
            );
            if(correctF) f = correctF;
        }
        const fColor = f ? (f.color||'#8b5cf6') : null;
        const showThumb = S.settings ? (S.settings.showThumbs !== false) : true;
        // Use logo image, or siteIcon FA icon, or default globe
        let logo;
        if(showThumb && l.logo){
            logo = `<img src="${esc(l.logo)}" data-wm-error="178">`;
        } else if(l.siteIcon) {
            logo = `<i class="${l.siteIcon.icon}" style="color:${l.siteIcon.color};font-size:26px;"></i>`;
        } else {
            // Try to auto-detect from URL
            const _si = detectSiteIcon(l.url);
            if(_si) logo = `<i class="${_si.icon}" style="color:${_si.color};font-size:26px;"></i>`;
            else logo = '<i class="fa-solid fa-globe"></i>';
        }
        return `
        <div class="link-container" id="lc-${l.id}">
            <div class="link-card" data-wm-click="179" data-wm-click-0="${l.id}">
                <div style="position:absolute;top:10px;right:10px;z-index:10;">
                    <i class="fa-solid fa-arrow-up-right-from-square" data-wm-click="180" data-wm-click-0="${jsArg(l.url)}" style="color:var(--primary);font-size:16px;cursor:pointer;padding:4px;"></i>
                </div>
                <div class="bookmark-status-actions">
                    <button type="button" class="vip-toggle" aria-pressed="${l.vip===true}" aria-label="${esc(T(l.vip===true?'vipRemove':'vipAdd'))}" title="${esc(T(l.vip===true?'vipRemove':'vipAdd'))}" data-wm-click="181" data-wm-click-0="${l.id}"><i class="${l.vip===true?'fa-solid':'fa-regular'} fa-star" aria-hidden="true"></i></button>
                    <button type="button" class="arc-icon" aria-label="${esc(l.archived?'Unarchive':T('archive'))}" title="${esc(l.archived?'Unarchive':T('archive'))}" data-wm-click="182" data-wm-click-0="${l.id}"><i class="${l.archived?'fa-solid fa-box-open':'fa-solid fa-box-archive'}" aria-hidden="true"></i></button>
                </div>
                <div class="bm-edit-overlay" style="flex-direction:row;align-items:center;padding:0 12px;justify-content:space-between;">
                    <button type="button" class="bm-edit-btn wm-manage-edit" data-wm-click="183" data-wm-click-0="${l.id}" title="Edit bookmark"><i class="fa-solid fa-pen"></i> Edit</button>
                    <div class="bm-del-btn bm-edit-btn" data-wm-click="184" data-wm-click-0="${l.id}" title="Delete" style="width:44px;height:44px;border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:18px;">
                        <i class="fa-solid fa-trash-can"></i>
                    </div>
                </div>
                <div style="display:flex;flex-direction:column;align-items:center;gap:6px;flex-shrink:0;">
                    <div class="limg">${logo}</div>
                    <div style="display:flex;gap:2px;align-items:center;">
                        <span class="card-act${l.fav?' ca-red':''}" data-wm-click="185" data-wm-click-0="${l.id}" title="Favorite"><i class="${l.fav?'fa-solid':'fa-regular'} fa-heart" style="${l.fav?'color:#ef4444;':''}"></i></span>
                        <span class="card-act${l.pinned?' ca-blue':''}" data-wm-click="186" data-wm-click-0="${l.id}" title="Pin"><i class="fa-solid fa-thumbtack"></i></span>
                        <span class="card-act" data-wm-click="187" data-wm-click-0="${jsArg(l.url)}" data-wm-click-1="${jsArg(l.title)}" title="Share" style="color:#22c55e;"><i class="fa-solid fa-arrow-up-from-bracket"></i></span>
                        <span class="card-act" data-wm-click="188" data-wm-click-0="${jsArg(l.url)}" title="Copy URL"><i class="fa-regular fa-copy"></i></span>
                    </div>
                    <div style="font-size:10px;color:var(--text-dim);text-align:center;line-height:1.3;opacity:.7;white-space:nowrap;">${_fmtDate(WebMarkSyncCore.bookmarkDate(l))}</div>
                </div>
                <div class="linfo">
                    <h4>${esc(l.title)}</h4>
                    <p>${esc(l.desc||'')}</p>
                    <div class="linfo-badges">
                    ${(f&&S.settings&&S.settings.showFolders!==false)?`<span class="badge" style="border:2px solid ${fColor};color:${fColor};font-weight:600;"><i class="${f.icon}" style="font-size:11px;color:${fColor};"></i> ${esc(f.name)}</span>`:''
                    }${(S.settings&&S.settings.showTags!==false&&l.tags&&l.tags.length)?l.tags.map(t=>`<span class="badge" style="color:var(--primary);border-color:rgba(34,197,94,.3);"><i class="fa-solid fa-hashtag" style="font-size:9px;color:var(--primary);"></i> ${esc(t)}</span>`).join(''):''
                    }${(S.settings&&S.settings.showViews&&l.views)?`<span class="badge"><i class="fa-solid fa-eye" style="font-size:9px;"></i> ${l.views}</span>`:''
                    }${browserSourceBadge(l,sourceFolders)
                    }${l.pinned?`<span class="badge" style="color:#3b82f6;border-color:rgba(59,130,246,.3);"><i class="fa-solid fa-thumbtack" style="font-size:9px;color:#3b82f6;"></i> Pinned</span>`:''
                    }
                    </div>
                </div>
            </div>
        </div>`;
    }).join('');
}

function esc(s){ return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;'); }



function toggleVDD(){ document.getElementById('viewDD')?.classList.toggle('open'); }
document.addEventListener('click',function(e){
    const vb=document.getElementById('viewBtn');
    if(vb&&!vb.contains(e.target)) document.getElementById('viewDD')?.classList.remove('open');
});
function setView(v,e){ if(e)e.stopPropagation(); S.view=v; save(); applyView(); updVCheck(); }
function applyView(){ document.getElementById('linkListWrap').className='view-'+S.view; }
function updVCheck(){
    ['list','cards','headlines','imagetitle'].forEach(v=>{
        const el=document.getElementById('vc-'+v); if(el) el.style.display=S.view===v?'inline':'none';
        // Desktop view buttons
        const btn=document.getElementById('vb-'+v);
        if(btn){
            btn.style.background=S.view===v?'var(--primary)':'transparent';
            btn.style.color=S.view===v?'#000':'var(--text-dim)';
        }
        // Mobile dropdown: tick + highlight
        const vopt=document.getElementById('vopt-'+v);
        const vcheck=document.getElementById('vcheck-'+v);
        if(vopt){
            vopt.style.background=S.view===v?'rgba(34,197,94,.12)':'';
            vopt.style.color=S.view===v?'var(--primary)':'var(--text)';
            vopt.style.fontWeight=S.view===v?'700':'500';
        }
        if(vcheck) vcheck.style.display=S.view===v?'inline':'none';
    });
    // Update mobile icon
    const iconMap = {
        'list': 'fa-list-ul',
        'cards': 'fa-border-all',
        'headlines': 'fa-align-left',
        'imagetitle': 'fa-table-cells-large'
    };
    const iconEl = document.getElementById('currentViewIcon');
    if(iconEl) iconEl.className = 'fa-solid ' + iconMap[S.view];
}

// ADD MODAL
function confirmCloseAddModal(){
    const url = document.getElementById('lUrl')?.value.trim();
    const title = document.getElementById('lTitle')?.value.trim();
    const hasInput = (url && url.length>0) || (title && title.length>0);
    if(hasInput && !confirm(T('confirmLeave')||'Leave without saving?')) return;
    closeModal('addModal');
}
function openAddModal(id=null){
    resetWebMeta();
    S.editingLink=id; S.tempLogo=null; S.selectedFolderId=null;
    // Hide generating banner
    const gb = document.getElementById('generatingBanner'); if(gb) gb.style.display='none';
    if(id){
        const l=S.links.find(x=>x.id===id);
        document.getElementById('lUrl').value=l.url;
        document.getElementById('lTitle').value=l.title;
        document.getElementById('lDesc').value=l.desc||'';
        document.getElementById('lTags').value=(l.tags||[]).join(', ');
        S.selectedFolderId=l.fId||null; S.tempLogo=l.logo||null;
        document.getElementById('logoPrev').innerHTML=l.logo?`<img src="${esc(l.logo)}">`:'<i class="fa-solid fa-globe"></i>';
        document.getElementById('addModalTitle').textContent='Edit Bookmark';
    } else {
        ['lUrl','lTitle','lDesc','lTags'].forEach(id=>document.getElementById(id).value='');
        document.getElementById('logoPrev').innerHTML='<i class="fa-solid fa-globe"></i>';
        document.getElementById('addModalTitle').textContent='New Bookmark';
        const sb=document.getElementById('autoFolderSuggest'); if(sb) sb.style.display='none';
        S._autoFolderIcon=null;
    }
    updSelFolder();
    openModal('addModal');
    hideDupWarning();
    // Scroll modal content to top
    setTimeout(()=>{ const mc=document.querySelector('#addModal .mc'); if(mc) mc.scrollTop=0; },10);
}

function updSelFolder(){
    const f=S.folders.find(x=>x.id===S.selectedFolderId);
    if(f){
        document.getElementById('selFolderIcon').innerHTML=`<i class="${f.icon}" style="color:${f.color};font-size:18px;"></i>`;
        document.getElementById('selFolderName').textContent=f.name;
        document.getElementById('selFolderName').style.color='var(--text)';
    } else {
        document.getElementById('selFolderIcon').innerHTML='<i class="fa-regular fa-folder" style="color:var(--text-dim);font-size:18px;"></i>';
        document.getElementById('selFolderName').textContent='Choose Folder...';
        document.getElementById('selFolderName').style.color='var(--text-dim)';
    }
}

function _showDupWarning(type, matchedLink){
    const w   = document.getElementById('dupWarning');
    const inn = document.getElementById('dupWarningInner');
    const ico = document.getElementById('dupWarningIcon');
    const ttl = document.getElementById('dupWarningTitle');
    const msg = document.getElementById('dupWarningMsg');
    const cnt = document.getElementById('dupWarningContinue');
    if(!w) return;

    if(type === 'exact'){
        inn.style.background  = 'rgba(239,68,68,.12)';
        inn.style.border      = '1px solid rgba(239,68,68,.35)';
        ico.style.color       = '#ef4444';
        ttl.style.color       = '#fca5a5';
        msg.style.color       = '#fca5a5';
        cnt.style.background  = '#ef4444';
        cnt.style.color       = '#fff';
        ttl.textContent       = 'Duplicate Bookmark';
        const lbl = matchedLink.title || matchedLink.url;
        msg.textContent       = `"${lbl}" is already saved with this exact URL. Save another copy?`;
    } else {
        const domain = _getDomain(matchedLink.url);
        inn.style.background  = 'rgba(234,179,8,.10)';
        inn.style.border      = '1px solid rgba(234,179,8,.35)';
        ico.style.color       = '#eab308';
        ttl.style.color       = '#fde047';
        msg.style.color       = '#fde047';
        cnt.style.background  = '#eab308';
        cnt.style.color       = '#000';
        ttl.textContent       = 'Same Domain Already Bookmarked';
        const lbl = matchedLink.title || matchedLink.url;
        msg.textContent       = `You already have "${lbl}" saved from ${domain}. Save this one too?`;
    }
    const openExisting = document.getElementById('dupWarningOpen');
    openExisting.onclick = () => openAddModal(matchedLink.id);
    w.style.display = 'block';
    // Scroll the modal to show the warning
    setTimeout(()=>{
        const mc = document.querySelector('#addModal .mc');
        if(mc) mc.scrollTop = mc.scrollHeight;
    }, 30);
}

function hideDupWarning(){
    const w=document.getElementById('dupWarning');
    if(w) w.style.display='none';
}

function _getDomain(url){
    try{ return new URL(url).hostname.replace(/^www\./,''); }catch(e){ return null; }
}

function saveLink(force=false){
    const url=wmURL(document.getElementById('lUrl').value);
    if(!url){alert(S.lang==='ar'?'أدخل رابط HTTP أو HTTPS صالحاً':'Enter a valid HTTP or HTTPS URL');return;}
    document.getElementById('lUrl').value=url;

    // Only an identical URL is a duplicate. Different pages on one site save normally.
    if (!S.editingLink && !force) {
        const sourceFolders = new Map(S.folders.map(folder=>[folder.id,folder]));
        const exactMatch = S.links.find(link => wmURL(link.url)===url && !bookmarkBrowser(link,sourceFolders));
        if (exactMatch) {
            _showDupWarning('exact', exactMatch);
            return;
        }
    }
    hideDupWarning();
    const existing = S.editingLink ? S.links.find(link=>link.id===S.editingLink) : null;
    if (S.editingLink && !existing) return;
    const details = (!existing || wmURL(existing.url) !== url || wmDetails?.url === url)
        ? fetchWebMeta() : null;
    const fallback = fallbackWebMeta(url);
    const d={
        ...(existing||{imported:false}),
        id:S.editingLink||wmId(), url,
        title:document.getElementById('lTitle').value||fallback.title,
        desc:document.getElementById('lDesc').value,
        tags:document.getElementById('lTags').value.split(',').map(t=>t.trim()).filter(t=>t),
        logo:S.tempLogo, fId:S.selectedFolderId,
        fav:existing?.fav||false, archived:existing?.archived||false, views:existing?.views||0,
        siteIcon: _buildSiteIconForLink(url, document.getElementById('lTitle').value||fallback.title)
    };
    const previousLinks = S.links;
    S.links = existing ? S.links.map(link => link === existing ? d : link) : [...S.links, d];
    try { save(); }
    catch {
        S.links = previousLinks;
        showToast(T('bookmarkSaveError'), '#ef4444');
        return;
    }
    if (details) {
        details.saved = {
            bookmark:d,
            values:{title:d.title, desc:d.desc, logo:d.logo,tags:d.tags},
            auto:{
                title:d.title === details.generated.title,
                desc:!d.desc||d.desc === details.generated.desc,
                logo:(!d.logo||d.logo===details.generatedLogo)&&details.logoRevision===wmLogoRevision,
                tags:!d.tags.length||d.tags.join(', ')===details.generated.tags
            }
        };
    }
    init();
    closeModal('addModal');
}


// ── AUTO FOLDER ICON: detect website type from URL and suggest folder icon ──
const SITE_ICON_MAP = [
    // ── VIDEO / STREAMING ──
    { match:['youtube.com','youtu.be'], icon:'fa-brands fa-youtube', color:'#ef4444', tags:['video','youtube','streaming'], category:'Entertainment' },
    { match:['netflix.com'], icon:'fa-solid fa-film', color:'#ef4444', tags:['video','streaming','movies'], category:'Entertainment' },
    { match:['twitch.tv'], icon:'fa-brands fa-twitch', color:'#9146ff', tags:['gaming','streaming','live'], category:'Entertainment' },
    { match:['vimeo.com'], icon:'fa-brands fa-vimeo', color:'#1ab7ea', tags:['video','creative'], category:'Entertainment' },
    { match:['dailymotion.com'], icon:'fa-solid fa-play', color:'#0000ff', tags:['video'], category:'Entertainment' },
    { match:['disneyplus.com','disney+'], icon:'fa-solid fa-star', color:'#1a6fff', tags:['streaming','disney'], category:'Entertainment' },
    { match:['primevideo','amazon.com/video'], icon:'fa-brands fa-amazon', color:'#ff9900', tags:['streaming','amazon'], category:'Entertainment' },
    { match:['hbomax.com','max.com'], icon:'fa-solid fa-tv', color:'#a100d8', tags:['streaming','hbo'], category:'Entertainment' },
    { match:['hulu.com'], icon:'fa-solid fa-play-circle', color:'#1ce783', tags:['streaming','hulu'], category:'Entertainment' },
    { match:['peacocktv.com'], icon:'fa-solid fa-tv', color:'#0072ce', tags:['streaming'], category:'Entertainment' },
    { match:['paramountplus.com'], icon:'fa-solid fa-mountain', color:'#0064ff', tags:['streaming'], category:'Entertainment' },
    { match:['appletv.apple.com','tv.apple.com'], icon:'fa-brands fa-apple', color:'#555555', tags:['streaming','apple'], category:'Entertainment' },
    { match:['crunchyroll.com'], icon:'fa-solid fa-dragon', color:'#f47521', tags:['anime','streaming'], category:'Entertainment' },
    { match:['funimation.com'], icon:'fa-solid fa-film', color:'#5b0bb5', tags:['anime'], category:'Entertainment' },
    { match:['stremio.com'], icon:'fa-solid fa-film', color:'#8c4be8', tags:['streaming'], category:'Entertainment' },
    { match:['plex.tv'], icon:'fa-solid fa-play', color:'#e5a00d', tags:['media','streaming'], category:'Entertainment' },
    { match:['kodi.tv'], icon:'fa-solid fa-tv', color:'#17b2e7', tags:['media'], category:'Entertainment' },
    { match:['jellyfin.org'], icon:'fa-solid fa-server', color:'#00a4dc', tags:['media'], category:'Entertainment' },
    // ── SOCIAL MEDIA ──
    { match:['facebook.com','fb.com'], icon:'fa-brands fa-facebook', color:'#1877f2', tags:['social','facebook'], category:'Social' },
    { match:['instagram.com'], icon:'fa-brands fa-instagram', color:'#e1306c', tags:['social','instagram','photos'], category:'Social' },
    { match:['twitter.com','x.com'], icon:'fa-brands fa-x-twitter', color:'#000000', tags:['social','twitter'], category:'Social' },
    { match:['tiktok.com'], icon:'fa-brands fa-tiktok', color:'#010101', tags:['social','video','tiktok'], category:'Social' },
    { match:['linkedin.com'], icon:'fa-brands fa-linkedin', color:'#0077b5', tags:['work','professional','linkedin'], category:'Social' },
    { match:['reddit.com'], icon:'fa-brands fa-reddit', color:'#ff4500', tags:['social','community','reddit'], category:'Social' },
    { match:['snapchat.com'], icon:'fa-brands fa-snapchat', color:'#fffc00', tags:['social','snapchat'], category:'Social' },
    { match:['pinterest.com'], icon:'fa-brands fa-pinterest', color:'#e60023', tags:['social','photos','ideas'], category:'Social' },
    { match:['telegram.org','t.me'], icon:'fa-brands fa-telegram', color:'#2ca5e0', tags:['messaging','telegram'], category:'Social' },
    { match:['whatsapp.com'], icon:'fa-brands fa-whatsapp', color:'#25d366', tags:['messaging','whatsapp'], category:'Social' },
    { match:['discord.com'], icon:'fa-brands fa-discord', color:'#5865f2', tags:['social','gaming','discord'], category:'Social' },
    { match:['mastodon.social','mastodon.'], icon:'fa-brands fa-mastodon', color:'#6364ff', tags:['social'], category:'Social' },
    { match:['tumblr.com'], icon:'fa-brands fa-tumblr', color:'#35465d', tags:['social','blog'], category:'Social' },
    { match:['deviantart.com'], icon:'fa-brands fa-deviantart', color:'#05cc47', tags:['art','community'], category:'Creative' },
    { match:['behance.net'], icon:'fa-brands fa-behance', color:'#1769ff', tags:['design','portfolio'], category:'Creative' },
    { match:['dribbble.com'], icon:'fa-brands fa-dribbble', color:'#ea4c89', tags:['design','portfolio'], category:'Creative' },
    { match:['flickr.com'], icon:'fa-brands fa-flickr', color:'#ff0084', tags:['photos'], category:'Creative' },
    { match:['500px.com'], icon:'fa-solid fa-camera', color:'#0099e5', tags:['photos'], category:'Creative' },
    { match:['vk.com'], icon:'fa-brands fa-vk', color:'#4a76a8', tags:['social'], category:'Social' },
    { match:['weibo.com'], icon:'fa-brands fa-weibo', color:'#df2029', tags:['social'], category:'Social' },
    // ── MUSIC ──
    { match:['spotify.com'], icon:'fa-brands fa-spotify', color:'#1db954', tags:['music','spotify'], category:'Music' },
    { match:['soundcloud.com'], icon:'fa-brands fa-soundcloud', color:'#ff5500', tags:['music','soundcloud'], category:'Music' },
    { match:['music.apple.com','itunes'], icon:'fa-brands fa-apple', color:'#fc3c44', tags:['music','apple'], category:'Music' },
    { match:['deezer.com'], icon:'fa-brands fa-deezer', color:'#ef5466', tags:['music'], category:'Music' },
    { match:['tidal.com'], icon:'fa-solid fa-water', color:'#000000', tags:['music'], category:'Music' },
    { match:['bandcamp.com'], icon:'fa-brands fa-bandcamp', color:'#1da0c3', tags:['music','indie'], category:'Music' },
    { match:['last.fm'], icon:'fa-brands fa-lastfm', color:'#d51007', tags:['music'], category:'Music' },
    { match:['music.youtube.com'], icon:'fa-brands fa-youtube', color:'#ef4444', tags:['music','youtube'], category:'Music' },
    { match:['mixcloud.com'], icon:'fa-brands fa-mixcloud', color:'#5000ff', tags:['music','dj'], category:'Music' },
    // ── TECH / DEV ──
    { match:['github.com'], icon:'fa-brands fa-github', color:'#333333', tags:['dev','code','github'], category:'Tech' },
    { match:['gitlab.com'], icon:'fa-brands fa-gitlab', color:'#fc6d26', tags:['dev','code'], category:'Tech' },
    { match:['stackoverflow.com'], icon:'fa-brands fa-stack-overflow', color:'#f48024', tags:['dev','qa'], category:'Tech' },
    { match:['codepen.io'], icon:'fa-brands fa-codepen', color:'#000000', tags:['dev','design'], category:'Tech' },
    { match:['codesandbox.io'], icon:'fa-solid fa-cube', color:'#151515', tags:['dev'], category:'Tech' },
    { match:['npmjs.com'], icon:'fa-brands fa-npm', color:'#cb3837', tags:['dev','javascript'], category:'Tech' },
    { match:['developer.mozilla.org','mdn.'], icon:'fa-solid fa-code', color:'#8b5cf6', tags:['dev','docs'], category:'Tech' },
    { match:['cloud.google.com'], icon:'fa-brands fa-google', color:'#4285f4', tags:['cloud','google'], category:'Tech' },
    { match:['aws.amazon.com'], icon:'fa-brands fa-aws', color:'#ff9900', tags:['cloud','aws'], category:'Tech' },
    { match:['azure.microsoft.com'], icon:'fa-brands fa-microsoft', color:'#0078d4', tags:['cloud','microsoft'], category:'Tech' },
    { match:['digitalocean.com'], icon:'fa-brands fa-digital-ocean', color:'#0080ff', tags:['cloud','hosting'], category:'Tech' },
    { match:['vercel.com'], icon:'fa-solid fa-triangle-exclamation', color:'#000000', tags:['dev','deploy'], category:'Tech' },
    { match:['netlify.com'], icon:'fa-solid fa-bolt', color:'#00c7b7', tags:['dev','deploy'], category:'Tech' },
    { match:['heroku.com'], icon:'fa-brands fa-heroku', color:'#430098', tags:['dev','cloud'], category:'Tech' },
    { match:['docker.com','hub.docker.com'], icon:'fa-brands fa-docker', color:'#2496ed', tags:['dev','containers'], category:'Tech' },
    { match:['kubernetes.io'], icon:'fa-solid fa-dharmachakra', color:'#326ce5', tags:['dev'], category:'Tech' },
    { match:['jsfiddle.net'], icon:'fa-brands fa-jsfiddle', color:'#0084ff', tags:['dev'], category:'Tech' },
    { match:['replit.com'], icon:'fa-solid fa-code', color:'#f26207', tags:['dev'], category:'Tech' },
    { match:['leetcode.com'], icon:'fa-solid fa-code', color:'#ffa116', tags:['dev','interview'], category:'Tech' },
    { match:['hackerrank.com'], icon:'fa-brands fa-hackerrank', color:'#2ec866', tags:['dev'], category:'Tech' },
    { match:['bitbucket.org'], icon:'fa-brands fa-bitbucket', color:'#0052cc', tags:['dev','code'], category:'Tech' },
    { match:['figma.com'], icon:'fa-brands fa-figma', color:'#f24e1e', tags:['design','ui'], category:'Creative' },
    { match:['sketch.com'], icon:'fa-solid fa-pen-nib', color:'#f7b500', tags:['design'], category:'Creative' },
    { match:['invisionapp.com'], icon:'fa-solid fa-pen-ruler', color:'#ff3366', tags:['design','prototype'], category:'Creative' },
    { match:['canva.com'], icon:'fa-solid fa-palette', color:'#00c4cc', tags:['design','creative'], category:'Creative' },
    { match:['adobe.com','creative.adobe.com'], icon:'fa-brands fa-adobe', color:'#ff0000', tags:['design','creative','adobe'], category:'Creative' },
    // ── AI ──
    { match:['openai.com','chatgpt.com','chat.openai.com'], icon:'fa-solid fa-robot', color:'#10a37f', tags:['ai','chatgpt'], category:'AI' },
    { match:['claude.ai','anthropic.com'], icon:'fa-solid fa-brain', color:'#d97706', tags:['ai','claude'], category:'AI' },
    { match:['gemini.google.com','bard.google.com'], icon:'fa-brands fa-google', color:'#4285f4', tags:['ai','google'], category:'AI' },
    { match:['midjourney.com'], icon:'fa-solid fa-image', color:'#8b5cf6', tags:['ai','images'], category:'AI' },
    { match:['huggingface.co'], icon:'fa-solid fa-microchip', color:'#ff9a00', tags:['ai','ml'], category:'AI' },
    { match:['stability.ai','stablediffusion'], icon:'fa-solid fa-wand-magic-sparkles', color:'#f5a623', tags:['ai','images'], category:'AI' },
    { match:['perplexity.ai'], icon:'fa-solid fa-magnifying-glass-chart', color:'#20b2aa', tags:['ai','search'], category:'AI' },
    { match:['copilot.microsoft.com'], icon:'fa-brands fa-microsoft', color:'#0078d4', tags:['ai','microsoft'], category:'AI' },
    { match:['ollama.com'], icon:'fa-solid fa-robot', color:'#444444', tags:['ai','local'], category:'AI' },
    { match:['groq.com'], icon:'fa-solid fa-microchip', color:'#f55036', tags:['ai'], category:'AI' },
    // ── SHOPPING ──
    { match:['amazon.com','amazon.'], icon:'fa-brands fa-amazon', color:'#ff9900', tags:['shopping','amazon'], category:'Shopping' },
    { match:['ebay.com'], icon:'fa-brands fa-ebay', color:'#e53238', tags:['shopping','ebay'], category:'Shopping' },
    { match:['shopify.com'], icon:'fa-brands fa-shopify', color:'#96bf48', tags:['shopping','ecommerce'], category:'Shopping' },
    { match:['etsy.com'], icon:'fa-solid fa-bag-shopping', color:'#f56400', tags:['shopping','handmade'], category:'Shopping' },
    { match:['aliexpress.com'], icon:'fa-solid fa-bag-shopping', color:'#ff6a00', tags:['shopping'], category:'Shopping' },
    { match:['alibaba.com'], icon:'fa-solid fa-store', color:'#ff6a00', tags:['shopping','wholesale'], category:'Shopping' },
    { match:['walmart.com'], icon:'fa-solid fa-store', color:'#0071ce', tags:['shopping'], category:'Shopping' },
    { match:['target.com'], icon:'fa-solid fa-bullseye', color:'#cc0000', tags:['shopping'], category:'Shopping' },
    { match:['bestbuy.com'], icon:'fa-solid fa-computer', color:'#003087', tags:['shopping','tech'], category:'Shopping' },
    { match:['newegg.com'], icon:'fa-solid fa-computer', color:'#e57518', tags:['shopping','tech'], category:'Shopping' },
    { match:['wish.com'], icon:'fa-solid fa-gift', color:'#2fb7ec', tags:['shopping'], category:'Shopping' },
    { match:['shein.com'], icon:'fa-solid fa-shirt', color:'#000000', tags:['shopping','fashion'], category:'Shopping' },
    { match:['zalando.'], icon:'fa-solid fa-shoe-prints', color:'#ff6900', tags:['shopping','fashion'], category:'Shopping' },
    { match:['booking.com'], icon:'fa-solid fa-hotel', color:'#003580', tags:['travel','hotel'], category:'Travel' },
    { match:['airbnb.com'], icon:'fa-brands fa-airbnb', color:'#ff5a5f', tags:['travel','accommodation'], category:'Travel' },
    { match:['tripadvisor.com'], icon:'fa-solid fa-plane', color:'#34e0a1', tags:['travel'], category:'Travel' },
    { match:['expedia.com'], icon:'fa-solid fa-plane', color:'#00355f', tags:['travel'], category:'Travel' },
    { match:['kayak.com'], icon:'fa-solid fa-plane', color:'#ff690f', tags:['travel'], category:'Travel' },
    { match:['skyscanner.com'], icon:'fa-solid fa-plane', color:'#0770e3', tags:['travel','flights'], category:'Travel' },
    // ── NEWS ──
    { match:['bbc.com','bbc.co.uk'], icon:'fa-solid fa-newspaper', color:'#bb1919', tags:['news','bbc'], category:'News' },
    { match:['cnn.com'], icon:'fa-solid fa-newspaper', color:'#cc0000', tags:['news','cnn'], category:'News' },
    { match:['nytimes.com'], icon:'fa-solid fa-newspaper', color:'#000000', tags:['news','nyt'], category:'News' },
    { match:['theguardian.com'], icon:'fa-solid fa-newspaper', color:'#052962', tags:['news'], category:'News' },
    { match:['reuters.com'], icon:'fa-solid fa-newspaper', color:'#ff8000', tags:['news'], category:'News' },
    { match:['apnews.com'], icon:'fa-solid fa-newspaper', color:'#cc0000', tags:['news'], category:'News' },
    { match:['bloomberg.com'], icon:'fa-solid fa-chart-line', color:'#000000', tags:['news','finance'], category:'News' },
    { match:['forbes.com'], icon:'fa-solid fa-chart-bar', color:'#000000', tags:['news','business'], category:'News' },
    { match:['techcrunch.com'], icon:'fa-solid fa-rocket', color:'#0a1045', tags:['news','tech'], category:'News' },
    { match:['theverge.com'], icon:'fa-solid fa-bolt', color:'#ff3a3a', tags:['news','tech'], category:'News' },
    { match:['wired.com'], icon:'fa-solid fa-bolt', color:'#000000', tags:['news','tech'], category:'News' },
    { match:['arstechnica.com'], icon:'fa-solid fa-microchip', color:'#ff6600', tags:['news','tech'], category:'News' },
    { match:['hackernews','news.ycombinator.com'], icon:'fa-brands fa-y-combinator', color:'#ff6600', tags:['news','tech','dev'], category:'News' },
    { match:['producthunt.com'], icon:'fa-solid fa-cat', color:'#da552f', tags:['products','tech'], category:'Tech' },
    // ── PRODUCTIVITY ──
    { match:['notion.so','notion.com'], icon:'fa-solid fa-book-open', color:'#000000', tags:['productivity','notes'], category:'Productivity' },
    { match:['docs.google.com','drive.google.com'], icon:'fa-brands fa-google-drive', color:'#4285f4', tags:['productivity','google'], category:'Productivity' },
    { match:['sheets.google.com'], icon:'fa-solid fa-table', color:'#0f9d58', tags:['productivity','spreadsheet'], category:'Productivity' },
    { match:['slides.google.com'], icon:'fa-solid fa-display', color:'#f4b400', tags:['productivity','presentation'], category:'Productivity' },
    { match:['trello.com'], icon:'fa-brands fa-trello', color:'#0079bf', tags:['productivity','kanban'], category:'Productivity' },
    { match:['asana.com'], icon:'fa-solid fa-list-check', color:'#f06a6a', tags:['productivity','tasks'], category:'Productivity' },
    { match:['slack.com'], icon:'fa-brands fa-slack', color:'#4a154b', tags:['work','messaging'], category:'Work' },
    { match:['zoom.us','zoom.com'], icon:'fa-solid fa-video', color:'#2d8cff', tags:['work','meetings'], category:'Work' },
    { match:['teams.microsoft.com','teams.live.com'], icon:'fa-brands fa-microsoft', color:'#6264a7', tags:['work','meetings'], category:'Work' },
    { match:['meet.google.com'], icon:'fa-brands fa-google', color:'#00832d', tags:['work','meetings'], category:'Work' },
    { match:['monday.com'], icon:'fa-solid fa-calendar-check', color:'#f62b54', tags:['productivity','work'], category:'Productivity' },
    { match:['clickup.com'], icon:'fa-solid fa-list-check', color:'#7b68ee', tags:['productivity'], category:'Productivity' },
    { match:['jira.atlassian','atlassian.com'], icon:'fa-brands fa-atlassian', color:'#0052cc', tags:['dev','project'], category:'Tech' },
    { match:['confluence.atlassian'], icon:'fa-solid fa-book', color:'#0052cc', tags:['docs','wiki'], category:'Productivity' },
    { match:['airtable.com'], icon:'fa-solid fa-table-cells', color:'#18bfff', tags:['productivity','database'], category:'Productivity' },
    { match:['obsidian.md'], icon:'fa-solid fa-gem', color:'#7c3aed', tags:['notes','productivity'], category:'Productivity' },
    { match:['roamresearch.com'], icon:'fa-solid fa-brain', color:'#000000', tags:['notes'], category:'Productivity' },
    { match:['evernote.com'], icon:'fa-brands fa-evernote', color:'#51b749', tags:['notes'], category:'Productivity' },
    { match:['todoist.com'], icon:'fa-solid fa-list-check', color:'#db4035', tags:['productivity','tasks'], category:'Productivity' },
    { match:['linear.app'], icon:'fa-solid fa-bolt', color:'#5e6ad2', tags:['dev','project'], category:'Tech' },
    // ── LEARNING ──
    { match:['coursera.org'], icon:'fa-solid fa-graduation-cap', color:'#0056d2', tags:['learning','courses'], category:'Learning' },
    { match:['udemy.com'], icon:'fa-solid fa-graduation-cap', color:'#a435f0', tags:['learning','courses'], category:'Learning' },
    { match:['khanacademy.org'], icon:'fa-solid fa-graduation-cap', color:'#14bf96', tags:['learning','free'], category:'Learning' },
    { match:['wikipedia.org'], icon:'fa-brands fa-wikipedia-w', color:'#000000', tags:['reference','wiki'], category:'Reference' },
    { match:['medium.com'], icon:'fa-brands fa-medium', color:'#000000', tags:['blog','articles'], category:'Reading' },
    { match:['substack.com'], icon:'fa-solid fa-envelope-open-text', color:'#ff6719', tags:['newsletter','reading'], category:'Reading' },
    { match:['skillshare.com'], icon:'fa-solid fa-palette', color:'#00c4cc', tags:['learning'], category:'Learning' },
    { match:['lynda.com','linkedin.com/learning'], icon:'fa-brands fa-linkedin', color:'#0077b5', tags:['learning'], category:'Learning' },
    { match:['edx.org'], icon:'fa-solid fa-graduation-cap', color:'#02262b', tags:['learning'], category:'Learning' },
    { match:['pluralsight.com'], icon:'fa-solid fa-graduation-cap', color:'#f15b2a', tags:['learning','tech'], category:'Learning' },
    { match:['codecademy.com'], icon:'fa-solid fa-code', color:'#1f4056', tags:['learning','coding'], category:'Learning' },
    { match:['freecodecamp.org'], icon:'fa-solid fa-campground', color:'#0a0a23', tags:['learning','coding'], category:'Learning' },
    { match:['w3schools.com'], icon:'fa-solid fa-code', color:'#04aa6d', tags:['learning','dev'], category:'Learning' },
    { match:['docs.'], icon:'fa-solid fa-book', color:'#8b5cf6', tags:['docs','reference'], category:'Reference' },
    // ── FINANCE ──
    { match:['paypal.com'], icon:'fa-brands fa-paypal', color:'#003087', tags:['finance','payments'], category:'Finance' },
    { match:['stripe.com'], icon:'fa-brands fa-stripe', color:'#635bff', tags:['finance','payments'], category:'Finance' },
    { match:['coinbase.com'], icon:'fa-solid fa-bitcoin-sign', color:'#0052ff', tags:['crypto','finance'], category:'Finance' },
    { match:['binance.com'], icon:'fa-solid fa-bitcoin-sign', color:'#f0b90b', tags:['crypto','trading'], category:'Finance' },
    { match:['kraken.com'], icon:'fa-solid fa-coins', color:'#5741d9', tags:['crypto'], category:'Finance' },
    { match:['crypto.com'], icon:'fa-solid fa-bitcoin-sign', color:'#003399', tags:['crypto'], category:'Finance' },
    { match:['robinhood.com'], icon:'fa-solid fa-chart-line', color:'#00c805', tags:['stocks','investing'], category:'Finance' },
    { match:['etrade.com','e*trade'], icon:'fa-solid fa-chart-bar', color:'#6633cc', tags:['stocks','investing'], category:'Finance' },
    { match:['fidelity.com'], icon:'fa-solid fa-piggy-bank', color:'#367926', tags:['finance','investing'], category:'Finance' },
    { match:['mint.com'], icon:'fa-solid fa-leaf', color:'#5ab741', tags:['finance','budget'], category:'Finance' },
    { match:['wise.com'], icon:'fa-solid fa-money-bill-transfer', color:'#9fe870', tags:['finance','transfer'], category:'Finance' },
    { match:['revolut.com'], icon:'fa-solid fa-credit-card', color:'#191c1f', tags:['finance','banking'], category:'Finance' },
    // ── MAPS / TRAVEL ──
    { match:['maps.google.com','google.com/maps'], icon:'fa-solid fa-map-location-dot', color:'#4285f4', tags:['maps','navigation'], category:'Travel' },
    { match:['openstreetmap.org'], icon:'fa-solid fa-map', color:'#7ebc6f', tags:['maps'], category:'Travel' },
    { match:['waze.com'], icon:'fa-solid fa-car', color:'#65cde4', tags:['navigation'], category:'Travel' },
    { match:['uber.com'], icon:'fa-solid fa-car-side', color:'#000000', tags:['transport'], category:'Travel' },
    { match:['lyft.com'], icon:'fa-solid fa-car-side', color:'#ff00bf', tags:['transport'], category:'Travel' },
    { match:['transit.app'], icon:'fa-solid fa-bus', color:'#8b5cf6', tags:['transport','transit'], category:'Travel' },
    // ── GAMING ──
    { match:['steam','store.steampowered.com'], icon:'fa-brands fa-steam', color:'#00adee', tags:['gaming','steam'], category:'Gaming' },
    { match:['epicgames.com'], icon:'fa-solid fa-gamepad', color:'#313131', tags:['gaming'], category:'Gaming' },
    { match:['itch.io'], icon:'fa-solid fa-gamepad', color:'#fa5c5c', tags:['gaming','indie'], category:'Gaming' },
    { match:['gog.com'], icon:'fa-solid fa-compact-disc', color:'#86328a', tags:['gaming'], category:'Gaming' },
    { match:['xbox.com'], icon:'fa-brands fa-xbox', color:'#107c10', tags:['gaming'], category:'Gaming' },
    { match:['playstation.com','ps4','ps5'], icon:'fa-brands fa-playstation', color:'#003791', tags:['gaming'], category:'Gaming' },
    { match:['nintendo.com'], icon:'fa-solid fa-gamepad', color:'#e60012', tags:['gaming'], category:'Gaming' },
    { match:['twitch.tv'], icon:'fa-brands fa-twitch', color:'#9146ff', tags:['gaming','streaming'], category:'Gaming' },
    { match:['ign.com'], icon:'fa-solid fa-gamepad', color:'#e8001c', tags:['gaming','news'], category:'Gaming' },
    { match:['polygon.com'], icon:'fa-solid fa-gamepad', color:'#1b6bf5', tags:['gaming','news'], category:'Gaming' },
    // ── FOOD & RECIPE ──
    { match:['allrecipes.com'], icon:'fa-solid fa-utensils', color:'#d04a02', tags:['food','recipes'], category:'Food' },
    { match:['food52.com'], icon:'fa-solid fa-bowl-food', color:'#ef4836', tags:['food','recipes'], category:'Food' },
    { match:['seriouseats.com'], icon:'fa-solid fa-utensils', color:'#ff6a00', tags:['food'], category:'Food' },
    { match:['bonappetit.com'], icon:'fa-solid fa-wine-bottle', color:'#ef4444', tags:['food'], category:'Food' },
    { match:['yummly.com'], icon:'fa-solid fa-bowl-rice', color:'#e7523c', tags:['food','recipes'], category:'Food' },
    { match:['tasty.co'], icon:'fa-solid fa-burger', color:'#ff4081', tags:['food','video'], category:'Food' },
    { match:['yelp.com'], icon:'fa-brands fa-yelp', color:'#d32323', tags:['food','local','reviews'], category:'Food' },
    { match:['grubhub.com'], icon:'fa-solid fa-burger', color:'#f63440', tags:['food','delivery'], category:'Food' },
    { match:['doordash.com'], icon:'fa-solid fa-truck-fast', color:'#ef3c2d', tags:['food','delivery'], category:'Food' },
    { match:['ubereats.com'], icon:'fa-solid fa-burger', color:'#06c167', tags:['food','delivery'], category:'Food' },
    // ── HEALTH / FITNESS ──
    { match:['myfitnesspal.com'], icon:'fa-solid fa-heart-pulse', color:'#0047e1', tags:['health','fitness'], category:'Health' },
    { match:['strava.com'], icon:'fa-solid fa-person-running', color:'#fc4c02', tags:['fitness','running'], category:'Health' },
    { match:['fitbit.com'], icon:'fa-solid fa-heart-pulse', color:'#00b0b9', tags:['health','fitness'], category:'Health' },
    { match:['webmd.com'], icon:'fa-solid fa-stethoscope', color:'#e83737', tags:['health','medical'], category:'Health' },
    { match:['healthline.com'], icon:'fa-solid fa-hospital', color:'#0c6cad', tags:['health'], category:'Health' },
    { match:['mayoclinic.org'], icon:'fa-solid fa-stethoscope', color:'#013e7d', tags:['health','medical'], category:'Health' },
    { match:['peloton.com'], icon:'fa-solid fa-bicycle', color:'#d91927', tags:['fitness'], category:'Health' },
    { match:['nike.com/app','nikerun'], icon:'fa-solid fa-person-running', color:'#111111', tags:['fitness'], category:'Health' },
    // ── GENERAL ──
    { match:['google.com'], icon:'fa-brands fa-google', color:'#4285f4', tags:['search','google'], category:'Search' },
    { match:['bing.com'], icon:'fa-brands fa-microsoft', color:'#008373', tags:['search','microsoft'], category:'Search' },
    { match:['duckduckgo.com'], icon:'fa-solid fa-magnifying-glass', color:'#de5833', tags:['search','privacy'], category:'Search' },
    { match:['apple.com'], icon:'fa-brands fa-apple', color:'#555555', tags:['apple'], category:'Tech' },
    { match:['microsoft.com'], icon:'fa-brands fa-microsoft', color:'#0078d4', tags:['microsoft'], category:'Tech' },
    { match:['wordpress.com','wordpress.org'], icon:'fa-brands fa-wordpress', color:'#21759b', tags:['blog','cms'], category:'Web' },
    { match:['ghost.org'], icon:'fa-brands fa-ghost', color:'#15171a', tags:['blog'], category:'Web' },
    { match:['squarespace.com'], icon:'fa-brands fa-squarespace', color:'#000000', tags:['website'], category:'Web' },
    { match:['wix.com'], icon:'fa-solid fa-wand-magic-sparkles', color:'#0c6ebd', tags:['website'], category:'Web' },
    { match:['webflow.com'], icon:'fa-solid fa-wind', color:'#146ef5', tags:['design','website'], category:'Web' },
    { match:['cloudflare.com'], icon:'fa-solid fa-cloud', color:'#f48120', tags:['hosting','cdn'], category:'Tech' },
    { match:['namecheap.com'], icon:'fa-solid fa-earth-americas', color:'#de3723', tags:['domains'], category:'Tech' },
    { match:['godaddy.com'], icon:'fa-solid fa-earth-americas', color:'#1bdbdb', tags:['domains','hosting'], category:'Tech' },
    { match:['archive.org','wayback'], icon:'fa-solid fa-clock-rotate-left', color:'#6b6b6b', tags:['archive','reference'], category:'Reference' },
    { match:['patreon.com'], icon:'fa-brands fa-patreon', color:'#ff424d', tags:['creators','support'], category:'Social' },
    { match:['ko-fi.com'], icon:'fa-solid fa-mug-hot', color:'#ff5f5f', tags:['creators'], category:'Social' },
    { match:['gumroad.com'], icon:'fa-solid fa-bag-shopping', color:'#ff90e8', tags:['creators'], category:'Social' },
    { match:['producthunt.com'], icon:'fa-solid fa-rocket', color:'#da552f', tags:['products','startups'], category:'Tech' },
    { match:['hn.algolia.com'], icon:'fa-brands fa-y-combinator', color:'#ff6600', tags:['search','tech'], category:'Tech' },
];

// Derive smart tags from URL when no SITE_ICON_MAP match exists
function autoTagsFromUrl(url){
    if(!url) return [];
    const tags = [];
    try{
        const h = new URL(url).hostname.toLowerCase().replace('www.','');
        const parts = h.split('.');
        if(parts.length>=2) tags.push(parts[parts.length-2]);
        // Path keywords
        const path = new URL(url).pathname.toLowerCase();
        const pathWords = path.split(/[\/\-_]/).filter(w=>w.length>3&&w.length<20);
        pathWords.slice(0,3).forEach(w=>{ if(!tags.includes(w)) tags.push(w); });
    }catch(e){}
    return tags.slice(0,5);
}

function detectSiteIcon(url){
    if(!url) return null;
    const urlLow = url.toLowerCase();
    // Extract just the hostname for more precise matching
    let hostname = urlLow;
    try { hostname = new URL(url).hostname.toLowerCase(); } catch(e){}
    // 1) Exact domain match — match against full URL for path-based entries, hostname for domain entries
    for(const entry of SITE_ICON_MAP){
        for(const m of entry.match){
            // Prefer hostname match to avoid false positives from URL paths
            if(hostname.includes(m) || (m.includes('/') && urlLow.includes(m)))
                return {icon:entry.icon, color:entry.color, tags:entry.tags||[], category:entry.category||null};
        }
    }
    // 2) Smart keyword fallback — match against hostname ONLY (not path) to avoid false positives
    return _keywordIcon(hostname);
}

// Keyword fallback — covers every site type, always produces an icon
const _KW = [
    {w:['youtube','youtu.be','vimeo','dailymotion','twitch','tiktok','rumble','odysee','peertube','bitchute'],i:'fa-brands fa-youtube',c:'#ef4444',t:['video'],cat:'Entertainment'},
    {w:['netflix','hulu','hbomax','max.com','disneyplus','peacock','paramount','appletv','crunchyroll','funimation','plex','jellyfin'],i:'fa-solid fa-film',c:'#ef4444',t:['streaming'],cat:'Entertainment'},
    {w:['spotify','soundcloud','deezer','tidal','bandcamp','lastfm','mixcloud','audius','napster','pandora','iheart'],i:'fa-solid fa-music',c:'#1db954',t:['music'],cat:'Music'},
    {w:['podcast','anchor','buzzsprout','podbean','simplecast','spreaker'],i:'fa-solid fa-podcast',c:'#8b5cf6',t:['podcast'],cat:'Music'},
    {w:['facebook','instagram','twitter','x.com','tiktok','snapchat','pinterest','mastodon','tumblr','vk.com','weibo','threads'],i:'fa-solid fa-share-nodes',c:'#3b82f6',t:['social'],cat:'Social'},
    {w:['linkedin','xing','glassdoor','angel.co','wellfound'],i:'fa-brands fa-linkedin',c:'#0077b5',t:['professional'],cat:'Work'},
    {w:['discord','slack','teams','telegram','whatsapp','signal','matrix','rocketchat','mattermost','zulip'],i:'fa-solid fa-comments',c:'#5865f2',t:['messaging'],cat:'Social'},
    {w:['github','gitlab','bitbucket','sourcehut','codeberg'],i:'fa-brands fa-github',c:'#333',t:['code'],cat:'Tech'},
    {w:['stackoverflow','stackexchange','superuser','serverfault','askubuntu'],i:'fa-brands fa-stack-overflow',c:'#f48024',t:['dev','qa'],cat:'Tech'},
    {w:['npm','pypi','rubygems','packagist','crates.io','nuget','maven'],i:'fa-solid fa-box-open',c:'#cb3837',t:['packages'],cat:'Tech'},
    {w:['codepen','codesandbox','jsfiddle','replit','glitch','stackblitz','playcode'],i:'fa-solid fa-code',c:'#6366f1',t:['playground'],cat:'Tech'},
    {w:['openai','chatgpt','anthropic','claude','gemini','copilot','mistral','perplexity','groq','ollama','huggingface','midjourney','stability','runway','sora','grok','deepseek'],i:'fa-solid fa-robot',c:'#10a37f',t:['ai'],cat:'AI'},
    {w:['amazon','ebay','shopify','etsy','aliexpress','alibaba','walmart','target','bestbuy','newegg','wish','shein','temu','zalando','zara','asos'],i:'fa-solid fa-bag-shopping',c:'#f97316',t:['shopping'],cat:'Shopping'},
    {w:['booking','airbnb','tripadvisor','expedia','kayak','skyscanner','hotels','agoda','hostelworld','couchsurfing'],i:'fa-solid fa-plane',c:'#06b6d4',t:['travel'],cat:'Travel'},
    {w:['google.com','bing.com','duckduckgo','yahoo','baidu','yandex','ecosia','startpage','brave.com/search'],i:'fa-solid fa-magnifying-glass',c:'#4285f4',t:['search'],cat:'Search'},
    {w:['notion','obsidian','roamresearch','logseq','craft.do','anytype','mem.ai','capacities'],i:'fa-solid fa-book-open',c:'#000',t:['notes'],cat:'Productivity'},
    {w:['trello','asana','monday','clickup','linear','height','basecamp','teamwork','wrike','smartsheet'],i:'fa-solid fa-list-check',c:'#0079bf',t:['project'],cat:'Productivity'},
    {w:['docs.google','drive.google','sheets.google','slides.google','calendar.google','forms.google'],i:'fa-brands fa-google-drive',c:'#4285f4',t:['google'],cat:'Productivity'},
    {w:['microsoft.com','office.com','outlook','onedrive','sharepoint','onenote','azure','copilot.microsoft'],i:'fa-brands fa-microsoft',c:'#0078d4',t:['microsoft'],cat:'Tech'},
    {w:['apple.com','icloud','developer.apple'],i:'fa-brands fa-apple',c:'#555',t:['apple'],cat:'Tech'},
    {w:['zoom','meet.google','teams.microsoft','webex','whereby','jitsi','loom','riverside','descript'],i:'fa-solid fa-video',c:'#2d8cff',t:['meetings'],cat:'Work'},
    {w:['figma','sketch','invision','zeplin','framer','webflow','canva','adobe','affinity','procreate','blender','cinema4d'],i:'fa-solid fa-palette',c:'#ec4899',t:['design'],cat:'Creative'},
    {w:['coursera','udemy','edx','pluralsight','skillshare','lynda','codecademy','freecodecamp','khanacademy','brilliant','duolingo','babbel'],i:'fa-solid fa-graduation-cap',c:'#0056d2',t:['learning'],cat:'Learning'},
    {w:['wikipedia','fandom','wikia','mediawiki','wiktionary'],i:'fa-brands fa-wikipedia-w',c:'#000',t:['wiki'],cat:'Reference'},
    {w:['medium','substack','ghost','wordpress','blogger','wix','squarespace','webflow','hashnode','dev.to','beehiiv'],i:'fa-solid fa-pen-to-square',c:'#f97316',t:['blog'],cat:'Reading'},
    {w:['bbc','cnn','nytimes','theguardian','reuters','apnews','bloomberg','forbes','techcrunch','theverge','wired','arstechnica','wsj','economist','ft.com'],i:'fa-solid fa-newspaper',c:'#374151',t:['news'],cat:'News'},
    {w:['reddit','hackernews','ycombinator','producthunt','lobste.rs','lemmy','tildes'],i:'fa-brands fa-reddit',c:'#ff4500',t:['community'],cat:'Social'},
    {w:['paypal','stripe','wise','revolut','venmo','cashapp','square','braintree','klarna','afterpay'],i:'fa-solid fa-credit-card',c:'#003087',t:['payments'],cat:'Finance'},
    {w:['binance','coinbase','kraken','kucoin','bybit','okx','bitfinex','crypto.com','opensea','uniswap','metamask'],i:'fa-solid fa-bitcoin-sign',c:'#f7931a',t:['crypto'],cat:'Finance'},
    {w:['robinhood','etrade','fidelity','schwab','vanguard','td ameritrade','ibkr','webull','tradingview','investing.com','yahoo finance','morningstar'],i:'fa-solid fa-chart-line',c:'#22c55e',t:['investing'],cat:'Finance'},
    {w:['steam','epicgames','gog.com','itch.io','xbox','playstation','nintendo','origin','battlenet','ubisoft','ea.com','riot','blizzard'],i:'fa-solid fa-gamepad',c:'#1b2838',t:['gaming'],cat:'Gaming'},
    {w:['ign','gamespot','polygon','kotaku','pcgamer','rockpapershotgun','eurogamer'],i:'fa-solid fa-trophy',c:'#8b5cf6',t:['gaming','news'],cat:'Gaming'},
    {w:['allrecipes','food52','seriouseats','epicurious','yummly','tasty','bonappetit','food.com','bbc food'],i:'fa-solid fa-utensils',c:'#f59e0b',t:['recipes'],cat:'Food'},
    {w:['doordash','ubereats','grubhub','deliveroo','justeat','zomato','swiggy','yelp'],i:'fa-solid fa-truck-fast',c:'#ef4444',t:['delivery'],cat:'Food'},
    {w:['webmd','healthline','mayoclinic','nih.gov','nhs.uk','drugs.com','medscape','uptodate'],i:'fa-solid fa-stethoscope',c:'#0284c7',t:['medical'],cat:'Health'},
    {w:['strava','myfitnesspal','fitbit','garmin','nike','peloton','whoop','oura','apple health','google fit'],i:'fa-solid fa-person-running',c:'#fc4c02',t:['fitness'],cat:'Health'},
    {w:['nfl','nba','mlb','nhl','fifa','uefa','espn','skysports','bbc sport','cbssports','nbcsports','bleacherreport'],i:'fa-solid fa-trophy',c:'#f59e0b',t:['sports'],cat:'Sports'},
    {w:['booking','hotels','airbnb','hostelworld','agoda','marriott','hilton','hyatt','ihg','accor'],i:'fa-solid fa-hotel',c:'#003580',t:['hotels'],cat:'Travel'},
    {w:['maps.google','openstreetmap','waze','here.com','mapbox','mapquest'],i:'fa-solid fa-map-location-dot',c:'#22c55e',t:['maps'],cat:'Travel'},
    {w:['uber','lyft','bolt','grab','ola','gett','freenow'],i:'fa-solid fa-car-side',c:'#000',t:['transport'],cat:'Travel'},
    {w:['digitalocean','heroku','vercel','netlify','railway','render.com','fly.io','linode','vultr','hetzner'],i:'fa-solid fa-server',c:'#0080ff',t:['hosting'],cat:'Tech'},
    {w:['docker','kubernetes','terraform','ansible','puppet','chef','vagrant','jenkins','circleci','github actions','gitlab ci','travis'],i:'fa-brands fa-docker',c:'#2496ed',t:['devops'],cat:'Tech'},
    {w:['aws','amazon web','ec2','s3.amazonaws','lambda','cloudfront','rds','dynamodb'],i:'fa-brands fa-aws',c:'#ff9900',t:['cloud'],cat:'Tech'},
    {w:['cloud.google','gcp','bigquery','firebase','appengine','gke'],i:'fa-brands fa-google',c:'#4285f4',t:['cloud'],cat:'Tech'},
    {w:['cloudflare','fastly','akamai','imperva','sucuri'],i:'fa-solid fa-shield-halved',c:'#f48120',t:['cdn'],cat:'Tech'},
    {w:['wordpress','woocommerce','shopify','prestashop','magento','bigcommerce','opencart'],i:'fa-brands fa-wordpress',c:'#21759b',t:['ecommerce'],cat:'Web'},
    {w:['namecheap','godaddy','porkbun','dynadot','hover','enom','domain','registrar'],i:'fa-solid fa-earth-americas',c:'#3b82f6',t:['domains'],cat:'Tech'},
    {w:['pdf','acrobat','pdfescape','smallpdf','ilovepdf','sejda','pdftk','pdfcandy','revpdf'],i:'fa-solid fa-file-pdf',c:'#ef4444',t:['pdf'],cat:'Tools'},
    {w:['convert','compress','resize','optimize','minify','tool','utility','generator','checker','validator','formatter'],i:'fa-solid fa-screwdriver-wrench',c:'#6b7280',t:['tools'],cat:'Tools'},
    {w:['analytics','gtm','mixpanel','amplitude','hotjar','fullstory','clarity','heap','segment','posthog'],i:'fa-solid fa-chart-bar',c:'#6366f1',t:['analytics'],cat:'Tech'},
    {w:['semrush','ahrefs','moz','ubersuggest','serpstat','majestic','seobility','spyfu'],i:'fa-solid fa-magnifying-glass-chart',c:'#ff642d',t:['seo'],cat:'Tech'},
    {w:['mailchimp','sendgrid','mailgun','postmark','klaviyo','brevo','convertkit','activecampaign','hubspot','salesforce','marketo'],i:'fa-solid fa-envelope',c:'#ffe01b',t:['email'],cat:'Marketing'},
    {w:['patreon','ko-fi','buymeacoffee','gumroad','substack','memberful'],i:'fa-solid fa-hand-holding-heart',c:'#ff424d',t:['creators'],cat:'Creator'},
    {w:['twitch','kick.com','trovo','dlive','youtube live','facebook live'],i:'fa-solid fa-tower-broadcast',c:'#9146ff',t:['live'],cat:'Entertainment'},
    {w:['behance','dribbble','artstation','deviantart','pixiv','artfol'],i:'fa-solid fa-image',c:'#1769ff',t:['portfolio'],cat:'Creative'},
    {w:['flickr','500px','unsplash','pexels','pixabay','shutterstock','getty','istockphoto'],i:'fa-solid fa-camera',c:'#ff0084',t:['photos'],cat:'Creative'},
    {w:['law','legal','attorney','lawyer','court','lexis','westlaw','findlaw','justia','nolo'],i:'fa-solid fa-scale-balanced',c:'#6b7280',t:['legal'],cat:'Professional'},
    {w:['zillow','realtor','redfin','trulia','rightmove','zoopla','apartments','rentals'],i:'fa-solid fa-house',c:'#1277e1',t:['realestate'],cat:'Home'},
    {w:['science','nature','pubmed','arxiv','scholar','researchgate','academia','ieee','acm','springer','elsevier'],i:'fa-solid fa-flask',c:'#06b6d4',t:['science'],cat:'Science'},
    {w:['nasa','esa','spacex','blueorigin','roscosmos','isro','space','cosmos','astronomy'],i:'fa-solid fa-rocket',c:'#1e3a5f',t:['space'],cat:'Science'},
    {w:['archive.org','wayback','memento','perma.cc'],i:'fa-solid fa-clock-rotate-left',c:'#6b7280',t:['archive'],cat:'Reference'},
    {w:['gov','government','irs.gov','ssa.gov','cdc.gov','fda.gov','nhs.uk','europa.eu'],i:'fa-solid fa-landmark',c:'#374151',t:['government'],cat:'Government'},
    {w:['charity','donate','nonprofit','gofundme','globalgiving','justgiving','crowdfunding','kickstarter','indiegogo'],i:'fa-solid fa-hand-holding-dollar',c:'#22c55e',t:['charity'],cat:'Community'},
    {w:['car','auto','vehicle','motor','autotrader','cars.com','carfax','edmunds','kelley','bmw','mercedes','tesla','ford','toyota'],i:'fa-solid fa-car',c:'#6b7280',t:['cars'],cat:'Automotive'},
    {w:['fashion','style','clothing','wear','outfit','lookbook','vogue','gq','elle','cosmopolitan'],i:'fa-solid fa-shirt',c:'#ec4899',t:['fashion'],cat:'Fashion'},
    {w:['baby','parenting','kid','child','toddler','pregnancy','babycenter','whattoexpect'],i:'fa-solid fa-baby',c:'#f59e0b',t:['parenting'],cat:'Family'},
    {w:['church','mosque','temple','synagogue','faith','bible','quran','prayer','worship'],i:'fa-solid fa-place-of-worship',c:'#8b5cf6',t:['religion'],cat:'Community'},
    {w:['environment','climate','sustainability','green','eco','solar','renewable','energy'],i:'fa-solid fa-leaf',c:'#22c55e',t:['environment'],cat:'Science'},
    // Catch-all fallbacks by TLD and common patterns
    {w:['.edu','/university/','/college/','/academic/'],i:'fa-solid fa-graduation-cap',c:'#0056d2',t:['education'],cat:'Learning'},
    {w:['.gov','.mil'],i:'fa-solid fa-landmark',c:'#374151',t:['government'],cat:'Government'},
    {w:['api.','developer.','dev.','docs.','documentation'],i:'fa-solid fa-code',c:'#8b5cf6',t:['docs'],cat:'Tech'},
    {w:['blog.','journal.','news.','press.','media.'],i:'fa-solid fa-pen-to-square',c:'#f97316',t:['blog'],cat:'Reading'},
    {w:['shop.','store.','buy.','cart.','/shop/','/store/','/product/'],i:'fa-solid fa-bag-shopping',c:'#f97316',t:['shopping'],cat:'Shopping'},
    {w:['help.','support.','faq.','/help/','/support/','/faq/'],i:'fa-solid fa-circle-question',c:'#6b7280',t:['support'],cat:'Reference'},
    {w:['video','watch','stream','/v/','/watch?'],i:'fa-solid fa-play',c:'#ef4444',t:['video'],cat:'Entertainment'},
    {w:['music','audio','listen','/track/','/album/'],i:'fa-solid fa-headphones',c:'#8b5cf6',t:['music'],cat:'Music'},
    {w:['game','play','/game/','/games/'],i:'fa-solid fa-gamepad',c:'#8b5cf6',t:['gaming'],cat:'Gaming'},
    {w:['news','article','/news/','/article/','/post/'],i:'fa-solid fa-newspaper',c:'#6b7280',t:['news'],cat:'News'},
];

function _keywordIcon(urlLow){
    for(const e of _KW){
        for(const w of e.w){
            if(urlLow.includes(w)) return {icon:e.i, color:e.c, tags:e.t||[], category:e.cat||'General'};
        }
    }
    // Ultimate fallback — never return null, always give globe
    return {icon:'fa-solid fa-globe', color:'#6b7280', tags:[], category:'Web'};
}

function handleLogoUpload(e){
    const r=new FileReader();
    r.onload=ev=>{ S.tempLogo=ev.target.result; document.getElementById('logoPrev').innerHTML=`<img src="${S.tempLogo}">`; };
    r.readAsDataURL(e.target.files[0]);
}
function useAutoFolderIcon(){
    const si=S._autoFolderIcon; if(!si) return;
    // Open folder modal pre-set with this icon/color
    S.editingFolder=null; S.selIcon=si.icon; S.selColor=si.color;
    const urlVal=document.getElementById('lUrl').value.trim();
    let suggestName='';
    try{ suggestName=new URL(urlVal).hostname.replace('www.','').split('.')[0]; suggestName=suggestName.charAt(0).toUpperCase()+suggestName.slice(1); }catch(e){}
    document.getElementById('fName').value=suggestName;
    document.getElementById('folderModalTitle').textContent='Create Folder';
    document.getElementById('folderDelBtn').style.display='none';
    updIPreview(); renderCPick();
    S._createFolderFromAdd=true;
    document.getElementById('autoFolderSuggest').style.display='none';
    openModal('folderModal');
}

function refetchIcon(){
    const url=document.getElementById('lUrl')?.value.trim();
    if(!url||!url.startsWith('http')){ showToast('Enter a URL first','#f59e0b'); return; }
    S.tempLogo=null; fetchWebMeta();
}
function clearIcon(){
    wmLogoRevision++;
    S.tempLogo=null;
    document.getElementById('logoPrev').innerHTML='<i class="fa-solid fa-globe"></i>';
}

// Auto-generate icon from URL/title concept — used on link save when no logo uploaded
function _applyAutoIcon(url){
    // Already has a fetched image logo — don't overwrite
    if(S.tempLogo && !S.tempLogo.includes('google.com/s2/favicons')) return;
    const si = detectSiteIcon(url);
    if(si){
        // If only have a favicon fallback, prefer FA icon for cleaner look
        if(S.tempLogo && S.tempLogo.includes('google.com/s2/favicons')){
            // Keep favicon image — it's better than FA icon
            return;
        }
    }
}

// Generate site icon object for a link, called at save time
function _buildSiteIconForLink(url, title){
    const si = detectSiteIcon(url);
    if(si) return si;
    // Keyword fallback from title
    if(title){
        const tl = title.toLowerCase();
        for(const entry of SITE_ICON_MAP){
            for(const m of entry.match){
                if(tl.includes(m.replace('.com','').replace('.',''))){ 
                    return {icon:entry.icon, color:entry.color}; 
                }
            }
        }
    }
    return _keywordIcon(url)||null;
}

// openEditDetail is defined below near reminder functions
function openEditDetail(id){
    const l=S.links.find(x=>x.id===id); if(!l) return;
    S.editingLink=id; l.views=(l.views||0)+1; save();
    // Populate editable fields
    document.getElementById('dtTitleInput').value=l.title||'';
    document.getElementById('dtDescInput').value=l.desc||'';
    document.getElementById('dtViews') && (document.getElementById('dtViews').textContent=l.views);
    document.getElementById('dtUrl').textContent=l.url;
    document.getElementById('dtLogo').innerHTML=l.logo?`<img src="${esc(l.logo)}">`:'<i class="fa-solid fa-globe"></i>';
    const f=S.folders.find(x=>x.id===l.fId);
    const fb=document.getElementById('dtFolderBadge');
    fb.innerHTML=f?`<i class="${f.icon}" style="font-size:10px;"></i> ${esc(f.name)}`:'Unsorted';
    fb.style.background=f?(f.color||'#8b5cf6'):'#27272a';
    fb.style.color='#ffffff';
    const tagBadge=document.getElementById('dtTagBadge');
    tagBadge.textContent=(l.tags||[]).join(', ')||'No tags';
    tagBadge.style.background=(l.tags&&l.tags.length)?'var(--primary)':'#27272a';
    tagBadge.style.color=(l.tags&&l.tags.length)?'#000':'#ffffff';
    // Fav button state
    const favIcon=document.getElementById('dtFavIcon');
    const favBtn=document.getElementById('dtFavBtn');
    if(favIcon) favIcon.className=l.fav?'fa-solid fa-heart':'fa-regular fa-heart';
    if(favBtn) { favBtn.style.color=l.fav?'#ef4444':'var(--text-dim)'; favBtn.style.borderColor=l.fav?'rgba(239,68,68,.4)':'var(--border)'; }
    // Pin button state
    const pinIcon=document.getElementById('dtPinIcon');
    const pinBtn=document.getElementById('dtPinBtn');
    if(pinIcon) pinIcon.style.color=l.pinned?'#3b82f6':'var(--text-dim)';
    if(pinBtn) { pinBtn.style.color=l.pinned?'#3b82f6':'var(--text-dim)'; pinBtn.style.borderColor=l.pinned?'rgba(59,130,246,.4)':'var(--border)'; }
    // Show reminder if set
    const remVal=document.getElementById('dtReminderVal');
    if(l.reminder){
        const d=new Date(l.reminder);
        remVal.textContent=d.toLocaleString(undefined,{month:'short',day:'numeric',hour:'2-digit',minute:'2-digit'});
        remVal.style.color='var(--primary)';
    } else {
        remVal.textContent='Set Reminder';
        remVal.style.color='var(--text-dim)';
    }
    // Archive button label — show Unarchive if already archived
    const archLabel = document.getElementById('dtArchiveLabel');
    const archIcon = document.getElementById('dtArchiveIcon');
    if(archLabel) archLabel.textContent = l.archived ? 'Unarchive' : 'Archive';
    if(archIcon) archIcon.className = l.archived ? 'fa-solid fa-box-open' : 'fa-regular fa-file';
    // Reset save button
    const btn=document.querySelector('#editDetailModal button[data-wm-click="56"]');
    if(btn){ btn.style.background='var(--card)'; btn.style.color='var(--text)'; btn.style.borderColor='var(--border)'; }
    openModal('editDetailModal');
}

function saveEditDetail(){ 
    const l=S.links.find(x=>x.id===S.editingLink);
    if(l){
        l.title=document.getElementById('dtTitleInput').value.trim()||l.title;
        l.desc=document.getElementById('dtDescInput').value.trim();
        save();
    }
    closeModal('editDetailModal'); renderLinks(); 
}

function handleEditLogoUpload(e){
    const r=new FileReader();
    r.onload=ev=>{
        const l=S.links.find(x=>x.id===S.editingLink);
        if(l){ l.logo=ev.target.result; save(); markChanged(); }
        document.getElementById('dtLogo').innerHTML=`<img src="${ev.target.result}">`;
    };
    r.readAsDataURL(e.target.files[0]);
}

function rewriteAI(){ alert('Rewrite with AI — connect your AI backend!'); }

function favCurrent(){ 
    toggleFav(S.editingLink); 
    const l=S.links.find(x=>x.id===S.editingLink);
    const favIcon=document.getElementById('dtFavIcon');
    const favBtn=document.getElementById('dtFavBtn');
    if(favIcon) favIcon.className=l?.fav?'fa-solid fa-heart':'fa-regular fa-heart';
    if(favBtn) { favBtn.style.color=l?.fav?'#ef4444':'var(--text-dim)'; favBtn.style.borderColor=l?.fav?'rgba(239,68,68,.4)':'var(--border)'; }
    renderTabs(); markChanged(); 
}
function pinCurrent(){ 
    const l=S.links.find(x=>x.id===S.editingLink); 
    if(l){ l.pinned=!l.pinned; save(); }
    const pinIcon=document.getElementById('dtPinIcon');
    const pinBtn=document.getElementById('dtPinBtn');
    if(pinIcon) pinIcon.style.color=l?.pinned?'#3b82f6':'var(--text-dim)';
    if(pinBtn) { pinBtn.style.color=l?.pinned?'#3b82f6':'var(--text-dim)'; pinBtn.style.borderColor=l?.pinned?'rgba(59,130,246,.4)':'var(--border)'; }
    markChanged();
}
function deskNav(tab, btnId){
    // Close ALL inline pages (so Home works from folders/settings on mobile)
    document.querySelectorAll('.inline-page').forEach(p => p.classList.remove('active'));
    if(typeof _returnToSettings !== 'undefined') _returnToSettings = false;
    if(typeof _returnToFolders !== 'undefined') _returnToFolders = false;
    document.querySelectorAll('.dnl').forEach(b=>b.classList.remove('active'));
    const el=document.getElementById(btnId); if(el) el.classList.add('active');
    switchTab(tab);
}
function shareCurrent(){
    const l=S.links.find(x=>x.id===S.editingLink);
    if(l&&navigator.share) navigator.share({title:l.title,url:l.url});
    else if(l){ wmCopy(l.url); alert('Link copied!'); }
}
function waShare(){ const l=S.links.find(x=>x.id===S.editingLink); if(l) window.open(`https://wa.me/?text=${encodeURIComponent(l.title+'\n'+l.url)}`); }
function archiveCurrent(){ toggleArchive(S.editingLink); closeModal('editDetailModal'); }

// FOLDER SELECT
function openFolderSelect(src='add'){
    S.folderSelectSrc=src;
    document.getElementById('unsortedCnt').textContent=S.links.filter(l=>!l.fId&&!l.archived).length;
    // Clear the search box every time the modal opens
    const srch=document.getElementById('folderSelectSearch');
    if(srch){ srch.value=''; }
    const clr=document.getElementById('folderSelectSearchClear');
    if(clr) clr.style.display='none';
    renderFolderSelectList();
    openModal('folderSelectModal');
    requestAnimationFrame(()=>{
        const mc = document.querySelector('#folderSelectModal .mc');
        if(mc) mc.scrollTop = 0;
    });
}

function filterFolderSelectList(q){
    const clr=document.getElementById('folderSelectSearchClear');
    if(clr) clr.style.display=q?'block':'none';
    const el=document.getElementById('folderSelectList');
    const ql=q.trim().toLowerCase();
    const folders=ql?S.folders.filter(f=>f.name.toLowerCase().includes(ql)):S.folders;
    if(!folders.length){
        el.innerHTML=ql
            ?`<p style="color:var(--text-dim);text-align:center;padding:20px 0;font-size:13px;">No folders match "<b>${esc(ql)}</b>"</p>`
            :'<p style="color:var(--text-dim);text-align:center;padding:20px 0;">No folders yet</p>';
        return;
    }
    el.innerHTML=folders.map(f=>`
        <div class="frow" data-wm-click="189" data-wm-click-0="${f.id}">
            <div class="frow-icon" style="background:transparent;"><i class="${f.icon}" style="color:${f.color};"></i></div>
            <span class="frow-name">${esc(f.name)}</span>
            <i class="fa-solid fa-chevron-right" style="color:var(--text-dim);font-size:12px;"></i>
        </div>`).join('');
}

function renderFolderSelectList(){
    const el=document.getElementById('folderSelectList');
    el.innerHTML=S.folders.map(f=>`
        <div class="frow" data-wm-click="189" data-wm-click-0="${f.id}">
            <div class="frow-icon" style="background:transparent;"><i class="${f.icon}" style="color:${f.color};"></i></div>
            <span class="frow-name">${esc(f.name)}</span>
            <i class="fa-solid fa-chevron-right" style="color:var(--text-dim);font-size:12px;"></i>
        </div>`).join('')||'<p style="color:var(--text-dim);text-align:center;padding:20px 0;">No folders yet</p>';
}

function selectFolder(id){
    S.selectedFolderId=id;
    if(S.folderSelectSrc==='editDetail'&&S.editingLink){
        const l=S.links.find(x=>x.id===S.editingLink);
        if(l){ l.fId=id; save(); }
        const f=S.folders.find(x=>x.id===id);
        const fb=document.getElementById('dtFolderBadge');
        fb.innerHTML=f?`<i class="${f.icon}" style="font-size:10px;color:${f.color};"></i> ${esc(f.name)}`:'Unsorted';
        fb.style.background='#27272a';
        markChanged();
    } else { updSelFolder(); }
    closeModal('folderSelectModal');
}

// FOLDER MANAGE
function openManageFolders(){ 
    renderManageFolders(); 
    openModal('manageFoldersModal');
    requestAnimationFrame(()=>{
        const mc = document.querySelector('#manageFoldersModal .mc');
        if(mc) mc.scrollTop = 0;
    });
}

let _fmDragSrcId = null;
function renderManageFolders(){
    const el=document.getElementById('manageFoldersList');
    const q=(document.getElementById('manageFolderSearch')?.value||'').trim().toLowerCase();
    const mfClear=document.getElementById('mfSearchClear'); if(mfClear) mfClear.style.display=q?'block':'none';
    const folders=q?S.folders.filter(f=>f.name.toLowerCase().includes(q)):S.folders;
    if(!folders.length){ el.innerHTML=q?`<p style="color:var(--text-dim);text-align:center;padding:20px 0;font-size:13px;">No folders match "<b>${esc(q)}</b>"</p>`:'<p style="color:var(--text-dim);text-align:center;padding:20px 0;">No folders. Create one!</p>'; return; }
    el.innerHTML=folders.map(f=>{
        const cnt=S.links.filter(l=>l.fId===f.id&&!l.archived).length;
        const col=f.color||'#8b5cf6';
        return `
        <div class="fm-row" id="fmr-${f.id}" draggable="true"
            ondragstart="fmDragStart(event,${f.id})" ondragend="fmDragEnd(event)"
            ondragover="fmDragOver(event,${f.id})" ondrop="fmDrop(event,${f.id})"
            style="display:flex;align-items:center;gap:12px;padding:12px 0;border-bottom:1px solid var(--border);cursor:default;">
            <i class="fa-solid fa-grip-lines" id="fmgrip-${f.id}"
                ontouchstart="fmTouchStart(event,${f.id})" ontouchmove="fmTouchMove(event)" ontouchend="fmTouchEnd(event)"
                style="color:${col};font-size:20px;flex-shrink:0;cursor:grab;touch-action:none;padding:4px 6px;"></i>
            <i class="${f.icon}" style="color:${col};font-size:18px;flex-shrink:0;width:22px;text-align:center;"></i>
            <span style="font-size:15px;font-weight:500;flex:1;cursor:pointer;" data-wm-click="190" data-wm-click-0="${f.id}">${esc(f.name)}</span>
            <span style="font-size:12px;color:#fff;background:#52525b;border-radius:5px;padding:1px 8px;min-width:22px;text-align:center;">${cnt}</span>
            <button data-wm-click="190" data-wm-click-0="${f.id}" style="background:rgba(245,158,11,.12);color:#f59e0b;border:1px solid rgba(245,158,11,.25);border-radius:8px;padding:5px 10px;font-size:12px;font-weight:600;cursor:pointer;white-space:nowrap;"><i class="fa-solid fa-pen"></i></button>
            <button data-wm-click="191" data-wm-click-0="${f.id}" style="background:rgba(239,68,68,.12);color:#ef4444;border:1px solid rgba(239,68,68,.25);border-radius:8px;padding:5px 10px;font-size:12px;font-weight:600;cursor:pointer;"><i class="fa-solid fa-trash"></i></button>
        </div>`}).join('')||'<p style="color:var(--text-dim);text-align:center;padding:20px 0;">No folders. Create one!</p>';
}
function fmDragStart(e,id){ _fmDragSrcId=id; e.dataTransfer.effectAllowed='move'; setTimeout(()=>{ const el=document.getElementById('fmr-'+id); if(el) el.style.opacity='.4'; },0); }
function fmDragEnd(e){ document.querySelectorAll('.fm-row').forEach(r=>{ r.style.opacity=''; r.style.borderTop=''; r.style.borderBottom=''; }); _fmDragSrcId=null; }
function fmDragOver(e,id){ e.preventDefault(); e.dataTransfer.dropEffect='move'; document.querySelectorAll('.fm-row').forEach(r=>{ r.style.borderTop=''; r.style.borderBottom=''; }); const el=document.getElementById('fmr-'+id); if(el&&id!==_fmDragSrcId) el.style.borderTop='2px solid var(--primary)'; }
function fmDrop(e,targetId){ e.preventDefault(); if(!_fmDragSrcId||_fmDragSrcId===targetId) return; const si=S.folders.findIndex(f=>f.id===_fmDragSrcId); const ti=S.folders.findIndex(f=>f.id===targetId); if(si<0||ti<0) return; const [moved]=S.folders.splice(si,1); S.folders.splice(ti,0,moved); save(); renderManageFolders(); renderTabs(); _fmDragSrcId=null; }

// ── TOUCH DRAG FOR MANAGE FOLDERS ──
let _fmTouchId=null, _fmTouchClone=null, _fmTouchOffY=0, _fmScrollRaf=null;
function fmTouchStart(e,id){
    e.stopPropagation();
    _fmDragSrcId=id;
    _fmTouchId=id;
    const row=document.getElementById('fmr-'+id);
    if(!row) return;
    const rect=row.getBoundingClientRect();
    _fmTouchOffY=e.touches[0].clientY - rect.top;
    // Create floating clone
    _fmTouchClone=row.cloneNode(true);
    _fmTouchClone.style.cssText=`position:fixed;left:${rect.left}px;top:${rect.top}px;width:${rect.width}px;opacity:.85;z-index:9999;pointer-events:none;border-radius:12px;background:var(--card);box-shadow:0 8px 32px rgba(0,0,0,.4);`;
    document.body.appendChild(_fmTouchClone);
    row.style.opacity='.3';
}
function _fmGetScroller(){
    // On mobile: inline page body scrolls
    const inlinePage = document.getElementById('page-folders');
    if(inlinePage && inlinePage.classList.contains('active')){
        return document.getElementById('inlineFoldersList') || inlinePage.querySelector('.inline-page-body');
    }
    // On desktop/modal: .mc inside manageFoldersModal scrolls
    return document.querySelector('#manageFoldersModal .mc') || null;
}
function fmTouchMove(e){
    if(!_fmTouchClone||!_fmTouchId) return;
    e.preventDefault();
    const ty=e.touches[0].clientY;
    const tx=e.touches[0].clientX;
    _fmTouchClone.style.top=(ty-_fmTouchOffY)+'px';
    // Highlight target row
    document.querySelectorAll('.fm-row').forEach(r=>{ r.style.borderTop=''; });
    const el=document.elementFromPoint(tx, ty);
    const targetRow=el && el.closest('.fm-row');
    if(targetRow && targetRow.id!=='fmr-'+_fmTouchId){
        targetRow.style.borderTop='2px solid var(--primary)';
    }
    // Auto-scroll when near top or bottom edge
    if(_fmScrollRaf) cancelAnimationFrame(_fmScrollRaf);
    const scroller = _fmGetScroller();
    if(scroller){
        const sr = scroller.getBoundingClientRect();
        const ZONE = 80, SPEED = 8;
        let dir = 0;
        if(ty < sr.top + ZONE)    dir = -SPEED;
        else if(ty > sr.bottom - ZONE) dir =  SPEED;
        if(dir !== 0){
            const doScroll = () => {
                scroller.scrollTop += dir;
                if(_fmTouchClone) _fmScrollRaf = requestAnimationFrame(doScroll);
            };
            _fmScrollRaf = requestAnimationFrame(doScroll);
        }
    }
}
function fmTouchEnd(e){
    if(_fmScrollRaf){ cancelAnimationFrame(_fmScrollRaf); _fmScrollRaf=null; }
    if(!_fmTouchClone) return;
    document.body.removeChild(_fmTouchClone); _fmTouchClone=null;
    document.querySelectorAll('.fm-row').forEach(r=>{ r.style.opacity=''; r.style.borderTop=''; });
    const ty=e.changedTouches[0].clientY;
    const tx=e.changedTouches[0].clientX;
    const el=document.elementFromPoint(tx,ty);
    const targetRow=el&&el.closest('.fm-row');
    if(targetRow){
        const targetId=parseInt(targetRow.id.replace('fmr-',''));
        if(targetId&&targetId!==_fmDragSrcId){
            const si=S.folders.findIndex(f=>f.id===_fmDragSrcId);
            const ti=S.folders.findIndex(f=>f.id===targetId);
            if(si>=0&&ti>=0){ const [mv]=S.folders.splice(si,1); S.folders.splice(ti,0,mv); save(); renderManageFolders(); renderTabs(); }
        }
    }
    _fmDragSrcId=null; _fmTouchId=null;
}

function openCreateFolder(){
    S.editingFolder=null; S.selIcon='fa-solid fa-folder'; S.selColor='#8b5cf6';
    document.getElementById('fName').value='';
    document.getElementById('folderModalTitle').textContent='Create Folder';
    document.getElementById('folderDelBtn').style.display='none';
    updIPreview(); renderCPick();
    closeModal('folderSelectModal'); closeModal('manageFoldersModal');
    // On mobile inline page: hide folders page and return to it after save
    if(window.innerWidth <= 767 && document.getElementById('page-folders') &&
       document.getElementById('page-folders').classList.contains('active')){
        document.getElementById('page-folders').classList.remove('active');
        _returnToFolders = true;
    }
    openModal('folderModal');
    S._createFolderFromAdd = (S.folderSelectSrc==='add');
}

function openEditFolder(id){
    const f=S.folders.find(x=>x.id===id);
    if(!f) return;
    S.editingFolder=id; S.selIcon=f.icon; S.selColor=f.color;
    document.getElementById('fName').value=f.name;
    document.getElementById('folderModalTitle').textContent='Edit Folder';
    document.getElementById('folderDelBtn').style.display='block';
    updIPreview(); renderCPick();
    // On mobile inline page: hide it, open modal, return to folders page on close
    if(window.innerWidth <= 767 && document.getElementById('page-folders').classList.contains('active')){
        document.getElementById('page-folders').classList.remove('active');
        _returnToFolders = true;
    } else {
        closeModal('manageFoldersModal');
    }
    openModal('folderModal');
}

function deleteCurFolder(){
    if(!S.editingFolder) return;
    if(!confirm('Delete folder? Bookmarks become unsorted.')) return;
    S.folders=S.folders.filter(f=>f.id!==S.editingFolder);
    S.links.forEach(l=>{if(l.fId===S.editingFolder)l.fId=null;});
    S.editingFolder=null;
    save(); init(); closeModal('folderModal'); openManageFolders();
}

function saveFolder(){
    const name=document.getElementById('fName').value.trim();
    if(!name){alert('Enter folder name');return;}
    if(S.editingFolder){
        const f=S.folders.find(x=>x.id===S.editingFolder);
        if(!f) return;
        f.name=name; f.icon=S.selIcon; f.color=S.selColor;
        save(); init();
        // Close the folder modal
        document.getElementById('folderModal').classList.remove('active');
        S.editingFolder=null;
        // Return to correct view
        if(window.innerWidth <= 767){
            _returnToFolders = false;
            openPage('folders');
        } else {
            openManageFolders();
        }
    } else {
        const newId=wmId();
        S.folders.unshift({id:newId,name,icon:S.selIcon,color:S.selColor});
        S.selectedFolderId=newId;
        save(); init();
        document.getElementById('folderModal').classList.remove('active');
        updSelFolder();
        // Auto re-open add modal if folder was created from there
        if(S._createFolderFromAdd !== false){
            openModal('addModal');
        }
    }
}

function quickDeleteFolder(id){
    if(!confirm('Delete folder? Bookmarks become unsorted.')) return;
    S.folders=S.folders.filter(f=>f.id!==id);
    S.links.forEach(l=>{if(l.fId===id)l.fId=null;});
    save(); init(); renderManageFolders();
}

function deleteFolder(id){ quickDeleteFolder(id); }

function closeFolderModal(){
    const name = document.getElementById('fName').value.trim();
    if(name.length > 0 && !confirm(T('confirmLeaveFolder')||'Leave without saving?')) return;
    closeModal('folderModal'); if(S.editingFolder) openManageFolders();
}

// ICON PICKER
function openIconPicker(){ document.getElementById('iconSearch').value=''; renderIconGrid(); openModal('iconPickerModal'); }

// ── ICON KEYWORD ALIASES ──
// Maps search terms to icon names for better discoverability
const ICON_ALIASES = {
  // Tech & Internet
  'youtube': ['youtube','video','play'],
  'google': ['google'],
  'github': ['github','git','code'],
  'facebook': ['facebook'],
  'instagram': ['instagram'],
  'twitter': ['twitter','x-twitter'],
  'linkedin': ['linkedin'],
  'tiktok': ['tiktok'],
  'whatsapp': ['whatsapp'],
  'telegram': ['telegram'],
  'discord': ['discord'],
  'reddit': ['reddit'],
  'snapchat': ['snapchat'],
  'pinterest': ['pinterest'],
  'twitch': ['twitch'],
  'spotify': ['spotify'],
  'apple': ['apple'],
  'android': ['android'],
  'windows': ['windows'],
  'chrome': ['chrome'],
  'firefox': ['firefox'],
  'safari': ['safari'],
  'edge': ['edge'],
  'amazon': ['amazon'],
  'netflix': ['netflix'],
  'dropbox': ['dropbox'],
  'wordpress': ['wordpress'],
  'slack': ['slack'],
  'figma': ['figma'],
  'docker': ['docker'],
  'linux': ['linux'],
  'ubuntu': ['ubuntu'],
  'python': ['python'],
  'react': ['react'],
  'node': ['node'],
  'npm': ['npm'],
  'css': ['css3'],
  'html': ['html5'],
  'js': ['js'],
  'java': ['java'],
  'php': ['php'],
  'git': ['git','github','gitlab'],
  'gitlab': ['gitlab'],
  'jira': ['jira'],
  'trello': ['trello'],
  'notion': ['notion'],
  'zoom': ['zoom'],
  'paypal': ['paypal'],
  'stripe': ['stripe'],
  'bitcoin': ['bitcoin'],
  'ethereum': ['ethereum'],
  'wifi': ['wifi','signal','tower-broadcast','satellite-dish'],
  'network': ['network-wired','wifi','tower-broadcast'],
  'internet': ['globe','wifi','network-wired'],
  'server': ['server','database','hard-drive'],
  'database': ['database','server'],
  'api': ['code','plug','link'],
  'cloud': ['cloud','cloud-arrow-up','cloud-arrow-down'],
  'security': ['shield','shield-halved','lock','key'],
  'vpn': ['shield','lock','globe'],
  'robot': ['robot'],
  'ai': ['robot','brain','microchip'],
  'cpu': ['microchip','computer'],
  'computer': ['desktop','laptop','computer'],
  'laptop': ['laptop','laptop-code'],
  'mobile': ['mobile','mobile-screen'],
  'phone': ['phone','mobile','mobile-screen'],
  'tablet': ['tablet'],
  'keyboard': ['keyboard'],
  'mouse': ['computer-mouse'],
  'printer': ['print'],
  'headphones': ['headphones','headset'],
  'camera': ['camera','camera-retro','camera-rotate','video','photo-film','image'],
  'video': ['video','video-slash','film','clapperboard','photo-film','youtube','circle-play'],
  'movie': ['film','clapperboard','circle-play','ticket','photo-film','video','tv'],
  'film': ['film','clapperboard','circle-play','photo-film'],
  'cinema': ['film','clapperboard','ticket','circle-play'],
  'series': ['tv','film','circle-play','list'],
  'tv': ['tv','display','circle-play','film'],
  'television': ['tv','display','circle-play'],
  'stream': ['circle-play','tv','wifi','signal'],
  'streaming': ['circle-play','tv','film','youtube'],
  'netflix': ['film','circle-play','tv'],
  'youtube': ['youtube','circle-play','film','video'],
  'watch': ['circle-play','tv','film','clock'],
  'play': ['circle-play','play','forward'],
  'photo': ['image','camera','images','photo-film'],
  'picture': ['image','images','camera'],
  'gallery': ['images','photo-film','image'],
  'screenshot': ['camera','image','display'],
  'record': ['circle','microphone','video','camera'],
  'music': ['music','spotify','headphones','note-sticky'],
  'podcast': ['podcast','microphone','headphones'],
  'radio': ['radio','broadcast-tower'],
  'audio': ['headphones','volume-high','microphone','music'],
  'headphones': ['headphones','headset'],
  'microphone': ['microphone','microphone-slash','podcast'],
  'speaker': ['volume-high','volume-low','volume-xmark'],
  'sound': ['volume-high','music','headphones'],
  'server': ['server','database','hard-drive'],
  'database': ['database','server'],
  'api': ['code','plug','link'],
  'cloud': ['cloud','cloud-arrow-up','cloud-arrow-down'],
  'security': ['shield','shield-halved','lock','key'],
  'vpn': ['shield','lock','globe'],
  'robot': ['robot'],
  'ai': ['robot','brain','microchip'],
  'cpu': ['microchip','computer'],
  'computer': ['desktop','laptop','computer'],
  'laptop': ['laptop','laptop-code'],
  'mobile': ['mobile','mobile-screen'],
  'phone': ['phone','mobile','mobile-screen'],
  'tablet': ['tablet'],
  'keyboard': ['keyboard'],
  'mouse': ['computer-mouse'],
  'printer': ['print'],
  'game': ['gamepad','chess','dice'],
  'gaming': ['gamepad','chess','dice-d20'],
  'steam': ['steam'],
  'playstation': ['playstation'],
  'xbox': ['xbox'],
  'controller': ['gamepad'],
  // Files & Documents
  'file': ['file','folder','folder-open'],
  'folder': ['folder','folder-open','folder-tree'],
  'pdf': ['file-pdf'],
  'doc': ['file-word','file-lines'],
  'excel': ['file-excel'],
  'zip': ['file-zipper'],
  'code': ['code','file-code'],
  'link': ['link','arrow-up-right-from-square'],
  'bookmark': ['bookmark'],
  'note': ['note-sticky','pen'],
  'email': ['envelope','at'],
  'mail': ['envelope'],
  'calendar': ['calendar','calendar-days'],
  'clock': ['clock','stopwatch'],
  'time': ['clock','hourglass'],
  'list': ['list','list-check'],
  'task': ['list-check','clipboard-check'],
  'todo': ['list-check','circle-check'],
  'project': ['diagram-project','clipboard'],
  'chart': ['chart-bar','chart-line','chart-pie'],
  'stats': ['chart-bar','chart-line'],
  'graph': ['chart-line','chart-bar'],
  'report': ['file-lines','chart-bar'],
  'money': ['dollar-sign','credit-card','coins'],
  'finance': ['coins','chart-line','dollar-sign'],
  'payment': ['credit-card','paypal','wallet'],
  'wallet': ['wallet','coins'],
  'bank': ['building-columns','vault'],
  'shop': ['shop','bag-shopping','cart-shopping'],
  'store': ['store','shop'],
  'cart': ['cart-shopping','bag-shopping'],
  // Education & Work
  'school': ['school','graduation-cap','chalkboard'],
  'university': ['building-columns','graduation-cap'],
  'education': ['graduation-cap','book','school'],
  'book': ['book','book-open'],
  'reading': ['book-open','book-open-reader'],
  'learn': ['graduation-cap','book','lightbulb'],
  'study': ['book-open','pen','graduation-cap'],
  'work': ['briefcase','building','laptop'],
  'office': ['building','briefcase'],
  'job': ['briefcase','handshake'],
  'meeting': ['people-group','handshake','video'],
  'team': ['people-group','users'],
  'person': ['person','user','user-circle'],
  'user': ['user','user-circle','user-tie'],
  'people': ['people-group','users','person'],
  'news': ['newspaper','rss'],
  'blog': ['blog','pen-nib'],
  'write': ['pen','pen-nib','pencil'],
  'edit': ['pencil','pen','file-pen'],
  'search': ['magnifying-glass'],
  'settings': ['gear','sliders','wrench'],
  'tools': ['wrench','screwdriver','toolbox','hammer'],
  'build': ['hammer','screwdriver-wrench'],
  'home': ['house','home'],
  'house': ['house'],
  'map': ['map','location-dot','compass'],
  'location': ['location-dot','map-pin'],
  'travel': ['plane','car','globe'],
  'plane': ['plane','paper-plane'],
  'flight': ['plane'],
  'car': ['car','car-side','truck','motorcycle','taxi'],
  'bike': ['bicycle','motorcycle'],
  'truck': ['truck'],
  'ship': ['ship','sailboat','ferry'],
  'train': ['train'],
  // Health & Life
  'health': ['heart-pulse','stethoscope','kit-medical'],
  'medical': ['kit-medical','hospital','stethoscope'],
  'hospital': ['hospital','kit-medical'],
  'heart': ['heart'],
  'food': ['utensils','burger','pizza-slice'],
  'restaurant': ['utensils','fork-knife'],
  'pizza': ['pizza-slice'],
  'coffee': ['mug-hot','mug-saucer'],
  'drink': ['wine-glass','beer-mug-empty'],
  'sport': ['football','basketball','soccer-ball'],
  'fitness': ['dumbbell','person-running'],
  'gym': ['dumbbell'],
  'nature': ['tree','leaf','mountain'],
  'weather': ['sun','cloud','snowflake'],
  'star': ['star','star-half'],
  'fire': ['fire','fire-flame-curved'],
  'lightning': ['bolt','zap'],
  'gift': ['gift','box'],
  'party': ['champagne-glasses','party-horn'],
  'flag': ['flag'],
  'award': ['award','trophy','medal'],
  'trophy': ['trophy'],
  // Misc
  'sun': ['sun','sun-plant-wilt'],
  'moon': ['moon','cloud-moon'],
  'eye': ['eye','eye-slash','binoculars'],
  'bug': ['bug','bugs'],
  'warning': ['triangle-exclamation'],
  'info': ['circle-info'],
  'help': ['circle-question'],
  'lock': ['lock','lock-open'],
  'key': ['key'],
  'share': ['share','share-nodes'],
  'download': ['download','cloud-arrow-down'],
  'upload': ['upload','cloud-arrow-up'],
  'trash': ['trash','trash-can'],
  'plus': ['plus','circle-plus'],
  'minus': ['minus','circle-minus'],
  'check': ['check','circle-check'],
  'close': ['xmark','circle-xmark'],
  'arrow': ['arrow-right','arrow-left','arrow-up','arrow-down'],
  'refresh': ['arrows-rotate'],
  'sync': ['arrows-rotate','cloud-arrow-up'],
  'print': ['print'],
  'qr': ['qrcode'],
  'barcode': ['barcode'],
  'tag': ['tag','tags'],
  'label': ['tag'],
  'comment': ['comment','comments'],
  'chat': ['comments','message'],
  'notification': ['bell','bell-slash'],
  'alarm': ['bell','clock'],
  'idea': ['lightbulb'],
  'tip': ['lightbulb'],
  'magic': ['magic-wand-sparkles','wand-magic'],
  'filter': ['filter'],
  'sort': ['arrow-down-wide-short'],
  'grid': ['border-all','table-cells'],
  'table': ['table','border-all'],
  'image': ['image','images','photo-film'],
  'archive': ['box-archive'],
  'clipboard': ['clipboard','clipboard-check'],
  'pin': ['thumbtack'],
  'at': ['at'],
  'hashtag': ['hashtag'],
};


function renderIconGrid(){
    const raw=document.getElementById('iconSearch').value.toLowerCase().trim();
    const g=document.getElementById('iconGrid');
    if(!raw){ g.innerHTML=FA_ICONS.slice(0,500).map(ic=>{ const nm=ic.replace(/^fa-(solid|regular|brands)\s+fa-/,'').replace(/-/g,' '); return `<div class="ibox ${S.selIcon===ic?'sel':''}" data-wm-click="192" data-wm-click-0="${jsArg(ic)}" title="${nm}"><i class="${ic}"></i></div>`; }).join(''); return; }

    // Split query into words for multi-word support (e.g. "tv movie")
    const words = raw.split(/\s+/).filter(Boolean);

    const scoreMap = new Map();
    const addScore = (ic, pts) => scoreMap.set(ic, (scoreMap.get(ic)||0) + pts);

    words.forEach(q => {
        // 1. Alias matches
        Object.entries(ICON_ALIASES).forEach(([keyword, names]) => {
            if(keyword === q || keyword.startsWith(q) || q.startsWith(keyword) || keyword.includes(q)){
                names.forEach(n => FA_ICONS.forEach(ic => { if(ic.includes(n)) addScore(ic, keyword===q ? 10 : 6); }));
            }
        });
        // 2. Direct icon name match
        FA_ICONS.forEach(ic => {
            const name = ic.replace(/^fa-(solid|regular|brands|light)\s+fa-/,'');
            const nameSpaced = name.replace(/-/g,' ');
            if(name === q || nameSpaced === q)           addScore(ic, 12);
            else if(name.startsWith(q))                  addScore(ic, 8);
            else if(name.includes(q) || nameSpaced.includes(q)) addScore(ic, 5);
        });
    });

    // If multi-word, only keep icons that matched ALL words
    let filtered;
    if(words.length > 1){
        // For each icon, check it got score from every word
        const perWordSets = words.map(q => {
            const s = new Set();
            Object.entries(ICON_ALIASES).forEach(([keyword, names]) => {
                if(keyword===q||keyword.startsWith(q)||q.startsWith(keyword)||keyword.includes(q)){
                    names.forEach(n => FA_ICONS.forEach(ic => { if(ic.includes(n)) s.add(ic); }));
                }
            });
            FA_ICONS.forEach(ic => {
                const name=ic.replace(/^fa-(solid|regular|brands|light)\s+fa-/,'');
                if(name.includes(q)||name.replace(/-/g,' ').includes(q)) s.add(ic);
            });
            return s;
        });
        // Union all sets (any word match counts)
        const union = new Set();
        perWordSets.forEach(s => s.forEach(ic => union.add(ic)));
        filtered = [...scoreMap.entries()].filter(([ic])=>union.has(ic)).sort((a,b)=>b[1]-a[1]).map(([ic])=>ic);
    } else {
        filtered = [...scoreMap.entries()].sort((a,b)=>b[1]-a[1]).map(([ic])=>ic);
    }

    if(!filtered.length){
        g.innerHTML='<div style="grid-column:1/-1;text-align:center;padding:20px;color:var(--text-dim);font-size:13px;">No icons found. Try: globe, film, camera, tv, music, code…</div>';
        return;
    }
    g.innerHTML=filtered.slice(0,500).map(ic=>{
        const nm=ic.replace(/^fa-(solid|regular|brands)\s+fa-/,'').replace(/-/g,' ');
        return `<div class="ibox ${S.selIcon===ic?'sel':''}" data-wm-click="192" data-wm-click-0="${jsArg(ic)}" title="${nm}"><i class="${ic}"></i></div>`;
    }).join('');
}

function selIcon(ic){ S.selIcon=ic; renderIconGrid(); }
function saveIconSel(){
    updIPreview();
    // Temporarily suppress the _returnToFolders redirect so that closing the
    // icon picker doesn't exit the folderModal — we want to stay in folderModal.
    const savedReturnToFolders = typeof _returnToFolders !== 'undefined' ? _returnToFolders : false;
    const savedReturnToSettings = typeof _returnToSettings !== 'undefined' ? _returnToSettings : false;
    _returnToFolders = false;
    _returnToSettings = false;
    closeModal('iconPickerModal');
    // Restore the flags so that closing folderModal still returns correctly.
    _returnToFolders = savedReturnToFolders;
    _returnToSettings = savedReturnToSettings;
}
function updIPreview(){ document.getElementById('iPreview').innerHTML=`<i class="${S.selIcon}" style="color:${S.selColor};font-size:22px;"></i>`; }

function renderCPick(){
    document.getElementById('cPick').innerHTML=COLORS.map(c=>`<div class="dot ${S.selColor===c?'active':''}" style="background:${c};" data-wm-click="193" data-wm-click-0="${jsArg(c)}"></div>`).join('');
}
function selColor(c){ S.selColor=c; renderCPick(); updIPreview(); }

// TAGS
function openTagsEdit(){
    const l=S.links.find(x=>x.id===S.editingLink);
    document.getElementById('tagsInput').value=l?(l.tags||[]).join(', '):'';
    openModal('tagsModal');
}
function saveTags(){
    const l=S.links.find(x=>x.id===S.editingLink);
    if(l){ l.tags=document.getElementById('tagsInput').value.split(',').map(t=>t.trim()).filter(t=>t); save(); document.getElementById('dtTagBadge').textContent=l.tags.join(', ')||'No tags'; markChanged(); }
    closeModal('tagsModal');
}

// ── NEW SORT SYSTEM ──
S._sortMode = wmStorage.getItem('ly_sortMode') || 'date';
S._sourceMode = wmStorage.getItem('ly_sourceMode') || 'personal'; // 'all', 'personal', 'browser-chrome', etc.

// ── SOURCE DROPDOWN ──
function browserName(value) {
    const normalized = typeof value === 'string' ? value.trim().toLowerCase() : '';
    return Object.keys(_IMP_BROWSER_META).find(name=>name.toLowerCase()===normalized) || null;
}

function bookmarkBrowser(bookmark, folders) {
    if (bookmark.imported === false) return null;
    if (bookmark.importedFrom) return browserName(bookmark.importedFrom) || 'Other';
    const folder = folders.get(bookmark.fId);
    if (folder?._importBrowser) return browserName(folder._importBrowser) || 'Other';
    return bookmark.imported ? 'Other' : null;
}

function bookmarkSourceKey(bookmark,folders) {
    return JSON.stringify([bookmarkBrowser(bookmark,folders),wmURL(bookmark.url)]);
}

function sourceMatches(bookmark, mode, folders) {
    const browser = bookmarkBrowser(bookmark,folders);
    if(browser&&(S.settings?.hideImported||S.settings?.hiddenBrowsers?.some(name=>browserName(name)===browser)))return false;
    if (mode === 'personal') return browser === null;
    if (mode === 'imported') return browser !== null;
    if (mode.startsWith('browser-')) return browser?.toLowerCase() === mode.slice(8);
    return true;
}

const sourceLabels = {
    en:['Source','All Bookmarks','Personal','Imported','Other Browser'],
    it:['Origine','Tutti i segnalibri','Personali','Importati','Altro browser'],
    fr:['Source','Tous les favoris','Personnels','Importés','Autre navigateur'],
    es:['Origen','Todos los marcadores','Personales','Importados','Otro navegador'],
    ar:['المصدر','كل الإشارات المرجعية','شخصية','مستوردة','متصفح آخر'],
};

function sourceOptions() {
    const labels = sourceLabels[S.lang] || sourceLabels.en;
    const [,all,personal,imported] = labels;
    return [
        {key:'all',label:all,icon:'fa-solid fa-layer-group',color:'#8b5cf6'},
        {key:'personal',label:personal,icon:'fa-solid fa-bookmark',color:'#22c55e'},
        ...Object.keys(_IMP_BROWSER_META).map(name=>({
            ...browserSource(name),key:'browser-'+name.toLowerCase()
        })),
        {key:'imported',label:imported,icon:'fa-solid fa-file-import',color:'#2563eb'},
    ];
}

function browserSource(browser) {
    return {..._IMP_BROWSER_META[browser], label:browser==='Other' ?
        (sourceLabels[S.lang] || sourceLabels.en)[4] : browser};
}

function browserSourceBadge(bookmark, folders) {
    if (S.settings?.showImportedBadge === false) return '';
    const browser = bookmarkBrowser(bookmark,folders);
    if (!browser) return '';
    const {icon,color,label} = browserSource(browser);
    return '<span class="badge wm-browser-badge"><i class="'+icon+
        '" style="color:'+color+'" aria-hidden="true"></i> '+esc(label)+'</span>';
}

function sourceFoldersForHome(folders, links, mode) {
    const folderMap = new Map(folders.map(folder=>[folder.id,folder]));
    const populated = new Set(links.filter(bookmark=>!bookmark.archived &&
        sourceMatches(bookmark,mode,folderMap)).map(bookmark=>bookmark.fId));
    return folders.filter(folder=>populated.has(folder.id) ||
        (!folder._browserImport && !folder._importBrowser && (mode==='personal' || mode==='all')));
}

function toggleSourceDD(){
    const dd = document.getElementById('sourceDD');
    const open = !dd.classList.contains('open');
    closeAllDropdowns();
    if (!open) return;
    renderSourceBrowsers();
    dd.classList.add('open');
    dd.style.left = '0px';
    const rect = dd.getBoundingClientRect();
    dd.style.left = Math.min(0,window.innerWidth-8-rect.right) +
        Math.max(0,8-rect.left) + 'px';
    updateSourceChecks();
    dd.scrollTop=0;
}

function renderSourceBrowsers(){
    const menu = document.getElementById('sourceDD');
    const folders = new Map(S.folders.map(folder=>[folder.id,folder]));
    const counts = new Map();
    const active = S.links.filter(bookmark=>!bookmark.archived);
    for (const bookmark of active) {
        const browser = bookmarkBrowser(bookmark,folders);
        const key = browser ? 'browser-' + browser.toLowerCase() : 'personal';
        counts.set(key,(counts.get(key)||0)+1);
    }
    counts.set('all',active.filter(bookmark=>sourceMatches(bookmark,'all',folders)).length);
    counts.set('imported',active.length-(counts.get('personal')||0));
    menu.replaceChildren();
    for (const option of sourceOptions()) {
        const count = counts.get(option.key) || 0;
        if(option.key.startsWith('browser-')&&count===0)continue;
        const button = document.createElement('button');
        button.type='button';
        button.className='vopt wm-source-option';
        button.setAttribute('aria-pressed',String(option.key===(S._sourceMode||'personal')));
        button.innerHTML='<i class="' + option.icon + '" style="color:' + option.color +
            '" aria-hidden="true"></i><span>' + esc(option.label) +
            '</span><span class="wm-source-count">' + count + '</span>' +
            '<i class="fa-solid fa-check wm-source-check" aria-hidden="true"></i>';
        button.addEventListener('click',()=>{
            setSourceMode(option.key);
            document.getElementById('sourceBtn')?.focus({preventScroll:true});
        });
        menu.append(button);
    }
}

function setSourceMode(mode){
    if (!sourceOptions().some(option=>option.key===mode)) return;
    S._sourceMode = mode;
    wmStorage.setItem('ly_sourceMode', mode);
    closeAllDropdowns();
    updateSourceChecks();
    if(typeof S.activeTab==='number') {
        switchTab('all');
        return;
    }
    renderTabs();
    renderLinks();
}

// Restore sort button state on load
(function(){
    const mode = S._sortMode;
    if(mode.startsWith('browser-')){
        const browserColors={'browser-chrome':'#4285f4','browser-safari':'#006cff','browser-firefox':'#ff7139','browser-edge':'#0078d4','browser-opera':'#ff1b2d'};
        const browserIcons={'browser-chrome':'fa-brands fa-chrome','browser-safari':'fa-brands fa-safari','browser-firefox':'fa-brands fa-firefox','browser-edge':'fa-brands fa-edge','browser-opera':'fa-brands fa-opera'};
        setTimeout(()=>{
            const icon=document.getElementById('sortDateIcon');
            const btn=document.getElementById('sortBtn');
            if(icon){ icon.className=browserIcons[mode]||'fa-solid fa-arrow-down-wide-short'; icon.style.color=browserColors[mode]||'var(--primary)'; }
            if(btn) btn.style.borderColor=browserColors[mode]||'var(--primary)';
        },0);
    }
})();

function toggleSortDD(){
    closeAllDropdowns();
    const dd = document.getElementById('sortDD');
    if(dd){
        const isOpen = dd.classList.contains('open');
        dd.classList.toggle('open');
        if(!isOpen){ renderSortBrowsers(); updateSortChecks(); }
    }
}

function renderSortBrowsers(){
    const container = document.getElementById('sortDD-browsers');
    if(!container) return;

    const BROWSER_META = {
        'Chrome':  { icon:'fa-brands fa-chrome',  color:'#4285f4', key:'browser-chrome'  },
        'Firefox': { icon:'fa-brands fa-firefox',  color:'#ff7139', key:'browser-firefox' },
        'Safari':  { icon:'fa-brands fa-safari',   color:'#006cff', key:'browser-safari'  },
        'Edge':    { icon:'fa-brands fa-edge',     color:'#0078d4', key:'browser-edge'    },
        'Opera':   { icon:'fa-brands fa-opera',    color:'#ff1b2d', key:'browser-opera'   },
        'Brave':   { icon:'fa-solid fa-shield-halved', color:'#FB542B', key:'browser-brave' },
    };

    // Collect which browsers actually have imported bookmarks
    const presentBrowsers = new Set();
    S.links.forEach(l => {
        if(l.importedFrom && BROWSER_META[l.importedFrom]) presentBrowsers.add(l.importedFrom);
    });
    // Also check folder-level browser tags
    S.folders.forEach(f => {
        if(f._importBrowser && BROWSER_META[f._importBrowser]){
            const hasLinks = S.links.some(l => l.fId === f.id);
            if(hasLinks) presentBrowsers.add(f._importBrowser);
        }
    });

    if(presentBrowsers.size === 0){ container.innerHTML=''; return; }

    const browserOrder = ['Chrome','Firefox','Safari','Edge','Opera','Brave'];
    const present = browserOrder.filter(b => presentBrowsers.has(b));

    container.innerHTML = `
        <div style="padding:6px 14px 4px;font-size:10px;font-weight:700;color:var(--text-dim);text-transform:uppercase;letter-spacing:.5px;border-top:1px solid var(--border);margin-top:4px;">Browser</div>
        ${present.map(b => {
            const m = BROWSER_META[b];
            return `<div class="vopt" id="sopt-${m.key}" data-wm-click="194" data-wm-click-0="${jsArg(m.key)}">
                <i class="${m.icon}" style="color:${m.color};"></i> ${b}
                <span class="vchk" id="schk-${m.key}" style="margin-left:auto;color:var(--primary);display:${S._sortMode===m.key?'inline':'none'};"><i class="fa-solid fa-check"></i></span>
            </div>`;
        }).join('')}`;
}
function closeAllDropdowns(){
    document.getElementById('sourceBtn')?.setAttribute('aria-expanded','false');
    ['sortDD','folderFilterDD','tagDD','viewDD','sourceDD'].forEach(id=>{
        const d=document.getElementById(id); if(d) d.classList.remove('open');
    });
}
function setSortMode(mode){
    S._sortMode = mode;
    wmStorage.setItem('ly_sortMode', mode);
    S.activeTab = 'all';
    const icon = document.getElementById('sortDateIcon');
    const btn  = document.getElementById('sortBtn');
    const isManual = (mode === 'manual');
    const isDefault = (mode === 'date' || mode === 'name');
    const activeColor = isManual ? '#f97316' : (isDefault ? 'var(--text-dim)' : 'var(--primary)');
    if(icon){ icon.className = 'fa-solid fa-arrow-down-wide-short'; icon.style.color = activeColor; }
    if(btn) btn.style.borderColor = isDefault ? 'var(--border)' : activeColor;
    updateSortChecks();
    document.getElementById('sortDD')?.classList.remove('open');
    renderTabs();
    renderLinks();
}
function updateSortChecks(){
    ['manual','date','visits','last','folder','name','personal'].forEach(m=>{
        const el = document.getElementById('schk-'+m);
        if(el) el.style.display = (S._sortMode===m) ? 'inline' : 'none';
    });
    // Dynamic browser entries
    ['browser-chrome','browser-safari','browser-firefox','browser-edge','browser-opera','browser-brave'].forEach(m=>{
        const el = document.getElementById('schk-'+m);
        if(el) el.style.display = (S._sortMode===m) ? 'inline' : 'none';
    });
}
// Backward compat
function toggleSortDate(){ setSortMode(S._sortMode==='date'?'name':'date'); }
function updateSortDateBtn(){ updateSortChecks(); }

function _fmtDate(ts){
    if(!ts) return '';
    try {
        const d = new Date(ts);
        if(isNaN(d)) return '';
        const months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
        return months[d.getMonth()]+' '+d.getDate()+', '+d.getFullYear();
    } catch(e){ return ''; }
}

// LINK ACTIONS
function toggleFav(id){ const l=S.links.find(x=>x.id===id); if(l){l.fav=!l.fav;save();renderLinks();renderTabs();updateNavCounters();} }
function toggleVip(id) {
    const link = S.links.find(item=>item.id===id);
    if (!link) return;
    link.vip = link.vip!==true;
    save();
    renderLinks();
    updateNavCounters();
    showToast(T(link.vip?'vipAdded':'vipRemoved'),'#b77908');
}
function toggleArchive(id){ const l=S.links.find(x=>x.id===id); if(l){l.archived=!l.archived;save();init();} }
function toggleArchiveById(id){ toggleArchive(id); showToast(S.links.find(x=>x.id===id)?.archived?'Archived':'Unarchived','#3b82f6'); }
function togglePin(id){ const l=S.links.find(x=>x.id===id); if(l){l.pinned=!l.pinned;save();renderLinks();} }
function shareCard(url,title){ if(navigator.share) navigator.share({title,url}); else wmCopy(url).then(()=>alert('Link copied!')); }
function deleteLink(id){ requireDeletePassword(()=>{ 
    const link = S.links.find(x=>x.id===id);
    if(link){ 
        if(!S.trash) S.trash=[];
        S.trash.unshift({...link, deletedAt: Date.now()}); 
    }
    S.links=S.links.filter(x=>x.id!==id); 
    save(); init(); 
    showToast('Moved to trash','#ef4444');
}); }
function deleteCurrent(){ requireDeletePassword(()=>{ deleteLink(S.editingLink); closeModal('editDetailModal'); }); }

// TRASH BIN
function openTrashModal(){
    closeModal('settingsModal');
    renderTrashModal();
    openModal('trashModal');
}
function renderTrashModal(){
    const list = document.getElementById('trashList');
    if(!list) return;
    const trash = S.trash||[];
    if(!trash.length){
        list.innerHTML = '<div style="text-align:center;padding:40px 20px;opacity:.4;"><i class="fa-solid fa-trash-can" style="font-size:48px;display:block;margin-bottom:12px;"></i><div>Trash is empty</div></div>';
        return;
    }
    list.innerHTML = trash.map((l,i) => {
        const ago = formatTrashDate(l.deletedAt);
        const thumb = l.logo ? `<img src="${esc(l.logo)}" style="width:100%;height:100%;object-fit:cover;" data-wm-error="195">` : `<i class="fa-solid fa-link" style="font-size:18px;color:var(--text-dim);"></i>`;
        return `<div style="display:flex;align-items:center;gap:12px;padding:12px 0;border-bottom:1px solid var(--border);">
            <div style="width:44px;height:44px;border-radius:10px;background:var(--card2,#f4f4f5);border:1px solid var(--border);flex-shrink:0;display:flex;align-items:center;justify-content:center;overflow:hidden;">${thumb}</div>
            <div style="flex:1;min-width:0;">
                <div style="font-size:14px;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${esc(l.title||l.url||'Untitled')}</div>
                <div style="font-size:11px;color:var(--text-dim);margin-top:2px;">Deleted ${ago}</div>
            </div>
            <div style="display:flex;gap:6px;flex-shrink:0;">
                <button data-wm-click="196" data-wm-click-0="${i}" style="background:rgba(34,197,94,.15);color:#4ade80;border:1px solid rgba(34,197,94,.3);border-radius:8px;padding:5px 10px;font-size:12px;font-weight:600;cursor:pointer;" title="Restore"><i class="fa-solid fa-rotate-left"></i></button>
                <button data-wm-click="197" data-wm-click-0="${i}" style="background:rgba(239,68,68,.12);color:#ef4444;border:1px solid rgba(239,68,68,.25);border-radius:8px;padding:5px 10px;font-size:12px;font-weight:600;cursor:pointer;" title="Delete permanently"><i class="fa-solid fa-xmark"></i></button>
            </div>
        </div>`;
    }).join('');
}
function formatTrashDate(ts){
    if(!ts) return 'unknown';
    const diff = Date.now()-ts;
    const mins = Math.floor(diff/60000);
    if(mins<1) return 'just now';
    if(mins<60) return mins+'m ago';
    const hrs = Math.floor(mins/60);
    if(hrs<24) return hrs+'h ago';
    const days = Math.floor(hrs/24);
    return days+'d ago';
}
function restoreFromTrash(i){
    if(!S.trash||!S.trash[i]) return;
    const item = S.trash.splice(i,1)[0];
    delete item.deletedAt;
    S.links.unshift(item);
    save(); init();
    renderTrashModal();
    showToast('Bookmark restored!','var(--primary)');
}
function permanentDelete(i){
    if(!S.trash||!S.trash[i]) return;
    if(!confirm('Permanently delete this bookmark? This cannot be undone.')) return;
    S.trash.splice(i,1);
    save();
    renderTrashModal();
    showToast('Permanently deleted','#ef4444');
}
function emptyTrash(){
    if(!(S.trash&&S.trash.length)) return;
    if(!confirm('Empty trash? All '+S.trash.length+' items will be permanently deleted.')) return;
    S.trash=[];
    save();
    renderTrashModal();
    showToast('Trash emptied','#ef4444');
}
function openShareOptions(){ openModal('shareModal'); }
function openContact(){ openModal('contactModal'); }

function shareFormat(type){
    let org=S.folders.map(f=>({name:f.name,links:S.links.filter(l=>l.fId===f.id&&!l.archived)}));
    let unf=S.links.filter(l=>!l.fId&&!l.archived);
    if(unf.length) org.push({name:'Unsorted',links:unf});
    org=org.filter(g=>g.links.length>0);

    if(type==='copy'){
        let t='=== WEBMARK BOOKMARKS ===\n\n';
        org.forEach(g=>{ t+=`\n── ${g.name.toUpperCase()} (${g.links.length}) ──\n`; g.links.forEach(l=>{t+=`• ${l.title}\n  ${l.url}\n`;});});
        wmCopy(t).then(()=>alert('Copied!'));

    } else if(type==='excel'){
        try {
            // Helper: strip all control chars and XML-unsafe chars that break Excel
            function _xlClean(s){
                if(!s) return '';
                return String(s)
                    .replace(/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/g,'') // control chars
                    .replace(/[\uFFFE\uFFFF]/g,'')                           // BOM variants
                    .replace(/[\uD800-\uDFFF]/g,'')                           // lone surrogates
                    .trim();
            }
            const wb = XLSX.utils.book_new();
            // Single "All Bookmarks" sheet only — multiple sheets increase corruption risk
            const allRows = [];
            S.links.filter(l=>!l.archived).forEach(l => {
                const folder = S.folders.find(f=>f.id===l.fId);
                allRows.push({
                    Folder:      _xlClean(folder ? folder.name : 'Unsorted'),
                    Title:       _xlClean(l.title),
                    URL:         _xlClean(l.url),
                    Description: _xlClean(l.desc),
                    Tags:        _xlClean((l.tags||[]).join(', ')),
                    Favorite:    l.fav ? 'Yes' : 'No',
                    Views:       Number(l.views)||0,
                    Saved:       WebMarkSyncCore.bookmarkDate(l) ? _xlClean(new Date(WebMarkSyncCore.bookmarkDate(l)).toLocaleDateString('en-GB')) : ''
                });
            });
            const ws = XLSX.utils.json_to_sheet(allRows);
            ws['!cols'] = [{wch:18},{wch:38},{wch:55},{wch:45},{wch:25},{wch:9},{wch:7},{wch:13}];
            XLSX.utils.book_append_sheet(wb, ws, 'Bookmarks');
            // Use arraybuffer output to avoid binary string issues
            const wbout = XLSX.write(wb, {bookType:'xlsx', type:'array'});
            const blob = new Blob([wbout], {type:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'});
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url; a.download = 'WebMark_Bookmarks.xlsx';
            document.body.appendChild(a); a.click();
            setTimeout(()=>{ document.body.removeChild(a); URL.revokeObjectURL(url); }, 500);
            showToast('✅ Excel exported — '+allRows.length+' bookmarks','var(--primary)');
        } catch(err) {
            alert('Excel export failed: '+err.message);
        }
} else if(type==='pdf'){
        const {jsPDF}=window.jspdf;
        const doc=new jsPDF({orientation:'portrait',unit:'mm',format:'a4',compress:true});

        // ── Arabic / Unicode detection ──────────────────────────────────────
        function hasArabic(str){ return /[\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF\uFB50-\uFDFF\uFE70-\uFEFF]/.test(str||''); }

        // ── High-quality canvas renderer (fixes stretched/blurry font) ──────
        // DPI: render at 2× for sharpness, then place at real mm size in PDF.
        const SCALE = 2;          // retina multiplier
        const MM_TO_PT = 2.835;   // 1 mm ≈ 2.835 pt
        const PT_TO_PX = 1.333;   // 1 pt ≈ 1.333 px at 96 dpi

        // Measure text width in mm using a shared off-screen canvas
        const _mCanvas = document.createElement('canvas');
        const _mCtx = _mCanvas.getContext('2d');
        function measureTextMm(text, fontCss){
            _mCtx.font = fontCss;
            return (_mCtx.measureText(text).width / (PT_TO_PX * MM_TO_PT));
        }

        // Word-wrap: split `text` into lines that fit within `maxW` mm
        function wrapText(text, maxW, fontCss){
            if(!text) return [];
            const words = text.split(/\s+/);
            const lines = [];
            let cur = '';
            for(const w of words){
                const test = cur ? cur+' '+w : w;
                if(measureTextMm(test, fontCss) > maxW && cur){
                    lines.push(cur);
                    cur = w;
                } else {
                    cur = test;
                }
            }
            if(cur) lines.push(cur);
            return lines.length ? lines : [text];
        }

        // Render ONE line of text onto a canvas image and place it in the PDF.
        // Returns the height consumed in mm.
        function renderLine(text, x, y, opts){
            if(!text || !text.trim()) return 0;
            const fontSize = opts.fontSize || 9;          // in pt
            const color    = opts.color    || [30,30,30];
            const bold     = opts.bold     || false;
            const maxW     = opts.maxW     || 172;        // mm available
            const isAr     = hasArabic(text);

            // Real pixel dimensions of the line image
            const lineHmm  = fontSize * 0.45 + 1.2;      // mm height for one line
            const canvasW  = Math.round(maxW  * MM_TO_PT * PT_TO_PX * SCALE);
            const canvasH  = Math.round(lineHmm * MM_TO_PT * PT_TO_PX * SCALE);

            const cv  = document.createElement('canvas');
            cv.width  = canvasW;
            cv.height = canvasH;
            const ctx = cv.getContext('2d');
            ctx.clearRect(0, 0, canvasW, canvasH);

            const pxSize   = Math.round(fontSize * PT_TO_PX * SCALE);
            const fontCss  = (bold ? 'bold ' : '') + pxSize + 'px "Segoe UI",Arial,sans-serif';
            ctx.font       = fontCss;
            ctx.fillStyle  = `rgb(${color[0]},${color[1]},${color[2]})`;
            ctx.direction  = isAr ? 'rtl' : 'ltr';
            ctx.textBaseline = 'middle';
            const drawX    = isAr ? canvasW - 4 : 4;
            ctx.fillText(text, drawX, canvasH / 2);

            const imgData = cv.toDataURL('image/png');
            // Place image at exact mm dimensions (no stretching)
            doc.addImage(imgData, 'PNG', x, y, maxW, lineHmm, undefined, 'FAST');
            return lineHmm;
        }

        // ── Page-break helper ────────────────────────────────────────────────
        // Single source of truth: all y updates flow through here.
        const PAGE_BOTTOM = 278;
        const PAGE_TOP    = 14;
        function checkY(curY, neededH){
            if(curY + neededH > PAGE_BOTTOM){ doc.addPage(); return PAGE_TOP; }
            return curY;
        }

        // Estimate block height (no drawing) for pre-flight page-break decisions.
        function estimateH(text, opts){
            if(!text || !text.trim()) return 0;
            const fontSize = opts.fontSize || 9;
            const bold     = opts.bold     || false;
            const maxW     = opts.maxW     || 172;
            const lineGap  = fontSize * 0.45 + 1.7;
            const fontCss  = (bold?'bold ':'')+Math.round(fontSize * PT_TO_PX * SCALE)+'px "Segoe UI",Arial,sans-serif';
            return wrapText(text, maxW - 2, fontCss).length * lineGap;
        }

        // Render wrapped multi-line block. Takes curY, returns updated y.
        function addTextBlock(text, x, curY, opts){
            if(!text || !text.trim()) return curY;
            const fontSize = opts.fontSize || 9;
            const bold     = opts.bold     || false;
            const maxW     = opts.maxW     || 172;
            const lineHmm  = fontSize * 0.45 + 1.2;
            const lineGap  = lineHmm + 0.5;
            const fontCss  = (bold?'bold ':'')+Math.round(fontSize * PT_TO_PX * SCALE)+'px "Segoe UI",Arial,sans-serif';
            const lines    = wrapText(text, maxW - 2, fontCss);
            for(const line of lines){
                curY = checkY(curY, lineGap);
                renderLine(line, x, curY, {...opts, maxW});
                curY += lineGap;
            }
            return curY;
        }

        // ── PDF Header ───────────────────────────────────────────────────────
        let y = 12;
        y = addTextBlock('WebMark — Bookmarks', 13, y, {fontSize:18, color:[34,197,94], bold:true, maxW:184});
        y = addTextBlock('Generated: '+new Date().toLocaleDateString(), 13, y + 1, {fontSize:9, color:[120,120,120], maxW:120});
        y += 5;

        org.forEach(g => {
            if(!g.links.length) return;

            // ── Folder header: keep with at least first bookmark (orphan guard) ──
            y = checkY(y, 24);
            doc.setFillColor(139, 92, 246);
            doc.roundedRect(12, y, 186, 9, 2, 2, 'F');
            y = addTextBlock(g.name + ' (' + g.links.length + ')', 15, y + 1.2,
                {fontSize:10.5, color:[255,255,255], bold:true, maxW:178});
            y += 3;

            g.links.forEach(l => {
                const title = (l.title || '(no title)');

                // ── Pre-flight: ensure room for title + url before drawing anything ──
                const titleH = estimateH('• ' + title, {fontSize:9.5, bold:true, maxW:176});
                y = checkY(y, titleH + 6);

                // ── Bookmark title ───────────────────────────────────────────
                y = addTextBlock('• ' + title, 14, y,
                    {fontSize:9.5, color:[20,20,20], bold:true, maxW:176});

                // ── URL ──────────────────────────────────────────────────────
                const safeUrl  = (l.url || '').slice(0, 120);
                doc.setFont('helvetica', 'normal');
                doc.setFontSize(7.5);
                doc.setTextColor(80, 100, 200);
                const urlLines = doc.splitTextToSize(safeUrl, 166);
                y = checkY(y, urlLines.length * 3.8 + 2);
                doc.text(urlLines, 18, y + 2.5);
                y += urlLines.length * 3.8 + 1.5;

                // ── Description ──────────────────────────────────────────────
                if(l.desc && l.desc.trim()){
                    const dH = estimateH(l.desc.trim(), {fontSize:8, maxW:168});
                    y = checkY(y, Math.min(dH, 8));
                    y = addTextBlock(l.desc.trim(), 18, y, {fontSize:8, color:[80,80,80], maxW:168});
                    y += 0.5;
                }

                // ── Arabic description ───────────────────────────────────────
                if(l.descAr && l.descAr.trim() && l.descAr !== l.desc){
                    const dH = estimateH(l.descAr.trim(), {fontSize:8, maxW:168});
                    y = checkY(y, Math.min(dH, 8));
                    y = addTextBlock(l.descAr.trim(), 18, y, {fontSize:8, color:[80,100,80], maxW:168});
                    y += 0.5;
                }

                // ── Tags ─────────────────────────────────────────────────────
                if(l.tags && l.tags.length){
                    y = checkY(y, 6);
                    y = addTextBlock('🏷 ' + l.tags.join(', '), 18, y,
                        {fontSize:7.5, color:[140,70,200], maxW:168});
                }

                y += 2.5; // gap between bookmarks
            });

            y += 4; // gap between folders
        });

        // ── Page numbers ─────────────────────────────────────────────────────
        const pageCount = doc.internal.getNumberOfPages();
        for(let i = 1; i <= pageCount; i++){
            doc.setPage(i);
            doc.setFont('helvetica', 'normal');
            doc.setFontSize(8);
            doc.setTextColor(160, 160, 160);
            doc.text('WebMark  |  Page ' + i + ' / ' + pageCount, 14, 291);
        }
        wmDownload('WebMark_Bookmarks.pdf', doc.output('arraybuffer'), 'application/pdf');
    }
    closeModal('shareModal');
}

function showHelp(){
    const existing = document.getElementById('helpModal');
    if(existing) existing.remove();
    const isAr = S.lang==='ar';
    const dir = isAr ? 'rtl' : 'ltr';
    const HL = {
        en:{ title:'Help & Guide', gestures:'⚡ Quick Gestures', tap:'Tap a bookmark → view & edit details', open:'Tap 🔗 icon (top right) → open the link', actions:'♥ Pin ↑ Copy buttons under thumbnail', reminder:'🔔 Set Reminder — How it works', reminderDesc:'When you open a bookmark and tap <b style="color:#a78bfa;">Set Reminder</b>, you pick a <b>date and time</b>. At that exact moment the app sends you a <b>browser notification</b>:', reminderEx:'⏰ WebMark Reminder: [bookmark title]', reminderUse:'Example uses:', reminderU1:'Save an article → remind yourself at 8pm tonight', reminderU2:'Save a product → remind on payday', reminderU3:'Save a tool → remind on the weekend', reminderWarn:'⚠️ Limitation: Works only while the browser is open. You must allow notifications when prompted.', folders:'📁 Folders & Tags', foldersT1:'Use the ✏️ pencil next to "All" to enter edit mode — drag to reorder folders AND bookmarks', foldersT2:'The sort ↕ button lets you sort by date, visits, last visited, folder, or name', foldersT3:'Tags are only shown on manually saved bookmarks', backup:'💾 Backup & Import', backupT1:'Export JSON → saves all bookmarks to a file', backupT2:'Import JSON → restores from a backup file', backupT3:'Import HTML → import bookmarks from Chrome/Firefox/Safari/Edge' },
        fr:{ title:'Aide & Guide', gestures:'⚡ Gestes rapides', tap:'Appuyer sur un favori → voir & modifier', open:'Appuyer sur 🔗 (en haut à droite) → ouvrir le lien', actions:'♥ Épingler ↑ Copier sous la vignette', reminder:'🔔 Définir un rappel — Comment ça marche', reminderDesc:'Quand vous ouvrez un favori et appuyez sur <b style="color:#a78bfa;">Définir rappel</b>, vous choisissez une <b>date et heure</b>. À ce moment exact, l\'app envoie une <b>notification</b>:', reminderEx:'⏰ WebMark Rappel: [titre du favori]', reminderUse:'Exemples:', reminderU1:'Sauvegarder un article → rappel ce soir à 20h', reminderU2:'Sauvegarder un produit → rappel le jour de paie', reminderU3:'Sauvegarder un outil → rappel ce week-end', reminderWarn:'⚠️ Limitation: Fonctionne uniquement quand le navigateur est ouvert.', folders:'📁 Dossiers & Étiquettes', foldersT1:'Utilisez ✏️ à côté de "Tout" pour le mode édition — glissez pour réorganiser', foldersT2:'Le bouton tri ↕ permet de trier par date, visites, dossier ou nom', foldersT3:'Les étiquettes sont uniquement sur les favoris sauvegardés manuellement', backup:'💾 Sauvegarde & Import', backupT1:'Exporter JSON → sauvegarde tous vos favoris', backupT2:'Importer JSON → restaurer une sauvegarde', backupT3:'Importer HTML → importer depuis Chrome/Firefox/Safari/Edge' },
        es:{ title:'Ayuda & Guía', gestures:'⚡ Gestos rápidos', tap:'Toca un marcador → ver & editar detalles', open:'Toca 🔗 (arriba a la derecha) → abrir el enlace', actions:'♥ Fijar ↑ Copiar bajo la miniatura', reminder:'🔔 Establecer recordatorio — Cómo funciona', reminderDesc:'Cuando abres un marcador y tocas <b style="color:#a78bfa;">Establecer recordatorio</b>, eliges una <b>fecha y hora</b>. En ese momento exacto la app envía una <b>notificación</b>:', reminderEx:'⏰ WebMark Recordatorio: [título del marcador]', reminderUse:'Ejemplos:', reminderU1:'Guarda un artículo → recuérdame esta noche a las 8pm', reminderU2:'Guarda un producto → recuérdame el día de pago', reminderU3:'Guarda una herramienta → recuérdame el fin de semana', reminderWarn:'⚠️ Limitación: Solo funciona con el navegador abierto.', folders:'📁 Carpetas & Etiquetas', foldersT1:'Usa ✏️ junto a "Todo" para el modo edición — arrastra para reordenar', foldersT2:'El botón orden ↕ permite ordenar por fecha, visitas, carpeta o nombre', foldersT3:'Las etiquetas solo aparecen en marcadores guardados manualmente', backup:'💾 Copia & Importar', backupT1:'Exportar JSON → guarda todos tus marcadores', backupT2:'Importar JSON → restaurar una copia', backupT3:'Importar HTML → importar desde Chrome/Firefox/Safari/Edge' },
        it:{ title:'Aiuto & Guida', gestures:'⚡ Gesti rapidi', tap:'Tocca un segnalibro → visualizza & modifica', open:'Tocca 🔗 (in alto a destra) → apri il link', actions:'♥ Fissa ↑ Copia sotto la miniatura', reminder:'🔔 Imposta promemoria — Come funziona', reminderDesc:'Quando apri un segnalibro e tocchi <b style="color:#a78bfa;">Imposta promemoria</b>, scegli <b>data e ora</b>. In quel momento esatto l\'app invia una <b>notifica</b>:', reminderEx:'⏰ WebMark Promemoria: [titolo del segnalibro]', reminderUse:'Esempi:', reminderU1:'Salva un articolo → ricordami stasera alle 20', reminderU2:'Salva un prodotto → ricordami il giorno di paga', reminderU3:'Salva uno strumento → ricordami nel weekend', reminderWarn:'⚠️ Limitazione: Funziona solo con il browser aperto.', folders:'📁 Cartelle & Tag', foldersT1:'Usa ✏️ accanto a "Tutti" per la modalità modifica — trascina per riordinare', foldersT2:'Il pulsante ordina ↕ permette di ordinare per data, visite, cartella o nome', foldersT3:'I tag appaiono solo sui segnalibri salvati manualmente', backup:'💾 Backup & Importa', backupT1:'Esporta JSON → salva tutti i segnalibri', backupT2:'Importa JSON → ripristina da un backup', backupT3:'Importa HTML → importa da Chrome/Firefox/Safari/Edge' },
        ar:{ title:'المساعدة والدليل', gestures:'⚡ الإيماءات السريعة', tap:'اضغط على إشارة مرجعية ← عرض وتعديل التفاصيل', open:'اضغط على 🔗 (أعلى اليمين) ← فتح الرابط', actions:'♥ تثبيت ↑ نسخ تحت الصورة المصغرة', reminder:'🔔 ضبط تذكير — كيف يعمل', reminderDesc:'عند فتح إشارة مرجعية والضغط على <b style="color:#a78bfa;">ضبط تذكير</b>، تختار <b>تاريخاً ووقتاً</b>. في تلك اللحظة بالضبط يرسل التطبيق <b>إشعاراً</b>:', reminderEx:'⏰ تذكير WebMark: [عنوان الإشارة المرجعية]', reminderUse:'أمثلة:', reminderU1:'احفظ مقالاً ← ذكّرني الليلة الساعة 8 مساءً', reminderU2:'احفظ منتجاً ← ذكّرني يوم الراتب', reminderU3:'احفظ أداةً ← ذكّرني في عطلة نهاية الأسبوع', reminderWarn:'⚠️ قيد: يعمل فقط عندما يكون المتصفح مفتوحاً.', folders:'📁 المجلدات والوسوم', foldersT1:'استخدم ✏️ بجانب "الكل" للدخول إلى وضع التحرير — اسحب لإعادة الترتيب', foldersT2:'زر الترتيب ↕ يتيح الترتيب حسب التاريخ أو الزيارات أو المجلد أو الاسم', foldersT3:'تظهر الوسوم فقط على الإشارات المحفوظة يدوياً', backup:'💾 النسخ الاحتياطي والاستيراد', backupT1:'تصدير JSON ← حفظ جميع الإشارات المرجعية', backupT2:'استيراد JSON ← استعادة من نسخة احتياطية', backupT3:'استيراد HTML ← استيراد من Chrome/Firefox/Safari/Edge' }
    };
    const h = HL[S.lang] || HL.en;
    const m = document.createElement('div');
    m.id = 'helpModal';
    m.dir = dir;
    m.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.75);z-index:2000;display:flex;align-items:flex-start;justify-content:center;overflow-y:auto;padding:20px 0 40px;backdrop-filter:blur(6px);';
    m.innerHTML = `
    <div style="background:var(--card);border:1px solid var(--border);border-radius:20px;padding:22px 20px 28px;width:100%;max-width:520px;margin:0 12px;animation:slideUp .28s ease;" dir="${dir}">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:18px;">
            <div style="font-size:18px;font-weight:800;">📖 ${h.title}</div>
            <button data-wm-click="198" style="background:rgba(255,255,255,.07);border:none;color:var(--text-dim);width:32px;height:32px;border-radius:50%;cursor:pointer;font-size:18px;display:flex;align-items:center;justify-content:center;">✕</button>
        </div>
        <div style="font-size:13px;line-height:1.7;color:var(--text);display:flex;flex-direction:column;gap:14px;">
            <div style="background:rgba(34,197,94,.07);border:1px solid rgba(34,197,94,.2);border-radius:12px;padding:14px;">
                <div style="font-weight:700;color:var(--text);margin-bottom:6px;font-size:14px;">${h.gestures}</div>
                <div>• <b style="color:var(--text);">${h.tap}</b></div>
                <div>• <b style="color:var(--text);">${h.open}</b></div>
                <div>• <b style="color:var(--text);">${h.actions}</b></div>
            </div>
            <div style="background:rgba(99,102,241,.07);border:1px solid rgba(99,102,241,.2);border-radius:12px;padding:14px;">
                <div style="font-weight:700;color:var(--text);margin-bottom:6px;font-size:14px;">${h.reminder}</div>
                <div>${h.reminderDesc}</div>
                <div style="background:rgba(0,0,0,.3);border-radius:8px;padding:8px 12px;margin:8px 0;font-family:monospace;font-size:12px;color:#c4b5fd;">${h.reminderEx}</div>
                <div style="color:#818cf8;font-size:12px;font-weight:600;margin-top:6px;">${h.reminderUse}</div>
                <div>• ${h.reminderU1}</div>
                <div>• ${h.reminderU2}</div>
                <div>• ${h.reminderU3}</div>
                <div style="margin-top:8px;color:#f87171;font-size:12px;">${h.reminderWarn}</div>
            </div>
            <div style="background:rgba(6,182,212,.07);border:1px solid rgba(6,182,212,.2);border-radius:12px;padding:14px;">
                <div style="font-weight:700;color:var(--text);margin-bottom:6px;font-size:14px;">${h.folders}</div>
                <div>• ${h.foldersT1}</div>
                <div>• ${h.foldersT2}</div>
                <div>• ${h.foldersT3}</div>
            </div>
            <div style="background:rgba(245,158,11,.07);border:1px solid rgba(245,158,11,.2);border-radius:12px;padding:14px;">
                <div style="font-weight:700;color:var(--text);margin-bottom:6px;font-size:14px;">${h.backup}</div>
                <div>• ${h.backupT1}</div>
                <div>• ${h.backupT2}</div>
                <div>• ${h.backupT3}</div>
            </div>
            <div style="text-align:center;font-size:11px;opacity:.5;margin-top:4px;">WebMark · by Saad Mounir · v3.0</div>
        </div>
    </div>`;
    m.addEventListener('click', e=>{ if(e.target===m) m.remove(); });
    document.body.appendChild(m);
}
function closeModal(id){ 
    if(id==='addModal') resetWebMeta();
    document.getElementById(id).classList.remove('active');
    // If we came from the inline settings page, go back to it
    if(typeof _returnToSettings !== 'undefined' && _returnToSettings && window.innerWidth <= 767) {
        _returnToSettings = false;
        document.getElementById('page-settings').classList.add('active');
        document.getElementById('settingsPageBody').scrollTop = 0;
        return;
    }
    // If we came from the inline folders page, go back to it
    if(typeof _returnToFolders !== 'undefined' && _returnToFolders && window.innerWidth <= 767) {
        _returnToFolders = false;
        openPage('folders');
        return;
    }
}
function openModal(id){
    const modal = document.getElementById(id);
    if(!modal) return;
    modal.classList.add('active');
    const mc = modal.querySelector('.mc');
    if(mc){ mc.scrollTop = 0; requestAnimationFrame(()=>{ mc.scrollTop = 0; }); }
}

// EXPORT / IMPORT
function exportData(){
    const blob = new Blob([JSON.stringify({f:S.folders,l:S.links},null,2)],{type:'application/json'});
    const a = document.createElement('a'); a.href=URL.createObjectURL(blob); a.download='WebMark_Backup.json'; a.click();
    closeModal('shareModal');
}
function importData(e){
    const file = e.target.files[0];
    if(!file){ e.target.value=''; return; }
    const r = new FileReader();
    r.onload = ev => {
        try {
            const raw = ev.target.result.trim();
            const d = JSON.parse(raw);
            // Accept both {f,l} format (WebMark/Linkery) and plain array
            let importedFolders = [], importedLinks = [];
            if(d && Array.isArray(d.l) && Array.isArray(d.f)){
                importedFolders = d.f; importedLinks = d.l;
            } else if(d && Array.isArray(d.links)){
                importedLinks = d.links; importedFolders = d.folders||[];
            } else if(Array.isArray(d)){
                importedLinks = d;
            } else {
                alert('Invalid backup file. Please use a WebMark JSON backup.');
                e.target.value=''; return;
            }
            if(!importedLinks.length){ alert('No bookmarks found in this file.'); e.target.value=''; return; }

            // Merge folders: map old IDs → new IDs to avoid collisions with existing data
            const existingIds = new Set(S.folders.map(f=>f.id));
            const maxId = S.folders.reduce((m,f)=>Math.max(m,f.id||0), 0);
            const idMap = {}; // oldId → newId
            let nextId = maxId + 1;
            importedFolders.forEach(f => {
                const oldId = f.id;
                // If same name already exists, reuse that folder's id
                const existing = S.folders.find(x=>x.name===f.name);
                if(existing){
                    idMap[oldId] = existing.id;
                } else {
                    const newId = existingIds.has(oldId) ? nextId++ : oldId;
                    idMap[oldId] = newId;
                    existingIds.add(newId);
                    S.folders.push(Object.assign({}, f, {id: newId}));
                }
            });

            // Remap fId on imported links and merge
            const remappedLinks = importedLinks.map(l => {
                const newLink = Object.assign({}, l);
                if(l.fId != null && idMap[l.fId] != null) newLink.fId = idMap[l.fId];
                return newLink;
            });

            // Avoid duplicating links already present (match by url)
            const existingUrls = new Set(S.links.map(l=>l.url));
            const newLinks = remappedLinks.filter(l=>!existingUrls.has(l.url));
            S.links = [...S.links, ...newLinks];

            save(); init();
            alert('✅ Import successful! ' + newLinks.length + ' new bookmarks loaded (folders preserved).');
        } catch(err) {
            alert('Could not read file. Make sure it is a valid WebMark JSON backup.');
        }
        e.target.value='';
    };
    r.onerror = () => { alert('Error reading file. Please try again.'); e.target.value=''; };
    r.readAsText(file);
}

// TAG DROPDOWN
function toggleTagDD(){
    const dd=document.getElementById('tagDD');
    const isOpen=dd.classList.contains('open');
    if(!isOpen) renderTagDD();
    dd.classList.toggle('open');
}
function renderTagDD(){
    const allTags=[...new Set(S.links.flatMap(l=>l.tags||[]))].sort();
    const el=document.getElementById('tagDDList');
    if(!allTags.length){ el.innerHTML='<div style="padding:12px 14px;color:var(--text-dim);font-size:13px;">No tags yet</div>'; return; }
    const active=S.activeTagFilter||null;
    el.innerHTML=`<div class="vopt ${!active?'tag-active':''}" data-wm-click="199" style="${!active?'color:var(--primary)':''}"><i class="fa-solid fa-xmark"></i> All (no filter) ${!active?'<span class="vchk"><i class="fa-solid fa-check"></i></span>':''}</div>`
        + allTags.map(t=>`<div class="vopt ${active===t?'tag-active':''}" data-wm-click="200" data-wm-click-0="${jsArg(t)}" style="${active===t?'color:var(--primary)':''}"><i class="fa-solid fa-hashtag" style="font-size:11px;"></i> ${esc(t)} ${active===t?'<span class="vchk"><i class="fa-solid fa-check"></i></span>':''}</div>`).join('');
}
function toggleFolderFilterDD(){
    const dd=document.getElementById('folderFilterDD');
    const isOpen=dd.classList.contains('open');
    if(!isOpen) renderFolderFilterDD();
    dd.classList.toggle('open');
}
function toggleViewDD(){
    const dd=document.getElementById('viewDD');
    dd.classList.toggle('open');
}
function renderFolderFilterDD(){
    const el=document.getElementById('folderFilterDDList');
    const isAll = S.activeTab==='all';
    let h=`<div class="vopt" data-wm-click="201" style="${isAll?'color:var(--primary)':''}"><i class="fa-solid fa-border-all" style="font-size:11px;"></i> All ${isAll?'<span class="vchk"><i class="fa-solid fa-check"></i></span>':''}</div>`;
    const sourceFolders = sourceFoldersForHome(S.folders,S.links,S._sourceMode||'personal');
    if(!sourceFolders.length){ h+='<div style="padding:12px 14px;color:var(--text-dim);font-size:13px;">No folders yet</div>'; }
    else {
        h+=sourceFolders.map(f=>{
            const isActive=S.activeTab===f.id;
            const color = f.color || '#8b5cf6';
            const icon = f.icon || 'fa-solid fa-folder';
            return `<div class="vopt" data-wm-click="202" data-wm-click-0="${f.id}" style="${isActive?`color:${color};`:''}"><i class="${icon}" style="font-size:12px;color:${color};"></i> ${esc(f.name)} ${isActive?'<span class="vchk"><i class="fa-solid fa-check"></i></span>':''}</div>`;
        }).join('');
    }
    el.innerHTML=h;
    // Update folder filter icon to show active state
    const btn=document.getElementById('folderFilterBtn');
    if(btn) btn.style.borderColor=(!isAll)?'var(--primary)':'var(--border)';
    const icon=document.getElementById('folderFilterIcon');
    if(icon) icon.style.color=(!isAll)?'var(--primary)':'var(--text-dim)';
}
document.addEventListener('click',function(e){
    // Close all dropdowns when clicking outside their parent buttons
    const pairs = [
        ['sourceControl','sourceDD'],
        ['sortBtn','sortDD'],
        ['folderFilterBtn','folderFilterDD'],
        ['tagBtn','tagDD'],
        ['viewSwitcherBtn','viewDD'],
    ];
    pairs.forEach(([btnId, ddId])=>{
        const btn = document.getElementById(btnId);
        const dd  = document.getElementById(ddId);
        if(dd && btn && !btn.contains(e.target)){
            dd.classList.remove('open');
            if(ddId==='sourceDD') updateSourceChecks();
        }
    });
});
function switchTabFromDD(id){
    S.activeTab=id;
    document.getElementById('tagDD').classList.remove('open');
    document.getElementById('folderFilterDD')?.classList.remove('open');
    // Update folder filter icon active state
    const btn=document.getElementById('folderFilterBtn');
    if(btn) btn.style.borderColor=(id!=='all')?'var(--primary)':'var(--border)';
    const icon=document.getElementById('folderFilterIcon');
    if(icon) icon.style.color=(id!=='all')?'var(--primary)':'var(--text-dim)';
    renderTabs(); renderLinks();
}
function filterByTag(tag){
    S.activeTagFilter=tag;
    document.getElementById('tagDD').classList.remove('open');
    if(tag){ document.getElementById('search').value=tag; }
    else { document.getElementById('search').value=''; }
    renderLinks();
}
document.addEventListener('click',function(e){
    if(!document.getElementById('tagBtn').contains(e.target)) document.getElementById('tagDD').classList.remove('open');
});

// ── THEME TOGGLE ──
function toggleTheme(){
    document.body.classList.toggle('light-mode');
    const isLight=document.body.classList.contains('light-mode');
    wmStorage.setItem('ly_theme', isLight?'light':'dark');
    const tog=document.getElementById('themeToggle');
    const inner=document.getElementById('themeInner');
    if(tog) tog.className=isLight?'theme-toggle light-mode-btn':'theme-toggle dark-mode-btn';
    if(inner) inner.innerHTML=isLight?'<i class="fa-regular fa-sun"></i>':'<i class="fa-regular fa-moon"></i>';
    // Sync settings page toggle if it exists
    if(typeof _syncSpThemeToggle === 'function') _syncSpThemeToggle();
}
// Apply saved theme on load — default is LIGHT MODE
(function(){
    const saved = wmStorage.getItem('ly_theme');
    // Default to light if no preference saved
    const isLight = saved === null ? true : (saved === 'light');
    if(isLight){
        document.body.classList.add('light-mode');
        setTimeout(()=>{
            const tog=document.getElementById('themeToggle');
            const inner=document.getElementById('themeInner');
            if(tog) tog.className='theme-toggle light-mode-btn';
            if(inner) inner.innerHTML='<i class="fa-regular fa-sun"></i>';
        },0);
    }
})();


// ── BOOKMARK EDIT MODE ──
S._bmEditMode = false;
let _dragSrcId = null;

// Touch drag support for bookmark reordering
let _touchDragEl = null, _touchDragId = null, _touchDragClone = null, _touchDragOffY = 0;

// ── TOUCH DRAG REORDER ──
let _tdId=null, _tdEl=null, _tdClone=null, _tdOffY=0, _tdScrollEl=null, _tdScrollRAF=null;

function _bmTouchStart(e, id) {
    if(!S._bmEditMode) return;
    e.preventDefault();
    e.stopPropagation();
    _tdId = id;
    _tdEl = document.getElementById('lc-'+id);
    _tdScrollEl = document.getElementById('linkListWrap');
    const touch = e.touches[0];
    const rect = _tdEl.getBoundingClientRect();
    _tdOffY = touch.clientY - rect.top;
    // Clone for visual feedback
    _tdClone = _tdEl.cloneNode(true);
    _tdClone.style.cssText = `position:fixed;left:${rect.left}px;top:${rect.top}px;width:${rect.width}px;z-index:9999;opacity:0.85;pointer-events:none;border-radius:16px;box-shadow:0 10px 40px rgba(0,0,0,.6);transform:scale(1.02);`;
    document.body.appendChild(_tdClone);
    _tdEl.style.opacity = '0.25';
    _tdEl.style.transform = 'scale(0.97)';
}

function _bmTouchMove(e) {
    if(!_tdClone) return;
    e.preventDefault();
    const touch = e.touches[0];
    const newTop = touch.clientY - _tdOffY;
    _tdClone.style.top = newTop + 'px';
    // Highlight target
    _tdClone.style.display = 'none';
    const under = document.elementFromPoint(touch.clientX, touch.clientY);
    _tdClone.style.display = '';
    document.querySelectorAll('.link-container.td-over').forEach(el=>el.classList.remove('td-over'));
    const tc = under && under.closest('.link-container');
    if(tc && tc.id !== 'lc-'+_tdId) tc.classList.add('td-over');
    // Auto-scroll
    if(_tdScrollEl) {
        const scrollRect = _tdScrollEl.getBoundingClientRect();
        const margin = 60;
        if(touch.clientY < scrollRect.top + margin) {
            _tdScrollEl.scrollTop -= 8;
        } else if(touch.clientY > scrollRect.bottom - margin) {
            _tdScrollEl.scrollTop += 8;
        }
    }
}

function _bmTouchEnd(e) {
    if(!_tdClone) return;
    e.preventDefault();
    const touch = e.changedTouches[0];
    // Remove highlight
    document.querySelectorAll('.link-container.td-over').forEach(el=>el.classList.remove('td-over'));
    // Find drop target
    _tdClone.style.display = 'none';
    const under = document.elementFromPoint(touch.clientX, touch.clientY);
    _tdClone.style.display = '';
    const tc = under && under.closest('.link-container');
    if(tc && tc.id !== 'lc-'+_tdId) {
        const targetId = tc.id.replace('lc-','');
        const tidNum = isNaN(targetId) ? targetId : parseInt(targetId);
        const si = S.links.findIndex(l=>String(l.id)===String(_tdId));
        const ti = S.links.findIndex(l=>String(l.id)===String(tidNum));
        if(si>=0 && ti>=0 && si!==ti) {
            const [moved] = S.links.splice(si, 1);
            S.links.splice(ti, 0, moved);
            save();
            // Auto-switch to manual mode so the new order is visible
            if(S._sortMode !== 'manual'){
                S._sortMode = 'manual';
                wmStorage.setItem('ly_sortMode','manual');
                updateSortChecks();
                const icon=document.getElementById('sortDateIcon');
                const btn=document.getElementById('sortBtn');
                if(icon) icon.style.color='#f97316';
                if(btn) btn.style.borderColor='#f97316';
                showToast('↕ Switched to Manual Order','#22c55e');
            }
        }
    }
    // Cleanup
    _tdClone.remove(); _tdClone = null;
    if(_tdEl) { _tdEl.style.opacity=''; _tdEl.style.transform=''; _tdEl=null; }
    _tdId = null;
    // Re-render keeping edit mode
    renderLinks();
    const wrap = document.getElementById('linkListWrap');
    if(wrap && S._bmEditMode) wrap.classList.add('link-list-edit-mode');
}

function toggleBookmarkEditMode(){
    S._bmEditMode = !S._bmEditMode;
    const on = S._bmEditMode;
    const wrap = document.getElementById('linkListWrap');
    if(wrap) wrap.classList.toggle('link-list-edit-mode', on);
}

function bmDragStart(e, id){
    _dragSrcId = parseInt(id)||id;
    e.dataTransfer.effectAllowed = 'move';
    e.dataTransfer.setData('text/plain', id);
    setTimeout(()=>{ const el=document.getElementById('lc-'+id); if(el) el.classList.add('dragging'); }, 0);
}
function bmDragEnd(e){
    document.querySelectorAll('.link-container.dragging,.link-container.drag-over').forEach(el=>{ el.classList.remove('dragging','drag-over'); });
}
function bmDragOver(e, id){
    e.preventDefault(); e.dataTransfer.dropEffect='move';
    document.querySelectorAll('.drag-over').forEach(el=>el.classList.remove('drag-over'));
    const el=document.getElementById('lc-'+id); if(el) el.classList.add('drag-over');
}
function bmDrop(e, targetId){
    e.preventDefault();
    if(_dragSrcId===null||_dragSrcId===targetId) return;
    const srcIdx = S.links.findIndex(l=>l.id===_dragSrcId);
    const tgtIdx = S.links.findIndex(l=>l.id===targetId);
    if(srcIdx<0||tgtIdx<0) return;
    const [moved] = S.links.splice(srcIdx,1);
    S.links.splice(tgtIdx,0,moved);
    save();
    // Auto-switch to manual mode after drag so the new order is visible
    if(S._sortMode !== 'manual'){
        S._sortMode = 'manual';
        wmStorage.setItem('ly_sortMode','manual');
        updateSortChecks();
        const icon=document.getElementById('sortDateIcon');
        const btn=document.getElementById('sortBtn');
        if(icon) icon.style.color='#f97316';
        if(btn) btn.style.borderColor='#f97316';
        showToast('↕ Switched to Manual Order','#22c55e');
    }
    renderLinks();
    const wrap=document.getElementById('linkListWrap');
    if(wrap&&S._bmEditMode) wrap.classList.add('link-list-edit-mode');
    _dragSrcId=null;
}

// ── LANGUAGE ──

// ── FLAG IMAGES: render proper flags on all browsers (Chrome, Firefox, Android, iOS) ──
const FLAG_IMGS = {
    en: '<img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAkCAMAAAD4m0k4AAABwlBMVEVHcEwAGVEEK2gCH1YAHVUBHlUAFEiqEzACHlYCIFinsrKfDya4tbmhFSyztr3ExsqkqLIjOWvMwcOfDygMM2ygDym6hI3KysoDDz+VACvZ2dkIG029dYOoV1+5ubm9i5Oyqqq6urq6foj////MFTfKETHHDiwAHWLLEzTFDiq+CyTBDSfDDSjIDy4AFlMBMnsAJG0BGFYBLnfOFzoBJm8AFk0AG1v+/v79/PwIKWgCH1wBLG7pp7HkkJ30ztXr7fPol6bmk6EFI2fsq7cLL3ORChwGIWDo6vDtsbu3CiABEkQAED4ONHrV2uXRHEO4GDl4hqqstszX19jgdolgcZn99/j46OzQJUWiCiA/WY7GFjL09fhofKX77O7aXXPzydHRUGPQNk/xxczmnajdZ3zc3eArQXnFzN3i4uXvusPWRWHggI/R0dP13eGgrMXNPVLJIDvAvsAvT4yHlLROaJtOX4T18vXDxszZV26vSFnQy8zuvcXNL0mLnL16j7b14ua4DSYjN2vhiZe0bHg2R3eZpMD12d6vWmY/UHwVP4PUb4LMvMDFeIfDh5GdNkK4OU3DUGvWm6bMkJ28dX7PsLXgz9H2/EKBAAAAI3RSTlMAhrOTYqGx/FV3BVD9mRT3+9tLvCpv4mgqBrHbIyOuxj+0xxxCV0cAAAQdSURBVDjLdZWHVyJJEMbHhJjD5r2wd9czjIeODiJhJIkgoAtIRpAcBBEBRTHnuHlvd+//va4hKe/2ew8er9/3q66qrqYJgtdTYU9HV3t7e1dHT6fwaS/xE73qe4O/B1+8HvIYVSAOPhznev5k4Fnfry3c4OhA990hMfra5XJlzbbQFK/p6WmVMfupG+vb0Eh7VxveUSjs7GkTjPQfrNzlD4nlr9/OlAgrE6gTVjQnJYPL/+Q5k8k0y0suv//w5Xzfm94ilpf9/pQWCOWJFexVAMugs87MzLDzvBy3cSaiRK414uNXv91u348CYttuAiRp0BlneLGs1XlUYlJepNyVEYV0WJ3DSMqHiUqoBpBkE2DZbZueYjYUSOGRyAiVdce5Go3Y7X4NlFKwtgAsO1P2RZhgEiFFiAbAODX17lQXzUmluVs+LVUVGOMBCG/xM/4ErtFD1wEeMfil9jlM6HaMGBgbA4BljWWfm2JiZwh5d+gqoKo2813hLCKVRsI4UhnNjdUAjxmHpza8uLwA/QCwBkInBTNKrK8nFNAuACiDLpC53WeYODTdtgZ+bneY4FTbpxn+5B5IP0ZRlEFZcZPV8MhppOkLj3PVtUfsOsHt1VrmNG63W6+3JDa9SE8BgMJRyxx/prbTmz0z/PhxQLiyyiN3zg4nBa2BXMjj4yrwWErtZXxlgfjw/hjmoOmHbCiKYRgyvu/WqC1akCW5ESuNj4sx0L3c8Dft4AeJRKK/QRNY49jfBBrptNgb/nHeXwfIR/6W6A/9NaDu/9/ozXQaAElK4ymNJaoNh8+0uJEbkWKw1V7zH3/vx8C+2odaDw7sxXhw4oE/mLvUItcWcXUILbY5y440WBOXyfUw0kNwNVKGtRa1BqQ+uoXzXS1fEPms7mbHii9VBi/43IwoqK8oasBj6ZwebuktMRxQwdQHdHjJUBKJUj7nGuwwMaGGOVRYkpYEsp2Edi8kkslJDMyawL+ziucJh/evZwP0PNJD7mqzAyOVmFgc8RU4CfhrAMuGcIK3ORGT8jk4GgMaqFVtNgUquL5kUFzSVxyzk3WAZSHSegmHz/BTDwDuDAbkazac1uaxWFyMZj2mOoD9Cj2Fs3fM0zVgvAbIOScM/8b54mIsUbm5x4B8FvuV70XBZPVSNQAxD0gkoQpsEltcXCwmfXsOQu5RIG9EVIoWOPohIAZAArqGtNBRESPnn++I+zTyxkTFzRAtr8uENDAHdUAyW+av8BHeZWGB2Et7Y+dftq5lTUlcH3G0BoCbc53hr9y/V58XiHz+YOWgf0TQ+F/vEvwydLWA9WlPIpNNViXz5NOHW1v9v/9BHB50D4wOPn46en/rezbw5Hm/bAn0ltfS7vCfL8D3V9+rnz1QvS+FnW0dXQKBAL9kwpfVxf8ABj55g+3Y6poAAAAASUVORK5CYII=" srcset="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAkCAMAAAD4m0k4AAABwlBMVEVHcEwAGVEEK2gCH1YAHVUBHlUAFEiqEzACHlYCIFinsrKfDya4tbmhFSyztr3ExsqkqLIjOWvMwcOfDygMM2ygDym6hI3KysoDDz+VACvZ2dkIG029dYOoV1+5ubm9i5Oyqqq6urq6foj////MFTfKETHHDiwAHWLLEzTFDiq+CyTBDSfDDSjIDy4AFlMBMnsAJG0BGFYBLnfOFzoBJm8AFk0AG1v+/v79/PwIKWgCH1wBLG7pp7HkkJ30ztXr7fPol6bmk6EFI2fsq7cLL3ORChwGIWDo6vDtsbu3CiABEkQAED4ONHrV2uXRHEO4GDl4hqqstszX19jgdolgcZn99/j46OzQJUWiCiA/WY7GFjL09fhofKX77O7aXXPzydHRUGPQNk/xxczmnajdZ3zc3eArQXnFzN3i4uXvusPWRWHggI/R0dP13eGgrMXNPVLJIDvAvsAvT4yHlLROaJtOX4T18vXDxszZV26vSFnQy8zuvcXNL0mLnL16j7b14ua4DSYjN2vhiZe0bHg2R3eZpMD12d6vWmY/UHwVP4PUb4LMvMDFeIfDh5GdNkK4OU3DUGvWm6bMkJ28dX7PsLXgz9H2/EKBAAAAI3RSTlMAhrOTYqGx/FV3BVD9mRT3+9tLvCpv4mgqBrHbIyOuxj+0xxxCV0cAAAQdSURBVDjLdZWHVyJJEMbHhJjD5r2wd9czjIeODiJhJIkgoAtIRpAcBBEBRTHnuHlvd+//va4hKe/2ew8er9/3q66qrqYJgtdTYU9HV3t7e1dHT6fwaS/xE73qe4O/B1+8HvIYVSAOPhznev5k4Fnfry3c4OhA990hMfra5XJlzbbQFK/p6WmVMfupG+vb0Eh7VxveUSjs7GkTjPQfrNzlD4nlr9/OlAgrE6gTVjQnJYPL/+Q5k8k0y0suv//w5Xzfm94ilpf9/pQWCOWJFexVAMugs87MzLDzvBy3cSaiRK414uNXv91u348CYttuAiRp0BlneLGs1XlUYlJepNyVEYV0WJ3DSMqHiUqoBpBkE2DZbZueYjYUSOGRyAiVdce5Go3Y7X4NlFKwtgAsO1P2RZhgEiFFiAbAODX17lQXzUmluVs+LVUVGOMBCG/xM/4ErtFD1wEeMfil9jlM6HaMGBgbA4BljWWfm2JiZwh5d+gqoKo2813hLCKVRsI4UhnNjdUAjxmHpza8uLwA/QCwBkInBTNKrK8nFNAuACiDLpC53WeYODTdtgZ+bneY4FTbpxn+5B5IP0ZRlEFZcZPV8MhppOkLj3PVtUfsOsHt1VrmNG63W6+3JDa9SE8BgMJRyxx/prbTmz0z/PhxQLiyyiN3zg4nBa2BXMjj4yrwWErtZXxlgfjw/hjmoOmHbCiKYRgyvu/WqC1akCW5ESuNj4sx0L3c8Dft4AeJRKK/QRNY49jfBBrptNgb/nHeXwfIR/6W6A/9NaDu/9/ozXQaAElK4ymNJaoNh8+0uJEbkWKw1V7zH3/vx8C+2odaDw7sxXhw4oE/mLvUItcWcXUILbY5y440WBOXyfUw0kNwNVKGtRa1BqQ+uoXzXS1fEPms7mbHii9VBi/43IwoqK8oasBj6ZwebuktMRxQwdQHdHjJUBKJUj7nGuwwMaGGOVRYkpYEsp2Edi8kkslJDMyawL+ziucJh/evZwP0PNJD7mqzAyOVmFgc8RU4CfhrAMuGcIK3ORGT8jk4GgMaqFVtNgUquL5kUFzSVxyzk3WAZSHSegmHz/BTDwDuDAbkazac1uaxWFyMZj2mOoD9Cj2Fs3fM0zVgvAbIOScM/8b54mIsUbm5x4B8FvuV70XBZPVSNQAxD0gkoQpsEltcXCwmfXsOQu5RIG9EVIoWOPohIAZAArqGtNBRESPnn++I+zTyxkTFzRAtr8uENDAHdUAyW+av8BHeZWGB2Et7Y+dftq5lTUlcH3G0BoCbc53hr9y/V58XiHz+YOWgf0TQ+F/vEvwydLWA9WlPIpNNViXz5NOHW1v9v/9BHB50D4wOPn46en/rezbw5Hm/bAn0ltfS7vCfL8D3V9+rnz1QvS+FnW0dXQKBAL9kwpfVxf8ABj55g+3Y6poAAAAASUVORK5CYII= 2x" width="24" height="18" alt="EN" style="border-radius:2px;vertical-align:middle;">',
    fr: '<img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAkCAMAAAD4m0k4AAAAvVBMVEVHcEynESIFLVMCMVkBIUXNzc2OBxLMzMzLy8tQJD5WHDmcDRwCIkidDBrJycnLy8sIKU2aCxjBvr4ANmAAHEKnDx9hGCvU1NTExMTDw8P////MDyPPEScANGLIDSAAN2bDCxy/ChkAJFHGDB4AMF4AKVcAJ1UALFoAIksALlsAO2r19viPCBKtDh4AHEGcCRalCxn89fbV1dXEw8P89PUVPWcWRG/v7+8VNmHGEigUMlvOzc3g4ODp5+f7+/ucxdAVAAAAGnRSTlMAWZiwX3mwmrw1FHJVkyZJdaZw9tHQBt/fCLmVL7UAAAHDSURBVDjLldVPa9tAEIfhd3ZXK3stUlNC3ZBDW8i53/+zmNxKWkhITIMlJaq024NW/4ol13uy5Wd+mhkWLACw1uYVgYDGhc0vTp9PT9cCrgpbRwokkNkSePgdvAuvU+3K7KtG1tXWgYINObATsIECYp0tAJwy5jO6QcsXrzZtQg6wyw8AdzxnNhSwHr3m2DQftZn67txDW/iexSc/gACYjrTe/zPl/e5p+BIYCk7z6QkAKPxFHnVZPkGl0XsPkM7x0H1Snaf1YSkeDSoZ2knTGTvyKNLen8rWo3Z0v1bf82S+ndZjxj5ZWpMG0EH5ZOxnV6t1FIau/SUe20kA5Sfen/MYfPQzXDeRk0ADhqnXS/ENNEZ89B4Qzvh4+ZY8U4+qey8yR0ceg5jogXo2vvMouMALmMHXnPcBZWs80nt1qqbp80GBX2in3T2Dx8CiH6aVbmg79na2rtt5e1vr/+VxyBqw1lqA7G7RY2xFbYfsl039jdJJdTxEGwb/ITSYygL8PISrI6s3slzJ9raE1c2qdFLZqDN0aGr2Wr5T7Z0vRv8yj3AlOpftLcD78Ms+CQVy/eYeZya9yUXzx+SwqX2xKgH4C56lsVwnPPmMAAAAAElFTkSuQmCC" srcset="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAkCAMAAAD4m0k4AAAAvVBMVEVHcEynESIFLVMCMVkBIUXNzc2OBxLMzMzLy8tQJD5WHDmcDRwCIkidDBrJycnLy8sIKU2aCxjBvr4ANmAAHEKnDx9hGCvU1NTExMTDw8P////MDyPPEScANGLIDSAAN2bDCxy/ChkAJFHGDB4AMF4AKVcAJ1UALFoAIksALlsAO2r19viPCBKtDh4AHEGcCRalCxn89fbV1dXEw8P89PUVPWcWRG/v7+8VNmHGEigUMlvOzc3g4ODp5+f7+/ucxdAVAAAAGnRSTlMAWZiwX3mwmrw1FHJVkyZJdaZw9tHQBt/fCLmVL7UAAAHDSURBVDjLldVPa9tAEIfhd3ZXK3stUlNC3ZBDW8i53/+zmNxKWkhITIMlJaq024NW/4ol13uy5Wd+mhkWLACw1uYVgYDGhc0vTp9PT9cCrgpbRwokkNkSePgdvAuvU+3K7KtG1tXWgYINObATsIECYp0tAJwy5jO6QcsXrzZtQg6wyw8AdzxnNhSwHr3m2DQftZn67txDW/iexSc/gACYjrTe/zPl/e5p+BIYCk7z6QkAKPxFHnVZPkGl0XsPkM7x0H1Snaf1YSkeDSoZ2knTGTvyKNLen8rWo3Z0v1bf82S+ndZjxj5ZWpMG0EH5ZOxnV6t1FIau/SUe20kA5Sfen/MYfPQzXDeRk0ADhqnXS/ENNEZ89B4Qzvh4+ZY8U4+qey8yR0ceg5jogXo2vvMouMALmMHXnPcBZWs80nt1qqbp80GBX2in3T2Dx8CiH6aVbmg79na2rtt5e1vr/+VxyBqw1lqA7G7RY2xFbYfsl039jdJJdTxEGwb/ITSYygL8PISrI6s3slzJ9raE1c2qdFLZqDN0aGr2Wr5T7Z0vRv8yj3AlOpftLcD78Ms+CQVy/eYeZya9yUXzx+SwqX2xKgH4C56lsVwnPPmMAAAAAElFTkSuQmCC 2x" width="24" height="18" alt="FR" style="border-radius:2px;vertical-align:middle;">',
    es: '<img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAkCAMAAAD4m0k4AAABdFBMVEVHcEyJFBeRGBuNFRmYGx6RFhp4Cw5wCQuXGx+fIiaRFhmQFRmGFRiDDxGECxZ0CgybICR0CgyiIieLEBN7DA+cJCeLFhpvCQluCAv6uAD6vAD7wACrFBf7wwD7wgD6twD6tQC5Iyi0HSGdDxK3ICWWDA+wFxv6uQCjERSaDRCyGh6tFBmgEBOoExb7xgCmEhWuFRqPEhX7vgD7xQCDDRCKDxL5swD5sQD5sAC8JSv6uwD5rQBvCQugICV2CwzgrwSdHCB8Cw2mFh+pISbFTRPVmQW2KBbRpQOVFxuYEhXQoADfqgG9hQDnsgjWcBCaLhfNXQ+4MxHCjADupQOVSA7RkgGeJxjqnwTggwfKWQvAPxXRZg/VfhWtopiyISfnkgXAZxfvuQWkR0OrJA+skZiPOBqtXBDYqhR/Xwz0tQK/PBa9exOQdyOjjleeWk1bZWGiizTHoRq2mDHruxi+apqhgYWvQyJXMVC5lxrFrFl0Q1xpLEO52sypAAAAGXRSTlMAVo1j/59zsHaw3bUUwgeZRUX27d8qIyrxy5Ag8gAAAuhJREFUOMt11WdX4kAYBeAEpNnQddVVENuiglhAYkVRShQRAgvSe7Vi2VW3/Pl9pyTEiPcDH+C5b+ZwZiYMgzPO6lUag8GgUenVI+PDzCcZZofgc1Bt+HKIcozTB+kfUOlHJhR6kNWMcRwzgrTfXyrN45RKJb8fWmcQ6KEnsiyr1qsG+p0c53RyDOjSHoT4+e8kCwt2n+8Ytc6cYkKONXMICv69rpc4jd2+5CMxb25ums1mp5sW5F7GcZZQiJcKvcYrOPZrtNBjvL2npwXEbwKxKCQfC+R4SROO/CrxG6kWFOYDhYRpfWtrhsa0nyhHYzm+y6nns+XgDyZVuV6HiL5atVhMOK7rdCYKD4zzPB+/CeQzianZWSicejHH3uRt/37yumiBZhqyv7+8vAx+jhaon2nnW6+B22BVxt97WhCXY6m+NpuCkPIqueRJQfSJlitylUxeXbqqMk7GU08LdH74Lr166Hu5/xNJhpXjqd/GBcItlp/F9OGVr/GrEbnz9hw/t70TvKAF8JZCLedDhWKwWBW5wksF/N9XGoXj5r+/jWKlU+lOl5aD/M7lBXPupd5UqJ0nhbe3Wif6UuhOlzjyu6gQpt5UKEaSQrNPSKU7eRmXe1Kg3hW5h0Iy1RTSxSBdjcjxcsAfkALdCY8PpxWhU0sJ4bvwu9V0PSmIG6f9FJluP9/fJp4fHuWrIcvBXioo9sHUtYyL45E/uLzFBVcik5f2cTaaKR/Mdbncl5NHUChneelQwamCbGzU43AA0rs7ZDz2iUy2bjvxMK2U7BCaCcdZgdTjuUA2FotlA/G6DWKFgjMk3SEyvoLjwFmE2Gwh5Gnhg1dyVMCeFKQ7pAd3dDnyYgHxFfgtBD86PhmPPS2sLYY4zi0Lx1mti+859u4jj4dBVzjHwQtBi+91rco49NV9gkKKVqJhImiPbpThuDENO6h4d0yMaqF3ciTGg/JNp0VuiP38BTU5qtYajTqdzmjUspPky/98wzH1uE6tAwAAAABJRU5ErkJggg==" srcset="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAkCAMAAAD4m0k4AAABdFBMVEVHcEyJFBeRGBuNFRmYGx6RFhp4Cw5wCQuXGx+fIiaRFhmQFRmGFRiDDxGECxZ0CgybICR0CgyiIieLEBN7DA+cJCeLFhpvCQluCAv6uAD6vAD7wACrFBf7wwD7wgD6twD6tQC5Iyi0HSGdDxK3ICWWDA+wFxv6uQCjERSaDRCyGh6tFBmgEBOoExb7xgCmEhWuFRqPEhX7vgD7xQCDDRCKDxL5swD5sQD5sAC8JSv6uwD5rQBvCQugICV2CwzgrwSdHCB8Cw2mFh+pISbFTRPVmQW2KBbRpQOVFxuYEhXQoADfqgG9hQDnsgjWcBCaLhfNXQ+4MxHCjADupQOVSA7RkgGeJxjqnwTggwfKWQvAPxXRZg/VfhWtopiyISfnkgXAZxfvuQWkR0OrJA+skZiPOBqtXBDYqhR/Xwz0tQK/PBa9exOQdyOjjleeWk1bZWGiizTHoRq2mDHruxi+apqhgYWvQyJXMVC5lxrFrFl0Q1xpLEO52sypAAAAGXRSTlMAVo1j/59zsHaw3bUUwgeZRUX27d8qIyrxy5Ag8gAAAuhJREFUOMt11WdX4kAYBeAEpNnQddVVENuiglhAYkVRShQRAgvSe7Vi2VW3/Pl9pyTEiPcDH+C5b+ZwZiYMgzPO6lUag8GgUenVI+PDzCcZZofgc1Bt+HKIcozTB+kfUOlHJhR6kNWMcRwzgrTfXyrN45RKJb8fWmcQ6KEnsiyr1qsG+p0c53RyDOjSHoT4+e8kCwt2n+8Ytc6cYkKONXMICv69rpc4jd2+5CMxb25ums1mp5sW5F7GcZZQiJcKvcYrOPZrtNBjvL2npwXEbwKxKCQfC+R4SROO/CrxG6kWFOYDhYRpfWtrhsa0nyhHYzm+y6nns+XgDyZVuV6HiL5atVhMOK7rdCYKD4zzPB+/CeQzianZWSicejHH3uRt/37yumiBZhqyv7+8vAx+jhaon2nnW6+B22BVxt97WhCXY6m+NpuCkPIqueRJQfSJlitylUxeXbqqMk7GU08LdH74Lr166Hu5/xNJhpXjqd/GBcItlp/F9OGVr/GrEbnz9hw/t70TvKAF8JZCLedDhWKwWBW5wksF/N9XGoXj5r+/jWKlU+lOl5aD/M7lBXPupd5UqJ0nhbe3Wif6UuhOlzjyu6gQpt5UKEaSQrNPSKU7eRmXe1Kg3hW5h0Iy1RTSxSBdjcjxcsAfkALdCY8PpxWhU0sJ4bvwu9V0PSmIG6f9FJluP9/fJp4fHuWrIcvBXioo9sHUtYyL45E/uLzFBVcik5f2cTaaKR/Mdbncl5NHUChneelQwamCbGzU43AA0rs7ZDz2iUy2bjvxMK2U7BCaCcdZgdTjuUA2FotlA/G6DWKFgjMk3SEyvoLjwFmE2Gwh5Gnhg1dyVMCeFKQ7pAd3dDnyYgHxFfgtBD86PhmPPS2sLYY4zi0Lx1mti+859u4jj4dBVzjHwQtBi+91rco49NV9gkKKVqJhImiPbpThuDENO6h4d0yMaqF3ciTGg/JNp0VuiP38BTU5qtYajTqdzmjUspPky/98wzH1uE6tAwAAAABJRU5ErkJggg== 2x" width="24" height="18" alt="ES" style="border-radius:2px;vertical-align:middle;">',
    it: '<img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAkCAMAAAD4m0k4AAAA9lBMVEVHcEzJx8eVGSAHf0YCiE6SGB+fISoBcjgDdDinJjDLy8tWVTjHycd8enrKysrJycnPz88AcjfMzMwDj1UKcDkHkFmbHSViQSvLy8vDw8OoJTABjlWnIiyNFBymISyIEhjJKC7////JJTDMKDPGIy7CHykAlUnEISu/HSYAnFMAoFjOKjYAmU8AnlbQLTn2+vgAk0YAolsAl0yQFRytJC4AjkKdGSGmHSYApF789fYBj1QAkUUCi07T09MAmlDExMQLlVQAhEMAgT8AejwAh0oAkET89vfw8PDl5OQVm1UWoFwAbjPGLDgAi0AWpWP+/v65GiPZ2dm2/vSrAAAAIHRSTlMAbpuUrLB3Wf1avBSIAkkmnNHbcHM1SAbiCNrx7fHGK/FGs9EAAAH5SURBVDjLfdXZYppAAEbhEQVxS8yedFewRBF3xCCoKBaa1Ni8/8t0diZh7H/B1XeGuRsA0Bo35atiCa1YL5ydP4ATu6t8g9/aVemzH+DFsR+Gb2F4X23CrvFe126VL54Hbko+3Kbr9Mbjca/3miRJmsIG7bLarGsVNE1TP83QPACxs4AbY997HbbwhqybZTN/2CjYLATvsIDseEz+0A0Gtm0bPCDecT4ErdavAZstBvT4/wSYGyzIfPdEQD0Kgs2CXQf6EwHzxmwOAp/7Ltzzx8AWfZsGmV9JAjvzNMC+i70kEH3bm4PY53616velgcE8DQSfDwzRmzggfoX9RBIIHgcB9X3kc8GTIXoaMD+ZSII248ijIApE//O3LODeokHmpQHjpkUDen3kJUFb8JY3BVGcHX8yYL4Dgy0KmB+NZIHJPQlEnw9M0dMg48tlPhB9Zw6DSPR7eWBR/wiDXcT8Enp3IwuYJ0HM/X7v5gNL9OQP3LuuLLAEz4IR9/KAcRJssd9jfzjkgo7oSYA94bKgI/i/NED+EEVbuCAZHiXB47vAjXb6C52+Xq/DtzRl3ZPIvfkUBrudrusXpeJ1Ge263qxervFwl1ILMdRT9RZAXSzX8DPEn47G+VmhXr3H2ZTvq6ohd1G+k75OMH+AXUFRVFVVFK3ynRz4D1u7D25/c32DAAAAAElFTkSuQmCC" srcset="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAkCAMAAAD4m0k4AAAA9lBMVEVHcEzJx8eVGSAHf0YCiE6SGB+fISoBcjgDdDinJjDLy8tWVTjHycd8enrKysrJycnPz88AcjfMzMwDj1UKcDkHkFmbHSViQSvLy8vDw8OoJTABjlWnIiyNFBymISyIEhjJKC7////JJTDMKDPGIy7CHykAlUnEISu/HSYAnFMAoFjOKjYAmU8AnlbQLTn2+vgAk0YAolsAl0yQFRytJC4AjkKdGSGmHSYApF789fYBj1QAkUUCi07T09MAmlDExMQLlVQAhEMAgT8AejwAh0oAkET89vfw8PDl5OQVm1UWoFwAbjPGLDgAi0AWpWP+/v65GiPZ2dm2/vSrAAAAIHRSTlMAbpuUrLB3Wf1avBSIAkkmnNHbcHM1SAbiCNrx7fHGK/FGs9EAAAH5SURBVDjLfdXZYppAAEbhEQVxS8yedFewRBF3xCCoKBaa1Ni8/8t0diZh7H/B1XeGuRsA0Bo35atiCa1YL5ydP4ATu6t8g9/aVemzH+DFsR+Gb2F4X23CrvFe126VL54Hbko+3Kbr9Mbjca/3miRJmsIG7bLarGsVNE1TP83QPACxs4AbY997HbbwhqybZTN/2CjYLATvsIDseEz+0A0Gtm0bPCDecT4ErdavAZstBvT4/wSYGyzIfPdEQD0Kgs2CXQf6EwHzxmwOAp/7Ltzzx8AWfZsGmV9JAjvzNMC+i70kEH3bm4PY53616velgcE8DQSfDwzRmzggfoX9RBIIHgcB9X3kc8GTIXoaMD+ZSII248ijIApE//O3LODeokHmpQHjpkUDen3kJUFb8JY3BVGcHX8yYL4Dgy0KmB+NZIHJPQlEnw9M0dMg48tlPhB9Zw6DSPR7eWBR/wiDXcT8Enp3IwuYJ0HM/X7v5gNL9OQP3LuuLLAEz4IR9/KAcRJssd9jfzjkgo7oSYA94bKgI/i/NED+EEVbuCAZHiXB47vAjXb6C52+Xq/DtzRl3ZPIvfkUBrudrusXpeJ1Ge263qxervFwl1ILMdRT9RZAXSzX8DPEn47G+VmhXr3H2ZTvq6ohd1G+k75OMH+AXUFRVFVVFK3ynRz4D1u7D25/c32DAAAAAElFTkSuQmCC 2x" width="24" height="18" alt="IT" style="border-radius:2px;vertical-align:middle;">',
    ar: '<img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAkCAMAAAD4m0k4AAAAhFBMVEVHcEwAQSQERCsAPiIAOiABUTMETTIBRCgBSSwANBwCXT4ASCoCWjsBVTYATCoATywAVDAARyYAVzMAUS4BWjYARCUAXTkAYDwAYz8ASSgAZkIAQSIAPiEAakYAOh4ANBtUi3MALheHrp1flH46fGBIhGoudFdsnIh5pJIjakuhwbTQ3thaoMkyAAAADnRSTlMAwBTmiZorVG+rq9u24ljE4fQAAAJlSURBVDjLdZWJkuIgFEVjazrRdshGNpNWZMf5//+bByFk0bllWZZ1zuNBAkSRy3eSxpfL9RLHaZp8R/9NcoCvr/Tatm3TNHhKWZZ/rvG795XEx3qIvi9d23bd7fb7e4N0Hai4zKsKPj/X+JQmNunp/FPUdQFC13W/U25TOhsY0VoZyhBCPer7vuh7VFWFFT7y7dxlWeYhTmi7Nb/F/bRgUuXEZ/Xohc/4nl+EPb/DA2+Fpl3x8ubmu+A73guhvBRMUcVaziVuP+AZGqwQ+NYIzl+MScK1pIwTwe3irngr4CbwHWEv/aKEKMkk01gxo7QiggUeDfdJ8JPlShImmJCUQGcMfhBDeU4CPwuebzjj6kVfVCklpeaUKxhNE5LNfD/eoxIHvhGCK0YkNzAHTYnmhJSECBL4SQh8w6A6YUZQJV6UUi0Y4dAUC3zhBf+oMAzRCpiu1oTZkaAvw42kDre8FfIy8PPCl6Y0mApOqOSKciMCX9wfIOz5+dXMK0M4xoLkDrd8DUJVbvn5RXZrj6YNEXgvvJX3+Lw4C++EfF/+E+55K2T5Bz57L+/4wQpVs94k3OA3fOGHxyNC1WZTGabhkVEm8Uyv+eHxdMLqrc9d7cwIBU9aM23yYsWPVsjwbpcs3VSK0L8ed7wV+szzn9ZmaWfiZ2FTHm0nG3DLOwFt+D2+5e8gFOid3+ELf396AXDfdNEvve9w4J3Q5xmCU3n0gX/HcRjsSf3GP54g1EUB//ycp3M9hXP9cLzPGa3r+Il+npOoro9x8rW7O+BCOh2OjznPKefUcofk/xeU9U5nm9NpvpD+AYGjjY7S5sPFAAAAAElFTkSuQmCC" srcset="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAkCAMAAAD4m0k4AAAAhFBMVEVHcEwAQSQERCsAPiIAOiABUTMETTIBRCgBSSwANBwCXT4ASCoCWjsBVTYATCoATywAVDAARyYAVzMAUS4BWjYARCUAXTkAYDwAYz8ASSgAZkIAQSIAPiEAakYAOh4ANBtUi3MALheHrp1flH46fGBIhGoudFdsnIh5pJIjakuhwbTQ3thaoMkyAAAADnRSTlMAwBTmiZorVG+rq9u24ljE4fQAAAJlSURBVDjLdZWJkuIgFEVjazrRdshGNpNWZMf5//+bByFk0bllWZZ1zuNBAkSRy3eSxpfL9RLHaZp8R/9NcoCvr/Tatm3TNHhKWZZ/rvG795XEx3qIvi9d23bd7fb7e4N0Hai4zKsKPj/X+JQmNunp/FPUdQFC13W/U25TOhsY0VoZyhBCPer7vuh7VFWFFT7y7dxlWeYhTmi7Nb/F/bRgUuXEZ/Xohc/4nl+EPb/DA2+Fpl3x8ubmu+A73guhvBRMUcVaziVuP+AZGqwQ+NYIzl+MScK1pIwTwe3irngr4CbwHWEv/aKEKMkk01gxo7QiggUeDfdJ8JPlShImmJCUQGcMfhBDeU4CPwuebzjj6kVfVCklpeaUKxhNE5LNfD/eoxIHvhGCK0YkNzAHTYnmhJSECBL4SQh8w6A6YUZQJV6UUi0Y4dAUC3zhBf+oMAzRCpiu1oTZkaAvw42kDre8FfIy8PPCl6Y0mApOqOSKciMCX9wfIOz5+dXMK0M4xoLkDrd8DUJVbvn5RXZrj6YNEXgvvJX3+Lw4C++EfF/+E+55K2T5Bz57L+/4wQpVs94k3OA3fOGHxyNC1WZTGabhkVEm8Uyv+eHxdMLqrc9d7cwIBU9aM23yYsWPVsjwbpcs3VSK0L8ed7wV+szzn9ZmaWfiZ2FTHm0nG3DLOwFt+D2+5e8gFOid3+ELf396AXDfdNEvve9w4J3Q5xmCU3n0gX/HcRjsSf3GP54g1EUB//ycp3M9hXP9cLzPGa3r+Il+npOoro9x8rW7O+BCOh2OjznPKefUcofk/xeU9U5nm9NpvpD+AYGjjY7S5sPFAAAAAElFTkSuQmCC 2x" width="24" height="18" alt="AR" style="border-radius:2px;vertical-align:middle;">'
};
function getFlagImg(lang){ return FLAG_IMGS[lang]||FLAG_IMGS.en; }

const LANG_LABELS={en:'English',fr:'Français',es:'Español',it:'Italiano',ar:'العربية'};
const LANG_FLAGS={en:'🇬🇧',fr:'🇫🇷',es:'🇪🇸',it:'🇮🇹',ar:'🇸🇦'};

function openLangModal(){
    // update checkmarks
    Object.keys(LANG_LABELS).forEach(l=>{
        const el=document.getElementById('lc-'+l);
        if(el) el.style.display=l===S.lang?'inline':'none';
    });
    openModal('langModal');
}
function setLang(l){
    S.lang=l;
    wmStorage.setItem('ly_lang',l);
    (globalThis.browser || globalThis.chrome).storage.local.set({webmarkLanguage:l}).catch(console.error);
    Object.keys(LANG_LABELS).forEach(lang=>{
        const el=document.getElementById('lc-'+lang);
        if(el) el.style.display=lang===l?'inline':'none';
    });
    applyTranslations();
    renderTabs(); renderLinks();
    // Update settings display
    const slc=document.getElementById('settLangCurrent');
    if(slc) slc.innerHTML=`${getFlagImg(l)} ${LANG_LABELS[l]||l}`;
    closeModal('langModal');
}
// Apply saved lang on load
(function(){
    if(S.lang!=='en') document.body.setAttribute('dir',S.lang==='ar'?'rtl':'ltr');
})();

// ── SETTINGS ──
S.sortByDate = S.settings.sortByDate;
// Migrate old settings: ensure new defaults are applied for existing users
if(S.settings.showThumbs===undefined) S.settings.showThumbs=true;
if(S.settings.openNewTab===undefined) S.settings.openNewTab=true;
if(S.settings.showFolders===undefined) S.settings.showFolders=true;

function openSettings(){
    updateSettingToggles();
    // Populate stats
    const total=S.links.filter(l=>!l.archived).length;
    const favs=S.links.filter(l=>l.fav&&!l.archived).length;
    const arch=S.links.filter(l=>l.archived).length;
    const el=id=>document.getElementById(id);
    if(el('statTotalLinks')) el('statTotalLinks').textContent=total;
    if(el('statTotalFolders')) el('statTotalFolders').textContent=S.folders.length;
    if(el('statFavs')) el('statFavs').textContent=favs;
    if(el('statArchived')) el('statArchived').textContent=arch;
    // Trash badge
    const trashBadge=el('trashCountBadge');
    if(trashBadge){
        const cnt=(S.trash||[]).length;
        if(cnt>0){ trashBadge.textContent=cnt; trashBadge.style.display='inline'; }
        else { trashBadge.style.display='none'; }
    }
    // Delete password status
    const dp=el('delPassStatus');
    if(dp){
        const storedUser=getDeleteUser();
        if(getDeletePass()&&storedUser){
            dp.textContent=maskUsername(wmDecode(storedUser));
            dp.style.color='var(--primary)';
            dp.style.fontFamily='monospace';
            dp.style.letterSpacing='2px';
        } else {
            dp.textContent='OFF';
            dp.style.color='var(--text-dim)';
            dp.style.fontFamily='inherit';
            dp.style.letterSpacing='normal';
        }
    }
    openModal('settingsModal');
    setTimeout(updateBrowserPills,20);
    setTimeout(renderPerBrowserToggles,20);
    setTimeout(updateDelPassLabel, 10);
    // Sync font labels
    const fSize = parseInt(wmStorage.getItem('ly_fontSize')||'14');
    const dfl = document.getElementById('desk-fontSizeLabel');
    if(dfl) dfl.textContent = fSize+'px';
    const savedF = wmStorage.getItem('ly_font')||'Inter';
    document.querySelectorAll('.font-pill').forEach(p=>p.classList.toggle('active', p.dataset.font===savedF));
}
function updateSettingToggles(){
    const defaultTrue=['showFolders','openNewTab','showThumbs','showImportedBadge','pinnedTop'];
    ['showFolders','showTags','sortByDate','compactCards','showViews','openNewTab','showThumbs','hideImported','pinnedTop','showImportedBadge'].forEach(k=>{
        const tog=document.getElementById('tog-'+k);
        const inner=document.getElementById('togInner-'+k);
        if(!tog||!inner) return;
        const on = S.settings[k] !== undefined ? S.settings[k] : defaultTrue.includes(k);
        tog.style.background=on?'var(--primary)':'#27272a';
        inner.style.left=on?'auto':'2px';
        inner.style.right=on?'2px':'auto';
    });
    // Accent color dots
    const cur=S.settings.accentColor||'#22c55e';
    document.querySelectorAll('.accent-dot').forEach(d=>{
        d.style.border=d.dataset.color===cur?'3px solid #fff':'2px solid transparent';
        d.style.transform=d.dataset.color===cur?'scale(1.2)':'scale(1)';
    });
    // Current lang in settings
    const slc=document.getElementById('settLangCurrent');
    if(slc) slc.innerHTML=`${getFlagImg(S.lang)} ${LANG_LABELS[S.lang]||'English'}`;
}
function toggleSetting(k){
    if(!S.settings) S.settings={};
    const defaultTrue=['showFolders','openNewTab','showThumbs','showImportedBadge','pinnedTop'];
    const cur = S.settings[k] !== undefined ? S.settings[k] : defaultTrue.includes(k);
    S.settings[k]=!cur;
    if(k==='sortByDate') S.sortByDate=S.settings[k];
    if(k==='compactCards') applyCompactCards();
    if(k==='animEditMode') applyAnimEditMode();
    wmStorage.setItem('ly_settings',JSON.stringify(S.settings));
    updateSettingToggles();
    if(k==='hideImported'||k==='showImportedBadge')refreshBookmarkVisibility();else renderLinks();
}

function setAccent(color){
    S.settings.accentColor=color;
    wmStorage.setItem('ly_settings',JSON.stringify(S.settings));
    document.documentElement.style.setProperty('--primary',color);
    // Update FAB shadow
    document.querySelector('.fab') && (document.querySelector('.fab').style.boxShadow=`0 4px 24px ${color}77`);
    updateSettingToggles();
}

function applyAccentColor(){
    const color=S.settings&&S.settings.accentColor;
    if(color && color!=='#22c55e'){
        document.documentElement.style.setProperty('--primary',color);
        const fab=document.querySelector('.fab');
        if(fab) fab.style.boxShadow=`0 4px 24px ${color}77`;
    }
}

function applyCompactCards(){
    const on=S.settings&&S.settings.compactCards;
    document.body.classList.toggle('compact-cards',!!on);
}

function clearAllData(){
    requireDeletePassword(()=>{
        // Triple-confirm for safety
        if(!confirm('⚠️ FINAL WARNING: This deletes ALL '+S.links.length+' bookmarks and '+S.folders.length+' folders permanently!')) return;
        S.folders=[]; S.links=[];
        wmStorage.removeItem('ly_f'); wmStorage.removeItem('ly_l');
        wmStorage.removeItem('ly_synccode'); wmStorage.removeItem('ly_jsonbin_id');
        save(); init(); closeModal('settingsModal');
        showToast('All data cleared.','#ef4444');
    });
}

function deleteAllPersonalBookmarks(){
    const personal = S.links.filter(l => !l.imported);
    if(!personal.length){
        showToast('No personal bookmarks to delete.','#f59e0b');
        return;
    }
    requireDeletePassword(()=>{
        if(!confirm('Delete all ' + personal.length + ' personal (non-imported) bookmarks?\n\nImported browser bookmarks will NOT be affected.\nThis cannot be undone.')) return;
        // Move to trash before deleting
        if(!S.trash) S.trash = [];
        personal.forEach(l => {
            S.trash.unshift({...l, deletedAt: Date.now()});
        });
        S.links = S.links.filter(l => l.imported);
        // Remove personal-only folders (folders with no remaining links)
        const usedFolderIds = new Set(S.links.map(l => l.fId));
        S.folders = S.folders.filter(f => f._browserImport || usedFolderIds.has(f.id));
        save(); init(); closeModal('settingsModal'); closePage && closePage();
        showToast('Deleted ' + personal.length + ' personal bookmarks (moved to trash).', '#f97316');
    });
}

// ── BROWSER BOOKMARK IMPORT ──
const importTopics = {
    'Education': ['graduation-cap', '#2563eb', /\b(course|tutorial|learn|education|university|lesson|language learning|study)\b/i],
    'Technology': ['laptop-code', '#6366f1', /\b(software|programming|developer|coding|technology|computer|linux|javascript|python)\b/i],
    'AI': ['robot', '#0f766e', /\b(artificial intelligence|chatbot|generative ai|language model|machine learning)\b/i],
    'Shopping': ['bag-shopping', '#c2410c', /\b(shopping|shop|store|product|buy|discount|retail)\b/i],
    'Travel': ['plane', '#0369a1', /\b(travel|hotel|flights?|tourism|destinations?|vacation|viaggi|voyage)\b/i],
    'Food': ['utensils', '#15803d', /\b(recipe|recipes|cooking|baking|restaurants?|ricette|recettes|cucina)\b/i],
    'News': ['newspaper', '#b91c1c', /\b(news|notizie|actualités|headlines|journalism)\b/i],
    'Finance': ['coins', '#a16207', /\b(finance|banking|investing|mortgage|stock market|taxes|budget)\b/i],
    'Health': ['heart-pulse', '#be185d', /\b(health|fitness|medical|medicine|nutrition|workouts?|healthcare)\b/i],
    'Entertainment': ['film', '#7c3aed', /\b(movie|movies|films?|cinema|tv series|streaming|comedies)\b/i],
    'Gaming': ['gamepad', '#7e22ce', /\b(gaming|gameplay|video games|playstation|xbox|nintendo|steam)\b/i],
    'Music': ['music', '#047857', /\b(music|songs?|albums?|lyrics|playlists?|musica|musique)\b/i],
    'Work': ['briefcase', '#4338ca', /\b(jobs?|careers?|hiring|resume|recruitment|lavoro|emploi)\b/i],
    'Creative': ['palette', '#be185d', /\b(design|photography|illustration|artwork|creative|painting)\b/i],
    'Social': ['users', '#2563eb', /\b(social network|community|forums?|discussion|social media)\b/i],
    'Productivity': ['list-check', '#15803d', /\b(productivity|task management|to.do list|workspace|calendar)\b/i],
    'Reference': ['book', '#475569', /\b(encyclopedia|dictionary|reference|manual|documentation)\b/i],
    'Search': ['magnifying-glass', '#2563eb', /\b(search engine|web search)\b/i],
    'Web': ['globe', '#475569', /$^/],
    'Other websites': ['globe', '#475569', /$^/],
};

function classifyBrowserBookmark(bookmark) {
    const fallback = detectSiteIcon(bookmark.url)?.category;
    const aliases = {Tech:'Technology', Learning:'Education', Reading:'Reference'};
    const best = Object.entries(importTopics).map(([name, [, , match]]) => {
        const title = bookmark.title || '';
        const desc = bookmark.desc || '';
        const path = new URL(bookmark.url).pathname.replace(/[-_/]+/g, ' ');
        const score = (match.test(title) ? 4 : 0) + (match.test(desc) ? 2 : 0) + (match.test(path) ? 1 : 0);
        return {name, score};
    }).sort((a,b)=>b.score-a.score)[0];
    return best.score >= 4 || (!fallback && best.score > 0) ? best.name :
        (aliases[fallback] || fallback || 'Other websites');
}

function browserTopicFolder(browser, topic) {
    const folderKey = browser + '::' + topic;
    const existing = S.folders.find(folder => folder._browserImport && folder._folderKey === folderKey);
    if (existing) return existing.id;
    const [icon, color] = importTopics[topic] || importTopics['Other websites'];
    const id = wmId();
    S.folders.push({id, name:topic + ' (' + browser + ')', icon:'fa-solid fa-'+icon, color,
        _browserImport:true, _importBrowser:browser, _importCategory:topic, _folderKey:folderKey});
    return id;
}

function readBrowserBookmarkRows(text, format) {
    if (format === 'html') {
        const doc = new DOMParser().parseFromString(text, 'text/html');
        return [...doc.querySelectorAll('a[href]')].map(anchor => {
            const dt = anchor.closest('dt');
            const details = dt?.nextElementSibling;
            const date = Number(anchor.getAttribute('add_date')) * 1000;
            return {url:anchor.getAttribute('href'), title:anchor.textContent,
                desc:details?.tagName === 'DD' ? details.textContent : '',
                logo:anchor.getAttribute('icon') || anchor.getAttribute('icon_uri'),
                addedAt:Number.isSafeInteger(date) && date >= Date.UTC(1990,0,1) && date <= Date.now() ? date : null};
        });
    }
    const raw = JSON.parse(text);
    const listed = Array.isArray(raw) ? raw : raw?.l || raw?.links;
    if (Array.isArray(listed)) return listed;
    const roots = raw?.roots ? Object.values(raw.roots) : raw?.children;
    if (!Array.isArray(roots)) throw new Error('This JSON file does not contain browser bookmarks.');
    const rows = [];
    function walk(items) {
        for (const item of items) {
            if (!item || typeof item !== 'object') continue;
            const url = item.url || item.uri;
            if (typeof url === 'string') {
                // Chrome/Edge use microseconds since 1601. Firefox uses microseconds since 1970.
                const stamp = Number(item.date_added || item.dateAdded);
                const date = Math.trunc(stamp / 1000) - (item.date_added ? 11644473600000 : 0);
                rows.push({...item,url,title:item.title || item.name,
                    addedAt:Number.isSafeInteger(date) && date >= Date.UTC(1990,0,1) && date <= Date.now() ? date : null});
            }
            if (Array.isArray(item.children)) walk(item.children);
        }
    }
    walk(roots);
    return rows;
}

async function publicImportMetadata(url) {
    const page = new URL(url);
    if (!/^(?:[a-z0-9-]+\.)+[a-z][a-z0-9-]*$/i.test(page.hostname) ||
        /\.(?:local|localhost|internal|test|invalid|lan|home)$/i.test(page.hostname) ||
        page.username || page.password || page.port) return null;
    const videoId = page.searchParams.get('v');
    page.search = '';
    page.hash = '';
    if (/^(?:www\.)?youtube\.com$/i.test(page.hostname) && /^[\w-]{11}$/.test(videoId || '')) {
        page.searchParams.set('v', videoId);
    }
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 5500);
    try {
        const response = await fetch('https://api.microlink.io?url=' + encodeURIComponent(page.href) + '&meta=true', {
            signal:controller.signal, credentials:'omit', referrerPolicy:'no-referrer'
        });
        if (response.status === 429) return {rateLimited:true};
        if (!response.ok) return null;
        const result = await response.json();
        return result.status === 'success' ? result.data : null;
    } catch { return null; }
    finally { clearTimeout(timeout); }
}

async function enrichBrowserImports(bookmarks, browser) {
    if (!navigator.onLine) return;
    const originals = bookmarks.map(bookmark=>({...bookmark}));
    for (let index=0; index<originals.length; index+=3) {
        const batch = originals.slice(index,index+3);
        const found = await Promise.all(batch.map(bookmark => publicImportMetadata(bookmark.url)));
        let changed = false;
        const currentById = new Map(S.links.map(bookmark => [bookmark.id, bookmark]));
        const previousFolders = S.folders.slice();
        const rollback = [];
        found.forEach((data,i)=>{
            if (!data || data.rateLimited) return;
            const original = batch[i];
            const bookmark = currentById.get(original.id);
            if (!bookmark || bookmark.url !== original.url || bookmark.importedFrom !== browser || bookmark.fId !== original.fId ||
                bookmark.title !== original.title || bookmark.desc !== original.desc || bookmark.logo !== original.logo) return;
            const title = typeof data.title === 'string' && data.title.trim() ? data.title.trim().slice(0,500) : bookmark.title;
            const desc = typeof data.description === 'string' && data.description.trim() ? shortWebDescription(data.description) : bookmark.desc;
            const logo = wmImage(data.image?.url) || wmImage(data.logo?.url) || bookmark.logo;
            const topic = classifyBrowserBookmark({...bookmark,title,desc});
            const fId = browserTopicFolder(browser,topic);
            if (title === bookmark.title && desc === bookmark.desc && logo === bookmark.logo && fId === bookmark.fId) return;
            rollback.push([bookmark, {title:bookmark.title,desc:bookmark.desc,logo:bookmark.logo,fId:bookmark.fId}]);
            Object.assign(bookmark,{title,desc,logo,fId});
            changed = true;
        });
        if (changed) {
            const used = new Set([...S.links, ...(S.trash || [])].map(bookmark=>bookmark.fId));
            const vacated = new Set(rollback.map(([,before])=>before.fId));
            S.folders = S.folders.filter(folder=>!folder._browserImport || !vacated.has(folder.id) || used.has(folder.id));
            try {
                save();
                await wmStorage.flush?.();
                if (typeof S.activeTab === 'number' && !S.folders.some(folder=>folder.id===S.activeTab)) S.activeTab='all';
                renderTabs();
                renderLinks();
            } catch (error) {
                for (const [bookmark,before] of rollback) Object.assign(bookmark,before);
                S.folders = previousFolders;
                throw error;
            }
        }
        if (found.some(data=>data?.rateLimited)) break;
    }
}

async function importBrowserFile(event, format) {
    const input = event.target;
    const file = input.files?.[0];
    if (!file) return;
    const browser = browserName(S.settings?.importBrowser) || 'Chrome';
    input.value = '';
    try {
        const rows = readBrowserBookmarkRows(await file.text(),format);
        const folders = new Map(S.folders.map(folder=>[folder.id,folder]));
        const urls = new Set(S.links.filter(bookmark=>bookmarkBrowser(bookmark,folders)===browser)
            .map(bookmark=>wmURL(bookmark.url)));
        const additions = [];
        let duplicates = 0;
        const previousFolders = S.folders.slice();
        for (const row of rows) {
            const raw = row?.url || row?.uri;
            const url = typeof raw === 'string' && /^https?:\/\//i.test(raw.trim()) ? wmURL(raw) : null;
            if (!url) continue;
            if (urls.has(url)) { duplicates++; continue; }
            urls.add(url);
            const fallback = fallbackWebMeta(url);
            const title = String(row.title || row.name || fallback.title).trim().slice(0,500);
            const desc = shortWebDescription(String(row.desc || row.description || fallback.desc));
            const icon = wmImage(row.logo || row.icon);
            const page = new URL(url);
            const logo = icon && icon.length <= 150000 ? icon :
                (/^(?:[a-z0-9-]+\.)+[a-z][a-z0-9-]*$/i.test(page.hostname) &&
                 !/\.(?:local|localhost|internal|test|invalid|lan|home)$/i.test(page.hostname)
                    ? 'https://www.google.com/s2/favicons?domain=' + encodeURIComponent(page.hostname) + '&sz=128' : null);
            const bookmark = {id:wmId(), url,title,desc,logo,tags:[], fav:false,archived:false,views:0,
                addedAt:row.addedAt ?? (Number.isSafeInteger(row.id) && row.id>=Date.UTC(1990,0,1) ? row.id : null),
                siteIcon:_buildSiteIconForLink(url,title), imported:true, importedFrom:browser};
            bookmark.fId = browserTopicFolder(browser,classifyBrowserBookmark(bookmark));
            additions.push(bookmark);
        }
        const oldLinks = S.links;
        if (additions.length) {
            S.links = [...oldLinks,...additions];
            try { save(); await wmStorage.flush?.(); }
            catch (error) { S.folders=previousFolders; S.links=oldLinks; throw error; }
        }
        closeModal('importBMModal');
        if (additions.length) {
            document.getElementById('search').value = '';
            document.getElementById('searchClearBtn').style.display = 'none';
            navTo('all','nav-home');
            deskNav('all','dnl-home');
            setSourceMode('browser-' + browser.toLowerCase());
        }
        showToast(additions.length + ' bookmarks imported from ' + browser + (duplicates ? ' · ' + duplicates + ' duplicates skipped' : ''));
        if (additions.length) enrichBrowserImports(additions,browser).catch(error=>showToast(error.message,'#ef4444'));
    } catch (error) {
        showToast('Import failed: ' + error.message,'#ef4444');
    }
}

function importBrowserBookmarks(event) { return importBrowserFile(event,'html'); }
function importBrowserJSON(event) { return importBrowserFile(event,'json'); }


function openTagsMgr(){
    closeModal('settingsModal');
    renderAllTags();
    openModal('manageTagsModal');
}

function renderAllTags(){
    const container = document.getElementById('allTagsList');
    if(!container) return;
    // Collect all tags with counts
    const tagMap = {};
    S.links.forEach(l=>{
        if(l.tags) l.tags.forEach(t=>{
            if(!t) return;
            tagMap[t] = (tagMap[t]||0) + 1;
        });
    });
    const tags = Object.entries(tagMap).sort((a,b)=>b[1]-a[1]);
    if(!tags.length){
        container.innerHTML='<div style="text-align:center;padding:30px;color:var(--text-dim);"><i class="fa-solid fa-hashtag" style="font-size:36px;display:block;margin-bottom:10px;opacity:.3;"></i>No tags yet</div>';
        return;
    }
    container.innerHTML = `
        <div style="font-size:11px;font-weight:700;color:var(--text-dim);text-transform:uppercase;letter-spacing:.6px;margin-bottom:12px;">${tags.length} tags used across your bookmarks</div>
        <div style="display:flex;flex-wrap:wrap;gap:8px;">
        ${tags.map(([tag,cnt])=>`
            <div style="display:inline-flex;align-items:center;gap:6px;padding:6px 12px;background:var(--card);border:1px solid var(--border);border-radius:20px;cursor:pointer;transition:all .15s;"
                data-wm-click="200" data-wm-click-0="${jsArg(tag)}"
                oncontextmenu="event.preventDefault();deleteTagGlobal(${jsArg(tag)})">
                <i class="fa-solid fa-hashtag" style="font-size:10px;color:var(--primary);"></i>
                <span style="font-size:13px;font-weight:600;color:var(--text);">${esc(tag)}</span>
                <span style="background:#3f3f46;color:#fff;border-radius:5px;padding:1px 6px;font-size:10px;font-weight:700;">${cnt}</span>
                <span data-wm-click="203" data-wm-click-0="${jsArg(tag)}" style="color:#ef4444;font-size:11px;margin-left:2px;cursor:pointer;" title="Remove tag from all bookmarks"><i class="fa-solid fa-xmark"></i></span>
            </div>
        `).join('')}
        </div>`;
}

function filterByTag(tag){
    closeModal('manageTagsModal');
    document.getElementById('search').value = tag;
    renderLinks();
}

function deleteTagGlobal(tag){
    if(!confirm(`Remove tag "#${tag}" from all bookmarks?`)) return;
    S.links.forEach(l=>{ if(l.tags) l.tags = l.tags.filter(t=>t!==tag); });
    save();
    renderAllTags();
    renderLinks();
    showToast(`Removed "#${tag}" from all bookmarks`, '#ef4444');
}

// ── IMPORT PICKER ──
const _IMP_BROWSER_META = {
    Chrome:  { icon:'fa-brands fa-chrome',  color:'#4285f4' },
    Firefox: { icon:'fa-brands fa-firefox', color:'#ff7139' },
    Safari:  { icon:'fa-brands fa-safari',  color:'#006cff' },
    Edge:    { icon:'fa-brands fa-edge',    color:'#0078d4' },
    Opera:   { icon:'fa-brands fa-opera',   color:'#ff1b2d' },
    Brave:   { icon:'fa-solid fa-shield-halved', color:'#FB542B' },
    Other:   { icon:'fa-solid fa-globe', color:'#6366f1' },
};

// Called when importBMModal opens — render browser rows based on what's already imported
function renderImportPicker(){
    const container = document.getElementById('importBrowserRows');
    if(!container) return;
    const present = Object.keys(_IMP_BROWSER_META);
    const cur = browserName(S.settings?.importBrowser) || 'Chrome';
    const folders = new Map(S.folders.map(folder=>[folder.id,folder]));
    container.innerHTML = present.map(b=>{
        const m = _IMP_BROWSER_META[b];
        const cnt = S.links.filter(l=>bookmarkBrowser(l,folders)===b).length;
        return `<label style="display:flex;align-items:center;gap:12px;padding:11px 14px;border-radius:12px;border:2px solid var(--border);cursor:pointer;transition:border-color .15s;" class="imp-pick-row">
            <input type="radio" name="imp-src" value="browser-${b.toLowerCase()}" class="imp-pick-rb" style="width:16px;height:16px;accent-color:${m.color};cursor:pointer;">
            <i class="${m.icon}" style="color:${m.color};font-size:18px;width:22px;text-align:center;"></i>
            <span style="font-size:13px;font-weight:600;flex:1;">${b==='Other'?(sourceLabels[S.lang] || sourceLabels.en)[4]:b}${cnt?` <span style="font-size:11px;color:var(--text-dim);font-weight:400;">${cnt} imported</span>`:''}</span>
        </label>`;
    }).join('');
    // Reset UI
    document.getElementById('importFormatRow').style.display = 'none';
    document.getElementById('importHelpBox').style.display = 'none';
    document.getElementById('importBMResult').style.display = 'none';
    document.getElementById('importBMOkBtn').style.display = 'none';
    document.getElementById('importBMCancelBtn').style.display = 'block';
    document.getElementById('import-pick-err').style.display = 'none';
    // Pre-select the current import browser
    const defRb = document.querySelector(`input[name="imp-src"][value="browser-${cur.toLowerCase()}"]`);
    if(defRb){ defRb.checked=true; onImportSourceChange(); }
}

function onImportSourceChange(){
    const sel = document.querySelector('input[name="imp-src"]:checked')?.value || '';
    const fmtRow = document.getElementById('importFormatRow');
    const helpBox = document.getElementById('importHelpBox');
    fmtRow.style.display = sel.startsWith('browser-') ? 'block' : 'none';
    if(sel.startsWith('browser-')) updateImportHelpVisibility();
    else helpBox.style.display = 'none';
}

function updateImportHelpVisibility(){
    const fmt = document.querySelector('input[name="imp-fmt"]:checked')?.value || 'html';
    document.getElementById('importHelpBox').style.display = (fmt==='html') ? 'block' : 'none';
}

// Wire format radio change
document.addEventListener('change', e=>{
    if(e.target.name === 'imp-fmt') updateImportHelpVisibility();
    if(e.target.name === 'imp-src') onImportSourceChange();
});

function doImportSelected(){
    const sel = document.querySelector('input[name="imp-src"]:checked')?.value;
    const err = document.getElementById('import-pick-err');
    err.style.display = 'none';
    if(!sel){ err.textContent='Please select a source.'; err.style.display='block'; return; }

    if(sel === 'personal'){
        // Personal JSON backup
        document.getElementById('bmPersonalJsonFile').click();
        return;
    }

    const fmt = document.querySelector('input[name="imp-fmt"]:checked')?.value || 'html';
    const selectedBrowser = browserName(sel.slice(8));
    if (!selectedBrowser) return;
    // Temporarily set import browser so the existing functions use it
    if(!S.settings) S.settings={};
    S.settings.importBrowser = selectedBrowser;
    wmStorage.setItem('ly_settings', JSON.stringify(S.settings));

    if(fmt === 'html'){
        document.getElementById('bmHtmlFile').click();
    } else {
        document.getElementById('bmJsonFile').click();
    }
}

async function importPersonalJSON(e) {
    if (!e.target.files?.[0]) return;
    await importData(e);
    closeModal('importBMModal');
}

// ── BROWSER CHOOSER ──
function setImportBrowser(name){
    if(!S.settings) S.settings={};
    S.settings.importBrowser = name;
    wmStorage.setItem('ly_settings',JSON.stringify(S.settings));
    updateBrowserPills();
    updateImportBMBrowserLabel();
    showToast('Import browser set to '+name,'#3b82f6');
}

function updateImportBMBrowserLabel(){
    const lbl = document.getElementById('importBMBrowserLabel');
    if(!lbl) return;
    const name = (S.settings&&S.settings.importBrowser)||'Chrome';
    const browserIconMap = {Chrome:'fa-brands fa-chrome',Firefox:'fa-brands fa-firefox',Edge:'fa-brands fa-edge',Safari:'fa-brands fa-safari',Opera:'fa-brands fa-opera',Brave:'fa-solid fa-shield-halved'};
    const browserColors = {Chrome:'#4285f4',Firefox:'#ff7139',Edge:'#0078d4',Safari:'#006cff',Opera:'#ff1b2d',Brave:'#FB542B'};
    lbl.innerHTML = `<i class="${browserIconMap[name]||'fa-solid fa-globe'}" style="color:${browserColors[name]||'#a1a1aa'};margin-right:6px;"></i>${name}`;
}


function updateBrowserPills(){
    const cur=(S.settings&&S.settings.importBrowser)||'Chrome';
    document.querySelectorAll('.browser-pill').forEach(p=>{
        p.classList.toggle('active', p.dataset.b===cur);
    });
}

function renderPerBrowserToggles(){
    const targets=[document.getElementById('perBrowserToggles'),document.getElementById('sp-perBrowserToggles')].filter(Boolean);
    const folders=new Map(S.folders.map(folder=>[folder.id,folder])),counts=new Map();
    for(const bookmark of S.links){const name=bookmarkBrowser(bookmark,folders);if(name)counts.set(name,(counts.get(name)||0)+1);}
    for(const target of targets){
        target.replaceChildren();
        if(!counts.size){const empty=document.createElement('p');empty.textContent='No imports yet';target.append(empty);continue;}
        for(const [name,count] of counts){
            const source=browserSource(name),hidden=S.settings?.hiddenBrowsers?.some(value=>browserName(value)===name);
            const row=document.createElement('div');row.style.cssText='display:flex;align-items:center;gap:10px;padding:6px 0';
            const icon=document.createElement('i');icon.className=source.icon;icon.style.color=source.color;
            const label=document.createElement('span');label.textContent=source.label+' ('+count+')';label.style.flex='1';
            const toggle=document.createElement('button');toggle.type='button';toggle.setAttribute('role','switch');toggle.setAttribute('aria-checked',String(!hidden));toggle.setAttribute('aria-label','Show '+source.label+' bookmarks');
            toggle.textContent=hidden?'Hidden':'Visible';toggle.style.cssText='border:1px solid var(--border);border-radius:12px;padding:7px 12px;color:var(--text);background:'+(hidden?'var(--card)':'var(--primary)');
            toggle.addEventListener('click',()=>toggleBrowserVisibility(name));row.append(icon,label,toggle);target.append(row);
        }
    }
}
function refreshBookmarkVisibility(){renderTabs();renderLinks();renderPerBrowserToggles();if(document.getElementById('sourceDD')?.classList.contains('open'))renderSourceBrowsers();}
function toggleBrowserVisibility(value){
    const name=browserName(value);if(!name)return;
    S.settings||={};const hidden=new Set((S.settings.hiddenBrowsers||[]).map(browserName).filter(Boolean));
    if(hidden.has(name))hidden.delete(name);else hidden.add(name);
    S.settings.hiddenBrowsers=[...hidden];wmStorage.setItem('ly_settings',JSON.stringify(S.settings));refreshBookmarkVisibility();
}

// ── ANIMATE EDIT MODE TOGGLE ──
function applyAnimEditMode(){S.settings.animEditMode=false;document.body.classList.add('no-edit-anim');}

// ── EXPORT IMPORTED BOOKMARKS ──
// ── COLLAPSIBLE SETTINGS SECTIONS ──
function toggleSettSection(bodyId, headerEl){
    const body = document.getElementById(bodyId);
    if(!body) return;
    const isOpen = body.classList.contains('open');
    body.classList.toggle('open', !isOpen);
    headerEl.classList.toggle('open', !isOpen);
    // Force arrow icon to stay visible after DOM repaint
    const arrow = headerEl.querySelector('.coll-arrow');
    if(arrow){ arrow.style.display='inline-flex'; arrow.style.visibility='visible'; arrow.style.opacity='1'; }
}

function resetCollapsibleSections(){
    document.querySelectorAll('.collapsible-section-body').forEach(b=>{
        b.classList.remove('open');
    });
    document.querySelectorAll('.sett-section-hdr.collapsible').forEach(h=>{
        h.classList.remove('open');
    });
}

// Patch openSettings to also reset collapsibles
const _origOpenSettings2 = openSettings;
openSettings = function(){
    resetCollapsibleSections();
    _origOpenSettings2();
};

// ── EXPORT BOOKMARKS (browser + personal picker + JSON/HTML format) ──
// ── UNIFIED EXPORT PICKER ──
const _BROWSER_META_EXPORT = {
    'Chrome':  { icon:'fa-brands fa-chrome',  color:'#4285f4' },
    'Firefox': { icon:'fa-brands fa-firefox',  color:'#ff7139' },
    'Safari':  { icon:'fa-brands fa-safari',   color:'#006cff' },
    'Edge':    { icon:'fa-brands fa-edge',     color:'#0078d4' },
    'Opera':   { icon:'fa-brands fa-opera',    color:'#ff1b2d' },
    'Brave':   { icon:'fa-solid fa-shield-halved', color:'#FB542B' },
};

function _getImportCounts(){
    const counts = {};
    S.links.forEach(l=>{
        if(!l.imported) return;
        const br = l.importedFrom || (() => { const f=S.folders.find(x=>x.id===l.fId); return f&&f._importBrowser||null; })();
        if(br) counts[br] = (counts[br]||0)+1;
    });
    return counts;
}

function openExportPicker(){
    const counts = _getImportCounts();
    const browsers = Object.keys(counts).filter(b=>counts[b]>0);
    const personalCount = S.links.filter(l=>!l.imported).length;
    const totalCount = S.links.length;

    const el = document.getElementById('deletePassContent');
    document.getElementById('deletePassTitle').textContent = '📤 Export Bookmarks';

    el.innerHTML = `
        <p style="font-size:13px;color:var(--text-dim);margin-bottom:12px;line-height:1.6;">Choose what to export:</p>

        <div style="font-size:11px;font-weight:700;color:var(--text-dim);text-transform:uppercase;letter-spacing:.5px;margin-bottom:6px;">Source</div>
        <div style="display:flex;flex-direction:column;gap:6px;margin-bottom:12px;">
            <!-- All Bookmarks quick option -->
            <label style="display:flex;align-items:center;gap:10px;padding:10px 12px;border-radius:12px;border:2px solid var(--border);cursor:pointer;" class="exp-pick-row" id="exp-all-row">
                <input type="checkbox" value="__all__" class="exp-pick-cb" style="width:16px;height:16px;accent-color:#7c3aed;cursor:pointer;">
                <i class="fa-solid fa-layer-group" style="color:#7c3aed;font-size:18px;width:22px;text-align:center;"></i>
                <span style="font-size:13px;font-weight:700;flex:1;">All Bookmarks</span>
                <span style="font-size:11px;color:var(--text-dim);font-weight:600;">${totalCount}</span>
            </label>
            ${personalCount ? `<label style="display:flex;align-items:center;gap:10px;padding:10px 12px;border-radius:12px;border:2px solid var(--border);cursor:pointer;" class="exp-pick-row">
                <input type="checkbox" value="__personal__" class="exp-pick-cb" style="width:16px;height:16px;accent-color:#22c55e;cursor:pointer;">
                <i class="fa-solid fa-bookmark" style="color:#22c55e;font-size:18px;width:22px;text-align:center;"></i>
                <span style="font-size:13px;font-weight:600;flex:1;">My Bookmarks <span style="font-size:11px;font-weight:400;color:var(--text-dim);">personal</span></span>
                <span style="font-size:11px;color:var(--text-dim);font-weight:600;">${personalCount}</span>
            </label>` : ''}
            ${browsers.map(b=>{
                const meta = _BROWSER_META_EXPORT[b] || { icon:'fa-solid fa-globe', color:'#a1a1aa' };
                return `<label style="display:flex;align-items:center;gap:10px;padding:10px 12px;border-radius:12px;border:2px solid var(--border);cursor:pointer;" class="exp-pick-row">
                    <input type="checkbox" value="${b}" class="exp-pick-cb" style="width:16px;height:16px;accent-color:${meta.color};cursor:pointer;">
                    <i class="${meta.icon}" style="color:${meta.color};font-size:18px;width:22px;text-align:center;"></i>
                    <span style="font-size:13px;font-weight:600;flex:1;">${b}</span>
                    <span style="font-size:11px;color:var(--text-dim);font-weight:600;">${counts[b]}</span>
                </label>`;
            }).join('')}
        </div>

        <div style="display:flex;gap:6px;margin-bottom:12px;">
            <button data-wm-click="204" style="background:rgba(34,197,94,.12);color:var(--primary);border:none;border-radius:8px;padding:5px 10px;font-size:11px;font-weight:600;cursor:pointer;">All</button>
            <button data-wm-click="205" style="background:var(--card);border:1px solid var(--border);color:var(--text-dim);border-radius:8px;padding:5px 10px;font-size:11px;font-weight:600;cursor:pointer;">None</button>
        </div>

        <div style="font-size:11px;font-weight:700;color:var(--text-dim);text-transform:uppercase;letter-spacing:.5px;margin-bottom:6px;">Format</div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:6px;margin-bottom:12px;">
            <label style="display:flex;align-items:center;gap:8px;padding:9px 10px;border-radius:10px;border:2px solid var(--border);cursor:pointer;font-size:12px;font-weight:600;">
                <input type="radio" name="exp-fmt" value="json" checked style="accent-color:var(--primary);"> <i class="fa-solid fa-code" style="color:#eab308;"></i> JSON
            </label>
            <label style="display:flex;align-items:center;gap:8px;padding:9px 10px;border-radius:10px;border:2px solid var(--border);cursor:pointer;font-size:12px;font-weight:600;">
                <input type="radio" name="exp-fmt" value="html" style="accent-color:var(--primary);"> <i class="fa-brands fa-html5" style="color:#e34c26;"></i> HTML
            </label>
        </div>

        <p id="export-pick-err" style="color:#ef4444;font-size:12px;margin-bottom:8px;display:none;"></p>
        <button class="btn-p" data-wm-click="206"><i class="fa-solid fa-download"></i> Export Selected</button>
        <button class="btn-s" data-wm-click="172">Cancel</button>
    `;

    // "All Bookmarks" checkbox selects/deselects all others
    setTimeout(()=>{
        const allCb = document.querySelector('.exp-pick-cb[value="__all__"]');
        if(allCb) allCb.addEventListener('change', ()=>{ toggleAllExportPicks(allCb.checked, true); });
        document.querySelectorAll('.exp-pick-row').forEach(row=>{
            const cb = row.querySelector('.exp-pick-cb');
            if(cb) cb.addEventListener('change', ()=>{
                row.style.borderColor = cb.checked ? (cb.style.accentColor||'var(--primary)') : 'var(--border)';
            });
        });
    }, 50);
    openModal('deletePassModal');
}

// exportImportedLinks opens the same picker (backwards compat from settings buttons)
function exportImportedLinks(){ openExportPicker(); }

function toggleAllExportPicks(checked, skipAllCheckbox){
    document.querySelectorAll('.exp-pick-cb').forEach(cb=>{
        if(skipAllCheckbox && cb.value==='__all__') return;
        cb.checked = checked;
        const row = cb.closest('.exp-pick-row');
        if(row) row.style.borderColor = checked ? (cb.style.accentColor||'var(--primary)') : 'var(--border)';
    });
}

function doExportSelected(){
    const selected = [...document.querySelectorAll('.exp-pick-cb:checked')].map(cb=>cb.value);
    const fmt = document.querySelector('input[name="exp-fmt"]:checked')?.value || 'json';
    const err = document.getElementById('export-pick-err');
    if(!selected.length){ err.textContent='Please select at least one source.'; err.style.display='block'; return; }
    err.style.display='none';

    const includeAll = selected.includes('__all__');
    const includePersonal = includeAll || selected.includes('__personal__');
    const selectedBrowsers = includeAll
        ? Object.keys(_getImportCounts())
        : selected.filter(s=>s!=='__personal__'&&s!=='__all__');

    const links = S.links.filter(l=>{
        if(!l.imported && includePersonal) return true;
        if(l.imported){
            if(includeAll) return true;
            if(l.importedFrom && selectedBrowsers.includes(l.importedFrom)) return true;
            const f = S.folders.find(x=>x.id===l.fId);
            if(f && f._importBrowser && selectedBrowsers.includes(f._importBrowser)) return true;
        }
        return false;
    });

    if(!links.length){ showToast('No bookmarks found for selection','#f59e0b'); closeModal('deletePassModal'); return; }

    const nameTag = includeAll ? 'all' : selected.map(s=>s==='__personal__'?'personal':s==='__all__'?'all':s.toLowerCase()).join('_');
    const dateTag = new Date().toISOString().slice(0,10);

    if(fmt === 'html'){
        const blob = new Blob([buildBookmarkHTML(links)], {type:'text/html;charset=utf-8'});
        const a = document.createElement('a'); a.href = URL.createObjectURL(blob);
        a.download = `webmark_${nameTag}_${dateTag}.html`;
        document.body.appendChild(a); a.click(); document.body.removeChild(a);
    } else {
        // Collect only the folders actually referenced by the exported links
        const usedFolderIds = new Set(links.map(l=>l.fId).filter(id=>id!=null));
        const exportedFolders = S.folders.filter(f=>usedFolderIds.has(f.id));
        const exportPayload = {f: exportedFolders, l: links};
        const blob = new Blob([JSON.stringify(exportPayload,null,2)], {type:'application/json'});
        const a = document.createElement('a'); a.href = URL.createObjectURL(blob);
        a.download = `webmark_${nameTag}_${dateTag}.json`;
        document.body.appendChild(a); a.click(); document.body.removeChild(a);
    }
    closeModal('deletePassModal');
    showToast(`Exported ${links.length} bookmarks as ${fmt.toUpperCase()}`, '#22c55e');
}

function buildBookmarkHTML(links){
    // Group by folder
    const folderMap = Object.create(null);
    links.forEach(l=>{
        const f = S.folders.find(x=>x.id===l.fId);
        const fname = f ? f.name : 'Unsorted';
        if(!folderMap[fname]) folderMap[fname]=[];
        folderMap[fname].push(l);
    });
    let inner = '';
    Object.entries(folderMap).forEach(([fname, items])=>{
        inner += `    <DT><H3>${esc(fname)}</H3>
    <DL><p>
`;
        items.forEach(l=>{
            const ts = Math.floor((l.id||Date.now())/1000);
            inner += `        <DT><A HREF="${esc(l.url)}" ADD_DATE="${ts}">${esc(l.title||l.url)}</A>
`;
        });
        inner += `    </DL><p>
`;
    });
    return `<!DOCTYPE NETSCAPE-Bookmark-file-1>
<!-- This is an automatically generated file.
     It will be read and overwritten.
     DO NOT EDIT! -->
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8">
<TITLE>Bookmarks</TITLE>
<H1>Bookmarks</H1>
<DL><p>
${inner}</DL>`;
}

// Keep old function name as alias for backward compat
function doExportSelectedBrowsers(){ doExportSelected(); }
function toggleAllBrowserPicks(c){ toggleAllExportPicks(c); }

// ── CLEAR IMPORTED BOOKMARKS (browser picker + password) ──
function clearImportedLinks(){
    // Collect which browsers have imported bookmarks
    const browserMeta = {
        'Chrome':  { icon:'fa-brands fa-chrome',  color:'#4285f4' },
        'Firefox': { icon:'fa-brands fa-firefox',  color:'#ff7139' },
        'Safari':  { icon:'fa-brands fa-safari',   color:'#006cff' },
        'Edge':    { icon:'fa-brands fa-edge',     color:'#0078d4' },
        'Opera':   { icon:'fa-brands fa-opera',    color:'#ff1b2d' },
        'Brave':   { icon:'fa-solid fa-shield-halved', color:'#FB542B' },
    };
    const counts = {};
    S.links.forEach(l => {
        if(l.imported && l.importedFrom){
            counts[l.importedFrom] = (counts[l.importedFrom]||0) + 1;
        }
    });
    // Also count by folder._importBrowser for links without importedFrom
    S.links.forEach(l => {
        if(l.imported && !l.importedFrom){
            const f = S.folders.find(x=>x.id===l.fId);
            if(f && f._importBrowser){
                counts[f._importBrowser] = (counts[f._importBrowser]||0) + 1;
            }
        }
    });

    const browsers = Object.keys(counts).filter(b => counts[b] > 0);
    if(!browsers.length){ showToast('No imported bookmarks to remove','#f59e0b'); return; }

    // Build modal content
    const el = document.getElementById('deletePassContent');
    const titleEl = document.getElementById('deletePassTitle');
    titleEl.textContent = '🗑️ Remove Imported Bookmarks';

    el.innerHTML = `
        <p style="font-size:13px;color:var(--text-dim);margin-bottom:16px;line-height:1.6;">
            Choose which browser's imported bookmarks to remove:
        </p>
        <div style="display:flex;flex-direction:column;gap:8px;margin-bottom:16px;">
            ${browsers.map(b => {
                const meta = browserMeta[b] || { icon:'fa-solid fa-globe', color:'#a1a1aa' };
                return `<label style="display:flex;align-items:center;gap:12px;padding:12px 14px;border-radius:12px;border:2px solid var(--border);cursor:pointer;transition:border-color .15s;" class="browser-pick-row" data-browser="${b}">
                    <input type="checkbox" value="${b}" class="browser-pick-cb" style="width:18px;height:18px;accent-color:${meta.color};cursor:pointer;">
                    <i class="${meta.icon}" style="color:${meta.color};font-size:20px;width:24px;text-align:center;"></i>
                    <span style="font-size:14px;font-weight:600;flex:1;">${b}</span>
                    <span style="font-size:12px;color:var(--text-dim);font-weight:600;">${counts[b]} bookmark${counts[b]!==1?'s':''}</span>
                </label>`;
            }).join('')}
        </div>
        <div style="display:flex;gap:8px;align-items:center;margin-bottom:10px;">
            <button data-wm-click="207" style="background:var(--primary-light,rgba(34,197,94,.12));color:var(--primary);border:none;border-radius:8px;padding:6px 12px;font-size:12px;font-weight:600;cursor:pointer;">Select All</button>
            <button data-wm-click="208" style="background:var(--card);border:1px solid var(--border);color:var(--text-dim);border-radius:8px;padding:6px 12px;font-size:12px;font-weight:600;cursor:pointer;">Deselect All</button>
        </div>
        <p id="clear-browser-err" style="color:#ef4444;font-size:12px;margin-bottom:8px;display:none;"></p>
        <button class="btn-p" data-wm-click="209" style="background:#ef4444;"><i class="fa-solid fa-trash"></i> Remove Selected</button>
        <button class="btn-s" data-wm-click="172">Cancel</button>
    `;

    // Highlight checked rows
    setTimeout(()=>{
        document.querySelectorAll('.browser-pick-row').forEach(row=>{
            const cb = row.querySelector('.browser-pick-cb');
            cb.addEventListener('change', ()=>{
                row.style.borderColor = cb.checked ? cb.style.accentColor || 'var(--primary)' : 'var(--border)';
            });
        });
    }, 50);

    openModal('deletePassModal');
}

function toggleAllBrowserPicks(checked){
    document.querySelectorAll('.browser-pick-cb').forEach(cb=>{
        cb.checked = checked;
        const row = cb.closest('.browser-pick-row');
        if(row) row.style.borderColor = checked ? (cb.style.accentColor||'var(--primary)') : 'var(--border)';
    });
}

function confirmClearSelectedBrowsers(){
    const selected = [...document.querySelectorAll('.browser-pick-cb:checked')].map(cb=>cb.value);
    const err = document.getElementById('clear-browser-err');
    if(!selected.length){
        err.textContent = 'Please select at least one browser.';
        err.style.display = 'block';
        return;
    }
    err.style.display = 'none';
    closeModal('deletePassModal');

    // Now require delete password
    requireDeletePassword(()=>{
        let removed = 0;
        selected.forEach(browser=>{
            const before = S.links.length;
            S.links = S.links.filter(l=>{
                if(!l.imported) return true;
                if(l.importedFrom === browser) return false;
                const f = S.folders.find(x=>x.id===l.fId);
                if(f && f._importBrowser === browser) return false;
                return true;
            });
            removed += before - S.links.length;
            // Remove browser folders for selected browsers
            S.folders = S.folders.filter(f=>!(f._browserImport && f._importBrowser===browser));
        });
        save(); init();
        showToast(`Removed ${removed} imported bookmark${removed!==1?'s':''} from ${selected.join(', ')}`, '#ef4444');
    });
}

// Close modal on backdrop tap
document.querySelectorAll('.modal').forEach(m=>m.addEventListener('click',function(e){ if(e.target===this) closeModal(this.id); }));

// ── REMINDER ──
const _remState = { year:0, month:0, day:0, hour:0, min:0 };
const _remMonths=['January','February','March','April','May','June','July','August','September','October','November','December'];

function openReminderPicker(){
    const l=S.links.find(x=>x.id===S.editingLink);
    const now=new Date();
    if(l&&l.reminder){
        const d=new Date(l.reminder);
        _remState.year=d.getFullYear(); _remState.month=d.getMonth();
        _remState.day=d.getDate(); _remState.hour=d.getHours(); _remState.min=d.getMinutes();
    } else {
        _remState.year=now.getFullYear(); _remState.month=now.getMonth();
        _remState.day=now.getDate(); _remState.hour=now.getHours(); _remState.min=now.getMinutes();
    }
    renderRemCalendar(); renderRemTime();
    openModal('reminderModal');
}

function renderRemCalendar(){
    document.getElementById('remCalTitle').textContent=_remMonths[_remState.month]+' '+_remState.year;
    const first=new Date(_remState.year,_remState.month,1).getDay();
    const days=new Date(_remState.year,_remState.month+1,0).getDate();
    const today=new Date();
    let h='';
    for(let i=0;i<first;i++) h+=`<div></div>`;
    for(let d=1;d<=days;d++){
        const isToday=d===today.getDate()&&_remState.month===today.getMonth()&&_remState.year===today.getFullYear();
        const isSel=d===_remState.day;
        h+=`<div data-wm-click="210" data-wm-click-0="${d}" style="padding:6px 2px;border-radius:50%;cursor:pointer;font-size:13px;font-weight:${isSel?700:400};background:${isSel?'var(--primary)':'transparent'};color:${isSel?'#000':isToday?'var(--primary)':'var(--text)'};aspect-ratio:1;display:flex;align-items:center;justify-content:center;">${d}</div>`;
    }
    document.getElementById('remCalDays').innerHTML=h;
}

function remSelDay(d){ _remState.day=d; renderRemCalendar(); }
function remCalPrev(){ _remState.month--; if(_remState.month<0){_remState.month=11;_remState.year--;} renderRemCalendar(); }
function remCalNext(){ _remState.month++; if(_remState.month>11){_remState.month=0;_remState.year++;} renderRemCalendar(); }
function renderRemTime(){
    document.getElementById('remHour').textContent=String(_remState.hour).padStart(2,'0');
    document.getElementById('remMin').textContent=String(_remState.min).padStart(2,'0');
}
function remTimeAdj(part,delta){
    if(part==='h'){ _remState.hour=(_remState.hour+delta+24)%24; }
    else { _remState.min=(_remState.min+delta+60)%60; }
    renderRemTime();
}
function saveReminder(){
    const l=S.links.find(x=>x.id===S.editingLink); if(!l) return;
    const dt=new Date(_remState.year,_remState.month,_remState.day,_remState.hour,_remState.min);
    l.reminder=dt.getTime(); save();
    document.getElementById('dtReminderVal').textContent=dt.toLocaleString(undefined,{month:'short',day:'numeric',hour:'2-digit',minute:'2-digit'});
    document.getElementById('dtReminderVal').style.color='var(--primary)';
    scheduleReminder(l);
    closeModal('reminderModal');
    markChanged();
    showToast('Reminder set for '+dt.toLocaleString(undefined,{month:'short',day:'numeric',hour:'2-digit',minute:'2-digit'}),'var(--primary)');
}

function scheduleReminder(l){
    if(!l||!l.reminder) return;
    const delay=l.reminder-Date.now();
    if(delay<=0) return; // already past
    if('Notification' in window){
        Notification.requestPermission().then(perm=>{
            if(perm==='granted'){
                // Store reminder in wmStorage for persistence
                let remList=JSON.parse(wmStorage.getItem('ly_reminders')||'{}');
                remList[l.id]={ts:l.reminder,title:l.title,url:l.url||''};
                wmStorage.setItem('ly_reminders',JSON.stringify(remList));
                // Schedule in-session notification
                clearTimeout(window['_rem_'+l.id]);
                window['_rem_'+l.id]=setTimeout(()=>{
                    new Notification('⏰ WebMark Reminder',{body:l.title,icon:'https://ui-avatars.com/api/?name=W&background=22c55e&color=000',tag:'wm-rem-'+l.id});
                    // Remove from list after firing
                    let rl=JSON.parse(wmStorage.getItem('ly_reminders')||'{}');
                    delete rl[l.id]; wmStorage.setItem('ly_reminders',JSON.stringify(rl));
                    showToast('⏰ Reminder: '+l.title,'var(--primary)');
                },delay);
            } else {
                showToast('Enable notifications for reminders!','#f59e0b');
            }
        });
    } else {
        // Fallback: use in-page alert via setTimeout
        clearTimeout(window['_rem_'+l.id]);
        window['_rem_'+l.id]=setTimeout(()=>{
            showToast('⏰ Reminder: '+l.title,'var(--primary)');
            // Show in-page popup
            const popup=document.createElement('div');
            popup.style.cssText='position:fixed;top:80px;left:50%;transform:translateX(-50%);background:#1c1c1e;border:2px solid var(--primary);color:#fff;padding:16px 22px;border-radius:16px;font-size:14px;font-weight:600;z-index:9999;max-width:320px;text-align:center;box-shadow:0 8px 32px rgba(0,0,0,.5);';
            popup.innerHTML=`<i class="fa-solid fa-bell" style="color:var(--primary);font-size:20px;display:block;margin-bottom:8px;"></i><div>⏰ Reminder</div><div style="font-size:12px;font-weight:400;margin-top:4px;color:#a1a1aa;">${l.title}</div><button data-wm-click="211" style="margin-top:10px;background:var(--primary);border:none;border-radius:8px;padding:6px 16px;color:#000;font-weight:700;cursor:pointer;">Dismiss</button>`;
            document.body.appendChild(popup);
            setTimeout(()=>popup.remove(),15000);
        },delay);
    }
}

function initReminders(){
    // On page load, reschedule any saved reminders
    S.links.forEach(l=>{ if(l.reminder && l.reminder>Date.now()) scheduleReminder(l); });
}

// ── SAVE CHANGES BUTTON GREEN WHEN CHANGES MADE ──
function markChanged(){
    const btn=document.querySelector('#editDetailModal button[data-wm-click="56"]');
    if(btn){ btn.style.background='var(--primary)'; btn.style.color='#000'; btn.style.borderColor='var(--primary)'; }
}

// Intercept changes in editDetail to trigger markChanged
// ── SYNC — Code-based via paste.rs (truly CORS-free, no account needed) ──

function initUserChip(){
    // Header shows static "WebMark" + "by saad" — no greeting element needed
    const greeting=document.getElementById('greetingText');
    if(greeting){
        const h=new Date().getHours();
        const tw=h<12?'Good morning':h<17?'Good afternoon':'Good evening';
        const name=wmStorage.getItem('ly_username')||'';
        greeting.textContent = name ? `${tw}, ${name.split(' ')[0]}` : tw+'!';
    }
}

function openSyncModal(){
    const name=wmStorage.getItem('ly_username')||'';
    const ini=name?name.trim().split(' ').map(w=>w[0]).join('').toUpperCase().slice(0,2):'?';
    const sAvatar=document.getElementById('syncAvatarInModal');
    const sName=document.getElementById('syncUserName');
    if(sAvatar) sAvatar.textContent=ini;
    if(sName) sName.textContent=name||'Tap Edit to set your name';
    const saved=wmStorage.getItem('ly_synccode');
    const savedBox=document.getElementById('syncSavedCodeBox');
    if(saved&&savedBox){
        savedBox.style.display='block';
        document.getElementById('syncSavedCode').textContent=saved;
    }
    document.getElementById('syncUploadResult').style.display='none';
    document.getElementById('syncDownloadResult').style.display='none';
    document.getElementById('syncCodeInput').value='';
    openModal('syncModal');
}

function changeSyncName(){
    const cur=wmStorage.getItem('ly_username')||'';
    const n=(prompt('Enter your name:',cur)||'').trim();
    if(n){ 
        // SAFE: Only save name. NEVER touch bookmarks or folders.
        wmStorage.setItem('ly_username',n); 
        initUserChip(); 
        openSyncModal(); 
    }
}

// ── SYNC — Cross-device via JSONBin.io (free, no account needed, truly cross-device) ──
// Uses a public JSONBin master bin to store user data. Each sync gets a unique bin ID.
// Format: code = "JB" + 6-char alphanumeric bin ID in uppercase

// Cloud uploading is not configured; use local backup transfer.
function _saveSyncCode(code){
    wmStorage.setItem('ly_synccode',code);
    const btn=document.getElementById('syncUploadBtn');
    btn.disabled=false;
    btn.innerHTML='<i class="fa-solid fa-cloud-arrow-up"></i> Generate Sync Code';
    const box=document.getElementById('syncSavedCodeBox');
    document.getElementById('syncSavedCode').textContent=code;
    if(box) box.style.display='block';
}

function _showUploadOK(res,code){
    res.style.display='block';
    res.innerHTML=`<div style="color:var(--primary);font-size:13px;line-height:1.8;">
        <i class="fa-solid fa-check-circle"></i> <b>Uploaded!</b> ${S.links.length} bookmarks saved online.<br>
        <small style="color:var(--text-dim);">Enter this code on any device or browser to restore.</small>
    </div>`;
}

// ── DOWNLOAD: resolve code → fetch data ──
function applySync(d,code){
    const res=document.getElementById('syncDownloadResult');
    const mergeChoice = confirm(`Load ${d.l.length} bookmarks${d.n?' from '+d.n:''}?\n\nClick OK to REPLACE all current bookmarks.\nClick Cancel to abort (your bookmarks are safe).`);
    if(!mergeChoice){ res.style.display='none'; return; }
    // Only replace data when user explicitly confirms
    S.folders=d.f||[]; S.links=d.l; save();
    if(d.n) wmStorage.setItem('ly_username',d.n);
    wmStorage.setItem('ly_synccode',code);
    document.getElementById('syncSavedCode').textContent=code;
    document.getElementById('syncSavedCodeBox').style.display='block';
    res.innerHTML=`<span style="color:var(--primary);">✓ Loaded ${d.l.length} bookmarks!</span>`;
    initUserChip(); init();
    setTimeout(()=>closeModal('syncModal'),1500);
}

function copySyncCode(){
    const code=document.getElementById('syncSavedCode').textContent;
    wmCopy(code)
        .then(()=>{
            const btn=document.querySelector('#syncSavedCodeBox button');
            if(btn){ const orig=btn.innerHTML; btn.innerHTML='<i class="fa-solid fa-check"></i> Copied!'; setTimeout(()=>btn.innerHTML=orig,1800); }
        })
        .catch(()=>prompt('Your sync code:',code));
}

// ── TOAST NOTIFICATION ──
function showToast(msg, color='var(--primary)', duration=2200){
    let t=document.getElementById('globalToast');
    if(!t){ t=document.createElement('div'); t.id='globalToast'; t.style.cssText='position:fixed;bottom:100px;left:50%;transform:translateX(-50%);background:#1c1c1e;border:1px solid var(--border);color:#fff;padding:10px 20px;border-radius:20px;font-size:13px;font-weight:600;z-index:9999;opacity:0;transition:opacity .25s;pointer-events:none;white-space:nowrap;'; document.body.appendChild(t); }
    t.textContent=msg; t.style.borderColor=color; t.style.color=color; t.style.opacity='1';
    clearTimeout(t._to); t._to=setTimeout(()=>t.style.opacity='0', duration);
}

// ── DELETE PASSWORD (username + password) ──
function getDeletePass(){ return wmStorage.getItem('ly_delpass')||null; }
function getDeleteUser(){ return wmStorage.getItem('ly_deluser')||null; }
function maskUsername(u){ if(!u||u.length<=2) return u; return u[0]+'*'.repeat(Math.max(1,u.length-2))+u[u.length-1]; }

function requireDeletePassword(onSuccess){
    window._dpFromDeleteAction=true;
    if(!getDeletePass()){ onSuccess(); return; }  // No password set — proceed directly
    openEnterDeletePassword(onSuccess);
}

function openSetDeletePassword(onSuccess){
    const el=document.getElementById('deletePassContent');
    document.getElementById('deletePassTitle').textContent='🔐 Set Delete Password';
    el.innerHTML=`
        <p style="font-size:13px;color:var(--text-dim);margin-bottom:16px;line-height:1.6;">Create a username and password to protect bookmarks from deletion. Keep your username secret — it's needed to change the password.</p>
        <div class="field"><label>Username</label><input type="text" id="dp-username" placeholder="Choose a username" autocomplete="off" autocorrect="off" spellcheck="false"></div>
        <div class="field"><label>Password</label><input type="password" id="dp-new" placeholder="Min 4 characters" autocomplete="new-password"></div>
        <div class="field"><label>Confirm Password</label><input type="password" id="dp-confirm" placeholder="Confirm password" autocomplete="new-password"></div>
        <div id="dp-err" style="color:#ef4444;font-size:12px;margin-bottom:10px;display:none;"></div>
        <button class="btn-p" data-wm-click="212" style="background:#ef4444;"><i class="fa-solid fa-lock"></i> Set Password & Continue</button>
        <button class="btn-s" data-wm-click="172">Cancel</button>
    `;
    window._dpCallback=onSuccess;
    openModal('deletePassModal');
    setTimeout(()=>document.getElementById('dp-username')?.focus(),200);
}

function saveDeletePassword(){
    const uname=(document.getElementById('dp-username')?.value||'').trim();
    const p1=document.getElementById('dp-new')?.value||'';
    const p2=document.getElementById('dp-confirm')?.value||'';
    const err=document.getElementById('dp-err');
    if(!uname||uname.length<2){ err.style.display='block'; err.textContent='Username must be at least 2 characters.'; return; }
    if(!p1||p1.length<4){ err.style.display='block'; err.textContent='Password must be at least 4 characters.'; return; }
    if(p1!==p2){ err.style.display='block'; err.textContent='Passwords do not match.'; return; }
    wmStorage.setItem('ly_deluser', wmEncode(uname));
    wmStorage.setItem('ly_delpass', wmEncode(p1));
    const cb=window._dpCallback; window._dpCallback=null;
    closeModal('deletePassModal');
    showToast('Delete password set! ✓','var(--primary)');
    updateDelPassLabel && updateDelPassLabel();
    if(cb && window._dpFromDeleteAction){ window._dpFromDeleteAction=false; cb(); }
}

function openEnterDeletePassword(onSuccess){
    const el=document.getElementById('deletePassContent');
    document.getElementById('deletePassTitle').textContent='🔐 Enter Delete Password';
    el.innerHTML=`
        <p style="font-size:13px;color:var(--text-dim);margin-bottom:16px;line-height:1.6;">Enter your password to confirm this action.</p>
        <div class="field"><label>Password</label><input type="password" id="dp-enter" placeholder="Enter your password" autocomplete="off" autocorrect="off" spellcheck="false" data-wm-keydown="213"></div>
        <div id="dp-err2" style="color:#ef4444;font-size:12px;margin-bottom:10px;display:none;"></div>
        <button class="btn-p" data-wm-click="214" style="background:#ef4444;"><i class="fa-solid fa-trash"></i> Confirm Delete</button>
        <button class="btn-s" data-wm-click="172">Cancel</button>
        <div style="margin-top:8px;text-align:center;"><span data-wm-click="215" style="font-size:12px;color:var(--text-dim);cursor:pointer;text-decoration:underline;">Forgot password?</span></div>
    `;
    window._dpCallback=onSuccess;
    openModal('deletePassModal');
    setTimeout(()=>{ const f=document.getElementById('dp-enter'); if(f){f.value='';f.focus();} },200);
}

function verifyDeletePassword(){
    const val=document.getElementById('dp-enter')?.value||'';
    const stored=getDeletePass();
    const err=document.getElementById('dp-err2');
    if(!val){ err.style.display='block'; err.textContent='Please enter your password.'; return; }
    if(wmEncode(val)!==stored){ err.style.display='block'; err.textContent='Incorrect password. Try again.'; document.getElementById('dp-enter').value=''; document.getElementById('dp-enter').focus(); return; }
    closeModal('deletePassModal');
    const cb=window._dpCallback; window._dpCallback=null;
    if(cb) cb();
}

function openForgotPassword(){
    const el=document.getElementById('deletePassContent');
    document.getElementById('deletePassTitle').textContent='🔐 Forgot Password';
    const storedUser=getDeleteUser();
    if(!storedUser){
        el.innerHTML=`
            <div style="background:rgba(239,68,68,.08);border:1px solid rgba(239,68,68,.3);border-radius:10px;padding:12px 14px;margin-bottom:14px;font-size:13px;color:#fca5a5;">
                <i class="fa-solid fa-circle-exclamation"></i> No local username on file. Cannot reset the deletion lock.
            </div>
            <button class="btn-s" data-wm-click="172">Close</button>
        `;
        return;
    }
    const masked=maskUsername(wmDecode(storedUser));
    el.innerHTML=`
        <p style="font-size:13px;color:var(--text-dim);margin-bottom:16px;line-height:1.6;">Enter your username to reset the password. Only the first and last character are shown.</p>
        <div style="background:rgba(59,130,246,.08);border:1px solid rgba(59,130,246,.3);border-radius:10px;padding:12px 14px;margin-bottom:16px;font-size:15px;color:#93c5fd;display:flex;align-items:center;gap:10px;font-family:monospace;font-weight:700;letter-spacing:2px;">
            <i class="fa-solid fa-user-secret"></i> ${masked}
        </div>
        <div class="field"><label>Enter Your Username</label><input type="text" id="dp-recovery-user" placeholder="Type your full username" autocomplete="off" autocorrect="off" spellcheck="false" data-wm-keydown="216"></div>
        <div id="dp-rec-err" style="color:#ef4444;font-size:12px;margin-bottom:10px;display:none;"></div>
        <button class="btn-p" data-wm-click="217"><i class="fa-solid fa-arrow-right"></i> Verify Username</button>
        <button class="btn-s" data-wm-click="172">Cancel</button>
    `;
    setTimeout(()=>document.getElementById('dp-recovery-user')?.focus(),200);
}

function verifyRecoveryUsername(){
    const val=(document.getElementById('dp-recovery-user')?.value||'').trim();
    const stored=getDeleteUser();
    const err=document.getElementById('dp-rec-err');
    if(!val){ err.style.display='block'; err.textContent='Please enter your username.'; return; }
    if(wmEncode(val)!==stored){ err.style.display='block'; err.textContent='Incorrect username. Try again.'; return; }
    // Verified — show new password form
    const el=document.getElementById('deletePassContent');
    document.getElementById('deletePassTitle').textContent='🔐 Set New Password';
    el.innerHTML=`
        <div style="background:rgba(34,197,94,.08);border:1px solid rgba(34,197,94,.25);border-radius:10px;padding:10px 14px;margin-bottom:14px;font-size:13px;color:#86efac;"><i class="fa-solid fa-check-circle"></i> Username verified!</div>
        <div class="field"><label>New Password</label><input type="password" id="dp-reset1" placeholder="New password" autocomplete="new-password"></div>
        <div class="field"><label>Confirm Password</label><input type="password" id="dp-reset2" placeholder="Confirm password" autocomplete="new-password"></div>
        <div id="dp-err3" style="color:#ef4444;font-size:12px;margin-bottom:10px;display:none;"></div>
        <button class="btn-p" data-wm-click="218"><i class="fa-solid fa-lock"></i> Set New Password</button>
        <button class="btn-s" data-wm-click="172">Cancel</button>
    `;
}

function resetDeletePassword(){
    const p1=document.getElementById('dp-reset1')?.value||'';
    const p2=document.getElementById('dp-reset2')?.value||'';
    const err=document.getElementById('dp-err3');
    if(!p1||p1.length<4){ err.style.display='block'; err.textContent='Must be at least 4 characters.'; return; }
    if(p1!==p2){ err.style.display='block'; err.textContent='Passwords do not match.'; return; }
    wmStorage.setItem('ly_delpass', wmEncode(p1));
    closeModal('deletePassModal');
    showToast('Password reset successfully! ✓','var(--primary)');
}

function openManageDeletePassword(){
    const pass=getDeletePass();
    const storedUser=getDeleteUser();
    const el=document.getElementById('deletePassContent');
    document.getElementById('deletePassTitle').textContent='🔐 Delete Password';
    if(!pass){
        el.innerHTML=`
            <p style="font-size:13px;color:var(--text-dim);margin-bottom:16px;line-height:1.6;">No delete password set. Add one to protect bookmarks from accidental deletion.</p>
            <div class="field"><label>Username</label><input type="text" id="dp-username" placeholder="Choose a username" autocomplete="off" autocorrect="off" spellcheck="false"></div>
            <div class="field"><label>Password</label><input type="password" id="dp-new" placeholder="Min 4 characters" autocomplete="new-password"></div>
            <div class="field"><label>Confirm Password</label><input type="password" id="dp-confirm" placeholder="Confirm password" autocomplete="new-password"></div>
            <div id="dp-err" style="color:#ef4444;font-size:12px;margin-bottom:10px;display:none;"></div>
            <button class="btn-p" data-wm-click="212" style="background:var(--primary);"><i class="fa-solid fa-lock"></i> Set Password</button>
            <button class="btn-s" data-wm-click="172">Cancel</button>
        `;
    } else {
        const maskedUser=storedUser?maskUsername(wmDecode(storedUser)):'—';
        el.innerHTML=`
            <div style="background:rgba(34,197,94,.08);border:1px solid rgba(34,197,94,.25);border-radius:12px;padding:14px;margin-bottom:16px;">
                <div style="display:flex;align-items:center;gap:10px;margin-bottom:8px;">
                    <i class="fa-solid fa-shield-halved" style="color:var(--primary);font-size:22px;"></i>
                    <div><div style="font-size:14px;font-weight:700;color:var(--primary);">Password Protected</div><div style="font-size:12px;color:var(--text-dim);margin-top:2px;">All deletions require your password</div></div>
                </div>
                <div style="background:rgba(0,0,0,.15);border-radius:8px;padding:8px 12px;font-size:13px;color:var(--text-dim);display:flex;align-items:center;gap:8px;">
                    <i class="fa-solid fa-user-secret" style="color:var(--primary);"></i>
                    <span>Username: <b style="font-family:monospace;letter-spacing:2px;color:var(--text);">${maskedUser}</b></span>
                </div>
            </div>
            <button class="btn-p" data-wm-click="219" style="background:#8b5cf6;"><i class="fa-solid fa-user-pen"></i> Change Username</button>
            <button class="btn-p" data-wm-click="220" style="background:#3b82f6;"><i class="fa-solid fa-key"></i> Change Password</button>
            <button class="btn-d" data-wm-click="221"><i class="fa-solid fa-lock-open"></i> Remove Password</button>
            <button class="btn-s" data-wm-click="172">Close</button>
        `;
    }
    openModal('deletePassModal');
}

function openChangePasswordWithUsername(){
    // Must verify username first
    openForgotPassword();
}

function openChangeUsername(){
    const el = document.getElementById('deletePassContent');
    document.getElementById('deletePassTitle').textContent = '👤 Change Username';
    el.innerHTML = `
        <p style="font-size:13px;color:var(--text-dim);margin-bottom:16px;line-height:1.6;">Enter your current password, then set a new username.</p>
        <div class="field"><label>Current Password</label><input type="password" id="dp-cu-verify" placeholder="Current password" autocomplete="off"></div>
        <div class="field"><label>New Username</label><input type="text" id="dp-cu-newuser" placeholder="New username" autocomplete="off" autocorrect="off" spellcheck="false"></div>
        <div id="dp-cu-err" style="color:#ef4444;font-size:12px;margin-bottom:10px;display:none;"></div>
        <button class="btn-p" data-wm-click="222" style="background:#8b5cf6;"><i class="fa-solid fa-user-pen"></i> Save Username</button>
        <button class="btn-s" data-wm-click="131">Back</button>
    `;
    setTimeout(()=>document.getElementById('dp-cu-verify')?.focus(), 200);
}

function doChangeUsername(){
    const pass = document.getElementById('dp-cu-verify')?.value || '';
    const newUser = (document.getElementById('dp-cu-newuser')?.value || '').trim();
    const err = document.getElementById('dp-cu-err');
    if(wmEncode(pass) !== getDeletePass()){ err.textContent='Incorrect password.'; err.style.display='block'; document.getElementById('dp-cu-verify').value=''; document.getElementById('dp-cu-verify').focus(); return; }
    if(!newUser || newUser.length < 2){ err.textContent='Username must be at least 2 characters.'; err.style.display='block'; return; }
    wmStorage.setItem('ly_deluser', wmEncode(newUser));
    closeModal('deletePassModal');
    showToast('Username updated! ✓', 'var(--primary)');
    updateDelPassLabel && updateDelPassLabel();
}

function confirmRemoveDeletePassword(){
    const el=document.getElementById('deletePassContent');
    document.getElementById('deletePassTitle').textContent='🔐 Remove Password';
    el.innerHTML=`
        <p style="font-size:13px;color:var(--text-dim);margin-bottom:16px;line-height:1.6;">Enter your current password to remove protection.</p>
        <div class="field"><label>Current Password</label><input type="password" id="dp-remove-verify" placeholder="Enter current password" autocomplete="off" autocorrect="off" spellcheck="false" data-wm-keydown="223"></div>
        <div id="dp-remove-err" style="color:#ef4444;font-size:12px;margin-bottom:10px;display:none;"></div>
        <button class="btn-p" data-wm-click="224" style="background:#ef4444;"><i class="fa-solid fa-lock-open"></i> Remove Password</button>
        <button class="btn-s" data-wm-click="131">Back</button>
    `;
    setTimeout(()=>document.getElementById('dp-remove-verify')?.focus(),200);
}

function doRemoveDeletePassword(){
    const val=document.getElementById('dp-remove-verify')?.value||'';
    const stored=getDeletePass();
    const err=document.getElementById('dp-remove-err');
    if(!val){ err.style.display='block'; err.textContent='Please enter your password.'; return; }
    if(wmEncode(val)!==stored){ err.style.display='block'; err.textContent='Incorrect password.'; document.getElementById('dp-remove-verify').value=''; document.getElementById('dp-remove-verify').focus(); return; }
    wmStorage.removeItem('ly_delpass');
    wmStorage.removeItem('ly_deluser');
    closeModal('deletePassModal');
    showToast('Delete password removed.','#f59e0b');
    updateDelPassLabel && updateDelPassLabel();
}

function findDuplicates(){
    const seen=new Set(), dups=[];
    const folders=new Map(S.folders.map(folder=>[folder.id,folder]));
    S.links.forEach(link=>{ const key=bookmarkSourceKey(link,folders); if(seen.has(key)) dups.push(link.id); else seen.add(key); });
    if(!dups.length){ showToast('No duplicates found! ✓','var(--primary)'); return; }
    if(confirm(`Found ${dups.length} duplicate bookmark(s). Remove them?`)){
        requireDeletePassword(()=>{ S.links=S.links.filter(l=>!dups.includes(l.id)); save(); init(); showToast(`Removed ${dups.length} duplicate(s)!`,'var(--primary)'); closeModal('settingsModal'); });
    }
}

function archiveAllRead(){
    const visited=S.links.filter(l=>!l.archived&&l.views>0);
    if(!visited.length){ showToast('No visited bookmarks to archive.','#f59e0b'); return; }
    if(confirm(`Archive ${visited.length} visited bookmark(s)?`)){ visited.forEach(l=>l.archived=true); save(); init(); showToast(`Archived ${visited.length} bookmark(s)!`,'var(--primary)'); closeModal('settingsModal'); }
}

function openLink(url){
    const mode = wmStorage.getItem('ly_openLinkMode') || 'newtab';
    openLinkMode(url, mode);
}
function setOpenLinkMode(mode){
    wmStorage.setItem('ly_openLinkMode', mode);
    // Sync all select elements
    document.querySelectorAll('#sp-openLinkSelect,#desk-openLinkSelect').forEach(s=>{ if(s) s.value=mode; });
}
function openLinkMode(url, mode){
    // Close all open dropdowns first
    document.querySelectorAll('.open-dd.show').forEach(d=>d.classList.remove('show'));
    if(mode==='newtab')    { window.open(url,'_blank'); }
    else if(mode==='current') { window.location.href=url; }
    else if(mode==='incognito'){
        // Can't open incognito programmatically, so copy URL and show info
        wmCopy(url).then(()=>{
            showToast('🕵️ URL copied! Open an incognito window and paste.','#a78bfa');
        }).catch(()=>{ window.open(url,'_blank'); });
    }
    else if(mode==='copy') {
        wmCopy(url).then(()=>showToast('🔗 Link copied!','#22d3ee')).catch(()=>prompt('Copy:',url));
    }
}
function toggleOpenDD(el, url){
    // Close all others first
    document.querySelectorAll('.open-dd.show').forEach(d=>{
        if(d!==el.nextElementSibling) d.classList.remove('show');
    });
    const dd = el.nextElementSibling;
    if(dd) dd.classList.toggle('show');
}
// Close open-dd when clicking outside
document.addEventListener('click', function(){
    document.querySelectorAll('.open-dd.show').forEach(d=>d.classList.remove('show'));
});

// ══════════════════════════════════════════════
// ── NEW FEATURES ──
// ══════════════════════════════════════════════


// ── 2. SURPRISE ME — open a random bookmark ──
function surpriseMe() {
    const pool = S.links.filter(l=>!l.archived);
    if(!pool.length){ showToast('No bookmarks yet!','#f59e0b'); return; }
    const pick = pool[Math.floor(Math.random()*pool.length)];
    showToast('🎲 Opening: '+pick.title,'var(--primary)');
    setTimeout(()=>openLink(pick.url), 400);
}

// ── 3. COPY URL to clipboard from card ──
function copyUrl(url, el) {
    wmCopy(url).then(()=>{
        const orig = el.innerHTML;
        el.innerHTML = '<i class="fa-solid fa-check" style="color:var(--primary)"></i>';
        setTimeout(()=>el.innerHTML=orig, 1500);
    }).catch(()=>{ prompt('Copy this URL:', url); });
}

// ── 4. FOCUS MODE — filter by folder, hide all chrome ──
let _focusActive = false;
function enterFocusMode(folderId) {
    _focusActive = true;
    const f = S.folders.find(x=>x.id===folderId);
    const bar = document.getElementById('focusModeBar');
    const title = document.getElementById('focusModeTitle');
    if(bar) bar.classList.add('active');
    if(title) title.textContent = '🧠 Focus: ' + (f?f.name:'All');
    // Switch to that folder tab
    switchTab(folderId);
    // On mobile push mainWrap down
    const mw = document.getElementById('mainWrap');
    if(mw && window.innerWidth<=767) mw.style.paddingTop='130px';
    showToast('Focus mode: '+( f?f.name:'All'),'#8b5cf6');
}
function exitFocusMode() {
    _focusActive = false;
    const bar = document.getElementById('focusModeBar');
    if(bar) bar.classList.remove('active');
    const mw = document.getElementById('mainWrap');
    if(mw) mw.style.paddingTop='';
    switchTab('all');
    showToast('Focus mode off','var(--text-dim)');
}

// ── 5. BOOKMARK NOTES — save personal notes on any bookmark ──
function openNotes(id) {
    const l = S.links.find(x=>x.id===id);
    if(!l) return;
    S.editingLink = id;
    // Inline prompt fallback for simplicity
    const note = prompt('📝 Your note for "'+l.title+'":', l.note||'');
    if(note===null) return;
    l.note = note.trim();
    save();
    renderLinks();
    showToast(l.note ? '📝 Note saved!' : 'Note removed','#fbbf24');
}

// ── 6. EXPORT to CSV ──
function exportCSV() {
    const rows = [['Title','URL','Tags','Folder','Favorites','Views','Note']];
    S.links.forEach(l=>{
        const folder = S.folders.find(f=>f.id===l.fId);
        rows.push([
            '"'+(l.title||'').replace(/"/g,'""')+'"',
            '"'+(l.url||'')+'"',
            '"'+(l.tags||[]).join(', ')+'"',
            '"'+(folder?folder.name:'Unsorted')+'"',
            l.fav?'Yes':'No',
            l.views||0,
            '"'+(l.note||'').replace(/"/g,'""')+'"'
        ]);
    });
    const csv = rows.map(r=>r.join(',')).join('\n');
    const blob = new Blob([csv],{type:'text/csv'});
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'WebMark_bookmarks.csv';
    a.click();
    showToast('📊 Exported '+S.links.length+' bookmarks as CSV','var(--primary)');
}

// ── 7. READING LIST mode — mark bookmarks as "read" ──
function toggleRead(id) {
    const l = S.links.find(x=>x.id===id);
    if(!l) return;
    l.read = !l.read;
    save(); renderLinks();
    showToast(l.read?'✅ Marked as read':'↩️ Marked as unread','var(--primary)');
}

// ── 8. RECENTLY VISITED quick tab ──
function showRecentlyVisited() {
    const recent = [...S.links].filter(l=>l.views>0&&!l.archived)
        .sort((a,b)=>(b.lastVisited||0)-(a.lastVisited||0))
        .slice(0,10);
    if(!recent.length){ showToast('No visited bookmarks yet!','#f59e0b'); return; }
    // Switch to a virtual "Last 10 Visits" tab
    S.activeTab = '__recent__';
    S._recentIds = recent.map(l=>l.id);
    // Populate the 3 stat cards
    _updateRecentHeader(recent);
    // Close settings page on mobile
    document.querySelectorAll('.inline-page').forEach(p=>p.classList.remove('active'));
    document.querySelectorAll('.nitem').forEach(n=>n.classList.remove('active'));
    document.getElementById('nav-home')?.classList.add('active');
    renderTabs();
    renderLinks();
    showToast('📅 Last 10 visited bookmarks','#06b6d4');
}

function _updateRecentHeader(recent){
    const hdr = document.getElementById('recentHeader');
    if(!hdr) return;
    const isRecent = S.activeTab === '__recent__';
    hdr.style.display = isRecent ? 'block' : 'none';
    if(!isRecent || !recent) return;
    // Count card
    const cnt = document.getElementById('rh-count');
    if(cnt) cnt.textContent = recent.length;
    // Most visited
    const sorted = [...recent].sort((a,b)=>(b.views||0)-(a.views||0));
    const top = sorted[0];
    const rhTop = document.getElementById('rh-top');
    if(rhTop) rhTop.textContent = top ? (top.title||'—').slice(0,18)+(top.title&&top.title.length>18?'…':'') : '—';
    // Last opened
    const lastLink = recent[0]; // already sorted by lastVisited
    const rhLast = document.getElementById('rh-last');
    if(rhLast && lastLink && lastLink.lastVisited){
        const d = new Date(lastLink.lastVisited);
        rhLast.textContent = d.toLocaleDateString(undefined,{month:'short',day:'numeric',hour:'2-digit',minute:'2-digit'});
    }
}

// Update quick stats whenever links render
const _origRenderLinks = renderLinks;
renderLinks = function() {
    _origRenderLinks();
};

// ── 9. PATCH openLink to track lastVisited ──
const _origOpenLink = openLink;
openLink = function(url) {
    const l = S.links.find(x=>x.url===url);
    if(l){ l.lastVisited=Date.now(); l.views=(l.views||0)+1; save(); }
    _origOpenLink(url);
};

// ── INIT new features ──
document.addEventListener('DOMContentLoaded', async ()=>{
    await wmStartup;
    // Update Delete Password label
    updateDelPassLabel();
    // Update source button state on load
    updateSourceChecks();

    // Mandatory signup — show ONLY on first ever visit to this device
    // ly_welcomed is set the MOMENT the overlay is first shown, so it never shows twice
    if(!wmStorage.getItem('ly_welcomed')){
        showSignupOverlay();
    }
});

function showSignupOverlay(){
    const overlay = document.getElementById('signupOverlay');
    if(!overlay) return;
    // Mark as seen IMMEDIATELY — so even a hard refresh won't show again
    wmStorage.setItem('ly_welcomed', '1');
    updateSignupFormLang(S.lang);
    overlay.style.display = 'flex';
}

function updateSignupFormLang(l){
    const SIGNUP_LABELS = {
        en: { sub:'Set an optional local deletion lock.<br>No cloud account is created; bookmarks are not encrypted.', uLabel:'USERNAME', uPlaceholder:'Choose a username', pLabel:'PASSWORD', pPlaceholder:'Min 4 characters', cLabel:'CONFIRM PASSWORD', cPlaceholder:'Confirm password', btn:'&#8594; Get Started', skip:'Skip for now (not recommended)' },
        it: { sub:'Crea il tuo account per iniziare.<br>Questo protegge i segnalibri da eliminazioni accidentali.', uLabel:'NOME UTENTE', uPlaceholder:'Scegli un nome utente', pLabel:'PASSWORD', pPlaceholder:'Min 4 caratteri', cLabel:'CONFERMA PASSWORD', cPlaceholder:'Conferma la password', btn:'&#8594; Inizia', skip:'Salta per ora (non consigliato)' },
        fr: { sub:'Cr\u00e9ez votre compte pour commencer.<br>Cela prot\u00e8ge vos favoris des suppressions accidentelles.', uLabel:"NOM D'UTILISATEUR", uPlaceholder:"Choisissez un nom d'utilisateur", pLabel:'MOT DE PASSE', pPlaceholder:'Min 4 caract\u00e8res', cLabel:'CONFIRMER', cPlaceholder:'Confirmez le mot de passe', btn:'&#8594; Commencer', skip:"Ignorer pour l'instant (d\u00e9conseill\u00e9)" },
        es: { sub:'Crea tu cuenta para comenzar.<br>Esto protege tus marcadores de eliminaciones accidentales.', uLabel:'USUARIO', uPlaceholder:'Elige un nombre de usuario', pLabel:'CONTRASE\u00d1A', pPlaceholder:'M\u00edn 4 caracteres', cLabel:'CONFIRMAR CONTRASE\u00d1A', cPlaceholder:'Confirma la contrase\u00f1a', btn:'&#8594; Empezar', skip:'Omitir por ahora (no recomendado)' },
        ar: { sub:'\u0623\u0646\u0634\u0626 \u062d\u0633\u0627\u0628\u0643 \u0644\u0644\u0628\u062f\u0621.<br>\u0647\u0630\u0627 \u064a\u062d\u0645\u064a \u0625\u0634\u0627\u0631\u0627\u062a\u0643 \u0645\u0646 \u0627\u0644\u062d\u0630\u0641 \u0627\u0644\u0639\u0631\u0636\u064a.', uLabel:'\u0627\u0633\u0645 \u0627\u0644\u0645\u0633\u062a\u062e\u062f\u0645', uPlaceholder:'\u0627\u062e\u062a\u0631 \u0627\u0633\u0645 \u0645\u0633\u062a\u062e\u062f\u0645', pLabel:'\u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631', pPlaceholder:'4 \u0623\u062d\u0631\u0641 \u0639\u0644\u0649 \u0627\u0644\u0623\u0642\u0644', cLabel:'\u062a\u0623\u0643\u064a\u062f \u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631', cPlaceholder:'\u0623\u0643\u062f \u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631', btn:'\u0627\u0628\u062f\u0623 \u2190', skip:'\u062a\u062e\u0637\u064a \u0627\u0644\u0622\u0646 (\u063a\u064a\u0631 \u0645\u0633\u062a\u062d\u0633\u0646)' },
    };
    const t = SIGNUP_LABELS[l] || SIGNUP_LABELS.en;
    const overlay = document.getElementById('signupOverlay');
    if(!overlay || overlay.style.display === 'none') return;
    // Update subtitle
    const sub = document.getElementById('signup-sub');
    if(sub) sub.innerHTML = t.sub;
    // Update labels
    const lblU = document.getElementById('signup-lbl-u');
    const lblP = document.getElementById('signup-lbl-p');
    const lblC = document.getElementById('signup-lbl-c');
    if(lblU) lblU.textContent = t.uLabel;
    if(lblP) lblP.textContent = t.pLabel;
    if(lblC) lblC.textContent = t.cLabel;
    // Update placeholders
    const uInp = document.getElementById('signup-username');
    const pInp = document.getElementById('signup-pass');
    const cInp = document.getElementById('signup-confirm');
    if(uInp) uInp.placeholder = t.uPlaceholder;
    if(pInp) pInp.placeholder = t.pPlaceholder;
    if(cInp) cInp.placeholder = t.cPlaceholder;
    // Update button
    const btn = document.getElementById('signup-submit-btn');
    if(btn) btn.innerHTML = t.btn;
    // Update skip
    const skipBtn = document.getElementById('signup-skip-btn');
    if(skipBtn) skipBtn.textContent = t.skip;
    // RTL for Arabic
    const s2 = document.getElementById('signup-form');
    if(s2) s2.style.direction = l === 'ar' ? 'rtl' : 'ltr';
}

function doSignup(){
    const username = (document.getElementById('signup-username')?.value || '').trim();
    const pass     = document.getElementById('signup-pass')?.value || '';
    const confirm  = document.getElementById('signup-confirm')?.value || '';
    const err      = document.getElementById('signup-err');

    if(!username || username.length < 2){
        err.textContent = 'Username must be at least 2 characters.';
        err.style.display = 'block';
        document.getElementById('signup-username').style.borderColor = '#ef4444';
        document.getElementById('signup-username').focus();
        return;
    }
    if(!pass || pass.length < 4){
        err.textContent = 'Password must be at least 4 characters.';
        err.style.display = 'block';
        document.getElementById('signup-pass').focus();
        return;
    }
    if(pass !== confirm){
        err.textContent = 'Passwords do not match.';
        err.style.display = 'block';
        document.getElementById('signup-confirm').value = '';
        document.getElementById('signup-confirm').focus();
        return;
    }

    wmStorage.setItem('ly_deluser', wmEncode(username));
    wmStorage.setItem('ly_delpass', wmEncode(pass));
    wmStorage.setItem('ly_welcomed', '1');

    const overlay = document.getElementById('signupOverlay');
    if(overlay) overlay.style.display = 'none';

    updateDelPassLabel && updateDelPassLabel();
    showToast('Welcome, ' + username + '! Local deletion lock saved ✓', 'var(--primary)');
}

function skipSignup(){
    wmStorage.setItem('ly_welcomed', '1');
    const overlay = document.getElementById('signupOverlay');
    if(overlay) overlay.style.display = 'none';
    showToast('You can set a password anytime in Settings → Danger Zone', '#f59e0b');
}

function updateDelPassLabel(){
    const hasPass = !!getDeletePass();
    const labelDesk = document.getElementById('delPassActionLabel');
    const labelMob  = document.getElementById('sp-delPassActionLabel');
    const text = hasPass ? 'Change Username & Password' : 'Create Username & Password';
    if(labelDesk) labelDesk.textContent = text;
    if(labelMob)  labelMob.textContent  = text;
}

function updateSourceChecks(){
    const mode = S._sourceMode || 'personal';
    const option = sourceOptions().find(item=>item.key===mode) || sourceOptions()[1];
    const icon = document.getElementById('sourceIcon');
    const button = document.getElementById('sourceBtn');
    const menu = document.getElementById('sourceDD');
    const label = document.getElementById('sourceLabel');
    if(label) label.textContent=option.label;
    if(icon) { icon.className=option.icon; icon.style.color=option.color; }
    if(button) {
        const title=(sourceLabels[S.lang] || sourceLabels.en)[0] + ' · ' + option.label;
        button.title=title;
        button.setAttribute('aria-label',title);
        button.setAttribute('aria-expanded',String(menu?.classList.contains('open') || false));
        button.style.borderColor=mode==='all'?'var(--border)':option.color;
    }
}

// ── FONT SETTINGS ──
function setAppFont(fontName){
    const fontMap = {
        'Inter':       "'Inter',system-ui,sans-serif",
        'Roboto':      "'Roboto',sans-serif",
        'Poppins':     "'Poppins',sans-serif",
        'Lato':        "'Lato',sans-serif",
        'Nunito':      "'Nunito',sans-serif",
        'Georgia':     "Georgia,'Times New Roman',serif",
        'Merriweather':"'Merriweather',serif",
        'Courier':     "'Courier New',Courier,monospace",
        'System':      "system-ui,-apple-system,sans-serif"
    };
    const fontVal = fontMap[fontName] || fontMap['Inter'];
    document.documentElement.style.setProperty('--app-font', fontVal);
    wmStorage.setItem('ly_font', fontName);
    // Update pill active state
    document.querySelectorAll('.font-pill,[data-font]').forEach(p=>{
        p.classList.toggle('active', p.dataset.font===fontName);
    });
    // Sync select dropdowns
    document.querySelectorAll('#sp-fontSelect,#desk-fontSelect').forEach(s=>{ if(s) s.value=fontName; });
    // Keep app name always in Inter regardless of font choice
    document.querySelectorAll('.app-name-protected').forEach(el=>{
        el.style.fontFamily = "'Inter',system-ui,sans-serif";
    });
}
function adjustFontSize(delta){
    const cur = parseInt(wmStorage.getItem('ly_fontSize')||'14');
    const next = Math.min(20, Math.max(11, cur + delta));
    document.documentElement.style.setProperty('--app-font-size', next+'px');
    wmStorage.setItem('ly_fontSize', next);
    const lbl = document.getElementById('sp-fontSizeLabel');
    if(lbl) lbl.textContent = next+'px';
    const lbl2 = document.getElementById('desk-fontSizeLabel');
    if(lbl2) lbl2.textContent = next+'px';
}
const FONT_SIZES = { small:'12px', medium:'14px', large:'17px' };
function setFontSize(size){
    const px = FONT_SIZES[size] || '14px';
    const pxNum = parseInt(px);
    // Apply to both the CSS variable AND the html root so all elements scale
    document.documentElement.style.setProperty('--app-font-size', px);
    // Scale all explicit font sizes by patching a style tag
    applyFontSizeScale(pxNum);
    wmStorage.setItem('ly_fontSizeName', size);
    wmStorage.setItem('ly_fontSize', pxNum);
    document.querySelectorAll('[data-size]').forEach(b=>b.classList.toggle('active', b.dataset.size===size));
    const lbl=document.getElementById('sp-fontSizeLabel'); if(lbl) lbl.textContent=px;
    const lbl2=document.getElementById('desk-fontSizeLabel'); if(lbl2) lbl2.textContent=px;
    document.querySelectorAll('#sp-fontSizeSelect,#desk-fontSizeSelect').forEach(s=>{ if(s) s.value=size; });
}
function applyFontSizeScale(pxNum){
    // Base is 14px. Scale = pxNum/14
    const scale = pxNum / 14;
    let el = document.getElementById('_fontScaleStyle');
    if(!el){ el = document.createElement('style'); el.id='_fontScaleStyle'; document.head.appendChild(el); }
    if(scale === 1){
        el.textContent = '';
        return;
    }
    // Override body font-size and let inheritance do the work where possible
    // Also scale key text elements explicitly
    el.textContent = `
        body { font-size: ${pxNum}px !important; }
        .link-card, .linfo h4, .linfo p, .badge, .chip, .erow-lbl span,
        .vopt, .mhdr .mtitle, .field label, .frow-name, .fm-name,
        .nitem, .dnl, .greeting h2, .greeting p,
        .stat-label, .sett-section-hdr, .btn-p, .btn-s, .btn-d,
        input[type=text], input[type=url], select, textarea,
        .bact span, .card-act, .mtitle { font-size: calc(1em * ${scale}) !important; }
        .linfo h4 { font-size: calc(15px * ${scale}) !important; }
        .linfo p { font-size: calc(12px * ${scale}) !important; }
        .badge { font-size: calc(11px * ${scale}) !important; }
        .chip { font-size: calc(13px * ${scale}) !important; }
        .erow-lbl span { font-size: calc(13px * ${scale}) !important; }
        .vopt { font-size: calc(14px * ${scale}) !important; }
        .mtitle { font-size: calc(18px * ${scale}) !important; }
        .nitem { font-size: calc(10px * ${scale}) !important; }
        .sett-section-hdr { font-size: calc(10px * ${scale}) !important; }
        .btn-p, .btn-s, .btn-d { font-size: calc(15px * ${scale}) !important; }
    `;
}
function applyFontSettings(){
    const font = wmStorage.getItem('ly_font') || 'Inter';
    // Ensure medium is set as default if never configured
    if(!wmStorage.getItem('ly_fontSizeName')){
        wmStorage.setItem('ly_fontSizeName','medium');
        wmStorage.setItem('ly_fontSize','14');
    }
    const sizeName = wmStorage.getItem('ly_fontSizeName') || 'medium';
    const size = parseInt(wmStorage.getItem('ly_fontSize')||'14');
    const openMode = wmStorage.getItem('ly_openLinkMode') || 'newtab';
    // On first use, save defaults so selects show correctly
    if(!wmStorage.getItem('ly_font')) wmStorage.setItem('ly_font','Inter');
    if(!wmStorage.getItem('ly_fontSizeName')) wmStorage.setItem('ly_fontSizeName','medium');
    if(!wmStorage.getItem('ly_fontSize')) wmStorage.setItem('ly_fontSize','14');
    if(font) setAppFont(font);
    document.documentElement.style.setProperty('--app-font-size', size+'px');
    applyFontSizeScale(size);
    setTimeout(()=>{
        document.querySelectorAll('[data-size]').forEach(b=>b.classList.toggle('active', b.dataset.size===sizeName));
        document.querySelectorAll('#sp-fontSelect,#desk-fontSelect').forEach(s=>{ if(s) s.value=font; });
        document.querySelectorAll('#sp-fontSizeSelect,#desk-fontSizeSelect').forEach(s=>{ if(s) s.value=sizeName; });
        document.querySelectorAll('#sp-openLinkSelect,#desk-openLinkSelect').forEach(s=>{ if(s) s.value=openMode; });
    }, 100);
}
// Progressive enhancement: these overrides retain the original UI and data keys.
function save(){
 const snapshot=JSON.stringify({format:'webmark-v4',f:S.folders,l:S.links,trash:S.trash||[]});
 wmStorage.setItem('ly_state_v4',snapshot);
 for(const key of ['ly_f','ly_l','ly_trash'])wmStorage.removeItem(key);
 // Single authoritative snapshot avoids partially saved parallel collections.
 try{wmStorage.setItem('ly_view',S.view)}catch{}
}
async function shareCard(url,title){try{if(navigator.share){await navigator.share({title,url});return}await wmCopy(url);showToast(T('copied')==='copied'?'Link copied':T('copied'))}catch(e){if(e.name!=='AbortError')prompt(S.lang==='ar'?'انسخ الرابط:':'Copy URL:',url)}}
function shareCurrent(){const l=S.links.find(x=>x.id===S.editingLink);if(l)return shareCard(l.url,l.title)}
async function copyUrl(url,el){try{await wmCopy(url);if(el){const original=el.innerHTML;el.innerHTML='<i class="fa-solid fa-check"></i>';setTimeout(()=>el.innerHTML=original,1500)}else showToast('Copied ✓')}catch{prompt('Copy URL:',url)}}
function openLinkMode(raw,mode){const url=wmURL(raw);if(!url){showToast(S.lang==='ar'?'الرابط غير صالح':'Invalid HTTP/HTTPS URL','#ef4444');return}document.querySelectorAll('.open-dd.show').forEach(x=>x.classList.remove('show'));if(mode==='copy'||mode==='incognito'){wmCopy(url).then(()=>showToast(mode==='incognito'?'URL copied. Paste it in a private window.':'Copied ✓')).catch(()=>prompt('Copy URL:',url));return}if(mode==='current'){window.location.assign(url);return}const a=document.createElement('a');a.href=url;a.target='_blank';a.rel='noopener noreferrer';document.body.append(a);a.click();a.remove()}
function surpriseMe(){const pool=S.links.filter(l=>!l.archived);if(!pool.length)return showToast('No bookmarks yet!');openLink(pool[Math.floor(Math.random()*pool.length)].url)}
function deleteCurrent(){const id=S.editingLink;deleteLink(id);closeModal('editDetailModal')}
function exportData(){wmDownload('WebMark_Backup.json',JSON.stringify({format:'webmark-v4',f:S.folders,l:S.links,trash:S.trash||[],exportedAt:new Date().toISOString()},null,2));document.getElementById('shareModal')?.classList.remove('active')}
function wmMerge(raw){const data=wmNormalize(raw),before=S.links.length;const folders=S.folders.map(f=>({...f})),links=S.links.map(l=>({...l}));const map=new Map(),taken=new Set(folders.map(f=>f.id));for(const f of data.f){const existing=folders.find(x=>x.name===f.name&&x._importBrowser===f._importBrowser);if(existing){map.set(f.id,existing.id);continue}let id=f.id;while(taken.has(id))id=wmId();taken.add(id);map.set(f.id,id);folders.push({...f,id})}const sourceFolders=new Map(folders.map(folder=>[folder.id,folder])),incomingFolders=new Map(data.f.map(folder=>[folder.id,folder]));const urls=new Map(links.map(l=>[bookmarkSourceKey(l,sourceFolders),l])),ids=new Set(links.map(l=>l.id));for(const l of data.l){const source=bookmarkSourceKey(l,incomingFolders);const existing=urls.get(source);if(existing){const importedDate=WebMarkSyncCore.bookmarkDate(l),currentDate=WebMarkSyncCore.bookmarkDate(existing);if(importedDate!==null&&(currentDate===null||importedDate<currentDate))existing.addedAt=importedDate;continue}let id=l.id;while(ids.has(id))id=wmId();ids.add(id);const entry={...l,id,fId:map.get(l.fId)??null};urls.set(source,entry);links.push(entry)}const old={f:S.folders,l:S.links,trash:S.trash};S.folders=folders;S.links=links;const trashIds=new Set((S.trash||[]).map(l=>l.id));S.trash=[...(S.trash||[])];for(const l of data.trash){const source=bookmarkSourceKey(l,incomingFolders);if(urls.has(source)||S.trash.some(x=>bookmarkSourceKey(x,sourceFolders)===source&&x.deletedAt===l.deletedAt))continue;let id=l.id;while(ids.has(id)||trashIds.has(id))id=wmId();trashIds.add(id);S.trash.push({...l,id,fId:map.get(l.fId)??null})}try{save()}catch(e){S.folders=old.f;S.links=old.l;S.trash=old.trash;throw e}init();return links.length-before}
async function importData(e){const file=e.target.files?.[0];if(!file)return;try{if(file.size>30*1024*1024)throw Error('Backup exceeds 30 MB');const raw=JSON.parse(await file.text());const n=wmMerge(raw);showToast((S.lang==='ar'?'تم استيراد روابط جديدة: ':'New bookmarks imported: ')+n)}catch(err){alert((S.lang==='ar'?'تعذّر الاستيراد: ':'Import failed: ')+err.message)}finally{e.target.value=''}}
function wmTransferImport(){const input=document.createElement('input');input.type='file';input.accept='.json,application/json';input.onchange=importData;input.click()}
function openSyncModal(){const modal=document.getElementById('syncModal');const content=modal.querySelector('.mc');content.innerHTML=`<div class="mhdr"><h3>${S.lang==='ar'?'نقل البيانات بين أجهزتك':'Transfer between your devices'}</h3><button class="mback-btn wm-red-close" data-wm-click="162">×</button></div><p style="line-height:1.8;margin-bottom:18px">${S.lang==='ar'?'بياناتك محفوظة في هذا المتصفح فقط. صدّر نسخة JSON، وانقلها إلى الجهاز الآخر ثم استوردها. الاستيراد يدمج الروابط ولا يمسح الموجودة. هذه نسخة محلية، دون حساب سحابي أو مزامنة تلقائية.':'Data stays in this browser. Export a JSON backup, move it to your other device, then import it. Imports merge bookmarks without erasing existing data. No cloud account or automatic sync is configured.'}</p><button class="btn-p" data-wm-click="225">↓ ${S.lang==='ar'?'تصدير نسخة احتياطية':'Export backup'}</button><button class="btn-s" data-wm-click="226">↑ ${S.lang==='ar'?'استيراد نسخة احتياطية':'Import backup'}</button>`;openModal('syncModal')}
function syncUpload(){exportData()}function syncDownload(){wmTransferImport()}
async function summarizeWithAI(){showToast(S.lang==='ar'?'التلخيص يحتاج خدمة ذكاء اصطناعي متصلة؛ لم تُضبط في هذا التطبيق.':'AI summarization requires a configured server.','#f59e0b',5000)}
function rewriteAI(){summarizeWithAI()}
let wmDetails = null;
let wmDetailsTimer;
const wmDetailFields = {title:'lTitle', desc:'lDesc',tags:'lTags'};

function resetWebMeta() {
    clearTimeout(wmDetailsTimer);
    wmLogoRevision++;
    if (!wmDetails?.saved) wmDetails?.controller?.abort();
    wmDetails = null;
    document.getElementById('linkMetaStatus').textContent = '';
}

function queueWebMeta(event) {
    hideDupWarning();
    clearTimeout(wmDetailsTimer);
    wmDetailsTimer = setTimeout(fetchWebMeta, event?.inputType === 'insertFromPaste' ? 0 : 300);
}

function shortWebDescription(text) {
    const chars = Array.from(text.replace(/\s+/g, ' ').trim());
    if (chars.length <= 160) return chars.join('');
    const prefix = chars.slice(0, 159).join('');
    const boundary = prefix.lastIndexOf(' ');
    return (boundary > 118 ? prefix.slice(0, boundary) : prefix) + '…';
}
function fallbackWebMeta(url) {
    const page = new URL(url);
    const host = page.hostname.replace(/^www\./, '');
    const [owner, repo] = page.pathname.split('/').filter(Boolean);
    if (host === 'github.com' && owner && repo) {
        return {title:owner + '/' + repo, desc:'GitHub · ' + owner + '/' + repo};
    }
    return {title:host, desc:host + (page.pathname === '/' ? '' : page.pathname)};
}

function showWebMeta(details, data) {
    for (const [key, id] of Object.entries(wmDetailFields)) {
        const field = document.getElementById(id);
        if (data[key] && (!field.value || field.value === details.generated[key])) {
            field.value = data[key];
            details.generated[key] = data[key];
        }
    }
    if (data.logo && ((S.tempLogo===details.initialLogo&&!S.tempLogo)||S.tempLogo===details.generatedLogo) && details.logoRevision===wmLogoRevision) {
        S.tempLogo = data.logo;
        details.generatedLogo = data.logo;
        const image=document.createElement('img');image.src=data.logo;image.alt='';image.referrerPolicy='no-referrer';
        image.addEventListener('error',()=>{const fallback=WebMarkMetadata.favicon(details.url);if(image.src!==fallback){image.src=fallback;if(S.tempLogo===data.logo){S.tempLogo=fallback;details.generatedLogo=fallback;}if(details.saved?.auto.logo&&details.saved.bookmark.logo===data.logo){details.saved.bookmark.logo=fallback;save();renderLinks();}}},{once:true});
        document.getElementById('logoPrev').replaceChildren(image);
    }
}

let wmLogoRevision = 0;
function fetchWebMeta(force = false) {
    clearTimeout(wmDetailsTimer);
    if(!document.getElementById('addModal').classList.contains('active'))return null;
    const url=wmURL(document.getElementById('lUrl').value);if(!url){resetWebMeta();return null;}
    if(!force&&wmDetails?.url===url)return wmDetails;
    const generated={...wmDetails?.generated};
    if(force){wmLogoRevision++;S.tempLogo=null;}
    else if(wmDetails?.url!==url&&wmDetails?.generatedLogo===S.tempLogo)S.tempLogo=null;
    if(!wmDetails?.saved)wmDetails?.controller?.abort();
    const details={url,generated,initialLogo:S.tempLogo,logoRevision:wmLogoRevision};wmDetails=details;
    const fallback=fallbackWebMeta(url),host=new URL(url).hostname;
    const publicHost=/^(?:[a-z0-9-]+\.)+[a-z][a-z0-9-]*$/i.test(host)&&!/[.](local|localhost|internal|test|invalid|lan|home)$/i.test(host);
    showWebMeta(details,{title:fallback.title,logo:publicHost?WebMarkMetadata.favicon(url):'',tags:WebMarkCategories.tags(url).join(', ')});
    const status=document.getElementById('linkMetaStatus');status.textContent='';
    if(!navigator.onLine||!publicHost)return details;
    const page=new URL(url),video=page.searchParams.get('v');if(page.username||page.password||page.port)return details;
    page.search='';page.hash='';if(/^(www\.)?youtube\.com$/i.test(host)&&/^[\w-]{11}$/.test(video||''))page.searchParams.set('v',video);
    const controller=new AbortController();details.controller=controller;status.textContent=T('linkMetaLoading');
    WebMarkMetadata.fetch(page.href,controller.signal).then(data=>{
        if(controller.signal.aborted)return;
        const found={title:data.title,desc:data.desc?shortWebDescription(data.desc):'',logo:wmImage(data.logo),tags:WebMarkCategories.tags(url,data.title,data.desc,data.keywords).join(', ')};
        if(details.saved){
            const saved=details.saved,bookmark=S.links.find(link=>link===saved.bookmark&&link.url===url);if(!bookmark)return;
            const changes={};for(const key of ['title','desc','logo','tags']){const value=key==='tags'?found.tags.split(',').map(t=>t.trim()).filter(Boolean):found[key];if(value&&saved.auto[key]&&JSON.stringify(bookmark[key])===JSON.stringify(saved.values[key]))changes[key]=value;}
            if(Object.keys(changes).length){Object.assign(bookmark,changes);save();renderLinks();}return;
        }
        if(wmDetails===details&&wmURL(document.getElementById('lUrl').value)===url&&document.getElementById('addModal').classList.contains('active')){
            showWebMeta(details,found);status.textContent=data.title||data.desc?(S.lang==='ar'?'تم جلب معلومات الصفحة والوسوم':'Page details and tags loaded'):(S.lang==='ar'?'تعذر جلب العنوان والوصف من الموقع. يمكنك إدخالهما يدوياً.':'The site did not provide accessible details. Enter the title and description manually.');
        }
    }).catch(()=>{if(wmDetails===details)status.textContent=S.lang==='ar'?'تعذر جلب معلومات الموقع؛ يمكنك إدخالها يدوياً.':'Could not fetch this site. You can enter details manually.';});
    return details;
}

function refetchIcon() { fetchWebMeta(true); }

function cleanBookmarkUrl() {
    const input = document.getElementById('lUrl');
    const url = wmURL(input.value);
    if (!url) return;
    const page = new URL(url);
    const parameters = page.search.slice(1).split('&');
    const kept = parameters.filter(part => !/^(?:utm_[a-z0-9_]+|fbclid|gclid|msclkid|dclid|igshid|mc_cid|mc_eid)$/i.test(part.split('=')[0]));
    if (kept.length === parameters.length) {
        showToast(T('linkNoTracking'));
        return;
    }
    page.search = kept.join('&');
    input.value = page.href;
    queueWebMeta();
    showToast(T('linkTrackingRemoved'));
}
async function wmReadImage(file){if(!file)return null;if(!/^image\/(png|jpeg|webp|gif|avif)$/.test(file.type))throw Error('Use PNG, JPG, WebP, GIF or AVIF');if(file.size>8*1024*1024)throw Error('Maximum image size: 8 MB');const data=await new Promise((resolve,reject)=>{let reader=new FileReader();reader.onload=()=>resolve(reader.result);reader.onerror=reject;reader.readAsDataURL(file)});const img=new Image();img.src=data;await img.decode();const canvas=document.createElement('canvas'),scale=Math.min(1,256/Math.max(img.width,img.height));canvas.width=Math.max(1,Math.round(img.width*scale));canvas.height=Math.max(1,Math.round(img.height*scale));canvas.getContext('2d').drawImage(img,0,0,canvas.width,canvas.height);return canvas.toDataURL('image/png')}
async function handleLogoUpload(e){const revision=++wmLogoRevision;const inputUrl=document.getElementById('lUrl').value;try{let data=await wmReadImage(e.target.files?.[0]);if(!data||revision!==wmLogoRevision||inputUrl!==document.getElementById('lUrl').value||!document.getElementById('addModal').classList.contains('active'))return;S.tempLogo=data;document.getElementById('logoPrev').innerHTML='<img src="'+data+'" alt="">'}catch(err){showToast(err.message,'#ef4444')}finally{e.target.value=''}}
async function handleEditLogoUpload(e){try{const id=S.editingLink,data=await wmReadImage(e.target.files?.[0]);if(!data||id!==S.editingLink)return;const l=S.links.find(x=>x.id===id);if(l){l.logo=data;save();markChanged();renderLinks();document.getElementById('dtLogo').innerHTML='<img src="'+data+'" alt="">'}}catch(err){showToast(err.message,'#ef4444')}finally{e.target.value=''}}
const wmRemTimers=new Map();
function scheduleReminder(l){if(!l?.reminder||l.reminder<=Date.now())return;clearTimeout(wmRemTimers.get(l.id));const remaining=l.reminder-Date.now();wmRemTimers.set(l.id,setTimeout(async()=>{if(!S.links.includes(l)||!l.reminder)return;if(l.reminder>Date.now()){scheduleReminder(l);return}l.reminder=0;save();showToast('⏰ '+l.title,'var(--primary)',12000);try{if('Notification'in window&&Notification.permission==='granted'){const reg=await navigator.serviceWorker?.getRegistration();if(reg)await reg.showNotification('WebMark',{body:l.title,tag:'wm-'+l.id});else new Notification('WebMark',{body:l.title})}}catch{}},Math.min(remaining,2147483647)))}
function initReminders(){for(const [id,t]of wmRemTimers){clearTimeout(t)}wmRemTimers.clear();S.links.forEach(scheduleReminder)}
const wmSaveReminderOriginal=saveReminder;saveReminder=function(){const d=new Date(_remState.year,_remState.month,_remState.day,_remState.hour,_remState.min);if(d.getTime()<=Date.now())return showToast(S.lang==='ar'?'اختر موعداً في المستقبل':'Choose a future time','#f59e0b');wmSaveReminderOriginal();showToast(S.lang==='ar'?'التذكير يعمل أثناء فتح التطبيق؛ لا يُضمن بعد إغلاقه.':'Reminders run while the app is open; delivery after closing is not guaranteed.','#f59e0b',6000)};
function wmLayout(){let mobile=matchMedia('(max-width:767px)').matches;let top=(mobile?document.querySelector('.header'):document.querySelector('.desktop-nav'))?.getBoundingClientRect().bottom||0;let bottom=mobile?(document.querySelector('.bnav')?.getBoundingClientRect().height||62):0;document.documentElement.style.setProperty('--wm-top',Math.ceil(top)+'px');document.documentElement.style.setProperty('--wm-bottom',Math.ceil(bottom)+'px');document.documentElement.style.setProperty('--wm-height',(window.visualViewport?.height||innerHeight)+'px')}
let wmInstallEvent=null;window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();wmInstallEvent=e;document.querySelectorAll('.wm-install').forEach(b=>b.hidden=false)});
async function wmInstall(){if(wmInstallEvent){await wmInstallEvent.prompt();wmInstallEvent=null;return}alert(S.lang==='ar'?'Android: افتح الرابط في Chrome واختر «تثبيت التطبيق» أو «إضافة إلى الشاشة الرئيسية».\nWindows / Mac: من قائمة Chrome أو Edge اختر تثبيت التطبيق.\nMac Safari: ملف ← إضافة إلى Dock (إن كان متاحاً).\nللتثبيت والعمل دون اتصال استخدم رابط HTTPS، وليس ملفاً مرفقاً.':'Android: Chrome menu → Install app / Add to Home screen.\nWindows / Mac: Chrome or Edge menu → Install app.\nMac Safari: File → Add to Dock, when supported.\nInstallation and offline reopening require the HTTPS version.')}
function wmReady(){
 if(!wmStorage.persistent){let warning=document.createElement('div');warning.textContent='التخزين غير متاح: التغييرات مؤقتة. صدّر نسخة قبل الإغلاق. / Storage unavailable: export before closing.';warning.style.cssText='position:fixed;bottom:70px;left:10px;right:10px;z-index:11000;background:#713f12;color:white;padding:12px;border-radius:12px';document.body.append(warning)}

 const updateLanguage=()=>{document.documentElement.lang=S.lang;document.documentElement.dir=S.lang==='ar'?'rtl':'ltr'};updateLanguage();
 const original=window.setLang;window.setLang=function(l){original(l);updateLanguage();requestAnimationFrame(wmLayout)};
 document.querySelectorAll('input[type="url"]').forEach(x=>{x.dir='ltr';x.autocapitalize='off';x.spellcheck=false});
 document.addEventListener('keydown',e=>{if(e.key==='Escape'){const m=[...document.querySelectorAll('.modal.active')].pop();if(m)closeModal(m.id);else closePage()}});
 wmLayout();if(typeof ResizeObserver==='function'){const obs=new ResizeObserver(wmLayout);document.querySelectorAll('.header,.desktop-nav,.bnav').forEach(el=>obs.observe(el))}
 window.addEventListener('resize',wmLayout);window.visualViewport?.addEventListener('resize',wmLayout);
}
document.addEventListener('DOMContentLoaded',wmReady);

applyFontSettings();


const wmStartup=wmStorage.ready.then(()=>{
 S.lang=wmStorage.getItem('ly_lang')||S.lang;
 const saved=wmInitial();
 S.folders=saved.f;S.links=saved.l;S.trash=saved.trash;
 const storedSource=wmStorage.getItem('ly_sourceMode');
 S._sourceMode=sourceOptions().some(option=>option.key===storedSource)?storedSource:'personal';
 try{init()}finally{
  document.body.inert=false;
  document.body.removeAttribute('aria-busy');
 }
});

// ── TWEMOJI: Render flag emojis as images on all browsers (fixes Chrome on Windows/Android/iOS) ──
function applyTwemoji(){
    if(typeof twemoji==='undefined') return;
    // Only parse flag-containing elements to keep it fast
    const targets = [
        document.getElementById('settLangCurrent'),
        ...document.querySelectorAll('#langList .frow-icon, .lang-modal-flag')
    ].filter(Boolean);
    targets.forEach(el => twemoji.parse(el, {
        folder:'svg', ext:'.svg',
        base:'https://cdnjs.cloudflare.com/ajax/libs/twemoji/14.0.2/'
    }));
    // Also parse the language picker modal
    const lm = document.getElementById('langModal');
    if(lm) twemoji.parse(lm, {folder:'svg',ext:'.svg',base:'https://cdnjs.cloudflare.com/ajax/libs/twemoji/14.0.2/'});
}
setTimeout(applyTwemoji, 200);
// Patch setLang to re-apply twemoji after language change AND update mobile flag
const _setLangOrig = setLang;
window.setLang = function(l){
    _setLangOrig(l);
    // Update signup form placeholder text based on selected language
    updateSignupFormLang(l);
    // Always update mobile settings language label immediately
    const spLb = document.getElementById('sp-langLabel');
    if(spLb) spLb.innerHTML = getFlagImg(l) + ' ' + (LANG_LABELS[l] || l);
    // If the inline settings page is visible, re-sync it fully
    if(document.getElementById('page-settings') && 
       document.getElementById('page-settings').classList.contains('active')){
        if(typeof syncSettingsPage === 'function') syncSettingsPage();
    }
    setTimeout(applyTwemoji, 100);
};

